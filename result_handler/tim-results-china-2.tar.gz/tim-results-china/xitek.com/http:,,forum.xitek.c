[0712/071655.038525:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/071655.038907:INFO:switcher_clone.cc(787)] backtrace rip is 7fa49d5ef891
[0712/071656.082157:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/071656.085022:INFO:switcher_clone.cc(787)] backtrace rip is 7f5bd2872891
[1:1:0712/071656.109094:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/071656.109415:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/071656.120757:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[99093:99093:0712/071657.502938:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/071657.585380:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/071657.585753:INFO:switcher_clone.cc(787)] backtrace rip is 7f9e48d02891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/19eabb1a-09fa-4926-afaa-b5c3ac29085b
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[99127:99127:0712/071657.831294:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=99127
[99138:99138:0712/071657.831756:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=99138
[99093:99093:0712/071658.078545:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[99093:99124:0712/071658.079286:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/071658.079498:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/071658.079927:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/071658.081064:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/071658.081362:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/071658.088295:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x35fa832c, 1
[1:1:0712/071658.088769:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xdf82e49, 0
[1:1:0712/071658.089031:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15909e44, 3
[1:1:0712/071658.089293:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3eae601d, 2
[1:1:0712/071658.089590:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 492efffffff80d 2cffffff83fffffffa35 1d60ffffffae3e 44ffffff9effffff9015 , 10104, 4
[1:1:0712/071658.090954:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99093:99124:0712/071658.091333:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGI.�,��5`�>D��霊=
[99093:99124:0712/071658.091464:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is I.�,��5`�>D��X�霊=
[1:1:0712/071658.091303:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5bd0aad0a0, 3
[1:1:0712/071658.091614:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5bd0c38080, 2
[99093:99124:0712/071658.092049:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/071658.091919:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5bba8fbd20, -2
[99093:99124:0712/071658.092186:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99146, 4, 492ef80d 2c83fa35 1d60ae3e 449e9015 
[1:1:0712/071658.113837:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/071658.114677:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3eae601d
[1:1:0712/071658.115595:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3eae601d
[1:1:0712/071658.117246:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3eae601d
[1:1:0712/071658.118701:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.118951:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.119178:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.119423:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.120154:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3eae601d
[1:1:0712/071658.120503:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5bd28727ba
[1:1:0712/071658.120681:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5bd2869def, 7f5bd287277a, 7f5bd28740cf
[1:1:0712/071658.126388:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3eae601d
[1:1:0712/071658.126810:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3eae601d
[1:1:0712/071658.127583:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3eae601d
[1:1:0712/071658.129638:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.129882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.130109:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.130331:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3eae601d
[1:1:0712/071658.131594:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3eae601d
[1:1:0712/071658.132024:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5bd28727ba
[1:1:0712/071658.132221:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5bd2869def, 7f5bd287277a, 7f5bd28740cf
[1:1:0712/071658.139932:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/071658.140392:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/071658.140574:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca5cdc788, 0x7ffca5cdc708)
[1:1:0712/071658.155940:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/071658.161691:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[99093:99093:0712/071658.630670:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99093:99093:0712/071658.632165:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99093:99105:0712/071658.653143:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[99093:99105:0712/071658.653247:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[99093:99093:0712/071658.653470:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[99093:99093:0712/071658.653567:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[99093:99093:0712/071658.653744:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,99146, 4
[1:7:0712/071658.658323:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[99093:99117:0712/071658.693439:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/071658.795041:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xeb38735c220
[1:1:0712/071658.795325:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/071659.118645:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[99093:99093:0712/071700.894078:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[99093:99093:0712/071700.894222:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/071700.925544:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071700.929177:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071702.159724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 210c3dbe1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/071702.160088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071702.178699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 210c3dbe1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/071702.179018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071702.245203:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071702.556300:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071702.556584:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071702.947238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071702.955516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 210c3dbe1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/071702.955849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071702.994894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071703.005605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 210c3dbe1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/071703.005904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071703.019269:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/071703.023590:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xeb38735ae20
[1:1:0712/071703.024043:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[99093:99093:0712/071703.024558:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[99093:99093:0712/071703.039926:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[99093:99093:0712/071703.075423:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[99093:99093:0712/071703.075520:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/071703.130133:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071704.087176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f5bbc4d62e0 0xeb38759df60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071704.088823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 210c3dbe1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/071704.089048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071704.090447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071704.149243:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xeb38735b820
[1:1:0712/071704.149538:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[99093:99093:0712/071704.154780:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[99093:99093:0712/071704.163319:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/071704.171962:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/071704.172230:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[99093:99093:0712/071704.187840:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[99093:99093:0712/071704.207195:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99093:99093:0712/071704.209837:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99093:99105:0712/071704.212405:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[99093:99105:0712/071704.212516:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[99093:99093:0712/071704.212681:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[99093:99093:0712/071704.212719:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[99093:99093:0712/071704.212783:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,99146, 4
[1:7:0712/071704.221033:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071704.826657:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/071705.328114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f5bbc4d62e0 0xeb3875de9e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/071705.329156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 210c3dbe1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/071705.329400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/071705.330196:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[99093:99093:0712/071705.429583:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[99093:99124:0712/071705.430032:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/071705.430246:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/071705.430501:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/071705.430907:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/071705.431049:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/071705.434093:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x19954043, 1
[1:1:0712/071705.434442:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x10935321, 0
[1:1:0712/071705.434618:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1344dd7e, 3
[1:1:0712/071705.434769:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x6c0fc81, 2
[1:1:0712/071705.434912:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2153ffffff9310 4340ffffff9519 ffffff81fffffffcffffffc006 7effffffdd4413 , 10104, 5
[1:1:0712/071705.435895:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99093:99124:0712/071705.436130:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING!S�C@����~�Dj��=
[99093:99124:0712/071705.436200:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is !S�C@����~�Dx�j��=
[99093:99124:0712/071705.436461:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99194, 5, 21539310 43409519 81fcc006 7edd4413 
[1:1:0712/071705.436318:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5bd0aad0a0, 3
[1:1:0712/071705.436658:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5bd0c38080, 2
[1:1:0712/071705.436834:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5bba8fbd20, -2
[1:1:0712/071705.454533:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071705.455108:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/071705.455428:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6c0fc81
[1:1:0712/071705.455778:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6c0fc81
[1:1:0712/071705.456394:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6c0fc81
[1:1:0712/071705.457812:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.457999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.458178:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.458362:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.459039:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6c0fc81
[1:1:0712/071705.459337:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5bd28727ba
[1:1:0712/071705.459470:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5bd2869def, 7f5bd287277a, 7f5bd28740cf
[1:1:0712/071705.465258:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 6c0fc81
[1:1:0712/071705.465651:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 6c0fc81
[1:1:0712/071705.466371:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 6c0fc81
[1:1:0712/071705.468861:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.469131:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.469358:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.469612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 6c0fc81
[1:1:0712/071705.471147:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 6c0fc81
[1:1:0712/071705.471647:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5bd28727ba
[1:1:0712/071705.471852:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5bd2869def, 7f5bd287277a, 7f5bd28740cf
[1:1:0712/071705.481501:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/071705.482117:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/071705.482260:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffca5cdc788, 0x7ffca5cdc708)
[1:1:0712/071705.495559:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/071705.499476:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[99093:99093:0712/071705.499866:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[99093:99093:0712/071705.499958:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/071705.749343:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xeb3872f0220
[1:1:0712/071705.749623:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/071706.034020:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[99093:99093:0712/071706.450817:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99093:99093:0712/071706.457799:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99093:99105:0712/071706.495207:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[99093:99105:0712/071706.495312:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[99093:99093:0712/071706.495899:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://forum.xitek.com/
[99093:99093:0712/071706.496006:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://forum.xitek.com/, http://forum.xitek.com/thread-1842042-1-1-1.html, 1
[99093:99093:0712/071706.496182:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://forum.xitek.com/, HTTP/1.1 200 OK Server: openresty/1.9.15.1 Date: Fri, 12 Jul 2019 14:17:03 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding X-Powered-By: PHP/5.5.38 Set-Cookie: rb6q_2ce7_sid=A33PlY; expires=Sat, 13-Jul-2019 14:17:03 GMT; Max-Age=86400; path=/; domain=.xitek.com Set-Cookie: rb6q_2ce7_lastact=1562941023%09forum.php%09viewthread; expires=Sat, 13-Jul-2019 14:17:03 GMT; Max-Age=86400; path=/; domain=.xitek.com Set-Cookie: rb6q_2ce7_oldtopics=D1842042D; expires=Fri, 12-Jul-2019 15:17:03 GMT; Max-Age=3600; path=/; domain=.xitek.com Set-Cookie: rb6q_2ce7_fid108=1562937770; expires=Fri, 12-Jul-2019 15:17:03 GMT; Max-Age=3600; path=/; domain=.xitek.com Set-Cookie: rb6q_2ce7_visitedfid=108; expires=Sun, 11-Aug-2019 14:17:03 GMT; Max-Age=2592000; path=/; domain=.xitek.com Set-Cookie: rb6q_2ce7_sid=A33PlY; expires=Sat, 13-Jul-2019 14:17:03 GMT; Max-Age=86399; path=/; domain=.xitek.com Content-Encoding: gzip  ,99194, 5
[1:7:0712/071706.500346:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071706.534472:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://forum.xitek.com/
[1:1:0712/071706.582242:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071706.582799:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[99093:99093:0712/071706.683824:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://forum.xitek.com/, http://forum.xitek.com/, 1
[99093:99093:0712/071706.683987:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071706.736581:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071706.867968:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071706.897577:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071706.951221:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071706.951493:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.096275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/071707.100881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 210c3dd0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/071707.101251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/071707.109548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/071707.442526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.445162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , var STYLEID = '6', STATICURL = 'static/', IMGDIR = 'static/image/common', VERHASH = '0IZ', charset =
[1:1:0712/071707.445409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071707.459498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.510384:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071707.533641:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/071707.793354:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.801209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.871275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.876982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.986138:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7f5bba5ae070 0xeb3874184e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071707.988466:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.540678, 43, 0
[1:1:0712/071707.988689:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071708.002255:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.003048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071708.003304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071708.104138:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071708.108989:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071708.109510:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071708.110033:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071708.110475:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071708.695151:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071708.695491:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.717637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071708.717954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071708.728805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f5bba5ae070 0xeb3876dfc60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.758430:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f5bba5ae070 0xeb3876dfc60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.771597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.788573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f5bba5ae070 0xeb3876dfc60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.796011:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071708.869384:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.173743, 231, 1
[1:1:0712/071708.869699:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071710.005112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.006113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071710.006435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071710.165696:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.166204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071710.166316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071710.179447:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071710.179606:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.180588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071710.180740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071710.183860:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.195282:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.204311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.207855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.214116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.221308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.228302:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.235547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.245323:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.249971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.253442:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.260359:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.263527:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.268972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.273706:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.278193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f5bba5ae070 0xeb3877cf160 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071710.302721:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.123189, 62, 1
[1:1:0712/071710.302991:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071711.180333:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.181098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071711.181287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071711.214872:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.215424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071711.215561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071711.232260:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071711.232432:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.233125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071711.233259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071711.236084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f5bba5ae070 0xeb3874cede0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.249976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f5bba5ae070 0xeb3874cede0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.254172:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.263926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f5bba5ae070 0xeb3874cede0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.362561:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.130228, 266, 1
[1:1:0712/071711.362893:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071711.663788:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.664620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071711.664809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071711.950469:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071711.951062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071711.951232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.267742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.268548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071712.268737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.291244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.291997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071712.292184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.333196:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.333986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071712.334180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.355982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.356758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071712.356941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.375615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.376064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071712.376175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.383454:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.383910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071712.384029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.400568:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071712.400830:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.401835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071712.402002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071712.404205:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 403 0x7f5bba5ae070 0xeb3878ebb60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.406175:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.410118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 403 0x7f5bba5ae070 0xeb3878ebb60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.411410:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071712.849041:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.448224, 2600, 1
[1:1:0712/071712.849377:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071713.703452:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.10_2917e48 -> 0
		remove user.11_7d045b04 -> 0
		remove user.12_8ef4cc55 -> 0
		remove user.13_9dbdc113 -> 0
		remove user.14_ce496c61 -> 0
[1:1:0712/071714.252429:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.253269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.253514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.318763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.319600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.319888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.368286:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.369098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.369336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.409379:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.410125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.410352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.461869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.462945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.463188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.799588:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.800626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.800879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.854685:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 427 0x7f5bbc4d62e0 0xeb3877b0860 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.856729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , var bdShare=bdShare||{version:"1.0"};bdShare.ready=bdShare.ready||function(B,C){C=C||document;if(/co
[1:1:0712/071714.856968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071714.993861:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071714.994611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071714.994789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.020258:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.021155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.021344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.041537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.042039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.042160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.074340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.075299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.075529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.108079:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.108556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.108674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.131472:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.132458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.132703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.153828:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.154343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.154465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.165179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.165644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.165755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.181340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.181809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.181920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.206690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.207465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.207649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.238158:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.238924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.239132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.264585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.265541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.265785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.314136:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.314617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.314731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.322881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.323251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.323360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.336770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.337281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.337403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.360972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.361447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.361575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.381045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.381805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.381983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.407751:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.408576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.408770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.427341:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.427783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.427903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.479307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.480130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.480338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.500275:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.500734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.500850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.508828:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.509245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.509388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.527723:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.528741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.529009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.559838:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.560363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.560493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.568975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.569316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.569426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.581839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.582734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.582954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.594712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.595194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.595311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.626957:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.627428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.627542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.635964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.636463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.636592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.650845:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.651279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.651407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.659547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.659868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.659976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.686309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.687060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.687269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.697005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.697485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.697602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.730695:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.731465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.731649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.754607:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.755606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.755837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.772480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.773384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.773576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.805715:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.806208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.806324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.821138:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.821539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.821647:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.830160:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.830587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.830695:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.857402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.858167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.858364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.905160:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.906136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.906397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.923007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.923664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.923786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.933406:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.933864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.933974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.942363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.942677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.942788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.962750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.963238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.963353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.971556:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.971906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.972026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071715.981325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071715.981749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071715.981861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071716.047943:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071716.048764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071716.048973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071716.077621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071716.078553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071716.078775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071716.112812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071716.113810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071716.114056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071716.148201:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071716.149162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071716.149413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071716.207354:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071716.207545:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071716.208305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071716.208445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071716.212620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 491 0x7f5bba5ae070 0xeb3879c6b60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
		remove user.10_14d23dd2 -> 0
[99093:99093:0712/071726.200528:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/071726.252718:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/071726.379778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x213c4aa029c8, 0xeb3871721a0
[1:1:0712/071726.380006:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 1000
[1:1:0712/071726.380212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 555
[1:1:0712/071726.380330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 555 0x7f5bba5ae070 0xeb38814ba60 , 5:3_http://forum.xitek.com/, 1, -5:3_http://forum.xitek.com/, 491 0x7f5bba5ae070 0xeb3879c6b60 
[1:1:0712/071726.386572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071726.387182:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 10.1796, 0, 0
[1:1:0712/071726.387317:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071726.407060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071726.407673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071726.407851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071727.153988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/071727.154303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071727.868073:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071727.868387:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071727.870745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071727.870980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071727.874863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7f5bba5ae070 0xeb38814fe60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[99093:99093:0712/071727.907736:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071727.909346:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xeb3872ee420
[1:1:0712/071727.909619:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[99093:99093:0712/071727.916143:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[99093:99093:0712/071727.962667:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://forum.xitek.com/, http://forum.xitek.com/, 4
[99093:99093:0712/071727.962814:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071727.972267:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071728.024923:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c9001a048, 5:3_http://forum.xitek.com/, 5:4_http://forum.xitek.com/, about:blank
[1:1:0712/071728.025249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, open, 
[1:1:0712/071728.025517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 4, 2, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071728.026607:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	rj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Uj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Object.Tj [as push] (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://forum.xitek.com/thread-1842042-1-1-1.html:2482:9

[1:1:0712/071728.032783:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 557 0x7f5bba5ae070 0xeb38814fe60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071728.039346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, Yj, (a){if(a){if(!Kj(a)&&(a.id?a=Oj(a.id):a=null,!a))throw new M("'element' has already been filled.");i
[1:1:0712/071728.040452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 3, , , 0
[1:1:0712/071728.041617:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Uj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Object.Tj [as push] (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://forum.xitek.com/thread-1842042-1-1-1.html:2482:9

[1:1:0712/071730.588681:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[99093:99093:0712/071730.601942:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071730.604501:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0xeb38863c420
[1:1:0712/071730.604763:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[99093:99093:0712/071730.611491:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: aswift_0, 5, 5, 
[99093:99093:0712/071730.666385:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://forum.xitek.com/, http://forum.xitek.com/, 5
[99093:99093:0712/071730.666525:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071730.676386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071730.681383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[99093:99093:0712/071730.819254:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071730.820166:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0xeb38863ce20
[1:1:0712/071730.820788:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[99093:99093:0712/071730.826895:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_esf, 6, 6, 
[1:1:0712/071730.837632:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/071730.837801:INFO:render_frame_impl.cc(7019)] 	 [url] = http://forum.xitek.com
[99093:99093:0712/071730.843237:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://forum.xitek.com/
[1:1:0712/071730.852163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, MutationObserver, 
[1:1:0712/071730.852509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 4, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071730.853374:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071730.854061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, , (mutation) {
        // 返回被添加的节点,或者为null.
        var nodes = mutation.added
[1:1:0712/071730.854262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 5, , , 0
[1:1:0712/071730.854567:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071730.864411:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c8ffd85d0, 5:3_http://forum.xitek.com/, 5:6_http://forum.xitek.com/, about:blank
[1:1:0712/071730.864617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:6_http://forum.xitek.com/, 138c8ffd85d0, 138c8ff22860, MutationObserver, 
[1:1:0712/071730.864792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 6, 6, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071730.865075:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071730.865685:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.99701, 2, 0
[1:1:0712/071730.865791:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[99093:99093:0712/071730.868635:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99093:99093:0712/071730.874607:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99093:99105:0712/071730.911757:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[99093:99105:0712/071730.911923:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[99093:99093:0712/071730.912114:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://googleads.g.doubleclick.net/
[99093:99093:0712/071730.912219:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://googleads.g.doubleclick.net/, http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#, 6
[99093:99093:0712/071730.912404:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_http://googleads.g.doubleclick.net/, HTTP/1.1 200 OK P3P: policyref="http://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Timing-Allow-Origin: * Vary: Accept-Encoding Date: Thu, 11 Jul 2019 19:19:43 GMT Expires: Thu, 25 Jul 2019 19:19:43 GMT Content-Type: text/html; charset=UTF-8 ETag: 6832606795824562093 X-Content-Type-Options: nosniff Content-Encoding: gzip Server: cafe Content-Length: 7008 X-XSS-Protection: 0 Age: 37361 Cache-Control: public, max-age=1209600  ,99194, 5
[1:7:0712/071730.922720:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071731.093064:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.093815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071731.094084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071731.258105:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.258892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071731.259188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071731.307776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.308715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071731.308948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071731.444678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.445531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071731.445797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071731.555739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.556590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071731.556827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071731.674495:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.675763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071731.676285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071731.900572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 586 0x7f5bbc4d62e0 0xeb38785e5e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071731.911908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , var bdShare=bdShare||{version:"1.0"};(function(){var P=new Date().getTime();var N=new Date().getTime
[1:1:0712/071731.912259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[99093:99093:0712/071731.947584:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071731.950516:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0xeb38861da20
[1:1:0712/071731.951119:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[99093:99093:0712/071731.954863:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[99093:99093:0712/071732.003413:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://forum.xitek.com/, http://forum.xitek.com/, 7
[99093:99093:0712/071732.003503:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071732.015359:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071732.046733:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[99093:99093:0712/071732.054843:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071732.056887:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0xeb3885f2e20
[1:1:0712/071732.057467:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[99093:99093:0712/071732.061825:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[99093:99093:0712/071732.111013:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://forum.xitek.com/, http://forum.xitek.com/, 8
[99093:99093:0712/071732.111165:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071732.121270:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071732.384018:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c8ffa1840, 5:3_http://forum.xitek.com/, 5:7_http://forum.xitek.com/, about:blank
[1:1:0712/071732.384370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/, 138c8ffa1840, 138c8ff22860, MutationObserver, 
[1:1:0712/071732.384677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 7, 2, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071732.385359:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071732.386178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffa1840, , (mutation) {
        // 返回被添加的节点,或者为null.
        var nodes = mutation.added
[1:1:0712/071732.386486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 3, , , 0
[1:1:0712/071732.387115:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071732.389260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/, 138c8ffa1840, 138c8ff22860, MutationObserver, 
[1:1:0712/071732.389725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 7, 4, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071732.390535:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071732.391199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffa1840, , (mutation) {
        // 返回被添加的节点,或者为null.
        var nodes = mutation.added
[1:1:0712/071732.391589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 5, , , 0
[1:1:0712/071732.392179:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071732.393951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/, 138c8ffa1840, 138c8ff22860, MutationObserver, 
[1:1:0712/071732.394286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 7, 6, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071732.395055:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071732.395742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:7_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffa1840, , (mutation) {
        // 返回被添加的节点,或者为null.
        var nodes = mutation.added
[1:1:0712/071732.396108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 7, , , 0
[1:1:0712/071732.396700:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071732.397294:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071732.433149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f5bbc4d62e0 0xeb388038f60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071732.434407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , processGoogleToken({"newToken":"NT","validLifetimeSecs":300,"freshLifetimeSecs":300,"1p_jar":"","puc
[1:1:0712/071732.434648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071732.444287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071732.482821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071732.483224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071732.972882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 555, 7f5bbcef3881
[1:1:0712/071733.011338:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138c8ff22860","ptid":"491 0x7f5bba5ae070 0xeb3879c6b60 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071733.011831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://forum.xitek.com/","ptid":"491 0x7f5bba5ae070 0xeb3879c6b60 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071733.012309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071733.013017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (){return n.processGoogleToken(d,1)}
[1:1:0712/071733.013280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071734.137321:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071735.172926:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071735.173228:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071735.200379:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://forum.xitek.com/, 5:6_http://forum.xitek.com/
[1:1:0712/071735.200676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071735.200889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071735.230761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 667 0x7f5bba5ae070 0xeb388348560 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071735.234356:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071735.306312:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[99093:99093:0712/071735.308437:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071735.310179:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0xeb388458e20
[1:1:0712/071735.310427:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[99093:99093:0712/071735.321650:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: frame, 9, 9, 
[99093:99093:0712/071735.354720:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://forum.xitek.com/, http://forum.xitek.com/, 9
[99093:99093:0712/071735.354898:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071735.451767:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c8ffb2398, 5:3_http://forum.xitek.com/, 5:9_http://forum.xitek.com/, about:blank
[1:1:0712/071735.451953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/, 138c8ffb2398, 138c8ff22860, MutationObserver, 
[1:1:0712/071735.452129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 9, 2, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071735.452383:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071735.453157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffb2398, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071735.453289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 3, , , 0
[1:1:0712/071735.453453:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071735.483395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/, 138c8ffb2398, 138c8ff22860, MutationObserver, 
[1:1:0712/071735.483626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 9, 4, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071735.483897:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071735.484862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffb2398, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071735.485005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 5, , , 0
[1:1:0712/071735.485193:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071735.516331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/, 138c8ffb2398, 138c8ff22860, MutationObserver, 
[1:1:0712/071735.516694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 9, 6, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071735.517296:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071735.519254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffb2398, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071735.519518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 7, , , 0
[1:1:0712/071735.519910:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071735.558929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/, 138c8ffb2398, 138c8ff22860, MutationObserver, 
[1:1:0712/071735.559353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 9, 8, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071735.567593:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071735.568449:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071735.570619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffb2398, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071735.570933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 9, , , 0
[1:1:0712/071735.571357:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071735.614430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/, 138c8ffb2398, 138c8ff22860, MutationObserver, 
[1:1:0712/071735.614909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 9, 10, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071735.615573:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071735.617654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffb2398, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071735.618003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 11, , , 0
[1:1:0712/071735.618420:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071735.658638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/, 138c8ffb2398, 138c8ff22860, MutationObserver, 
[1:1:0712/071735.659111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 9, 12, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071735.659731:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071735.667089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071735.667817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:9_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffb2398, , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071735.668229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 13, , , 0
[1:1:0712/071735.668627:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071735.673450:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.499999, 330, 1
[1:1:0712/071735.673622:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071736.098417:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_http://googleads.g.doubleclick.net/
[1:1:0712/071736.482009:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071736.482483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071736.482599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071736.495660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 705 0x7f5bbc4d62e0 0xeb3887970e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071736.496291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , try{window.localStorage.setItem('google_pub_config','{"sraConfigs":{"2":{"sraTimeout":60000}}}');}ca
[1:1:0712/071736.496515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071736.497277:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071737.519556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071737.519798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071740.025632:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.026452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071740.026681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071740.519702:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071740.519971:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.521674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071740.521894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071740.529248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 836 0x7f5bba5ae070 0xeb38908b4e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.532417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.538271:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 836 0x7f5bba5ae070 0xeb38908b4e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.553295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 836 0x7f5bba5ae070 0xeb38908b4e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.571304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 836 0x7f5bba5ae070 0xeb38908b4e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.584606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 836 0x7f5bba5ae070 0xeb38908b4e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[99093:99093:0712/071740.591319:INFO:CONSOLE(232)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://www.google-analytics.com/ga.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://forum.xitek.com/static/js/httphijack1.0.0.js (232)
[99093:99093:0712/071740.602385:INFO:CONSOLE(232)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://www.google-analytics.com/ga.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://forum.xitek.com/static/js/httphijack1.0.0.js (232)
[1:1:0712/071740.927157:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[99093:99093:0712/071740.929993:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://googleads.g.doubleclick.net/, http://googleads.g.doubleclick.net/, 6
[99093:99093:0712/071740.930096:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://googleads.g.doubleclick.net/, http://googleads.g.doubleclick.net
[1:1:0712/071740.975018:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071740.975483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071740.975601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.004894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.005332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.005443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.046518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.046950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.047061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.351029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.351491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.351722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.473944:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.474701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.474886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.527874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.528374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.528489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.707799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.708532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.708731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.709864:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.755326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071741.755508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071741.967054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071741.967893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071741.968158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071743.872162:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071744.836106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071744.836425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071746.493226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1012, "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071746.498608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (function(){var E;var g=window,n=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/071746.498893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071746.560308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071746.566295:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1012, "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071747.567366:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.00654, 0, 0
[1:1:0712/071747.567709:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/071747.684014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1018 0x7f5bbc4d62e0 0xeb388e474e0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071747.688507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (function(){var h={},mt={},c={id:"ce70a1f49c2ca89b4b7f15662df921f2",dm:["ww.xitek.com"],js:"tongji.b
[1:1:0712/071747.688735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071747.718468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x213c4aa029c8, 0xeb387172188
[1:1:0712/071747.718745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 100
[1:1:0712/071747.719193:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1190
[1:1:0712/071747.719420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1190 0x7f5bba5ae070 0xeb38986b4e0 , 5:3_http://forum.xitek.com/, 1, -5:3_http://forum.xitek.com/, 1018 0x7f5bbc4d62e0 0xeb388e474e0 
[1:1:0712/071747.830519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 600000
[1:1:0712/071747.831017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://forum.xitek.com/, 1207
[1:1:0712/071747.831217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1207 0x7f5bba5ae070 0xeb3899b8f60 , 5:3_http://forum.xitek.com/, 1, -5:3_http://forum.xitek.com/, 1018 0x7f5bbc4d62e0 0xeb388e474e0 
[1:1:0712/071747.837885:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.099254:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071748.099545:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/071748.104566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1020 0x7f5bba5ae070 0xeb3879c0360 , "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/071748.112593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://googleads.g.doubleclick.net/, 138c8ffd85d0, , , 
(function(){var m=this||self;
function n(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Arr
[1:1:0712/071748.112959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#", "googleads.g.doubleclick.net", 6, 1, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071748.153407:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/071748.158033:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.158728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:6_http://googleads.g.doubleclick.net/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd85d0, , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071748.159007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 2, , , 0
[1:1:0712/071748.159444:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[99093:99093:0712/071748.162712:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/071748.211700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.212529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071748.212752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071748.484432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.485281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071748.485508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071748.607824:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.608665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071748.608889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071748.720137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.720925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071748.721156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071748.899481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071748.899667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071748.943823:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071748.944331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071748.944454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071749.082281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071749.083035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071749.083240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071749.204777:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071749.205547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071749.205729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071749.743063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071749.743816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071749.743996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071749.867787:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1075 0x7f5bba916bd0 0xeb3889999d8 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071749.902829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://forum.xitek.com/, 138c9001a048, , , (function(window,document,location){var p;function aa(a){var b=0;return function(){return b<a.length
[1:1:0712/071749.903130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 1, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.047178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, D.google_process_slots, (){return sj(D)}
[1:1:0712/071750.047487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 2, , , 0
[1:1:0712/071750.050002:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.060076:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x213c4aa029c8, 0xeb387172160
[1:1:0712/071750.060333:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 30000
[1:1:0712/071750.060897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1285
[1:1:0712/071750.061151:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1285 0x7f5bba5ae070 0xeb3899dbb60 , 5:3_http://forum.xitek.com/, 2, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 1075 0x7f5bba916bd0 0xeb3889999d8 
[1:1:0712/071750.074493:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c8ffd0d60, 5:3_http://forum.xitek.com/, 5:5_http://forum.xitek.com/, about:blank
[1:1:0712/071750.074760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, open, 
[1:1:0712/071750.075081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 5, 3, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.076742:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.080916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1075 0x7f5bba916bd0 0xeb3889999d8 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071750.083017:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1075 0x7f5bba916bd0 0xeb3889999d8 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071750.085094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ffd0d60, Mx, (a){var b=a.iframeWin,c=a.vars;b&&(c.google_iframe_start_time=b.google_iframe_start_time);var d=new 
[1:1:0712/071750.085528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 4, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.087308:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.091088:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getElementById, 
[1:1:0712/071750.091336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 5, , , 0
[1:1:0712/071750.093023:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.093930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, now, 
[1:1:0712/071750.094228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 6, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.095660:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.098844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, indexOf, 
[1:1:0712/071750.099118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 7, , , 0
[1:1:0712/071750.100674:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	oh (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.101016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, Kh, (a){return Jh(a).eids||[]}
[1:1:0712/071750.101348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 8, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.102790:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.103633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, indexOf, 
[1:1:0712/071750.103940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 9, , , 0
[1:1:0712/071750.105494:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	oh (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.105832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, xj, (a,b){qj(uj,a,b,void 0)}
[1:1:0712/071750.106187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 10, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.107636:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.136021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, , (c){return Oh(a,c)}
[1:1:0712/071750.136546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 11, , , 0
[1:1:0712/071750.139131:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.156834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, Jh, (a){a.google_ad_modifications||(a.google_ad_modifications={});return a.google_ad_modifications}
[1:1:0712/071750.157343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 12, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.159906:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.161615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, call, 
[1:1:0712/071750.162071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 13, , , 0
[1:1:0712/071750.164815:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	v (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.165543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, push, 
[1:1:0712/071750.166098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 14, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.168733:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.169247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, next, 
[1:1:0712/071750.169758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 15, , , 0
[1:1:0712/071750.172371:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.172958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, push, 
[1:1:0712/071750.173529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 16, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.176177:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.176634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, next, 
[1:1:0712/071750.177154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 17, , , 0
[1:1:0712/071750.179777:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.180195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, push, 
[1:1:0712/071750.180847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 18, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.183480:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.183914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, next, 
[1:1:0712/071750.184507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 19, , , 0
[1:1:0712/071750.187147:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.187597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, push, 
[1:1:0712/071750.188245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 20, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.190932:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.191351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, next, 
[1:1:0712/071750.191971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 21, , , 0
[1:1:0712/071750.194642:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.195064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, push, 
[1:1:0712/071750.195795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 22, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.198491:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.198948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, next, 
[1:1:0712/071750.199619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 23, , , 0
[1:1:0712/071750.202256:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.202690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, push, 
[1:1:0712/071750.203429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 24, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.206067:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.206505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, next, 
[1:1:0712/071750.207195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 25, , , 0
[1:1:0712/071750.209859:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.210351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, $a, (a,b){for(var c=a.length,d=Array(c),e=x(a)?a.split(""):a,f=0;f<c;f++)f in e&&(d[f]=b.call(void 0,e[f
[1:1:0712/071750.211132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 26, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.213683:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.329683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getRandomValues, 
[1:1:0712/071750.330351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 27, , , 0
[1:1:0712/071750.332510:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	of (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	vy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.333012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, y, (a){return"number"==typeof a}
[1:1:0712/071750.333671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 28, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.335585:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.377175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getElementById, 
[1:1:0712/071750.378053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 29, , , 0
[1:1:0712/071750.380685:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.381201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, Ok, (a){a.google_reactive_ads_global_state||(a.google_reactive_ads_global_state=new Nk);return a.google_
[1:1:0712/071750.382104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 30, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.384744:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.410953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, addEventListener, 
[1:1:0712/071750.411894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 31, , , 0
[1:1:0712/071750.414782:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.415514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, As, (a,b){var c=this;this.j=a;uk(b,"rctcnf",T(426,function(d,e){return Bs(c,d,e)}),T(427,Ta(Zk,b,"rach::
[1:1:0712/071750.416516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 32, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.419027:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.421424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c9001a048, addEventListener, 
[1:1:0712/071750.422326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 33, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.425202:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.425854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ffd0d60, Vm, (a){return!!Um(a)||null!=a.google_pgb_reactive}
[1:1:0712/071750.426780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 34, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.429172:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.453352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getElementById, 
[1:1:0712/071750.454377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 35, , , 0
[1:1:0712/071750.456916:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.457393:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, nv, (){jv=iv();lv=jv.googleToken=jv.googleToken||{};var a=C();lv[1]&&lv[3]>a&&0<lv[2]||(lv[1]="",lv[2]=-
[1:1:0712/071750.458373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 36, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.460856:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.540634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, now, 
[1:1:0712/071750.541018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 37, , , 0
[1:1:0712/071750.541868:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.542078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, round, 
[1:1:0712/071750.542403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 38, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.543122:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.543452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, now, 
[1:1:0712/071750.543787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 39, , , 0
[1:1:0712/071750.544446:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.544672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 40, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, dv, (a,b,c){a-=b;return a>=(void 0===c?1E5:c)?"M":0<=a?a:"-M"}
[1:1:0712/071750.544979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 40, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.545641:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.738260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 41, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getBoundingClientRect, 
[1:1:0712/071750.739181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 41, , , 0
[1:1:0712/071750.741733:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.742383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 42, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, De, (a){return a?new Ee(Fe(a)):Va||(Va=new Ee)}
[1:1:0712/071750.743284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 42, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.746125:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.798734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 43, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, l.cb, (){return!(!window||!Array)}
[1:1:0712/071750.799703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 43, , , 0
[1:1:0712/071750.802286:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Yu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.802862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 44, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, mh, (a){return!(!a||!a.call)&&"function"===typeof a}
[1:1:0712/071750.803852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 44, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.806248:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.807376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 45, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, l.Qa, (){return this.i}
[1:1:0712/071750.808308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 45, , , 0
[1:1:0712/071750.811054:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.811661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 46, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, as, (a,b){if(!b)return null;var c=Ok(b);if(!c.wasReactiveAdConfigHandlerRegistered)return null;var d=0;N
[1:1:0712/071750.812641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 46, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.815005:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.841714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 47, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getBoundingClientRect, 
[1:1:0712/071750.842930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 47, , , 0
[1:1:0712/071750.846261:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.847322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 48, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, xm, (a){return{visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[a.visibilityState||a.webkitVisibilit
[1:1:0712/071750.848683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 48, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.851753:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.861031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 49, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071750.862137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 49, , , 0
[1:1:0712/071750.864914:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.865483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 50, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/071750.866519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 50, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.869109:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.870950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 51, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getAttribute, 
[1:1:0712/071750.871933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 51, , , 0
[1:1:0712/071750.874494:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.874927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 52, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/071750.876093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 52, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.879089:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.880223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 53, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getAttribute, 
[1:1:0712/071750.881720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 53, , , 0
[1:1:0712/071750.885483:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.886106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 54, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/071750.887616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 54, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.890213:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.901851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 55, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, contains, 
[1:1:0712/071750.902958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 55, , , 0
[1:1:0712/071750.905491:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.905905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 56, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/071750.907170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 56, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.909807:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.911414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 57, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071750.912472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 57, , , 0
[1:1:0712/071750.915018:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.915472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 58, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/071750.916539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 58, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.918910:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.919325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 59, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getAttribute, 
[1:1:0712/071750.920364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 59, , , 0
[1:1:0712/071750.927067:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.927505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 60, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/071750.928617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 60, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.931152:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.931669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 61, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getAttribute, 
[1:1:0712/071750.932775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 61, , , 0
[1:1:0712/071750.935226:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.935678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 62, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/071750.936789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 62, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.939225:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.947733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 63, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, contains, 
[1:1:0712/071750.948907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 63, , , 0
[1:1:0712/071750.951262:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.951688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 64, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/071750.952832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 64, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.955208:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.956175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 65, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071750.957272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 65, , , 0
[1:1:0712/071750.959752:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.960234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 66, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/071750.961395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 66, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.963883:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.964233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 67, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getAttribute, 
[1:1:0712/071750.965386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 67, , , 0
[1:1:0712/071750.968176:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.968653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 68, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/071750.970145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 68, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.972633:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.973101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 69, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getAttribute, 
[1:1:0712/071750.974276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 69, , , 0
[1:1:0712/071750.976888:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.977276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 70, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/071750.978523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 70, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.981073:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.983666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 71, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071750.984864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 71, , , 0
[1:1:0712/071750.987507:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.988091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 72, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071750.989365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 72, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071750.991934:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.992687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 73, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071750.993920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 73, , , 0
[1:1:0712/071750.996703:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071750.997310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 74, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071750.998576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 74, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.001256:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.002366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 75, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.003681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 75, , , 0
[1:1:0712/071751.006405:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.006956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 76, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.008534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 76, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.011955:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.013128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 77, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.014839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 77, , , 0
[1:1:0712/071751.018456:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.019139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 78, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.020954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 78, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.024361:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.025873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 79, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.027686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 79, , , 0
[1:1:0712/071751.031293:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.032003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 80, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.033876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 80, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.037283:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.038429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 81, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.040294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 81, , , 0
[1:1:0712/071751.043932:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.044739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 82, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.046655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 82, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.050103:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.051241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 83, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.053103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 83, , , 0
[1:1:0712/071751.056378:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.057081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 84, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.058675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 84, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.061409:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.062367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 85, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.064017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 85, , , 0
[1:1:0712/071751.068105:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.068771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 86, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.070927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 86, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.074290:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.075496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 87, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.076339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 87, , , 0
[1:1:0712/071751.077427:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.077848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 88, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.078491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 88, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.079384:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.079909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 89, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.080466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 89, , , 0
[1:1:0712/071751.081311:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.081604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 90, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.082193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 90, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.083039:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.083442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 91, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.084034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 91, , , 0
[1:1:0712/071751.084888:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.085172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 92, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.085771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 92, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.086556:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.086978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 93, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.087524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 93, , , 0
[1:1:0712/071751.090452:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.091136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 94, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.092996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 94, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.095866:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.096871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 95, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.098534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 95, , , 0
[1:1:0712/071751.101445:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.102097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 96, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.103896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 96, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.106974:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.108070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 97, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.109775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 97, , , 0
[1:1:0712/071751.112679:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.113237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 98, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/071751.115005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 98, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071751.117757:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.118692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 99, -5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, getComputedStyle, 
[1:1:0712/071751.120014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 99, , , 0
[1:1:0712/071751.120987:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071751.121310:INFO:switcher_impl.cc(1415)] 			[ERROR] updated frame chain. The number of frame chain is larger than the thresold, please check it! [num, thresold] = 100, 100
[99093:99093:0712/071751.408925:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071751.411316:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0xeb38863ba20
[1:1:0712/071751.411586:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[99093:99093:0712/071751.420974:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_ads_frame1, 10, 10, 
[1:1:0712/071751.438116:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/071751.438334:INFO:render_frame_impl.cc(7019)] 	 [url] = http://forum.xitek.com
[99093:99093:0712/071751.444502:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://forum.xitek.com/
[99093:99093:0712/071751.895117:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99093:99093:0712/071751.901194:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99093:99105:0712/071751.919656:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[99093:99093:0712/071751.919704:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://googleads.g.doubleclick.net/
[99093:99093:0712/071751.919744:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-1863278014148455&output=html&h=90&slotname=6700165483&adk=173344994&adf=3197273246&w=1025&fwr_io=true&fwrn=4&fwrnh=100&lmt=1562941070&rafmt=1&guci=2.2.0.0.2.2.0.0&format=1025x90&url=http%3A%2F%2Fforum.xitek.com%2Fthread-1842042-1-1-1.html&flash=0&fwr=0&fwrattr=true&resp_fmts=3&wgl=1&adsid=NT&dt=1562941047878&bpp=2961&bdt=21286&fdt=22204&idt=22217&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=5282683026990&frm=20&pv=2&ga_vid=1263838083.1562940600&ga_sid=1562940600&ga_hid=653941477&ga_fc=1&ga_cid=40668699.1562940977&iag=0&icsg=123114432184460&dssz=38&mdo=0&mso=8&u_tz=-420&u_his=2&u_java=0&u_h=647&u_w=1276&u_ah=623&u_aw=1211&u_cd=24&u_nplug=2&u_nmime=2&adx=0&ady=14929&biw=1025&bih=471&scr_x=0&scr_y=0&eid=4089042%2C20199336%2C151527023%2C151527223%2C368226350%2C368226360%2C21061795&oid=3&rx=0&eae=0&fc=656&brdim=95%2C44%2C95%2C44%2C1211%2C24%2C1050%2C603%2C1040%2C471&vis=1&rsz=%7C%7CeEbr%7C&abl=CS&pfx=0&fu=152&bc=23&ifi=1&uci=1.putig3xj0e3y&fsb=1&xpc=GakRwhWxcW&p=http%3A//forum.xitek.com&dtd=23509, 10
[99093:99105:0712/071751.919753:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[99093:99093:0712/071751.919818:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_https://googleads.g.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* content-type:text/html; charset=UTF-8 x-content-type-options:nosniff content-encoding:br date:Fri, 12 Jul 2019 14:17:51 GMT server:cafe content-length:3079 x-xss-protection:0 alt-svc:quic="googleads.g.doubleclick.net:443"; ma=2592000; v="46,43,39",quic=":443"; ma=2592000; v="46,43,39"  ,99194, 5
[1:7:0712/071751.926893:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/071751.989583:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x213c4aa029c8, 0xeb387172268
[1:1:0712/071751.989875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 0
[1:1:0712/071751.990419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1307
[1:1:0712/071751.990663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7f5bba5ae070 0xeb389f46e60 , 5:3_http://forum.xitek.com/, 100, , 1075 0x7f5bba916bd0 0xeb3889999d8 
[1:1:0712/071751.994344:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x213c4aab8aa0, 0xeb387172268
[1:1:0712/071751.994556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 0
[1:1:0712/071751.995070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1308
[1:1:0712/071751.995302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1308 0x7f5bba5ae070 0xeb389cf8a60 , 5:3_http://forum.xitek.com/, 100, , 1075 0x7f5bba916bd0 0xeb3889999d8 
[1:1:0712/071752.010207:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.520086:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/071757.520302:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.521391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.521536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071757.526362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1176 0x7f5bba5ae070 0xeb389965f60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.527051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.540372:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1176 0x7f5bba5ae070 0xeb389965f60 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.542402:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.544306:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[99093:99093:0712/071757.545958:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071757.548534:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0xeb389173220
[1:1:0712/071757.548723:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[99093:99093:0712/071757.552703:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: ifr, 11, 11, 
[99093:99093:0712/071757.582831:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_http://forum.xitek.com/, http://forum.xitek.com/, 11
[99093:99093:0712/071757.582975:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071757.588438:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c8ff95408, 5:3_http://forum.xitek.com/, 5:11_http://forum.xitek.com/, about:blank
[1:1:0712/071757.588697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.588983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 2, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.589605:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.590434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.590642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 3, , , 0
[1:1:0712/071757.591033:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.592547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.592829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 4, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.593432:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.594073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.594339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 5, , , 0
[1:1:0712/071757.594731:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.596113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.596441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 6, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.597016:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.597654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.597934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 7, , , 0
[1:1:0712/071757.598344:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.599712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.600039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 8, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.600662:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.601294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.601591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 9, , , 0
[1:1:0712/071757.601977:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.603368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.603725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 10, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.604324:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.604935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.605293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 11, , , 0
[1:1:0712/071757.605685:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.607104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.607506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 12, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.608101:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.608744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.609122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 13, , , 0
[1:1:0712/071757.609529:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.610902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.611345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 14, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.611915:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.612604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.612996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 15, , , 0
[1:1:0712/071757.613410:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.614787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.615277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 16, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.615861:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.616509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.616921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 17, , , 0
[1:1:0712/071757.617335:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.618726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.619196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 18, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.619799:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.620441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.620893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 19, , , 0
[1:1:0712/071757.621300:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.622707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.623252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 20, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.623861:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.624590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071757.625102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 21, , , 0
[1:1:0712/071757.625522:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.626955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/, 138c8ff95408, 138c8ff22860, MutationObserver, 
[1:1:0712/071757.627558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 11, 22, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071757.628161:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071757.635564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.636166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:11_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff95408, , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071757.636732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 23, , , 0
[1:1:0712/071757.637128:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071757.642625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.659999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.768997:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071757.791583:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071758.901116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1190, 7f5bbcef3881
[1:1:0712/071758.922725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138c8ff22860","ptid":"1018 0x7f5bbc4d62e0 0xeb388e474e0 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071758.923036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://forum.xitek.com/","ptid":"1018 0x7f5bbc4d62e0 0xeb388e474e0 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071758.923394:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071758.924077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071758.924257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071758.925124:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x213c4aa029c8, 0xeb387172150
[1:1:0712/071758.925286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 100
[1:1:0712/071758.925688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1415
[1:1:0712/071758.925883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1415 0x7f5bba5ae070 0xeb38a0caf60 , 5:3_http://forum.xitek.com/, 1, -5:3_http://forum.xitek.com/, 1190 0x7f5bba5ae070 0xeb38986b4e0 
[1:1:0712/071759.842750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071759.842976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/071801.519085:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:10_https://googleads.g.doubleclick.net/
[1:1:0712/071801.790064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1307, 7f5bbcef3881
[1:1:0712/071801.849457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138c9001a048138c8ff22860138c8ffd0d60138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ffd0d60138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860","ptid":"1075 0x7f5bba916bd0 0xeb3889999d8 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071801.852290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/","ptid":"1075 0x7f5bba916bd0 0xeb3889999d8 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071801.852785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071801.853389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (f){for(var g=[],h=0;h<arguments.length;++h)g[h]=arguments[h];return Pd(e,a,function(){return b.appl
[1:1:0712/071801.853574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071801.941472:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1308, 7f5bbcef3881
[1:1:0712/071802.008897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138c9001a048138c8ff22860138c8ffd0d60138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ffd0d60138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860138c9001a048138c8ff22860","ptid":"1075 0x7f5bba916bd0 0xeb3889999d8 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071802.012241:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/","ptid":"1075 0x7f5bba916bd0 0xeb3889999d8 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071802.012835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071802.013555:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_http://forum.xitek.com/, 5:3_http://forum.xitek.com/
[1:1:0712/071802.013773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://forum.xitek.com/, 138c9001a048, , , (){b.document.close()}
[1:1:0712/071802.014057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 1, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071802.015155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c9001a048, close, 
[1:1:0712/071802.015503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 2, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071802.016146:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/071803.882944:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071803.883390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/071803.883513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071803.909955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1415, 7f5bbcef3881
[1:1:0712/071803.952714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138c8ff22860","ptid":"1190 0x7f5bba5ae070 0xeb38986b4e0 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071803.953144:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://forum.xitek.com/","ptid":"1190 0x7f5bba5ae070 0xeb38986b4e0 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071803.953617:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071803.954405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071803.954663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071803.955570:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x213c4aa029c8, 0xeb387172150
[1:1:0712/071803.955777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 100
[1:1:0712/071803.956318:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1531
[1:1:0712/071803.956571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1531 0x7f5bba5ae070 0xeb3898c0760 , 5:3_http://forum.xitek.com/, 1, -5:3_http://forum.xitek.com/, 1415 0x7f5bba5ae070 0xeb38a0caf60 
[1:1:0712/071804.092280:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071804.093044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071804.093225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071804.308776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071804.309545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071804.309730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071804.443437:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071804.444240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071804.444432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071804.512282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , document.readyState
[1:1:0712/071804.512527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071804.705155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071804.705615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071804.705754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071804.765625:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071804.766372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071804.766556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071805.060463:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071805.060934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071805.061667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071805.268056:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071805.268866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071805.269109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[99093:99093:0712/071806.434200:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/, 10
[99093:99093:0712/071806.434332:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net
[1:1:0712/071806.434766:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/071807.138595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1509 0x7f5bbc4d62e0 0xeb38a13efe0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071807.142304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , var bdShare=bdShare||{};bdShare._LogPool=bdShare._LogPool||[],bdShare.ApiPVLogger||function(e){funct
[1:1:0712/071807.142549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071807.152086:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071807.242356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1510 0x7f5bbc4d62e0 0xeb38a0ecde0 , "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071807.257946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , , (function(window,document){var k;function aa(a){var b=0;return function(){return b<a.length?{done:!1
[1:1:0712/071807.258235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071807.351153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, Km, (){var a=O(),b=a.__google_ad_urls;if(!b)return a.__google_ad_urls=new Gm(a);try{if(0<=b.getOseId())r
[1:1:0712/071807.351523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 2, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.353646:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.355407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, sa, (a){return"function"==pa(a)}
[1:1:0712/071807.355703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 3, , , 0
[1:1:0712/071807.357088:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[99093:99093:0712/071807.403285:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/071807.405179:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 12, 0xeb389171420
[1:1:0712/071807.405443:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 12
[99093:99093:0712/071807.406775:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_osd_static_frame, 12, 12, 
[99093:99093:0712/071807.444630:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_http://forum.xitek.com/, http://forum.xitek.com/, 12
[99093:99093:0712/071807.444849:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 12, 12, http://forum.xitek.com/, http://forum.xitek.com
[1:1:0712/071807.454235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071807.493062:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 138c8ff683d8, 5:3_http://forum.xitek.com/, 5:12_http://forum.xitek.com/, about:blank
[1:1:0712/071807.493369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, addEventListener, 
[1:1:0712/071807.493674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 4, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.494976:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	vc (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	R (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Uh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.495485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, Xf, (a,b,c,d){Wf(a);var e=S.g().m;a.a&&a.a.getNewBlocks(b,e);a.b&&a.b.getNewBlocks(b,e);a.c&&!c()&&(d(!0
[1:1:0712/071807.495816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 5, , , 0
[1:1:0712/071807.496986:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.503043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, p.getNewBlocks, (a,b){for(var c=this.j.length,d=0;d<c;d++){var e=this.j[d];!e.m&&e.j&&(e.m=!0,a(e.j,e.B,e.G,e.l,void
[1:1:0712/071807.503414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 6, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.504716:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.505650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, , (b){for(var c=[],d=0;d<arguments.length;++d)c[d]=arguments[d];return a.Tb.apply(a,r(c))}
[1:1:0712/071807.506016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 7, , , 0
[1:1:0712/071807.507600:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

		remove user.11_d937bf99 -> 0
		remove user.12_45d6478 -> 0
[1:1:0712/071807.537906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, getBoundingClientRect, 
[1:1:0712/071807.538331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 8, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.541943:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.565585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd0d60, Be, (a){return new H(a.top,a.right,a.bottom,a.left)}
[1:1:0712/071807.566028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 9, , , 0
[1:1:0712/071807.569708:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.572296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, getBoundingClientRect, 
[1:1:0712/071807.572717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 10, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.575239:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ec (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.575857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd0d60, E, (a,b){this.x=void 0!==a?a:0;this.y=void 0!==b?b:0}
[1:1:0712/071807.576311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 11, , , 0
[1:1:0712/071807.579949:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.594564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, p.getOseId, (){return window&&Math.random&&navigator?this.l:-1}
[1:1:0712/071807.595069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 12, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.596899:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.597303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, bd, (a,b,c){(a=a.a[b])&&Zc(a,c)}
[1:1:0712/071807.597699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 13, , , 0
[1:1:0712/071807.599413:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.603227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, Km, (){var a=O(),b=a.__google_ad_urls;if(!b)return a.__google_ad_urls=new Gm(a);try{if(0<=b.getOseId())r
[1:1:0712/071807.603698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 14, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.605826:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.607282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, sa, (a){return"function"==pa(a)}
[1:1:0712/071807.607705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 15, , , 0
[1:1:0712/071807.609924:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.612197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, p.numBlocks, (){return this.j.length}
[1:1:0712/071807.612701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 16, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.614852:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.615398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, Sh, (a){Uh(a);Xf(a.a,function(b){for(var c=[],d=0;d<arguments.length;++d)c[d]=arguments[d];return a.Tb.a
[1:1:0712/071807.615907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 17, , , 0
[1:1:0712/071807.617681:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.619380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, p.getNewBlocks, (a,b){for(var c=this.j.length,d=0;d<c;d++){var e=this.j[d];!e.m&&e.j&&(e.m=!0,a(e.j,e.B,e.G,e.l,void
[1:1:0712/071807.619976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 18, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.621922:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.623320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, a.g, (){return a.Ta?a.Ta:a.Ta=new a}
[1:1:0712/071807.623887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 19, , , 0
[1:1:0712/071807.625649:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.674808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/, 138c9001a048, 138c8ff22860, p.getOseId, (){return window&&Math.random&&navigator?this.l:-1}
[1:1:0712/071807.675500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 4, 20, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.677572:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.678063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c9001a048, dh, (a,b){var c=Y;if(!c.B){c.B=!0;if(!c.s&&!ch()){var d=Q(137,function(e){for(var f=[],g=0;g<arguments.l
[1:1:0712/071807.678602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 21, , , 0
[1:1:0712/071807.680541:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.724980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, getComputedStyle, 
[1:1:0712/071807.725653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 22, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.729487:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.730003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd0d60, parseFloat, 
[1:1:0712/071807.730561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 23, , , 0
[1:1:0712/071807.733893:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.737947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, getComputedStyle, 
[1:1:0712/071807.738552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 24, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.750062:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071807.751948:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071807.752321:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071807.752679:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/071807.753700:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.754566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd0d60, parseFloat, 
[1:1:0712/071807.755427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 25, , , 0
[1:1:0712/071807.759719:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.765396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, getComputedStyle, 
[1:1:0712/071807.766089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 26, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.769099:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.769401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd0d60, parseFloat, 
[1:1:0712/071807.769660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 27, , , 0
[1:1:0712/071807.770669:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.851337:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x213c4aa029c8, 0xeb387172140
[1:1:0712/071807.851511:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 100
[1:1:0712/071807.851689:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1628
[1:1:0712/071807.852034:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1628 0x7f5bba5ae070 0xeb38a554460 , 5:3_http://forum.xitek.com/, 27, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 1510 0x7f5bbc4d62e0 0xeb38a0ecde0 
[1:1:0712/071807.853079:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3600000, 0x213c4aa029c8, 0xeb387172140
[1:1:0712/071807.853196:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 3600000
[1:1:0712/071807.853375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1629
[1:1:0712/071807.853485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1629 0x7f5bba5ae070 0xeb38a54f760 , 5:3_http://forum.xitek.com/, 27, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 1510 0x7f5bbc4d62e0 0xeb38a0ecde0 
[1:1:0712/071807.857111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/, 138c8ffd0d60, 138c8ff22860, addEventListener, 
[1:1:0712/071807.857383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 5, 28, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.858053:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	vc (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	R (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.858351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ffd0d60, O, (){var a=Ed.g();if(!a.a){if(!y)throw Error("Context has not been set and window is undefined.");a.a=
[1:1:0712/071807.858591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 29, , , 0
[1:1:0712/071807.858964:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/071807.859434:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x213c4aa029c8, 0xeb387172140
[1:1:0712/071807.859535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 250
[1:1:0712/071807.859710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1630
[1:1:0712/071807.859854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1630 0x7f5bba5ae070 0xeb38a5c1d60 , 5:3_http://forum.xitek.com/, 29, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 1510 0x7f5bbc4d62e0 0xeb38a0ecde0 
[1:1:0712/071807.867589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.868359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 30, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.869009:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.869757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.870453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 31, , , 0
[1:1:0712/071807.870896:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.872317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.873063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 32, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.873656:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.874331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.875143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 33, , , 0
[1:1:0712/071807.875540:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.876947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.877767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 34, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.878404:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.879130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.879977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 35, , , 0
[1:1:0712/071807.880376:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.881720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.882507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 36, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.883144:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.883776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.884588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 37, , , 0
[1:1:0712/071807.885019:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.886333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.887160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 38, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.887749:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.888424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.889215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 39, , , 0
[1:1:0712/071807.889613:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.891006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 40, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.891912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 40, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.892514:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.893253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 41, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.894116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 41, , , 0
[1:1:0712/071807.894519:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.895873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 42, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.896726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 42, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.897339:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.898055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 43, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.898948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 43, , , 0
[1:1:0712/071807.899342:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.900648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 44, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.901128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 44, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.901391:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.901740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 45, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.902101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 45, , , 0
[1:1:0712/071807.902265:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.902779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 46, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.903173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 46, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.903411:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.903732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 47, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.904127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 47, , , 0
[1:1:0712/071807.904302:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.904811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 48, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.905183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 48, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.905413:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.905749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 49, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.906103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 49, , , 0
[1:1:0712/071807.906266:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.906779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 50, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.907179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 50, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.907423:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.907743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 51, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.908149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 51, , , 0
[1:1:0712/071807.908313:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.908859:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 52, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.909242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 52, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.909498:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.909876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 53, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.910285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 53, , , 0
[1:1:0712/071807.910452:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.911032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 54, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.911432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 54, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.911678:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.912059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 55, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.912464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 55, , , 0
[1:1:0712/071807.912627:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.913250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 56, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.913669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 56, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.913935:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.914274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 57, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.914654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 57, , , 0
[1:1:0712/071807.914816:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.915366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 58, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.915767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 58, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.916048:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.916372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 59, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.916746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 59, , , 0
[1:1:0712/071807.916929:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.917470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 60, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.917888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 60, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.918132:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.918461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 61, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.918875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 61, , , 0
[1:1:0712/071807.919038:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.919552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 62, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.920037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 62, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.920283:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.920602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 63, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.921084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 63, , , 0
[1:1:0712/071807.921257:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.921783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 64, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.922243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 64, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.922483:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.922800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 65, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.923238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 65, , , 0
[1:1:0712/071807.923398:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.923966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 66, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.924417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 66, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.924654:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.925019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 67, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.925441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 67, , , 0
[1:1:0712/071807.925600:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.926177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 68, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.926651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 68, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.926929:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.927326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 69, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.927872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 69, , , 0
[1:1:0712/071807.928051:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.928590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 70, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.929101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 70, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.929350:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.929684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 71, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (mutations) {
      mutations.forEach(function(mutation) {
        // 返回被添加的节点,或
[1:1:0712/071807.930168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 71, , , 0
[1:1:0712/071807.930345:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071807.930905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 72, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/, 138c8ff683d8, 138c8ff22860, MutationObserver, 
[1:1:0712/071807.931397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "forum.xitek.com", 12, 72, http://forum.xitek.com, forum.xitek.com, 3
[1:1:0712/071807.931633:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	installHook (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)
	http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1
	MutationObserver.<anonymous> (http://forum.xitek.com/static/js/httphijack1.0.0.js:1:1)

[1:1:0712/071807.932099:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071807.932410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 73, -5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:4_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:5_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/-5:12_http://forum.xitek.com/-5:3_http://forum.xitek.com/, 138c8ff22860, 138c8ff683d8, , (e) {
      scanElement(e.target, isClick, eventName, eventID);
    }
[1:1:0712/071807.932903:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 73, , , 0
[1:1:0712/071807.933068:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/071808.011933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071808.012673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/071808.012871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071808.226056:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071808.226796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/071808.227003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071808.367271:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071808.368040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/071808.368223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071808.675655:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1531, 7f5bbcef3881
[1:1:0712/071808.748153:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"138c8ff22860","ptid":"1415 0x7f5bba5ae070 0xeb38a0caf60 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071808.748469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://forum.xitek.com/","ptid":"1415 0x7f5bba5ae070 0xeb38a0caf60 ","rf":"5:3_http://forum.xitek.com/"}
[1:1:0712/071808.748823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://forum.xitek.com/thread-1842042-1-1-1.html"
[1:1:0712/071808.749434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://forum.xitek.com/, 138c8ff22860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/071808.749614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://forum.xitek.com/thread-1842042-1-1-1.html", "forum.xitek.com", 3, 1, , , 0
[1:1:0712/071808.750486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x213c4aa029c8, 0xeb387172150
[1:1:0712/071808.750649:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://forum.xitek.com/thread-1842042-1-1-1.html", 100
[1:1:0712/071808.751052:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://forum.xitek.com/, 1648
[1:1:0712/071808.751264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1648 0x7f5bba5ae070 0xeb389f3dd60 , 5:3_http://forum.xitek.com/, 1, -5:3_http://forum.xitek.com/, 1531 0x7f5bba5ae070 0xeb3898c0760 
