[0712/072111.017434:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/072111.017978:INFO:switcher_clone.cc(787)] backtrace rip is 7fd404e90891
[0712/072112.038762:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/072112.039054:INFO:switcher_clone.cc(787)] backtrace rip is 7fcb77534891
[1:1:0712/072112.043281:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/072112.043508:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/072112.049165:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[99732:99732:0712/072113.119438:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/27d69e74-2837-46c9-8a05-493ca5482725
[0712/072113.384490:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/072113.384808:INFO:switcher_clone.cc(787)] backtrace rip is 7f6314dc9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[99765:99765:0712/072113.610982:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=99765
[99776:99776:0712/072113.611429:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=99776
[99732:99732:0712/072113.632597:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[99732:99762:0712/072113.633655:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/072113.633893:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/072113.634160:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/072113.634804:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/072113.635028:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/072113.638130:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2f8ebe27, 1
[1:1:0712/072113.638679:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x85356a1, 0
[1:1:0712/072113.638979:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x18c6acb2, 3
[1:1:0712/072113.639194:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x35696063, 2
[1:1:0712/072113.639419:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa1565308 27ffffffbeffffff8e2f 63606935 ffffffb2ffffffacffffffc618 , 10104, 4
[1:1:0712/072113.640627:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99732:99762:0712/072113.640871:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�VS'��/c`i5�����
[99732:99762:0712/072113.640941:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �VS'��/c`i5���x���
[1:1:0712/072113.641073:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb7576f0a0, 3
[99732:99762:0712/072113.641315:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/072113.641313:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb758fa080, 2
[99732:99762:0712/072113.641417:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99784, 4, a1565308 27be8e2f 63606935 b2acc618 
[1:1:0712/072113.641500:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb5f5bdd20, -2
[1:1:0712/072113.662549:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/072113.663649:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 35696063
[1:1:0712/072113.664797:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 35696063
[1:1:0712/072113.666500:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 35696063
[1:1:0712/072113.667999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.668243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.668658:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.668887:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.669611:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 35696063
[1:1:0712/072113.669951:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcb775347ba
[1:1:0712/072113.670122:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcb7752bdef, 7fcb7753477a, 7fcb775360cf
[1:1:0712/072113.676315:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 35696063
[1:1:0712/072113.676824:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 35696063
[1:1:0712/072113.677755:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 35696063
[1:1:0712/072113.679925:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.680130:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.680320:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.680503:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 35696063
[1:1:0712/072113.681681:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 35696063
[1:1:0712/072113.681884:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcb775347ba
[1:1:0712/072113.681985:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcb7752bdef, 7fcb7753477a, 7fcb775360cf
[1:1:0712/072113.684301:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/072113.684624:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/072113.684720:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4cd18c68, 0x7ffe4cd18be8)
[1:1:0712/072113.699402:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/072113.705694:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[99732:99756:0712/072114.338181:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[99732:99732:0712/072114.369230:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99732:99732:0712/072114.371091:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99732:99732:0712/072114.394635:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[99732:99732:0712/072114.394815:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[99732:99732:0712/072114.395041:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,99784, 4
[99732:99743:0712/072114.395672:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[99732:99743:0712/072114.395914:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/072114.397416:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/072114.415509:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x78f8168a220
[1:1:0712/072114.416271:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/072114.875143:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[99732:99732:0712/072116.422544:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[99732:99732:0712/072116.422662:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/072116.447950:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072116.451366:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072117.328791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09837fa21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/072117.329130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072117.345591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09837fa21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/072117.345887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072117.363180:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072117.632788:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072117.633102:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072117.907443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072117.915771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09837fa21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/072117.916086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072117.936429:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072117.947022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09837fa21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/072117.947339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072117.952034:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[99732:99732:0712/072117.955474:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/072117.955448:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x78f81688e20
[1:1:0712/072117.955700:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[99732:99732:0712/072117.961708:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[99732:99732:0712/072117.991017:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[99732:99732:0712/072117.991166:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/072118.019276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072118.895000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fcb611982e0 0x78f8190b8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072118.896449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09837fa21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/072118.896722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072118.898189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[99732:99732:0712/072118.963132:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/072118.965188:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x78f81689820
[1:1:0712/072118.965436:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[99732:99732:0712/072118.970228:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/072118.973032:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/072118.973180:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[99732:99732:0712/072118.986911:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[99732:99732:0712/072118.997912:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99732:99732:0712/072118.998923:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[99732:99743:0712/072119.004985:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[99732:99743:0712/072119.005077:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[99732:99732:0712/072119.005227:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[99732:99732:0712/072119.005304:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[99732:99732:0712/072119.005437:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,99784, 4
[1:7:0712/072119.013955:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/072119.550087:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/072119.856101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7fcb611982e0 0x78f818d38e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/072119.857142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 09837fa21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/072119.857389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/072119.858179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[99732:99732:0712/072119.974226:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[99732:99732:0712/072119.974301:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/072120.004042:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072120.402763:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072121.134274:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072121.134617:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[99732:99732:0712/072121.333800:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[99732:99762:0712/072121.334209:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/072121.334399:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/072121.334677:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/072121.335131:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/072121.335313:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/072121.338575:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x13b824cf, 1
[1:1:0712/072121.338945:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x336ed7f6, 0
[1:1:0712/072121.339131:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1fed3f6e, 3
[1:1:0712/072121.339310:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x39f22ff4, 2
[1:1:0712/072121.339481:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff6ffffffd76e33 ffffffcf24ffffffb813 fffffff42ffffffff239 6e3fffffffed1f , 10104, 5
[1:1:0712/072121.340414:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99732:99762:0712/072121.340673:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��n3�$��/�9n?�j�
[99732:99762:0712/072121.340754:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��n3�$��/�9n?���j�
[1:1:0712/072121.340860:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb7576f0a0, 3
[99732:99762:0712/072121.341113:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99827, 5, f6d76e33 cf24b813 f42ff239 6e3fed1f 
[1:1:0712/072121.341218:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb758fa080, 2
[1:1:0712/072121.341472:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb5f5bdd20, -2
[1:1:0712/072121.363199:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/072121.363690:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 39f22ff4
[1:1:0712/072121.364146:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 39f22ff4
[1:1:0712/072121.364815:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 39f22ff4
[1:1:0712/072121.366260:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.366493:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.366712:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.366938:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.367662:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 39f22ff4
[1:1:0712/072121.368038:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcb775347ba
[1:1:0712/072121.368217:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcb7752bdef, 7fcb7753477a, 7fcb775360cf
[1:1:0712/072121.373223:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 39f22ff4
[1:1:0712/072121.373663:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 39f22ff4
[1:1:0712/072121.374487:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 39f22ff4
[1:1:0712/072121.376646:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.376919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.377193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.377428:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39f22ff4
[1:1:0712/072121.378657:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 39f22ff4
[1:1:0712/072121.379070:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcb775347ba
[1:1:0712/072121.379267:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcb7752bdef, 7fcb7753477a, 7fcb775360cf
[1:1:0712/072121.386637:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/072121.387154:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/072121.387338:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4cd18c68, 0x7ffe4cd18be8)
[1:1:0712/072121.402328:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/072121.405715:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/072121.534310:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072121.537701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 09837fb4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/072121.537993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/072121.546700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/072121.600502:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x78f81669220
[1:1:0712/072121.600786:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[99732:99732:0712/072122.292846:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[99732:99732:0712/072122.342072:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[99732:99762:0712/072122.342569:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/072122.342860:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/072122.343115:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/072122.343641:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/072122.343902:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/072122.347431:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1285b359, 1
[1:1:0712/072122.347836:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x32f2e43c, 0
[1:1:0712/072122.348096:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3de2305b, 3
[1:1:0712/072122.348353:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x11d5505c, 2
[1:1:0712/072122.348678:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3cffffffe4fffffff232 59ffffffb3ffffff8512 5c50ffffffd511 5b30ffffffe23d , 10104, 6
[1:1:0712/072122.349730:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[99732:99762:0712/072122.350065:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING<��2Y��\P�[0�=�
[99732:99762:0712/072122.350138:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is <��2Y��\P�[0�=8��
[1:1:0712/072122.350309:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb7576f0a0, 3
[99732:99762:0712/072122.350483:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 99843, 6, 3ce4f232 59b38512 5c50d511 5b30e23d 
[1:1:0712/072122.350557:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb758fa080, 2
[1:1:0712/072122.350763:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcb5f5bdd20, -2
[99732:99732:0712/072122.362547:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/072122.373350:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/072122.373736:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 11d5505c
[1:1:0712/072122.374025:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 11d5505c
[1:1:0712/072122.374716:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 11d5505c
[1:1:0712/072122.376232:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.376467:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.376699:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.376917:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.377641:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 11d5505c
[1:1:0712/072122.377966:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcb775347ba
[1:1:0712/072122.378142:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcb7752bdef, 7fcb7753477a, 7fcb775360cf
[1:1:0712/072122.383974:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 11d5505c
[1:1:0712/072122.384528:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 11d5505c
[1:1:0712/072122.385537:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 11d5505c
[1:1:0712/072122.387623:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.387907:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.388134:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.388393:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11d5505c
[1:1:0712/072122.389679:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 11d5505c
[1:1:0712/072122.390093:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcb775347ba
[1:1:0712/072122.390326:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcb7752bdef, 7fcb7753477a, 7fcb775360cf
[1:1:0712/072122.398121:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/072122.398699:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/072122.398887:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4cd18c68, 0x7ffe4cd18be8)
[99732:99743:0712/072122.400045:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[99732:99732:0712/072122.400286:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://scjgj.sh.gov.cn/
[99732:99732:0712/072122.400382:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120626152633992, 1
[99732:99732:0712/072122.400494:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_http://scjgj.sh.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 14:21:22 GMT Content-Type: text/html;charset=UTF-8 Content-Length: 12590 Connection: keep-alive Expires: Fri, 12 Jul 2019 14:21:22 GMT Pragma: no-cache Cache-Control: no-cache Set-Cookie: JSESSIONIDlz=0000XXmfg5rjbY5R_vSqc-n3n2I:16f9u5edl; Path=/ Content-Language: zh-CN X-Ser: BC15_dx-lt-yd-jiangsu-zhenjiang-3-cache-9, BC73_cl-shanghai-shanghai-1-cache-2, BC152_ck-shanghai-shanghai-3-cache-2, BC150_ck-beijing-beijing-2-cache-2  ,0, 6
[99732:99743:0712/072122.400131:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[3:3:0712/072122.402315:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/072122.413336:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/072122.417785:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/072122.490811:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/072122.631914:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x78f81682220
[1:1:0712/072122.632188:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/072122.661751:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_http://scjgj.sh.gov.cn/
[99732:99732:0712/072122.871480:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn/, 1
[99732:99732:0712/072122.871586:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://scjgj.sh.gov.cn/, http://scjgj.sh.gov.cn
[1:1:0712/072122.897958:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/072123.027019:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072123.118671:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072123.118951:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120626152633992"
[1:1:0712/072123.181589:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0623429, 244, 1
[1:1:0712/072123.181864:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/072123.233851:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/072123.234094:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120626152633992"
[1:1:0712/072123.336012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7fcb5f270070 0x78f81678360 , "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120626152633992"
[1:1:0712/072123.338508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_http://scjgj.sh.gov.cn/, 144ec3582860, , , 
//changediv();
function changediv(){
	var tab = document.getElementById("resultTb");
	var d = docum
[1:1:0712/072123.338759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120626152633992", "scjgj.sh.gov.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/072130.923841:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072130.924601:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072130.924997:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072130.925390:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072130.925723:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/072143.196507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_http://scjgj.sh.gov.cn/, 144ec3582860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/072143.196747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://scjgj.sh.gov.cn/lz/licenseLink.do?method=licenceView&entyId=20120626152633992", "scjgj.sh.gov.cn", 3, 1, , , 0
[1:1:0712/072143.201388:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[99732:99732:0712/072143.567616:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/072143.577181:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
