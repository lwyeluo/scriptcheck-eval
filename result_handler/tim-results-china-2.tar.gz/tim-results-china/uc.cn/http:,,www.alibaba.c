[0712/124710.514884:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124710.515367:INFO:switcher_clone.cc(787)] backtrace rip is 7f4c31279891
[0712/124711.330004:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124711.330368:INFO:switcher_clone.cc(787)] backtrace rip is 7f92d02fd891
[1:1:0712/124711.342012:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/124711.342252:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/124711.353848:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[10148:10148:0712/124712.431849:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dd09c545-ea11-488c-a4ba-280b9dfef031
[0712/124712.797267:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124712.797770:INFO:switcher_clone.cc(787)] backtrace rip is 7f2a55648891
[10148:10148:0712/124712.841247:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[10148:10179:0712/124712.842055:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/124712.842260:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124712.842506:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124712.843118:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124712.843294:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/124712.846216:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd9c92d4, 1
[1:1:0712/124712.846542:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36a6768c, 0
[1:1:0712/124712.846764:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x328c6cd, 3
[1:1:0712/124712.846986:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xe22c9c4, 2
[1:1:0712/124712.847223:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8c76ffffffa636 ffffffd4ffffff92ffffff9c0d ffffffc4ffffffc9220e ffffffcdffffffc62803 , 10104, 4
[1:1:0712/124712.848402:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10148:10179:0712/124712.848676:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�v�6Ԓ���"��(�9s+
[10148:10179:0712/124712.848776:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �v�6Ԓ���"��(hr�9s+
[10148:10179:0712/124712.849089:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/124712.848916:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92ce5380a0, 3
[10148:10179:0712/124712.849186:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10194, 4, 8c76a636 d4929c0d c4c9220e cdc62803 
[1:1:0712/124712.849277:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92ce6c3080, 2
[1:1:0712/124712.849475:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92b8386d20, -2
[1:1:0712/124712.869847:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124712.870907:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e22c9c4
[1:1:0712/124712.872096:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e22c9c4
[1:1:0712/124712.874044:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e22c9c4
[1:1:0712/124712.875921:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.876154:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.876385:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.876609:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.877399:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e22c9c4
[1:1:0712/124712.877847:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f92d02fd7ba
[1:1:0712/124712.878019:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f92d02f4def, 7f92d02fd77a, 7f92d02ff0cf
[1:1:0712/124712.883199:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e22c9c4
[1:1:0712/124712.883381:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e22c9c4
[1:1:0712/124712.883651:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e22c9c4
[1:1:0712/124712.884400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.884519:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.884617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.884732:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e22c9c4
[1:1:0712/124712.885186:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e22c9c4
[1:1:0712/124712.885343:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f92d02fd7ba
[1:1:0712/124712.885419:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f92d02f4def, 7f92d02fd77a, 7f92d02ff0cf
[1:1:0712/124712.887578:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124712.887923:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124712.888019:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe565b5bd8, 0x7ffe565b5b58)
[1:1:0712/124712.901825:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124712.907357:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[10181:10181:0712/124712.994525:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=10181
[10208:10208:0712/124712.995030:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=10208
[10148:10148:0712/124713.404980:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10148:10148:0712/124713.406474:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10148:10160:0712/124713.425067:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[10148:10160:0712/124713.425182:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[10148:10148:0712/124713.425275:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[10148:10148:0712/124713.425357:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[10148:10148:0712/124713.425519:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,10194, 4
[1:7:0712/124713.427656:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[10148:10173:0712/124713.488710:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/124713.541007:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xa3ea7c59220
[1:1:0712/124713.541284:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/124713.788082:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/124715.142717:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124715.144176:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[10148:10148:0712/124715.481425:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[10148:10148:0712/124715.481484:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/124716.067765:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124716.172981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ec808d01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/124716.173161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124716.181959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ec808d01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/124716.182131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124716.407260:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124716.407496:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124716.901690:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124716.909833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ec808d01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/124716.910126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124716.944643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124716.955096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ec808d01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/124716.955386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124716.967064:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/124716.973561:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xa3ea7c57e20
[1:1:0712/124716.973855:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[10148:10148:0712/124716.975834:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[10148:10148:0712/124716.989975:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[10148:10148:0712/124717.014636:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[10148:10148:0712/124717.014821:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/124717.071539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124718.060410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f92b9f612e0 0xa3ea7f30160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124718.061823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ec808d01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/124718.062161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124718.063697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[10148:10148:0712/124718.133520:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/124718.136845:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xa3ea7c58820
[1:1:0712/124718.137142:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[10148:10148:0712/124718.137561:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/124718.154984:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/124718.155249:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[10148:10148:0712/124718.159146:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[10148:10148:0712/124718.171121:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10148:10148:0712/124718.172366:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10148:10160:0712/124718.178815:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[10148:10160:0712/124718.178908:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[10148:10148:0712/124718.179060:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[10148:10148:0712/124718.179134:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[10148:10148:0712/124718.179262:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,10194, 4
[1:7:0712/124718.182711:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124718.843964:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/124719.478805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f92b9f612e0 0xa3ea8024de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124719.479997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ec808d01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/124719.480509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124719.481821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[10148:10148:0712/124719.579828:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[10148:10148:0712/124719.579951:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/124719.588722:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124719.994767:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124720.753404:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124720.753958:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[10148:10148:0712/124720.927920:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[10148:10179:0712/124720.928826:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/124720.929189:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124720.929467:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124720.929902:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124720.930085:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/124720.933348:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b21659, 1
[1:1:0712/124720.933778:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x23e5bf48, 0
[1:1:0712/124720.933943:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x10d32272, 3
[1:1:0712/124720.934093:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xa545177, 2
[1:1:0712/124720.934242:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 48ffffffbfffffffe523 5916ffffffb201 7751540a 7222ffffffd310 , 10104, 5
[1:1:0712/124720.935255:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10148:10179:0712/124720.935488:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGH��#Y�wQT
r"�s<s+
[10148:10179:0712/124720.935564:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is H��#Y�wQT
r"��Zs<s+
[10148:10179:0712/124720.935898:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10246, 5, 48bfe523 5916b201 7751540a 7222d310 
[1:1:0712/124720.936217:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92ce5380a0, 3
[1:1:0712/124720.936411:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92ce6c3080, 2
[1:1:0712/124720.936640:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92b8386d20, -2
[1:1:0712/124720.959068:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124720.959393:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a545177
[1:1:0712/124720.959791:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a545177
[1:1:0712/124720.960437:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a545177
[1:1:0712/124720.961918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.962113:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.962319:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.962508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.963221:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a545177
[1:1:0712/124720.963552:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f92d02fd7ba
[1:1:0712/124720.963767:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f92d02f4def, 7f92d02fd77a, 7f92d02ff0cf
[1:1:0712/124720.969838:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal a545177
[1:1:0712/124720.970215:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal a545177
[1:1:0712/124720.970983:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal a545177
[1:1:0712/124720.973128:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.973353:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.973544:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.973769:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal a545177
[1:1:0712/124720.975177:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal a545177
[1:1:0712/124720.975696:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f92d02fd7ba
[1:1:0712/124720.975875:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f92d02f4def, 7f92d02fd77a, 7f92d02ff0cf
[1:1:0712/124720.984516:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124720.985053:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124720.985217:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe565b5bd8, 0x7ffe565b5b58)
[1:1:0712/124720.999483:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124721.003989:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/124721.167780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124721.172605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ec808e2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/124721.172896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/124721.181872:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124721.231118:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xa3ea7c33220
[1:1:0712/124721.231289:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[10148:10148:0712/124721.984356:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10148:10148:0712/124722.013373:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[10148:10179:0712/124722.013787:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/124722.014026:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124722.014218:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124722.014609:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124722.014761:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/124722.017942:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e9d20b9, 1
[1:1:0712/124722.018242:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd720ecf, 0
[1:1:0712/124722.018448:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x13752537, 3
[1:1:0712/124722.018616:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x29334a36, 2
[1:1:0712/124722.018763:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcf0e720d ffffffb920ffffff9d2e 364a3329 37257513 , 10104, 6
[1:1:0712/124722.019692:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10148:10179:0712/124722.020049:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�r� �.6J3)7%us<s+
[10148:10179:0712/124722.020125:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �r� �.6J3)7%u�^s<s+
[1:1:0712/124722.020238:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92ce5380a0, 3
[10148:10179:0712/124722.020392:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10262, 6, cf0e720d b9209d2e 364a3329 37257513 
[1:1:0712/124722.020414:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92ce6c3080, 2
[1:1:0712/124722.020578:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f92b8386d20, -2
[1:1:0712/124722.034695:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124722.034931:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 29334a36
[1:1:0712/124722.035077:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 29334a36
[1:1:0712/124722.035305:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 29334a36
[1:1:0712/124722.035746:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.035893:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.036006:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[10148:10148:0712/124722.036095:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/124722.036096:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.036325:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 29334a36
[1:1:0712/124722.036449:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f92d02fd7ba
[1:1:0712/124722.036523:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f92d02f4def, 7f92d02fd77a, 7f92d02ff0cf
[1:1:0712/124722.037994:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 29334a36
[1:1:0712/124722.038156:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 29334a36
[1:1:0712/124722.038424:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 29334a36
[1:1:0712/124722.039143:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.039262:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.039359:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.039450:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 29334a36
[1:1:0712/124722.039908:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 29334a36
[1:1:0712/124722.040076:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f92d02fd7ba
[1:1:0712/124722.040149:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f92d02f4def, 7f92d02fd77a, 7f92d02ff0cf
[10148:10160:0712/124722.041398:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[10148:10160:0712/124722.041479:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[10148:10148:0712/124722.041546:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.alibaba.com/
[10148:10148:0712/124722.041583:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.alibaba.com/, https://www.alibaba.com/, 1
[10148:10148:0712/124722.041639:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.alibaba.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 19:47:21 GMT content-type:text/html;charset=UTF-8 vary:Accept-Encoding server:Apache-Coyote/1.1 set-cookie:JSESSIONID=95A9BE08DF77388DFD6814CC8BC412E0; Path=/; HttpOnly set-cookie:ali_apache_track=; Domain=.alibaba.com; Expires=Wed, 30-Jul-2087 23:01:28 GMT; Path=/ set-cookie:ali_apache_tracktmp=; Domain=.alibaba.com; Path=/ set-cookie:acs_usuc_t=acs_rt=c101f64cd9fd4f0e8b3ea8bd52ece406; Domain=.alibaba.com; Path=/ set-cookie:xman_t=MutZwweaY4vohIqv1/dthsVvVSQQ0xmi1ar9pak8d2u5PsyO+L4dVzUxLvhk6jeo; Domain=.alibaba.com; Path=/; HttpOnly p3p:CP="CAO PSA OUR" cache-control:s-maxage=3600 resin-trace:ali_resin_trace=aisn_homepage_version=null|septemberPromotion=black content-language:en-US strict-transport-security:max-age=31536000 strict-transport-security:max-age=31536000 content-encoding:gzip timing-allow-origin:* eagleid:0b090d4c15629608417591157efd00  ,0, 6
[1:1:0712/124722.042304:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124722.042634:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124722.042731:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe565b5bd8, 0x7ffe565b5b58)
[1:1:0712/124722.050562:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124722.056171:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/124722.075428:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/124722.118446:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124722.291033:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xa3ea7c4f220
[1:1:0712/124722.291319:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/124722.374328:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.alibaba.com/
[10148:10148:0712/124722.650908:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.alibaba.com/, https://www.alibaba.com/, 1
[10148:10148:0712/124722.651028:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.alibaba.com/, https://www.alibaba.com
[1:1:0712/124722.668574:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124722.790158:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124722.846412:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124722.971394:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124722.971683:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124722.980215:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 115 0x7f92b8039070 0xa3ea7d4da60 , "https://www.alibaba.com/"
[1:1:0712/124722.982284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , 
    var homeTimePage1 = +new Date();

[1:1:0712/124722.982514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "www.alibaba.com", 3, 1, , , 0
[1:1:0712/124723.020398:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0486619, 58, 1
[1:1:0712/124723.020675:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/124723.491626:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124723.491920:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124723.492758:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.493673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , 
    //pc
	try { document.domain = 'alibaba.com'; } catch(e) { }

[1:1:0712/124723.493894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "www.alibaba.com", 3, 1, , , 0
[1:1:0712/124723.495555:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "www.alibaba.com", "alibaba.com"
[1:1:0712/124723.497780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.500768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.551619:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.560300:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.562436:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124723.578919:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.590883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.609401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.619168:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7f92b8039070 0xa3ea7d93460 , "https://www.alibaba.com/"
[1:1:0712/124723.691944:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.199932, 151, 1
[1:1:0712/124723.692268:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124724.320865:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124724.321135:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124724.321761:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 230 0x7f92b8039070 0xa3ea7e34fe0 , "https://www.alibaba.com/"
[1:1:0712/124724.324010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (function(){try{if(localStorage){var b=localStorage.getItem("sc-header-login"),c=document.cookie.mat
[1:1:0712/124724.324286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124729.960078:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124729.960636:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124729.963345:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124729.963885:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124729.964307:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[10148:10148:0712/124748.119303:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/124748.124165:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/124748.500595:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 24.1794, 0, 0
[1:1:0712/124748.500893:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124748.696979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 243 0x7f92b9f612e0 0xa3ea7d58ce0 , "https://www.alibaba.com/"
[1:1:0712/124748.709454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , ,  !function(){function e(t,n,r){function i(o,s){if(!n[o]){if(!t[o]){var c="function"==typeof require&
[1:1:0712/124748.709657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124748.869958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 244 0x7f92b9f612e0 0xa3ea7d58b60 , "https://www.alibaba.com/"
[1:1:0712/124748.881310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , /*! 2019-03-20 10:16:09 v0.0.27 */
!(function (e) { function n (t) { if (o[t]) return o[t].exports; 
[1:1:0712/124748.881569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124749.321552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/124749.321738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124749.525958:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124749.526132:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124749.533833:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00767899, 71, 1
[1:1:0712/124749.533997:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124749.534811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124749.534924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124749.941798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/124749.942101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124749.960635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/124749.960933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124750.004202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124750.004552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124750.242269:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124750.242580:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124750.244006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124750.244285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124750.263948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.297526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.320867:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.362354:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.402799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.437757:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.474559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.476698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x1c6dde9429c8, 0xa3ea7ab79b0
[1:1:0712/124750.476925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 2000
[1:1:0712/124750.477293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 367
[1:1:0712/124750.477562:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 367 0x7f92b8039070 0xa3ea8222fe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 317 0x7f92b8039070 0xa3ea7ea5fe0 
[1:1:0712/124750.552486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.620008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.711406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.755016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 317 0x7f92b8039070 0xa3ea7ea5fe0 , "https://www.alibaba.com/"
[1:1:0712/124750.794846:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.552184, 25, 0
[1:1:0712/124750.795139:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124750.912142:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329 0x7f92b9f612e0 0xa3ea7e2f9e0 , "https://www.alibaba.com/"
[1:1:0712/124750.916132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , !function(t,a){var r=1e4,g_moduleConfig={uabModule:{stable:["AWSC/uab/117.js"],grey:["AWSC/uab/118.j
[1:1:0712/124750.916398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124750.923976:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124750.930299:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1c6dde9429c8, 0xa3ea7ab7c40
[1:1:0712/124750.930561:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/124750.936081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 390
[1:1:0712/124750.936354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 390 0x7f92b8039070 0xa3ea7d5d0e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 329 0x7f92b9f612e0 0xa3ea7e2f9e0 
[1:1:0712/124751.065316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124751.065641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124751.411915:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.alibaba.com/"
[1:1:0712/124751.412612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){b()}
[1:1:0712/124751.412888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124751.988590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124751.989390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , () {
                                if(performance && performance.getEntriesByName) {
             
[1:1:0712/124751.989658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124752.063781:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124752.064075:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124752.068671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124752.068976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124752.119300:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f92b8039070 0xa3ea7eb8a60 , "https://www.alibaba.com/"
[1:1:0712/124752.143127:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0788779, 65, 1
[1:1:0712/124752.143430:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124752.382962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124752.383317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124752.776578:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f92b9f612e0 0xa3ea7839be0 , "https://www.alibaba.com/"
[1:1:0712/124752.777538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , topBannerCallback({"code":500,"message":"no data "});
[1:1:0712/124752.777762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124752.790432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f92b9f612e0 0xa3ea7e30de0 , "https://www.alibaba.com/"
[1:1:0712/124752.797973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (function(){var e=function(){var e={},t={exports:e};var n=0;function r(){}function i(e,t,i){if("func
[1:1:0712/124752.798289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124752.864003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124752.867675:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x1c6dde9429c8, 0xa3ea7ab7a10
[1:1:0712/124752.867945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/124752.868343:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 462
[1:1:0712/124752.868576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 462 0x7f92b8039070 0xa3ea7eb8c60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 416 0x7f92b9f612e0 0xa3ea7e30de0 
[1:1:0712/124753.128627:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124753.128903:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124753.130421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124753.130594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124753.170692:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f92b8039070 0xa3ea7e35660 , "https://www.alibaba.com/"
[1:1:0712/124753.186958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f92b8039070 0xa3ea7e35660 , "https://www.alibaba.com/"
[1:1:0712/124753.197077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f92b8039070 0xa3ea7e35660 , "https://www.alibaba.com/"
[1:1:0712/124753.209527:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f92b8039070 0xa3ea7e35660 , "https://www.alibaba.com/"
[1:1:0712/124753.223904:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 433 0x7f92b8039070 0xa3ea7e35660 , "https://www.alibaba.com/"
[1:1:0712/124753.259642:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.130597, 97, 1
[1:1:0712/124753.259892:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124753.712021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (e){t(e)}
[1:1:0712/124753.712360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124753.720531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7f92cb598bb0 0xa3ea8057690 0 , "https://www.alibaba.com/"
[1:1:0712/124753.837236:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124754.143082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.143409:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/124754.143833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 494
[1:1:0712/124754.144066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 494 0x7f92b8039070 0xa3ea7eab260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.320930:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.321273:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/124754.321670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 507
[1:1:0712/124754.321918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 507 0x7f92b8039070 0xa3ea7d487e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.342555:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.342841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/124754.343223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 508
[1:1:0712/124754.343477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 508 0x7f92b8039070 0xa3ea7d4c9e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.372265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.372565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/124754.372984:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 509
[1:1:0712/124754.373228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 509 0x7f92b8039070 0xa3ea8423860 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.515034:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.515317:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/124754.515709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 519
[1:1:0712/124754.515987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 519 0x7f92b8039070 0xa3ea85fdd60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.573892:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.574189:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/124754.574628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 520
[1:1:0712/124754.574885:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 520 0x7f92b8039070 0xa3ea7eab960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.579472:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x1c6dde9429c8, 0xa3ea7ab7e78
[1:1:0712/124754.579761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 10
[1:1:0712/124754.580124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 521
[1:1:0712/124754.580364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7f92b8039070 0xa3ea78403e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f92cb598bb0 0xa3ea8057690 0 
[1:1:0712/124754.680535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124754.680865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124754.707098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 367, 7f92ba97e881
[1:1:0712/124754.730471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"317 0x7f92b8039070 0xa3ea7ea5fe0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124754.730893:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"317 0x7f92b8039070 0xa3ea7ea5fe0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124754.731323:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124754.731969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , () {
            if(!window.TOP_BANNER_DATA) {
                window.topBannerCallback({});
       
[1:1:0712/124754.732192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124754.884570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 462, 7f92ba97e881
[1:1:0712/124754.908781:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"416 0x7f92b9f612e0 0xa3ea7e30de0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124754.909153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"416 0x7f92b9f612e0 0xa3ea7e30de0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124754.909577:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124754.910144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){var t=e.modNames.join("^");try{e.callback()}catch(n){o({gmkey:"EXP",gokey:"pos=useCallbackError&c
[1:1:0712/124754.910360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124755.257649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , startMeasureFMP, (){var metaNodes=Array.prototype.filter.call(document.getElementsByName("data-spm"),function(node){r
[1:1:0712/124755.257854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/124755.993979:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124755.994260:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124755.995533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124755.995832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124756.059250:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.108586:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.186667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.278102:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.326545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.425823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.474199:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.545855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f92b8039070 0xa3ea7df5ce0 , "https://www.alibaba.com/"
[1:1:0712/124756.548945:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.554571, 18, 0
[1:1:0712/124756.549177:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124757.258928:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "open", "https://www.alibaba.com/"
[1:1:0712/124757.259803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , s.onopen, (){e.status="active";var t=e.getMsgQueue();t.length>0&&e.proessMsgQueue(t);var n="connTime="+((new D
[1:1:0712/124757.261177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124757.347335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 521, 7f92ba97e881
[1:1:0712/124757.378195:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124757.378570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124757.378972:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124757.379516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0712/124757.379773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
		remove user.10_cc45ad84 -> 0
[1:1:0712/124757.526868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124757.527193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124757.585636:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 509, 7f92ba97e881
[1:1:0712/124757.613665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124757.614025:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124757.614462:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124757.615003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124757.615247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124757.616995:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1c6dde9429c8, 0xa3ea7ab7950
[1:1:0712/124757.617218:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/124757.617589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 624
[1:1:0712/124757.617817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7f92b8039070 0xa3ea88e1660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 509 0x7f92b8039070 0xa3ea8423860 
[1:1:0712/124758.138378:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 494, 7f92ba97e881
[1:1:0712/124758.162003:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124758.162427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124758.162859:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124758.163473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0712/124758.163772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124758.466197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , rFACallBack, (){var hes=document.querySelectorAll(selector);if(hes.length>=config.minCount){var runTime=performan
[1:1:0712/124758.466530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124758.475645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1c6dde9429c8, 0xa3ea7ab7968
[1:1:0712/124758.475943:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/124758.476325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 636
[1:1:0712/124758.476577:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7f92b8039070 0xa3ea8afdd60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 577 0x7f92c734a960 0xa3ea82242e0 0xa3ea82242f0 
[1:1:0712/124758.813757:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 390, 7f92ba97e881
[1:1:0712/124758.842218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"329 0x7f92b9f612e0 0xa3ea7e2f9e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124758.842631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"329 0x7f92b9f612e0 0xa3ea7e2f9e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124758.843066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124758.843670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){S.state=b,x(S,r&&r.throwExceptionInCallback)}
[1:1:0712/124758.843925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124758.954341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x1c6dde9429c8, 0xa3ea7ab7950
[1:1:0712/124758.954717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/124758.955088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 650
[1:1:0712/124758.955314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 650 0x7f92b8039070 0xa3ea8fa89e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 390 0x7f92b8039070 0xa3ea7d5d0e0 
[1:1:0712/124759.372660:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124759.372942:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124759.374466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124759.374737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124759.393817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 606 0x7f92b8039070 0xa3ea7860a60 , "https://www.alibaba.com/"
[1:1:0712/124759.424783:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 606 0x7f92b8039070 0xa3ea7860a60 , "https://www.alibaba.com/"
[1:1:0712/124759.515482:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.142514, 335, 1
[1:1:0712/124759.515835:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124759.840275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 508, 7f92ba97e881
[1:1:0712/124759.871474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124759.871911:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124759.872410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124759.873029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/124759.873258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124759.942080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124759.942382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124800.005462:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124800.006237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , n.onload, (){i()}
[1:1:0712/124800.006510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124800.071600:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124800.072311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , n.onload, (){i()}
[1:1:0712/124800.072528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124800.074168:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 520, 7f92ba97e881
[1:1:0712/124800.104643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.105026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.105460:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124800.106102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/124800.106320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124800.167639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 624, 7f92ba97e881
[1:1:0712/124800.197761:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"509 0x7f92b8039070 0xa3ea8423860 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.198341:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"509 0x7f92b8039070 0xa3ea8423860 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.198793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124800.199441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124800.199689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124800.201866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1c6dde9429c8, 0xa3ea7ab7950
[1:1:0712/124800.202082:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/124800.202444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 684
[1:1:0712/124800.202688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 684 0x7f92b8039070 0xa3ea8ee3a60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 624 0x7f92b8039070 0xa3ea88e1660 
[1:1:0712/124800.678931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 636, 7f92ba97e881
[1:1:0712/124800.688856:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"577 0x7f92c734a960 0xa3ea82242e0 0xa3ea82242f0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.689208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"577 0x7f92c734a960 0xa3ea82242e0 0xa3ea82242f0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.689605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124800.690359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){trace(type,action)}
[1:1:0712/124800.690571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124800.691521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x1c6dde9429c8, 0xa3ea7ab7950
[1:1:0712/124800.691747:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/124800.692113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 692
[1:1:0712/124800.692351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7f92b8039070 0xa3ea8ee3be0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 636 0x7f92b8039070 0xa3ea8afdd60 
[1:1:0712/124800.765383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 507, 7f92ba97e881
[1:1:0712/124800.795290:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.795650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124800.796212:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124800.796799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/124800.797064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/124801.149763:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124801.150062:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/124801.151424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/124801.151720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124801.172147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.182285:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x1c6dde9429c8, 0xa3ea7ab79a0
[1:1:0712/124801.182596:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/124801.183015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 709
[1:1:0712/124801.183259:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f92b8039070 0xa3ea9099b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 669 0x7f92b8039070 0xa3ea8fa8660 
[1:1:0712/124801.245091:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.269596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.295466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.379429:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.421309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.463561:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 669 0x7f92b8039070 0xa3ea8fa8660 , "https://www.alibaba.com/"
[1:1:0712/124801.708988:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124801.710220:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124802.009468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124802.015258:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.865132, 0, 0
[1:1:0712/124802.015544:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124802.120544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 519, 7f92ba97e881
[1:1:0712/124802.135836:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3599eef42860","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124802.136236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f92cb598bb0 0xa3ea8057690 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/124802.136687:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/124802.137418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/124802.137653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124802.216498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f92b9f612e0 0xa3ea824b160 , "https://www.alibaba.com/"
[1:1:0712/124802.219458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0712/124802.219738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124802.307042:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 680 0x7f92b9f612e0 0xa3ea88e26e0 , "https://www.alibaba.com/"
[1:1:0712/124802.308091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="R3KTFa0Quk8CAdrxhyKpAJUj";goldlog.stag=1;
[1:1:0712/124802.308376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124802.309119:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/124802.334054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , document.readyState
[1:1:0712/124802.334449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/124802.455479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686 0x7f92b9f612e0 0xa3ea7759ce0 , "https://www.alibaba.com/"
[1:1:0712/124802.499041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 3599eef42860, , , !function(){function e(b,k,o,t,n){var h,d,p,v,u,f,l,C,g,w,m,S,j,A,x,y,E,_,R,O,T,D,P,M,I,B,L,N,V,W,z,
[1:1:0712/124802.499387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[10148:10148:0712/124810.125431:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/124815.483825:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124815.484290:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124815.485611:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0712/124815.490284:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/124815.587181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x1c6dde9429c8, 0xa3ea7ab7988
[1:1:0712/124815.587683:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/124815.588065:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 756
[1:1:0712/124815.588296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f92b8039070 0xa3eaa4c3d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 686 0x7f92b9f612e0 0xa3ea7759ce0 
[1:22:0712/124817.525571:WARNING:paced_sender.cc(261)] Elapsed time (2006 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124818.027248:WARNING:paced_sender.cc(261)] Elapsed time (2508 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124818.529396:WARNING:paced_sender.cc(261)] Elapsed time (3010 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124819.031542:WARNING:paced_sender.cc(261)] Elapsed time (3512 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124819.532434:WARNING:paced_sender.cc(261)] Elapsed time (4013 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124820.033496:WARNING:paced_sender.cc(261)] Elapsed time (4514 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124820.535611:WARNING:paced_sender.cc(261)] Elapsed time (5016 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124821.037731:WARNING:paced_sender.cc(261)] Elapsed time (5518 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124821.539843:WARNING:paced_sender.cc(261)] Elapsed time (6020 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124822.041982:WARNING:paced_sender.cc(261)] Elapsed time (6523 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124822.541878:WARNING:paced_sender.cc(261)] Elapsed time (7022 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124823.044023:WARNING:paced_sender.cc(261)] Elapsed time (7525 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124823.546300:WARNING:paced_sender.cc(261)] Elapsed time (8027 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124824.048433:WARNING:paced_sender.cc(261)] Elapsed time (8529 ms) longer than expected, limiting to 2000 ms
[1:22:0712/124824.550558:WARNING:paced_sender.cc(261)] Elapsed time (9031 ms) longer than expected, limiting to 2000 ms
