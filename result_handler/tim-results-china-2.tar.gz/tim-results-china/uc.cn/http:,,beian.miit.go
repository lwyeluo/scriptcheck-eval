[0712/124354.562045:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124354.562428:INFO:switcher_clone.cc(787)] backtrace rip is 7f311c9c7891
[0712/124355.474603:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124355.474990:INFO:switcher_clone.cc(787)] backtrace rip is 7fef04215891
[1:1:0712/124355.486634:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/124355.486903:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/124355.495420:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/124356.862892:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124356.863359:INFO:switcher_clone.cc(787)] backtrace rip is 7fa7bcad6891
[9747:9747:0712/124356.994421:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1b95f40a-b525-4eda-a73e-2d01020b54f5
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[9779:9779:0712/124357.128408:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9779
[9792:9792:0712/124357.128879:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9792
[9747:9747:0712/124357.632956:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9747:9777:0712/124357.634514:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/124357.634963:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124357.635411:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124357.636805:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124357.637175:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/124357.639658:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x32dad0b7, 1
[1:1:0712/124357.639883:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xb1ae4f, 0
[1:1:0712/124357.639977:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x26c069c1, 3
[1:1:0712/124357.640068:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b153ba, 2
[1:1:0712/124357.640176:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4fffffffaeffffffb100 ffffffb7ffffffd0ffffffda32 ffffffba53ffffffb101 ffffffc169ffffffc026 , 10104, 4
[1:1:0712/124357.640813:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1:1:0712/124357.640958:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef024500a0, 3
[9747:9777:0712/124357.641000:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGO��
[1:1:0712/124357.641080:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef025db080, 2
[9747:9777:0712/124357.641160:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is O��
[1:1:0712/124357.641171:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feeec29ed20, -2
[9747:9777:0712/124357.641596:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[9747:9777:0712/124357.641715:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9800, 4, 4faeb100 b7d0da32 ba53b101 c169c026 
[1:1:0712/124357.659438:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124357.660230:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b153ba
[1:1:0712/124357.661195:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b153ba
[1:1:0712/124357.662729:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b153ba
[1:1:0712/124357.664154:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.664336:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.664583:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.664759:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.665360:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b153ba
[1:1:0712/124357.665685:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef042157ba
[1:1:0712/124357.665816:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef0420cdef, 7fef0421577a, 7fef042170cf
[1:1:0712/124357.671152:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b153ba
[1:1:0712/124357.671501:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b153ba
[1:1:0712/124357.672184:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b153ba
[1:1:0712/124357.674100:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.674289:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.674483:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.674668:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b153ba
[1:1:0712/124357.675833:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b153ba
[1:1:0712/124357.676179:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef042157ba
[1:1:0712/124357.676304:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef0420cdef, 7fef0421577a, 7fef042170cf
[1:1:0712/124357.683603:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124357.684009:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124357.684149:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeaaeee528, 0x7ffeaaeee4a8)
[1:1:0712/124357.699514:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124357.705049:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9747:9747:0712/124358.270103:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9747:9747:0712/124358.271479:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9747:9759:0712/124358.294360:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9747:9759:0712/124358.294474:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[9747:9747:0712/124358.294610:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9747:9747:0712/124358.294712:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9747:9747:0712/124358.294890:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9800, 4
[1:7:0712/124358.296802:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124358.350791:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x35c72ba3e220
[1:1:0712/124358.351042:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[9747:9772:0712/124358.360216:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/124358.664974:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/124400.147590:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124400.151743:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9747:9747:0712/124400.483686:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9747:9747:0712/124400.483746:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/124400.891458:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124401.120102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08f6be441f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/124401.120439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124401.136812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08f6be441f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/124401.137156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124401.233443:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124401.233701:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124401.605111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124401.612762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08f6be441f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/124401.612992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124401.645446:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124401.655272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08f6be441f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/124401.655574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124401.667176:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/124401.670825:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x35c72ba3ce20
[1:1:0712/124401.671149:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9747:9747:0712/124401.671310:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9747:9747:0712/124401.685201:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9747:9747:0712/124401.708471:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9747:9747:0712/124401.708624:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/124401.763874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124402.779030:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7feeede792e0 0x35c72bbb9760 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124402.781510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08f6be441f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/124402.781940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124402.784999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9747:9747:0712/124402.864266:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/124402.868463:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x35c72ba3d820
[1:1:0712/124402.868861:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9747:9747:0712/124402.874041:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/124402.890531:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/124402.890773:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9747:9747:0712/124402.898096:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9747:9747:0712/124402.910847:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9747:9747:0712/124402.912239:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9747:9759:0712/124402.920462:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9747:9747:0712/124402.920573:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9747:9747:0712/124402.920670:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9747:9759:0712/124402.920627:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9747:9747:0712/124402.920810:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9800, 4
[1:7:0712/124402.927043:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124403.279340:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/124403.775949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7feeede792e0 0x35c72be18ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124403.777052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 08f6be441f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/124403.777298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124403.778113:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9747:9747:0712/124403.912584:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9747:9747:0712/124403.912644:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/124403.941495:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124404.270746:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124404.896271:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124404.896685:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9747:9747:0712/124404.898642:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9747:9777:0712/124404.899131:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/124404.899398:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124404.899785:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124404.900544:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124404.900794:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/124404.905528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1a039a76, 1
[1:1:0712/124404.906302:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x20ea1eff, 0
[1:1:0712/124404.906659:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x222a6913, 3
[1:1:0712/124404.907009:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x155fd69c, 2
[1:1:0712/124404.907438:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffff1effffffea20 76ffffff9a031a ffffff9cffffffd65f15 13692a22 , 10104, 5
[1:1:0712/124404.909812:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9747:9777:0712/124404.910379:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�� v���_i*"��2
[9747:9777:0712/124404.910543:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �� v���_i*"X&��2
[1:1:0712/124404.910805:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef024500a0, 3
[9747:9777:0712/124404.911077:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9844, 5, ff1eea20 769a031a 9cd65f15 13692a22 
[1:1:0712/124404.911314:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef025db080, 2
[1:1:0712/124404.911673:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7feeec29ed20, -2
[1:1:0712/124404.943542:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124404.943909:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 155fd69c
[1:1:0712/124404.944411:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 155fd69c
[1:1:0712/124404.944836:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 155fd69c
[1:1:0712/124404.945437:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.945566:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.945677:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.945798:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.946089:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 155fd69c
[1:1:0712/124404.946295:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef042157ba
[1:1:0712/124404.946383:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef0420cdef, 7fef0421577a, 7fef042170cf
[1:1:0712/124404.948338:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 155fd69c
[1:1:0712/124404.948539:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 155fd69c
[1:1:0712/124404.948878:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 155fd69c
[1:1:0712/124404.949773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.949918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.950033:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.950184:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 155fd69c
[1:1:0712/124404.950737:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 155fd69c
[1:1:0712/124404.950924:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef042157ba
[1:1:0712/124404.951014:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef0420cdef, 7fef0421577a, 7fef042170cf
[1:1:0712/124404.953931:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124404.954361:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124404.954474:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeaaeee528, 0x7ffeaaeee4a8)
[1:1:0712/124404.969232:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124404.974187:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/124405.095580:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x35c72ba00220
[1:1:0712/124405.095841:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/124405.136705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124405.141305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 08f6be56e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/124405.141652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/124405.150363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[9747:9747:0712/124405.426289:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9747:9747:0712/124405.428078:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9747:9759:0712/124405.438184:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[9747:9759:0712/124405.438332:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[9747:9747:0712/124405.438632:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[9747:9747:0712/124405.438711:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[9747:9747:0712/124405.438852:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 19:44:05 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: JSESSIONID=wArnuxvP4CxrwIr50-v3khPWybQqHPnRmatHYMZeq06RdRI4ha2x!285674180; path=/; HttpOnly Content-Encoding: gzip X-Via-JSL: 6baa318,- X-Cache: bypass  ,9844, 5
[1:7:0712/124405.447561:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124405.495443:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[9747:9747:0712/124405.591511:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[9747:9747:0712/124405.591569:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/124405.626350:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124405.704867:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124405.738487:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124405.738723:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/"
[1:1:0712/124405.856932:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://beian.miit.gov.cn/styles/styles.css"
[1:1:0712/124405.921564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7fef025db080 0x35c72bb5dce0 1 0 0x35c72bb5dcf8 , "http://beian.miit.gov.cn/"
[1:1:0712/124405.927535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 06d0b7a02860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/124405.927817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/124406.311311:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/124406.766989:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124406.767558:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124406.767946:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124406.768346:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124406.768712:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124407.282780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 139 0x7fef025db080 0x35c72bb5dce0 1 0 0x35c72bb5dcf8 , "http://beian.miit.gov.cn/"
[1:1:0712/124407.287605:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1cf1278829c8, 0x35c72b8881a0
[1:1:0712/124407.287862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://beian.miit.gov.cn/", 0
[1:1:0712/124407.288257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 146
[1:1:0712/124407.288486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 146 0x7feeebf51070 0x35c72bb385e0 , 5:3_http://beian.miit.gov.cn/, 1, -5:3_http://beian.miit.gov.cn/, 139 0x7fef025db080 0x35c72bb5dce0 1 0 0x35c72bb5dcf8 
[1:1:0712/124407.296218:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://beian.miit.gov.cn/"
[1:1:0712/124407.391119:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/124407.391380:INFO:render_frame_impl.cc(7019)] 	 [url] = http://beian.miit.gov.cn
[1:1:0712/124407.433195:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://beian.miit.gov.cn/, 146, 7feeee896881
[1:1:0712/124407.440146:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06d0b7a02860","ptid":"139 0x7fef025db080 0x35c72bb5dce0 1 0 0x35c72bb5dcf8 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0712/124407.440445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://beian.miit.gov.cn/","ptid":"139 0x7fef025db080 0x35c72bb5dce0 1 0 0x35c72bb5dcf8 ","rf":"5:3_http://beian.miit.gov.cn/"}
[1:1:0712/124407.440745:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://beian.miit.gov.cn/"
[1:1:0712/124407.441293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 06d0b7a02860, , , (){if(D.isReady)return;if(document.readyState!="loaded"&&document.readyState!="complete"){setTimeout
[1:1:0712/124407.441507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/124434.015037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 06d0b7a02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/124434.015358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[9747:9747:0712/124434.432844:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://beian.miit.gov.cn/
[9747:9747:0712/124434.448351:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/124434.455338:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[9747:9747:0712/124434.685576:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9747:9747:0712/124434.686535:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9747:9747:0712/124434.704677:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://beian.miit.gov.cn/
[9747:9747:0712/124434.704798:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/state/outPortal/loginPortal.action, 1
[9747:9747:0712/124434.704915:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://beian.miit.gov.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 19:44:34 GMT Content-Type: text/html; charset=GBK Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Language: en-US Content-Encoding: gzip X-Via-JSL: 6baa318,- X-Cache: bypass  ,9844, 5
[9747:9759:0712/124434.705787:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[9747:9759:0712/124434.705884:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/124434.706904:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124434.943106:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://beian.miit.gov.cn/
[1:1:0712/124435.002833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "unload", "http://beian.miit.gov.cn/"
[1:1:0712/124435.003587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 06d0b7a02860, , , (){if(typeof D!="undefined"&&!D.event.triggered)return D.event.handle.apply(arguments.callee.elem,ar
[1:1:0712/124435.003812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/124435.150989:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9747:9747:0712/124435.160464:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://beian.miit.gov.cn/, http://beian.miit.gov.cn/, 1
[9747:9747:0712/124435.160604:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://beian.miit.gov.cn/, http://beian.miit.gov.cn
[1:1:0712/124435.286186:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124435.342700:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124435.442528:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124435.442797:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124435.997233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7feeebf51070 0x35c72b61ec60 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124435.999705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://beian.miit.gov.cn/, 06d0b7a02860, , , /*
 * jQuery 1.2.6 - New Wave Javascript
 *
 * Copyright (c) 2008 John Resig (jquery.com)
 * Dua
[1:1:0712/124435.999967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://beian.miit.gov.cn/state/outPortal/loginPortal.action", "beian.miit.gov.cn", 3, 1, , , 0
[1:1:0712/124436.839610:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124436.902341:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124436.902836:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124436.920691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7feeebf51070 0x35c72b61ec60 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124436.924806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7feeebf51070 0x35c72b61ec60 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124436.928086:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7feeebf51070 0x35c72b61ec60 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124436.931502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7feeebf51070 0x35c72b61ec60 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124436.935975:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7feeebf51070 0x35c72b61ec60 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0712/124437.141555:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.222868, 1427, 1
[1:1:0712/124437.141732:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0100/000000.508122:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0100/000000.508210:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
[1:1:0100/000000.509635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7feeebf51070 0x35c72cb41760 , "http://beian.miit.gov.cn/state/outPortal/loginPortal.action"
