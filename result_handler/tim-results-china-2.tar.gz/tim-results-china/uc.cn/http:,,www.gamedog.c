[0712/125123.354780:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/125123.355071:INFO:switcher_clone.cc(787)] backtrace rip is 7f8715660891
[0712/125124.340916:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/125124.341199:INFO:switcher_clone.cc(787)] backtrace rip is 7f18d5cac891
[1:1:0712/125124.354232:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/125124.354500:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/125124.360046:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[10696:10696:0712/125125.649057:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bdd4a813-4576-440d-81f4-b54f3aa1f5cb
[0712/125125.853071:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/125125.853475:INFO:switcher_clone.cc(787)] backtrace rip is 7ff3f58f3891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[10729:10729:0712/125126.063821:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=10729
[10741:10741:0712/125126.064321:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=10741
[10696:10696:0712/125126.079388:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[10696:10727:0712/125126.080164:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/125126.080432:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/125126.080660:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/125126.081259:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/125126.081434:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/125126.084725:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d4aae1d, 1
[1:1:0712/125126.085129:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x21770f01, 0
[1:1:0712/125126.085295:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb3ac60e, 3
[1:1:0712/125126.085470:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x49c76bc, 2
[1:1:0712/125126.085667:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 010f7721 1dffffffae4a1d ffffffbc76ffffff9c04 0effffffc63a0b , 10104, 4
[1:1:0712/125126.086637:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10696:10727:0712/125126.086903:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGw!�J�v��:w�@
[1:1:0712/125126.086885:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18d3ee70a0, 3
[10696:10727:0712/125126.086985:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is w!�J�v��:�Sw�@
[1:1:0712/125126.087195:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18d4072080, 2
[1:1:0712/125126.087374:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18bdd35d20, -2
[10696:10727:0712/125126.087491:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[10696:10727:0712/125126.087576:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10743, 4, 010f7721 1dae4a1d bc769c04 0ec63a0b 
[1:1:0712/125126.110357:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/125126.111430:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 49c76bc
[1:1:0712/125126.112632:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 49c76bc
[1:1:0712/125126.114695:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 49c76bc
[1:1:0712/125126.116543:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.116802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.117028:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.117288:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.118123:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 49c76bc
[1:1:0712/125126.118528:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18d5cac7ba
[1:1:0712/125126.118697:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18d5ca3def, 7f18d5cac77a, 7f18d5cae0cf
[1:1:0712/125126.125117:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 49c76bc
[1:1:0712/125126.125501:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 49c76bc
[1:1:0712/125126.126239:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 49c76bc
[1:1:0712/125126.128280:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.128479:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.128665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.128850:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 49c76bc
[1:1:0712/125126.130114:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 49c76bc
[1:1:0712/125126.130472:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18d5cac7ba
[1:1:0712/125126.130625:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18d5ca3def, 7f18d5cac77a, 7f18d5cae0cf
[1:1:0712/125126.138305:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/125126.138721:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/125126.138869:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc59346cb8, 0x7ffc59346c38)
[1:1:0712/125126.156705:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/125126.161223:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[10696:10719:0712/125126.639428:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[10696:10696:0712/125126.665573:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10696:10696:0712/125126.667065:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10696:10696:0712/125126.692070:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[10696:10696:0712/125126.692376:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[10696:10696:0712/125126.692553:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,10743, 4
[10696:10708:0712/125126.693274:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[10696:10708:0712/125126.693379:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/125126.699372:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/125126.703110:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x33facd0eb220
[1:1:0712/125126.703417:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/125127.260157:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[10696:10696:0712/125128.885580:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[10696:10696:0712/125128.885652:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/125128.917702:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/125128.921213:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/125129.864767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/125129.865105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125129.878272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/125129.878594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125129.930657:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/125130.098217:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/125130.098496:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/125130.433028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/125130.441199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/125130.441532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125130.476350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/125130.486963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/125130.487280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125130.499044:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/125130.502432:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33facd0e9e20
[1:1:0712/125130.502660:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[10696:10696:0712/125130.503349:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[10696:10696:0712/125130.520037:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/125130.558825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[10696:10696:0712/125130.559951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[10696:10696:0712/125130.560083:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[10696:10696:0712/125130.599340:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/125131.092152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f18bf9102e0 0x33facd399be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/125131.093620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/125131.093818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125131.095313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[10696:10696:0712/125131.129947:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/125131.131028:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x33facd0ea820
[1:1:0712/125131.131278:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[10696:10696:0712/125131.141731:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/125131.143616:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/125131.143773:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[10696:10696:0712/125131.171819:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[10696:10696:0712/125131.187435:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10696:10696:0712/125131.188417:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10696:10708:0712/125131.194579:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[10696:10708:0712/125131.194659:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[10696:10696:0712/125131.197078:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[10696:10696:0712/125131.197116:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[10696:10696:0712/125131.197175:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,10743, 4
[1:7:0712/125131.198056:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/125131.719802:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/125132.152028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f18bf9102e0 0x33facd3990e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/125132.154427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/125132.154695:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125132.155475:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[10696:10696:0712/125132.230848:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[10696:10696:0712/125132.230990:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/125132.231230:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/125132.482743:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/125132.849814:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/125132.850118:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125133.068258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 535, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125133.073058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/125133.073380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125133.081281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[10696:10696:0712/125133.140937:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[10696:10727:0712/125133.141430:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/125133.141645:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/125133.141920:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/125133.142332:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/125133.142521:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/125133.145814:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2ff486e4, 1
[1:1:0712/125133.146216:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2b1b13cf, 0
[1:1:0712/125133.146377:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xac5e261, 3
[1:1:0712/125133.146525:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1099aee2, 2
[1:1:0712/125133.146669:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcf131b2b ffffffe4ffffff86fffffff42f ffffffe2ffffffaeffffff9910 61ffffffe2ffffffc50a , 10104, 5
[1:1:0712/125133.147670:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[10696:10727:0712/125133.147966:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�+��/⮙a��
5�@
[10696:10727:0712/125133.148051:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �+��/⮙a��
805�@
[1:1:0712/125133.147955:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18d3ee70a0, 3
[1:1:0712/125133.148160:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18d4072080, 2
[10696:10727:0712/125133.148319:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 10793, 5, cf131b2b e486f42f e2ae9910 61e2c50a 
[1:1:0712/125133.148347:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f18bdd35d20, -2
[1:1:0712/125133.171557:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/125133.171938:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1099aee2
[1:1:0712/125133.172277:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1099aee2
[1:1:0712/125133.172910:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1099aee2
[1:1:0712/125133.174312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.174530:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.174711:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.174918:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.175556:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1099aee2
[1:1:0712/125133.175871:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18d5cac7ba
[1:1:0712/125133.176015:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18d5ca3def, 7f18d5cac77a, 7f18d5cae0cf
[1:1:0712/125133.181747:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1099aee2
[1:1:0712/125133.182147:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1099aee2
[1:1:0712/125133.183010:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1099aee2
[1:1:0712/125133.184980:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.185199:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.185386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.185563:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1099aee2
[1:1:0712/125133.186769:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1099aee2
[1:1:0712/125133.187122:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f18d5cac7ba
[1:1:0712/125133.187269:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f18d5ca3def, 7f18d5cac77a, 7f18d5cae0cf
[1:1:0712/125133.193871:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/125133.194633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bf61c561f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/125133.194853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/125133.195302:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/125133.195827:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/125133.196020:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc59346cb8, 0x7ffc59346c38)
[1:1:0712/125133.210384:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/125133.214820:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/125133.397206:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x33facd0d8220
[1:1:0712/125133.397461:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/125133.505007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125133.506685:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/125133.506922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/125133.507206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125133.650075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125133.651026:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/125133.651238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/125133.651512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125134.224848:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/125134.283261:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/125134.404782:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.alibaba.com/"
[1:1:0712/125134.521224:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.aliexpress.com/"
[1:1:0712/125134.587286:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/125134.784244:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.1688.com/"
[1:1:0712/125134.845226:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/125134.938877:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/125135.008206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.009185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.009464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.076424:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.077432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.077726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.108420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.109469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.109767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.226422:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.227399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.227701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.249689:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.250159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.250318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.297060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.297577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.297719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.331583:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.332567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.332735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.363357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.363841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.363979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.389396:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.389888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.390026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.479596:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.480874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.481170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.528106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.528861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.529133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[10696:10696:0712/125135.576670:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[10696:10696:0712/125135.581860:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[10696:10708:0712/125135.618490:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[10696:10708:0712/125135.618593:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[10696:10696:0712/125135.618680:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.gamedog.cn/
[10696:10696:0712/125135.618721:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.gamedog.cn/, http://www.gamedog.cn/, 1
[10696:10696:0712/125135.618776:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.gamedog.cn/, HTTP/1.1 200 OK Server: JSP3/2.0.14 Date: Fri, 12 Jul 2019 19:51:35 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive ETag: W/"5d286c3c-2b2fb" Last-Modified: Fri, 12 Jul 2019 11:17:16 GMT Expires: Fri, 12 Jul 2019 20:06:00 GMT Cache-Control: max-age=900 Vary: Accept-Encoding Ohc-File-Size: 176891 Timing-Allow-Origin: * Ohc-Cache-HIT: bj2pbs95 [4], bjbgpcache175 [4] Content-Encoding: gzip  ,10793, 5
[1:7:0712/125135.622815:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/125135.625098:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.626028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.626322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.660703:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.gamedog.cn/
[1:1:0712/125135.727500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.728549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.728859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.778226:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.779200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.779535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[10696:10696:0712/125135.797590:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.gamedog.cn/, http://www.gamedog.cn/, 1
[10696:10696:0712/125135.797685:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.gamedog.cn/, http://www.gamedog.cn
[1:1:0712/125135.852033:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/125135.912492:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.913534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/125135.913831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125135.988635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/125135.989659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bf61c68e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/125135.989955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/125136.012582:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/125136.070179:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/125136.130720:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/125136.131005:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.gamedog.cn/"
[1:1:0712/125136.871829:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/125137.055287:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/125137.706090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125137.713882:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/125137.720044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.gamedog.cn/, 28236e642860, , , /*!
 * jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 *
 * Copyright 2010, John Resig
 * Du
[1:1:0712/125137.720307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.gamedog.cn/", "www.gamedog.cn", 3, 1, , , 0
		remove user.f_ede6830 -> 0
[1:1:0712/125137.777357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125137.923000:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125137.936657:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125137.950137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125137.957829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125137.967802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 204 0x7f18bdd50bd0 0x33facd1f5a58 , "http://www.gamedog.cn/"
[1:1:0712/125138.153021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125138.160418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.gamedog.cn/, 28236e642860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/125138.160719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.gamedog.cn/", "www.gamedog.cn", 3, 1, , , 0
[1:1:0712/125139.296920:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125139.600822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125139.607568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125139.609493:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125139.611309:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125139.613210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125139.616682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 228 0x7f18bdd50bd0 0x33facd2dded8 , "http://www.gamedog.cn/"
[1:1:0712/125143.977265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/125143.977888:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/125143.978262:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/125143.978707:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/125143.980686:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[10696:10696:0712/125207.268100:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/125207.400763:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[10696:10696:0712/125207.486333:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/gccm?psi=5c3d34f068b40f469152662c5fc3b9c3&di=586337&dri=0&dis=0&dai=0&ps=36x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562961099165&ti=%E6%89%8B%E6%B8%B8%E9%A2%86%E5%85%88%E9%97%A8%E6%88%B7_%E6%8E%92%E8%A1%8C%E6%A6%9C_%E6%B8%B8%E6%88%8F%E7%8B%97%E6%89%8B%E6%B8%B8%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562930236&rw=424&ltu=http%3A%2F%2Fwww.gamedog.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562961100&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[10696:10696:0712/125207.489160:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://pos.baidu.com/gccm?psi=5c3d34f068b40f469152662c5fc3b9c3&di=586337&dri=0&dis=0&dai=0&ps=36x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562961099165&ti=%E6%89%8B%E6%B8%B8%E9%A2%86%E5%85%88%E9%97%A8%E6%88%B7_%E6%8E%92%E8%A1%8C%E6%A6%9C_%E6%B8%B8%E6%88%8F%E7%8B%97%E6%89%8B%E6%B8%B8%E7%BD%91&ari=2&dbv=2&drs=1&pcs=1040x424&pss=1040x424&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562930236&rw=424&ltu=http%3A%2F%2Fwww.gamedog.cn%2F&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562961100&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://dup.baidustatic.com/js/ds.js (3)
[10696:10696:0712/125229.442670:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/125237.214039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.gamedog.cn/, 28236e642860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/125237.214365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.gamedog.cn/", "www.gamedog.cn", 3, 1, , , 0
