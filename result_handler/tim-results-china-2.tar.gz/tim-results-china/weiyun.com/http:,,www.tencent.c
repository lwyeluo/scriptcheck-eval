[0712/145653.592298:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145653.592811:INFO:switcher_clone.cc(787)] backtrace rip is 7f37cc857891
[0712/145654.657771:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145654.658167:INFO:switcher_clone.cc(787)] backtrace rip is 7f86ae5be891
[1:1:0712/145654.669982:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/145654.670305:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/145654.675813:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/145656.105811:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/145656.106327:INFO:switcher_clone.cc(787)] backtrace rip is 7feb1535b891
[27331:27331:0712/145656.261718:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/95f0b4e6-9799-4e9a-be86-cfd2a05f15e1
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[27363:27363:0712/145656.362533:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=27363
[27375:27375:0712/145656.362937:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=27375
[27331:27331:0712/145656.752869:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[27331:27361:0712/145656.753804:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/145656.754026:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145656.754277:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145656.754862:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145656.755022:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/145656.758002:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x24ede3a5, 1
[1:1:0712/145656.758385:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x158bc489, 0
[1:1:0712/145656.758549:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xeecaeeb, 3
[1:1:0712/145656.758712:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2505889f, 2
[1:1:0712/145656.758908:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff89ffffffc4ffffff8b15 ffffffa5ffffffe3ffffffed24 ffffff9fffffff880525 ffffffebffffffaeffffffec0e , 10104, 4
[1:1:0712/145656.760226:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[27331:27361:0712/145656.760472:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�ċ���$��%����2
[27331:27361:0712/145656.760563:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �ċ���$��%���\��2
[1:1:0712/145656.760454:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f86ac7f90a0, 3
[1:1:0712/145656.760667:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f86ac984080, 2
[27331:27361:0712/145656.760851:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/145656.760819:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8696647d20, -2
[27331:27361:0712/145656.760938:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 27383, 4, 89c48b15 a5e3ed24 9f880525 ebaeec0e 
[1:1:0712/145656.786185:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145656.787328:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2505889f
[1:1:0712/145656.788521:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2505889f
[1:1:0712/145656.790198:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2505889f
[1:1:0712/145656.791643:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.791842:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.792031:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.792267:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.792894:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2505889f
[1:1:0712/145656.793275:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f86ae5be7ba
[1:1:0712/145656.793428:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f86ae5b5def, 7f86ae5be77a, 7f86ae5c00cf
[1:1:0712/145656.799100:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2505889f
[1:1:0712/145656.799466:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2505889f
[1:1:0712/145656.800230:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2505889f
[1:1:0712/145656.802231:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.802423:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.802606:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.802811:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2505889f
[1:1:0712/145656.804055:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2505889f
[1:1:0712/145656.804467:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f86ae5be7ba
[1:1:0712/145656.804606:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f86ae5b5def, 7f86ae5be77a, 7f86ae5c00cf
[1:1:0712/145656.812263:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145656.812695:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145656.812841:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffbecc64e8, 0x7fffbecc6468)
[1:1:0712/145656.829190:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145656.836205:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[27331:27331:0712/145657.284543:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27331:27331:0712/145657.285952:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27331:27331:0712/145657.307796:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[27331:27331:0712/145657.307909:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[27331:27331:0712/145657.308077:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,27383, 4
[27331:27342:0712/145657.308455:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[27331:27342:0712/145657.308565:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/145657.310467:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[27331:27354:0712/145657.359896:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/145657.428119:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xab4b02b8220
[1:1:0712/145657.428272:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/145657.589385:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/145658.867902:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145658.871911:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[27331:27331:0712/145659.615613:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[27331:27331:0712/145659.615668:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145700.275797:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145700.505781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145700.506083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145700.522409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/145700.522680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145700.558173:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145700.558432:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145701.073135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145701.083255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145701.083569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145701.115343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145701.125997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/145701.126271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145701.138827:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/145701.142809:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xab4b02b6e20
[27331:27331:0712/145701.143089:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/145701.143106:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[27331:27331:0712/145701.158137:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[27331:27331:0712/145701.207931:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[27331:27331:0712/145701.208137:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/145701.220555:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145702.052955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f86982222e0 0xab4b045ace0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145702.054322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/145702.054537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145702.056077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145702.122993:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xab4b02b7820
[1:1:0712/145702.123219:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/145702.131946:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/145702.132090:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[27331:27331:0712/145702.139685:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[27331:27331:0712/145702.146289:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[27331:27331:0712/145702.164569:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[27331:27331:0712/145702.179475:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27331:27331:0712/145702.180776:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27331:27342:0712/145702.188280:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[27331:27342:0712/145702.188362:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[27331:27331:0712/145702.188631:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[27331:27331:0712/145702.188743:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[27331:27331:0712/145702.188921:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,27383, 4
[1:7:0712/145702.191633:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145702.634782:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/145703.186578:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 481 0x7f86982222e0 0xab4b046a960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145703.187640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/145703.187909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/145703.188690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[27331:27331:0712/145703.325823:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[27331:27331:0712/145703.325893:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/145703.358222:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145703.841037:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[27331:27331:0712/145704.128428:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[27331:27361:0712/145704.128846:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/145704.129067:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/145704.129283:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/145704.129691:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/145704.129832:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/145704.132953:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xb24cbf0, 1
[1:1:0712/145704.133351:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x11408b8e, 0
[1:1:0712/145704.133545:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x80a3ef, 3
[1:1:0712/145704.133734:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2efd79ea, 2
[1:1:0712/145704.133913:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8effffff8b4011 fffffff0ffffffcb240b ffffffea79fffffffd2e ffffffefffffffa3ffffff8000 , 10104, 5
[1:1:0712/145704.134920:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[27331:27361:0712/145704.136197:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��@��$�y�.
[27331:27361:0712/145704.136272:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��@��$�y�.
[27331:27361:0712/145704.136585:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 27429, 5, 8e8b4011 f0cb240b ea79fd2e efa38000 
[1:1:0712/145704.136437:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f86ac7f90a0, 3
[1:1:0712/145704.136744:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f86ac984080, 2
[1:1:0712/145704.136933:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8696647d20, -2
[1:1:0712/145704.157520:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/145704.157833:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2efd79ea
[1:1:0712/145704.158164:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2efd79ea
[1:1:0712/145704.158769:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2efd79ea
[1:1:0712/145704.160093:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.160297:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.160502:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.160674:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.161300:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2efd79ea
[1:1:0712/145704.161599:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f86ae5be7ba
[1:1:0712/145704.161728:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f86ae5b5def, 7f86ae5be77a, 7f86ae5c00cf
[1:1:0712/145704.167123:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2efd79ea
[1:1:0712/145704.167479:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2efd79ea
[1:1:0712/145704.168175:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2efd79ea
[1:1:0712/145704.170099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.170311:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.170524:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.170734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2efd79ea
[1:1:0712/145704.171906:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2efd79ea
[1:1:0712/145704.172263:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f86ae5be7ba
[1:1:0712/145704.172450:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f86ae5b5def, 7f86ae5be77a, 7f86ae5c00cf
[1:1:0712/145704.179759:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/145704.180264:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/145704.180432:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffbecc64e8, 0x7fffbecc6468)
[1:1:0712/145704.195595:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/145704.200811:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/145704.390024:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xab4b028f220
[1:1:0712/145704.390302:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/145704.610323:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145704.610647:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[27331:27331:0712/145705.053573:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27331:27331:0712/145705.056950:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27331:27342:0712/145705.082889:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[27331:27342:0712/145705.082987:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[27331:27331:0712/145705.083374:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.tencent.com/
[27331:27331:0712/145705.083456:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.tencent.com/, http://www.tencent.com/, 1
[27331:27331:0712/145705.083582:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.tencent.com/, HTTP/1.1 200 OK Server: NWS_UGC_HY Connection: keep-alive Date: Fri, 12 Jul 2019 21:43:03 GMT Cache-Control: max-age=600 Expires: Fri, 12 Jul 2019 21:53:03 GMT Last-Modified: Fri, 17 Feb 2017 02:11:37 GMT Content-Type: text/html Content-Length: 189 X-NWS-LOG-UUID: 15989984938083587327 b2f16ff66f2c450f6ef0e0b644a6e5d1 X-Cache-Lookup: Hit From Upstream X-Cache-Lookup: Hit From Disktank3  ,27429, 5
[1:7:0712/145705.090772:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145705.127172:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.tencent.com/
[27331:27331:0712/145705.242547:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.tencent.com/, http://www.tencent.com/, 1
[27331:27331:0712/145705.242604:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.tencent.com/, http://www.tencent.com
[1:1:0712/145705.244700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145705.249457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 23cdc544e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/145705.249824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/145705.255795:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/145705.270600:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/145705.330591:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145705.379880:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145705.380098:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.tencent.com/"
[1:1:0712/145705.384808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 121 0x7f86962fa070 0xab4b01321e0 , "http://www.tencent.com/"
[1:1:0712/145705.386646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tencent.com/, 3f43dcf22860, , , 
        location.href='https://www.tencent.com/zh-cn/index.html';
    
[1:1:0712/145705.386856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tencent.com/", "www.tencent.com", 3, 1, , , 0
[1:1:0712/145705.417175:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/145705.417337:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.tencent.com
[1:1:0712/145705.573951:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/145705.574713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 23cdc5321f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/145705.574944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/145706.440312:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145706.443071:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145706.443478:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145706.444220:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145706.444709:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145736.821774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.tencent.com/, 3f43dcf22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/145736.822145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.tencent.com/", "www.tencent.com", 3, 1, , , 0
[1:1:0712/145736.825499:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[27331:27331:0712/145737.107184:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.tencent.com/
[27331:27331:0712/145737.168728:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/145737.179816:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[27331:27331:0712/145737.489988:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27331:27331:0712/145737.491638:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27331:27342:0712/145737.530580:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[27331:27342:0712/145737.530682:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[27331:27331:0712/145737.530948:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.tencent.com/
[27331:27331:0712/145737.531051:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.tencent.com/, https://www.tencent.com/zh-cn/index.html, 1
[27331:27331:0712/145737.531225:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.tencent.com/, HTTP/1.1 200 status:200 server:NWSs date:Fri, 12 Jul 2019 21:43:36 GMT content-type:text/html content-length:3573 cache-control:max-age=600 expires:Fri, 12 Jul 2019 21:53:36 GMT last-modified:Wed, 22 May 2019 06:45:48 GMT content-encoding:gzip x-nws-log-uuid:ed197fa6-22b8-4e6b-8b48-21166355adbc x-cache-lookup:Hit From Upstream x-cache-lookup:Hit From Disktank3 Gz  ,27429, 5
[1:7:0712/145737.536889:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/145737.675309:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.tencent.com/
[1:1:0712/145737.747224:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[27331:27331:0712/145737.758852:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.tencent.com/, https://www.tencent.com/, 1
[27331:27331:0712/145737.758916:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.tencent.com/, https://www.tencent.com
[1:1:0712/145737.816721:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145737.938197:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145737.938500:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145738.211476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 251, "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145738.215177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.tencent.com/, 3f43dcf22860, , , /*!
  * Bowser - a browser detector
  * https://github.com/ded/bowser
  * MIT License | (c) Dusti
[1:1:0712/145738.215458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.tencent.com/zh-cn/index.html", "www.tencent.com", 3, 1, , , 0
[1:1:0712/145738.408562:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269, "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145738.410005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.tencent.com/, 3f43dcf22860, , , function removeXSS(s) {
	var pattern = new RegExp("[<>’”]")
	var rs = "";
	for (var i = 0; i < s
[1:1:0712/145738.410255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.tencent.com/zh-cn/index.html", "www.tencent.com", 3, 1, , , 0
[1:1:0712/145738.411338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269, "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145738.533142:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.122356, 321, 1
[1:1:0712/145738.533420:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145738.824112:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[27331:27413:0712/145738.873395:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/145739.011317:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145739.011620:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145739.019244:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f86962fa070 0xab4b034b1e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145739.038434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.tencent.com/, 3f43dcf22860, , , /*! jQuery v1.11.3 | (c) 2005, 2015 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){
[1:1:0712/145739.038843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.tencent.com/zh-cn/index.html", "www.tencent.com", 3, 1, , , 0
		remove user.f_b8c28789 -> 0
		remove user.10_f3b8bae6 -> 0
[1:1:0712/145739.355441:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f86962fa070 0xab4b034b1e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145739.361113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f86962fa070 0xab4b034b1e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145739.393353:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f86962fa070 0xab4b034b1e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145739.528380:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.516598, 0, 0
[1:1:0712/145739.528626:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/145739.694373:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.313038:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.609829:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/145741.609993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.611307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7f86962fa070 0xab4b04b87e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.612025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.tencent.com/, 3f43dcf22860, , , function autovideosize(){var e=$(document).width(),i=$(window).height(),n=$(document).height();$(".b
[1:1:0712/145741.612143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.tencent.com/zh-cn/index.html", "www.tencent.com", 3, 1, , , 0
[1:1:0712/145741.615801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7f86962fa070 0xab4b04b87e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.620402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7f86962fa070 0xab4b04b87e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.649757:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7f86962fa070 0xab4b04b87e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.672119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 370 0x7f86962fa070 0xab4b04b87e0 , "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145741.757099:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.tencent.com/zh-cn/index.html"
[1:1:0712/145742.092378:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3e1c97b43b40, 0xab4b0108440
[1:1:0712/145742.092693:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.tencent.com/zh-cn/index.html", 0
[1:1:0712/145742.093122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.tencent.com/, 465
[1:1:0712/145742.093355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 465 0x7f86962fa070 0xab4afe887e0 , 5:3_https://www.tencent.com/, 1, -5:3_https://www.tencent.com/, 370 0x7f86962fa070 0xab4b04b87e0 
[1:1:0712/145742.144959:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.tencent.com/zh-cn/index.html", 13
[1:1:0712/145742.145476:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.tencent.com/, 469
[1:1:0712/145742.145746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f86962fa070 0xab4b0b339e0 , 5:3_https://www.tencent.com/, 1, -5:3_https://www.tencent.com/, 370 0x7f86962fa070 0xab4b04b87e0 
