[0712/144918.248649:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144918.249042:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f6f01f891
[0712/144919.203355:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144919.203919:INFO:switcher_clone.cc(787)] backtrace rip is 7f8ed40be891
[1:1:0712/144919.216892:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/144919.217192:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/144919.222787:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[26408:26408:0712/144920.405354:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/650a3046-0cac-4843-8c86-6308c8c39fcd
[0712/144920.695988:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144920.696435:INFO:switcher_clone.cc(787)] backtrace rip is 7f7af7be3891
[26408:26408:0712/144920.840957:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26408:26438:0712/144920.841730:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/144920.841968:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144920.842198:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144920.842851:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144920.843017:INFO:zygote_linux.cc(633)] 		cid is 4
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/144920.846019:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d6b7388, 1
[1:1:0712/144920.846399:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x48666f7, 0
[1:1:0712/144920.846601:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x106582ae, 3
[1:1:0712/144920.846774:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b4c11c2, 2
[1:1:0712/144920.846978:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff766ffffff8604 ffffff88736b2d ffffffc2114c1b ffffffaeffffff826510 , 10104, 4
[1:1:0712/144920.847916:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26408:26438:0712/144920.848181:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�f��sk-�L��e6�'
[26408:26438:0712/144920.848252:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �f��sk-�L��e�6�'
[1:1:0712/144920.848169:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ed22f90a0, 3
[1:1:0712/144920.848417:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ed2484080, 2
[26408:26438:0712/144920.848646:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/144920.848574:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ebc147d20, -2
[26408:26438:0712/144920.848724:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26454, 4, f7668604 88736b2d c2114c1b ae826510 
[1:1:0712/144920.863353:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144920.864317:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b4c11c2
[1:1:0712/144920.865403:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b4c11c2
[1:1:0712/144920.867061:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b4c11c2
[1:1:0712/144920.868634:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.868828:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.869008:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.869194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.869836:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b4c11c2
[1:1:0712/144920.870161:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8ed40be7ba
[1:1:0712/144920.870309:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8ed40b5def, 7f8ed40be77a, 7f8ed40c00cf
[1:1:0712/144920.876707:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b4c11c2
[1:1:0712/144920.877114:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b4c11c2
[1:1:0712/144920.877864:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b4c11c2
[1:1:0712/144920.879890:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.880107:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.880293:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.880523:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b4c11c2
[1:1:0712/144920.881770:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b4c11c2
[1:1:0712/144920.882137:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8ed40be7ba
[1:1:0712/144920.882270:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8ed40b5def, 7f8ed40be77a, 7f8ed40c00cf
[1:1:0712/144920.890512:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144920.891084:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144920.891246:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffc0b7d638, 0x7fffc0b7d5b8)
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1:1:0712/144920.910654:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144920.913316:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26441:26441:0712/144920.926934:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26441
[26462:26462:0712/144920.927361:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26462
[26408:26408:0712/144921.455952:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26408:26408:0712/144921.457344:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26408:26420:0712/144921.477634:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26408:26420:0712/144921.477741:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26408:26408:0712/144921.477921:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26408:26408:0712/144921.478003:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26408:26408:0712/144921.478158:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26454, 4
[1:7:0712/144921.480597:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[26408:26432:0712/144921.516806:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/144921.617145:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x135b863a220
[1:1:0712/144921.617410:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/144921.972458:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/144923.551528:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144923.553747:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26408:26408:0712/144923.874254:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26408:26408:0712/144923.874419:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144924.507073:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144924.729829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd39f0e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144924.730161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144924.747132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd39f0e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144924.747492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144924.793308:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144924.793618:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144925.051137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144925.059496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd39f0e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144925.059819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144925.111420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144925.121981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd39f0e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144925.122234:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144925.134139:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[26408:26408:0712/144925.136862:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144925.137571:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x135b8638e20
[1:1:0712/144925.137806:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26408:26408:0712/144925.143698:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26408:26408:0712/144925.177383:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26408:26408:0712/144925.177544:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[26408:26408:0712/144925.192684:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/144925.214900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144925.876325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f8ebdd222e0 0x135b88f7660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144925.878142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd39f0e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/144925.878411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144925.879995:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26408:26408:0712/144925.956180:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144925.957374:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x135b8639820
[1:1:0712/144925.958067:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/144925.970142:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144925.970379:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26408:26408:0712/144925.970621:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[26408:26408:0712/144925.997565:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26408:26408:0712/144926.017588:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26408:26408:0712/144926.018260:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26408:26408:0712/144926.021095:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26408:26408:0712/144926.021154:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26408:26408:0712/144926.021252:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26454, 4
[26408:26420:0712/144926.022669:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26408:26420:0712/144926.022735:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/144926.029651:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144926.567758:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/144927.074016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f8ebdd222e0 0x135b88c1be0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144927.075137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1bd39f0e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/144927.075385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144927.076260:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26408:26408:0712/144927.216874:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26408:26408:0712/144927.217033:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/144927.246597:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144927.658987:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144928.329243:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144928.329575:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[26408:26408:0712/144928.500362:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26408:26438:0712/144928.500754:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/144928.500937:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144928.501221:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144928.501623:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144928.501795:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/144928.505423:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1898a736, 1
[1:1:0712/144928.505830:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1890ae34, 0
[1:1:0712/144928.506029:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3412b3dd, 3
[1:1:0712/144928.506240:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1050f201, 2
[1:1:0712/144928.506435:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 34ffffffaeffffff9018 36ffffffa7ffffff9818 01fffffff25010 ffffffddffffffb31234 , 10104, 5
[1:1:0712/144928.507489:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26408:26438:0712/144928.507720:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING4��6���Pݳ4��'
[26408:26438:0712/144928.507786:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 4��6���Pݳ4ؒ��'
[1:1:0712/144928.507894:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ed22f90a0, 3
[26408:26438:0712/144928.508102:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26505, 5, 34ae9018 36a79818 01f25010 ddb31234 
[1:1:0712/144928.508171:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ed2484080, 2
[1:1:0712/144928.508435:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8ebc147d20, -2
[1:1:0712/144928.529515:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144928.529936:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1050f201
[1:1:0712/144928.530305:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1050f201
[1:1:0712/144928.530972:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1050f201
[1:1:0712/144928.532495:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.532731:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.532950:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.533137:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.533826:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1050f201
[1:1:0712/144928.534178:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8ed40be7ba
[1:1:0712/144928.534369:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8ed40b5def, 7f8ed40be77a, 7f8ed40c00cf
[1:1:0712/144928.540185:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1050f201
[1:1:0712/144928.540586:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1050f201
[1:1:0712/144928.541195:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1050f201
[1:1:0712/144928.543167:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.543479:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.543776:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.544085:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1050f201
[1:1:0712/144928.545391:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1050f201
[1:1:0712/144928.545816:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8ed40be7ba
[1:1:0712/144928.546011:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8ed40b5def, 7f8ed40be77a, 7f8ed40c00cf
[1:1:0712/144928.555403:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144928.556077:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144928.556283:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffc0b7d638, 0x7fffc0b7d5b8)
[1:1:0712/144928.570688:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144928.573477:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/144928.664152:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144928.668812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1bd39f20e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/144928.669177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144928.677684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144928.775622:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x135b85e2220
[1:1:0712/144928.775877:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26408:26408:0712/144929.595624:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26408:26408:0712/144929.602524:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26408:26420:0712/144929.626191:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26408:26408:0712/144929.626454:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://support.qq.com/
[26408:26408:0712/144929.626526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://support.qq.com/, https://support.qq.com/products/16980?, 1
[26408:26408:0712/144929.626612:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://support.qq.com/, HTTP/1.1 200 status:200 server:nginx date:Fri, 12 Jul 2019 21:49:29 GMT content-type:text/html; charset=UTF-8 vary:Accept-Encoding set-cookie:_tucao_userinfo=K3Nmd1ZxdldiTmpDanJrcUkyNHZFSksyWmNXay8rYzBKdDlrZE9EVTVWL1g4YVNiaTE5TkpKVXNRWGdmaTNQT0JDdDllZzhJSXg1UWY0eldnNWFUQm9qOElTUnZyYTZ3NFlkT0pkdEpQblcyNTR5bmlJVzBSMXE4YW5lRDFGb2t6SVRuYWkwTkV3cXpRMnplT1p1YVE3cjE0eXNpbE45TmNidW0va2pWcGFpaUd0N2tWQVhpMkpnTWJoMStBYzhw--3yE37%2FaRGD4wglCpjpcv6g%3D%3D; path=/; domain=qq.com; HttpOnly set-cookie:_tucao_session=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/ set-cookie:_tucao_session=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/; domain=qq.com set-cookie:_tucao_session=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/; domain=tucao.qq.com set-cookie:_tucao_session=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/; domain=support.qq.com set-cookie:_tucao_session=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/; domain=tucao.oa.com set-cookie:_tucao_session=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/; domain=tucao-internal.oa.com content-encoding:gzip front-end-https:on content-security-policy:default-src 'self' data: tucao.qq.com support.qq.com; script-src 'self' 'unsafe-inline' 'unsafe-eval'  tucao.qq.com support.qq.com tajs.qq.com imgcache.qq.com js.aq.qq.com mat1.gtimg.com res.wx.qq.com ui.ptlogin2.qq.com xui.ptlogin2.qq.com ssl.ptlogin2.qq.com cdn.ur.qq.com wxapp.qq.com qzs.qq.com www.qq.com/404/ mat1.gtimg.com/www/ res.wx.qq.com sdi.3g.qq.com/js huayang.qq.com/polyfill_service/; style-src 'self' 'unsafe-inline' tucao.qq.com support.qq.com cdn.ur.qq.com h5app.qq.com imgcache.qq.com tajs.qq.com; img-src  data: *; frame-src 'self' *.qq.com *.gtimg.com *.myapp.com weixin: weixinping:; worker-src 'self' tucao.qq.com support.qq.com xui.ptlogin2.qq.com open.weixin.com open.weixin.qq.com; connect-src 'self'  ws: tucao.qq.com horizon-assets.qq.com; report-uri https://aq.qq.com/cn2/manage/mbtoken/hijack_csp_report;  ,26505, 5
[26408:26420:0712/144929.626351:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/144929.630379:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144929.686447:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://support.qq.com/
[26408:26408:0712/144929.821472:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://support.qq.com/, https://support.qq.com/, 1
[26408:26408:0712/144929.821535:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://support.qq.com/, https://support.qq.com
[1:1:0712/144929.827431:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144929.856678:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144929.936782:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144929.937065:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://support.qq.com/products/16980?"
[1:1:0712/144929.969555:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7f8ebbdfa070 0x135b875ed60 , "https://support.qq.com/products/16980?"
[1:1:0712/144929.972294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , 
                    var _User = null;
                    var productID = _ProductId = '16980';
   
[1:1:0712/144929.972554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144930.178747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157, "https://support.qq.com/products/16980?"
[1:1:0712/144930.186066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , function pgvGetCookieByName(e){var t=Tcss.d.cookie.match(new RegExp("(^|\\s)"+e+"([^;]*)(;|$)"));ret
[1:1:0712/144930.186352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144930.190753:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144930.196646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2859f75029c8, 0x135b8471a18
[1:1:0712/144930.196932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://support.qq.com/products/16980?", 5000
[1:1:0712/144930.197557:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 163
[1:1:0712/144930.197810:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 163 0x7f8ebbdfa070 0x135b875aae0 , 5:3_https://support.qq.com/, 1, -5:3_https://support.qq.com/, 157
[1:1:0712/144930.204932:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157, "https://support.qq.com/products/16980?"
[1:1:0712/144930.260745:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2859f75029c8, 0x135b84719a8
[1:1:0712/144930.260933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://support.qq.com/products/16980?", 5000
[1:1:0712/144930.261126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 166
[1:1:0712/144930.261240:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 166 0x7f8ebbdfa070 0x135b87510e0 , 5:3_https://support.qq.com/, 1, -5:3_https://support.qq.com/, 157
[1:1:0712/144930.266588:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157, "https://support.qq.com/products/16980?"
[1:1:0712/144930.278992:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144930.424195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172, "https://support.qq.com/products/16980?"
[1:1:0712/144930.427521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , /* Disable minification (remove `.min` from URL path) for more info */

(function(undefined) {var It
[1:1:0712/144930.427789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144930.438048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144930.465200:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/144931.071485:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 203 0x7f8ebc162bd0 0x135b8750c58 , "https://support.qq.com/products/16980?"
[1:1:0712/144931.162053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , !function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={i:r,l:!1,exports:{}};return e[r].
[1:1:0712/144931.162386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144938.158038:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144938.158530:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144938.158905:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144938.159541:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144938.160029:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144940.980561:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144940.981017:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144942.604426:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://support.qq.com/products/16980?", 0
[1:1:0712/144942.605222:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 318
[1:1:0712/144942.605542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 318 0x7f8ebbdfa070 0x135bc590ae0 , 5:3_https://support.qq.com/, 1, -5:3_https://support.qq.com/, 203 0x7f8ebc162bd0 0x135b8750c58 
[1:1:0712/144946.755973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2859f75029c8, 0x135b8471960
[1:1:0712/144946.756290:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://support.qq.com/products/16980?", 0
[1:1:0712/144946.756720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 325
[1:1:0712/144946.757010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 325 0x7f8ebbdfa070 0x135bdcaec60 , 5:3_https://support.qq.com/, 1, -5:3_https://support.qq.com/, 203 0x7f8ebc162bd0 0x135b8750c58 
[1:1:0712/144947.781781:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144947.788282:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://support.qq.com/products/16980?"
[1:1:0712/144948.163937:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.164742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.164969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.240869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.241840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.242100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.257501:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.258263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.258526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.274417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.275100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.275379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.305703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.306491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.306715:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.322420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.323096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.323337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.328736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.329426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.329650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.346365:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.347131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.347415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.373900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.374825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.375084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.391984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.392827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.393065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.399137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.399799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.400041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.415553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.416345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.416568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.447647:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.448438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.448677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.463949:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.464735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.464961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.478920:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.479715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.479964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.487194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.487841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.488081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.497754:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.498458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.498692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.514609:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.515284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.515511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.531447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.532097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.532350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.548394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.549141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.549405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.580793:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.581593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.581819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.593065:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.593786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.594074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.609437:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.610064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.610277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.625122:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.625741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.625951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.656541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.657306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.657576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.673095:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.673769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.673993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.683750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.684391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.684617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.700453:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.701071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.701287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.713974:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.714676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.714902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.730729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.731345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.731564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.742507:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.743140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.743391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.760313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.760998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.761229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.780961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.781624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.781845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.797732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.798347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.798570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.810453:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144948.811062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144948.811281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.877011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/144948.877300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144948.895229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/144948.895529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144950.037689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/144950.037992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144950.044214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/144950.044512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144950.073262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/144950.073538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144950.084395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/144950.084642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144951.430535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/144951.430837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144951.440319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/144951.440533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144952.907793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 163, 7f8ebe73f881
[1:1:0712/144952.922537:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"00bd53322860","ptid":"157","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144952.922778:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://support.qq.com/","ptid":"157","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144952.923093:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://support.qq.com/products/16980?"
[1:1:0712/144952.923700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (){(function(){var APC_r_url="//jqmt.qq.com/rpt.png?plf=3&";var APC_count=0,APC_idx=[],APC_task=[];f
[1:1:0712/144952.923878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144952.926661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 166, 7f8ebe73f881
[1:1:0712/144952.941496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"00bd53322860","ptid":"157","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144952.941742:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://support.qq.com/","ptid":"157","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144952.942049:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://support.qq.com/products/16980?"
[1:1:0712/144952.942612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (){t(0,100,0),function(t){function e(t){var e=document.createElement("script");e.src="https://captch
[1:1:0712/144952.942791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144952.992239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 318, 7f8ebe73f881
[1:1:0712/144953.008178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"00bd53322860","ptid":"203 0x7f8ebc162bd0 0x135b8750c58 ","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144953.008532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://support.qq.com/","ptid":"203 0x7f8ebc162bd0 0x135b8750c58 ","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144953.008947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://support.qq.com/products/16980?"
[1:1:0712/144953.009874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , undefined
[1:1:0712/144953.010100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144953.034562:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://support.qq.com/, 325, 7f8ebe73f881
[1:1:0712/144953.053519:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"00bd53322860","ptid":"203 0x7f8ebc162bd0 0x135b8750c58 ","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144953.053836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://support.qq.com/","ptid":"203 0x7f8ebc162bd0 0x135b8750c58 ","rf":"5:3_https://support.qq.com/"}
[1:1:0712/144953.054253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://support.qq.com/products/16980?"
[1:1:0712/144953.054910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (){var t=window.innerHeight-e._elLayoutBody.getBoundingClientRect().top;e._elLayoutBody.style.minHei
[1:1:0712/144953.055135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144953.509249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144953.510005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144953.510232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144953.510991:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144953.577199:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144953.577952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , (e){if(!k){var n=e.target,i=n.tagName;n.src;if("IMG"==i||"VIDEO"==i||"AUDIO"==i||"SOURCE"==i){var t=
[1:1:0712/144953.578201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
[1:1:0712/144953.578789:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://support.qq.com/products/16980?"
[1:1:0712/144954.255596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://support.qq.com/, 00bd53322860, , , 
[1:1:0712/144954.255883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://support.qq.com/products/16980?", "support.qq.com", 3, 1, , , 0
		remove user.11_319f31c7 -> 0
		remove user.12_7351ab90 -> 0
[26408:26408:0712/144958.827769:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/144958.975349:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/145002.645116:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145002.645688:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/145002.646178:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[26408:26408:0712/145020.819474:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
