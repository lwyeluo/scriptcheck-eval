[0712/144642.977005:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144642.977336:INFO:switcher_clone.cc(787)] backtrace rip is 7f69afde6891
[0712/144643.973367:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144643.973702:INFO:switcher_clone.cc(787)] backtrace rip is 7f0341d7d891
[1:1:0712/144643.985419:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/144643.985676:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/144643.993858:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/144645.462445:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/144645.462872:INFO:switcher_clone.cc(787)] backtrace rip is 7f3342e84891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[26071:26071:0712/144645.677021:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26071
[26082:26082:0712/144645.677443:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=26082
[26039:26039:0712/144645.836220:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f4cff03b-b620-4ac3-be29-1212944dc301
[26039:26039:0712/144646.426849:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[26039:26069:0712/144646.427532:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/144646.427789:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144646.428032:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144646.428644:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144646.428830:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/144646.431929:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x11ac2d75, 1
[1:1:0712/144646.432292:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xb29a6ee, 0
[1:1:0712/144646.432503:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x24e8c4d1, 3
[1:1:0712/144646.432726:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x7c3d2b3, 2
[1:1:0712/144646.432967:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffeeffffffa6290b 752dffffffac11 ffffffb3ffffffd2ffffffc307 ffffffd1ffffffc4ffffffe824 , 10104, 4
[1:1:0712/144646.433991:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26039:26069:0712/144646.434274:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�)u-�������$&�j.
[26039:26069:0712/144646.434347:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �)u-�������$�#&�j.
[1:1:0712/144646.434268:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f033ffb80a0, 3
[1:1:0712/144646.434471:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0340143080, 2
[26039:26069:0712/144646.434606:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/144646.434634:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0329e06d20, -2
[26039:26069:0712/144646.434707:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26092, 4, eea6290b 752dac11 b3d2c307 d1c4e824 
[1:1:0712/144646.450453:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144646.451357:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7c3d2b3
[1:1:0712/144646.452381:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7c3d2b3
[1:1:0712/144646.454099:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7c3d2b3
[1:1:0712/144646.455927:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.456170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.456401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.456640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.457429:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7c3d2b3
[1:1:0712/144646.457849:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0341d7d7ba
[1:1:0712/144646.458026:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0341d74def, 7f0341d7d77a, 7f0341d7f0cf
[1:1:0712/144646.464928:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7c3d2b3
[1:1:0712/144646.465352:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7c3d2b3
[1:1:0712/144646.466258:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7c3d2b3
[1:1:0712/144646.468790:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.469029:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.469256:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.469480:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7c3d2b3
[1:1:0712/144646.471037:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7c3d2b3
[1:1:0712/144646.471481:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0341d7d7ba
[1:1:0712/144646.471669:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0341d74def, 7f0341d7d77a, 7f0341d7f0cf
[1:1:0712/144646.481164:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144646.481655:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144646.481853:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc17301478, 0x7ffc173013f8)
[1:1:0712/144646.499430:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144646.506672:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[26039:26039:0712/144647.079130:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26039:26039:0712/144647.080525:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26039:26051:0712/144647.101077:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[26039:26051:0712/144647.101180:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[26039:26039:0712/144647.101341:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[26039:26039:0712/144647.101423:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[26039:26039:0712/144647.101572:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,26092, 4
[1:7:0712/144647.107943:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144647.167756:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x154ebcfcf220
[1:1:0712/144647.168034:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[26039:26064:0712/144647.171438:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/144647.441510:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/144649.164690:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144649.169485:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[26039:26039:0712/144649.319705:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[26039:26039:0712/144649.319809:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144650.027342:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144650.295156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144650.295419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144650.322230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/144650.322401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144650.353064:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144650.353212:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144650.760738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144650.764609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144650.764771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144650.809292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144650.812433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/144650.812556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144650.816379:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/144650.820701:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x154ebcfcde20
[1:1:0712/144650.820880:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[26039:26039:0712/144650.829022:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[26039:26039:0712/144650.832584:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[26039:26039:0712/144650.859598:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[26039:26039:0712/144650.859777:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/144650.902416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144651.613139:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f032b9e12e0 0x154ebd238060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144651.614439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/144651.614648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144651.616155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26039:26039:0712/144651.693575:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/144651.695496:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x154ebcfce820
[1:1:0712/144651.696736:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[26039:26039:0712/144651.710487:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/144651.714914:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/144651.715185:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[26039:26039:0712/144651.745882:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[26039:26039:0712/144651.761786:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26039:26039:0712/144651.762780:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26039:26051:0712/144651.769364:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[26039:26051:0712/144651.769443:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[26039:26039:0712/144651.772247:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[26039:26039:0712/144651.772327:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[26039:26039:0712/144651.772457:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,26092, 4
[1:7:0712/144651.773794:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144652.277995:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/144652.420666:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7f032b9e12e0 0x154ebcecf4e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144652.421696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/144652.421936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/144652.422804:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[26039:26039:0712/144652.636301:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[26039:26039:0712/144652.636463:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/144652.652898:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144653.027815:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[26039:26039:0712/144653.314765:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[26039:26069:0712/144653.315248:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/144653.315445:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/144653.315647:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/144653.316041:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/144653.316232:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/144653.319368:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x29fe43fe, 1
[1:1:0712/144653.319732:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26a6a68, 0
[1:1:0712/144653.319897:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3d780382, 3
[1:1:0712/144653.320051:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1cd358fc, 2
[1:1:0712/144653.320255:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 686a6a02 fffffffe43fffffffe29 fffffffc58ffffffd31c ffffff8203783d , 10104, 5
[1:1:0712/144653.321247:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[26039:26069:0712/144653.321523:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGhjj�C�)�X��x=��j.
[26039:26069:0712/144653.321601:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is hjj�C�)�X��x=���j.
[1:1:0712/144653.321507:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f033ffb80a0, 3
[1:1:0712/144653.321721:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0340143080, 2
[26039:26069:0712/144653.321846:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 26136, 5, 686a6a02 fe43fe29 fc58d31c 8203783d 
[1:1:0712/144653.321917:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f0329e06d20, -2
[1:1:0712/144653.343604:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/144653.344059:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1cd358fc
[1:1:0712/144653.344475:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1cd358fc
[1:1:0712/144653.345261:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1cd358fc
[1:1:0712/144653.347028:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.347283:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.347516:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.347741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.348588:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1cd358fc
[1:1:0712/144653.348965:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0341d7d7ba
[1:1:0712/144653.349135:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0341d74def, 7f0341d7d77a, 7f0341d7f0cf
[1:1:0712/144653.356224:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1cd358fc
[1:1:0712/144653.356670:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1cd358fc
[1:1:0712/144653.357589:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1cd358fc
[1:1:0712/144653.360134:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.360461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.360696:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.360940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cd358fc
[1:1:0712/144653.362544:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1cd358fc
[1:1:0712/144653.363026:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f0341d7d7ba
[1:1:0712/144653.363215:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f0341d74def, 7f0341d7d77a, 7f0341d7f0cf
[1:1:0712/144653.383368:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/144653.384026:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/144653.384250:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc17301478, 0x7ffc173013f8)
[1:1:0712/144653.401147:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/144653.406589:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/144653.618487:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144653.618756:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144653.646397:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x154ebcf9c220
[1:1:0712/144653.646658:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/144653.990875:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144653.995533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1eca4deae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/144653.995856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144654.004058:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144654.088840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/144654.089624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1eca4dd81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/144654.089862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[26039:26039:0712/144654.091316:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[26039:26039:0712/144654.098880:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[26039:26051:0712/144654.145493:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[26039:26051:0712/144654.145598:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[26039:26039:0712/144654.146106:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.weiyun.com/
[26039:26039:0712/144654.146235:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.weiyun.com/, https://www.weiyun.com/xy.html, 1
[26039:26039:0712/144654.146416:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.weiyun.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 21:46:53 GMT content-type:text/html x-powered-by:TSW/Node.js server:TSW/1.4.0 cache-control:max-age=600000 vary:Origin, Accept mod-map:weiyun_web:weiyun/web/sync.js cache-offline:false content-encoding:gzip  ,26136, 5
[1:7:0712/144654.151995:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/144654.199404:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.weiyun.com/
[26039:26039:0712/144654.359394:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.weiyun.com/, https://www.weiyun.com/, 1
[26039:26039:0712/144654.359478:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.weiyun.com/, https://www.weiyun.com
[1:1:0712/144654.409586:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/144654.429785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144654.431463:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/144654.431725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1eca4deae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/144654.432010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144654.539210:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/144654.540083:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/144654.540332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1eca4deae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/144654.540644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/144654.587349:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144654.624678:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144654.624885:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.weiyun.com/xy.html"
[1:1:0712/144654.656117:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0312049, 291, 1
[1:1:0712/144654.656342:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/144654.685921:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/144654.686124:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.weiyun.com/xy.html"
[1:1:0712/144654.687029:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 146 0x7f0329ab9070 0x154ebd0bde60 , "https://www.weiyun.com/xy.html"
[1:1:0712/144654.688182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.weiyun.com/, 065464202860, , , 
        var ua = window && window.navigator && window.navigator.userAgent || '';
        $('.privac
[1:1:0712/144654.688343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.weiyun.com/xy.html", "www.weiyun.com", 3, 1, , , 0
[1:1:0712/144654.689985:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/144656.449055:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144656.449565:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144656.449980:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144656.450406:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144656.450826:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/144723.495099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.weiyun.com/, 065464202860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/144723.495434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.weiyun.com/xy.html", "www.weiyun.com", 3, 1, , , 0
[26039:26039:0712/144723.845349:INFO:CONSOLE(245)] "Uncaught ReferenceError: $ is not defined", source: https://www.weiyun.com/xy.html (245)
[26039:26039:0712/144723.964864:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/144723.976106:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
