[0712/215901.924522:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/215901.924921:INFO:switcher_clone.cc(787)] backtrace rip is 7fa129189891
[0712/215902.897480:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/215902.897857:INFO:switcher_clone.cc(787)] backtrace rip is 7ff4ac196891
[1:1:0712/215902.909531:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/215902.909793:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/215902.914964:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[7573:7573:0712/215904.094994:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7c187ce4-ec51-4eda-adac-20caa0759937
[0712/215904.370755:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/215904.371069:INFO:switcher_clone.cc(787)] backtrace rip is 7f867660b891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[7606:7606:0712/215904.589508:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7606
[7618:7618:0712/215904.589946:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7618
[7573:7573:0712/215904.732160:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[7573:7604:0712/215904.732858:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/215904.733206:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/215904.733419:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/215904.734023:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/215904.734172:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/215904.737057:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x18db4a8a, 1
[1:1:0712/215904.737377:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1fb77573, 0
[1:1:0712/215904.737534:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1c205370, 3
[1:1:0712/215904.737693:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x287f4782, 2
[1:1:0712/215904.737897:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7375ffffffb71f ffffff8a4affffffdb18 ffffff82477f28 7053201c , 10104, 4
[1:1:0712/215904.738817:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7573:7604:0712/215904.739034:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGsu��J��G(pS ֠E
[7573:7604:0712/215904.739109:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is su��J��G(pS �1֠E
[7573:7604:0712/215904.739414:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[7573:7604:0712/215904.739473:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7626, 4, 7375b71f 8a4adb18 82477f28 7053201c 
[1:1:0712/215904.739236:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff4aa3d10a0, 3
[1:1:0712/215904.739944:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff4aa55c080, 2
[1:1:0712/215904.740093:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff49421fd20, -2
[1:1:0712/215904.758448:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/215904.759326:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 287f4782
[1:1:0712/215904.760264:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 287f4782
[1:1:0712/215904.761869:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 287f4782
[1:1:0712/215904.763380:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.763567:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.763746:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.763953:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.764588:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 287f4782
[1:1:0712/215904.764957:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff4ac1967ba
[1:1:0712/215904.765100:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff4ac18ddef, 7ff4ac19677a, 7ff4ac1980cf
[1:1:0712/215904.770682:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 287f4782
[1:1:0712/215904.771035:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 287f4782
[1:1:0712/215904.771751:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 287f4782
[1:1:0712/215904.773763:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.773973:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.774162:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.774365:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 287f4782
[1:1:0712/215904.775590:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 287f4782
[1:1:0712/215904.775957:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff4ac1967ba
[1:1:0712/215904.776101:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff4ac18ddef, 7ff4ac19677a, 7ff4ac1980cf
[1:1:0712/215904.783807:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/215904.784266:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/215904.784429:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdf30e3b78, 0x7ffdf30e3af8)
[1:1:0712/215904.800595:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/215904.806488:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[7573:7573:0712/215905.385782:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215905.386512:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7573:0712/215905.391555:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[7573:7585:0712/215905.391529:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[7573:7573:0712/215905.391601:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[7573:7585:0712/215905.391634:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215905.391669:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,7626, 4
[1:7:0712/215905.398228:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/215905.480656:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x220ef47b0220
[1:1:0712/215905.480911:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[7573:7597:0712/215905.486178:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/215905.784687:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/215907.015278:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215907.020156:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/215907.631434:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[7573:7573:0712/215907.631540:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/215907.883813:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215908.226394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bcf62261f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/215908.226702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/215908.235038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bcf62261f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/215908.235175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/215908.259493:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215908.259668:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215908.616209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215908.622481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bcf62261f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/215908.622761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/215908.658918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215908.669466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bcf62261f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/215908.669742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/215908.681814:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215908.683251:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215908.686191:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220ef47aee20
[1:1:0712/215908.686415:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7573:7573:0712/215908.690695:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[7573:7573:0712/215908.747503:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[7573:7573:0712/215908.747660:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/215908.787515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215909.901889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7ff495dfa2e0 0x220ef4a4fde0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215909.903204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bcf62261f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/215909.903399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/215909.904929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7573:7573:0712/215909.977584:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215909.980280:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x220ef47af820
[1:1:0712/215909.980616:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7573:7573:0712/215909.985497:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/215910.000619:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/215910.000816:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[7573:7573:0712/215910.002023:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[7573:7573:0712/215910.016604:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215910.017655:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/215910.023708:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[7573:7585:0712/215910.023825:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215910.023900:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[7573:7573:0712/215910.023977:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[7573:7573:0712/215910.024110:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,7626, 4
[1:7:0712/215910.026306:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/215910.760148:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/215911.091504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7ff495dfa2e0 0x220ef4b915e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215911.092488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2bcf62261f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/215911.092679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/215911.093383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/215911.236731:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/215911.245791:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[7573:7573:0712/215911.245856:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/215911.628039:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215911.979902:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215911.980111:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7573:7573:0712/215912.040215:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[7573:7604:0712/215912.040816:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/215912.041096:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/215912.041318:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/215912.041760:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/215912.041915:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/215912.045540:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1ab55abf, 1
[1:1:0712/215912.046431:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3979e3b0, 0
[1:1:0712/215912.046822:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf2dd39b, 3
[1:1:0712/215912.047334:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x19fd129, 2
[1:1:0712/215912.047688:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb0ffffffe37939 ffffffbf5affffffb51a 29ffffffd1ffffff9f01 ffffff9bffffffd32d0f , 10104, 5
[1:1:0712/215912.050037:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7573:7604:0712/215912.050541:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��y9�Z�)џ��-�E
[7573:7604:0712/215912.050644:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��y9�Z�)џ��-H�E
[1:1:0712/215912.050548:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff4aa3d10a0, 3
[7573:7604:0712/215912.051042:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7671, 5, b0e37939 bf5ab51a 29d19f01 9bd32d0f 
[1:1:0712/215912.051003:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff4aa55c080, 2
[1:1:0712/215912.051413:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff49421fd20, -2
[1:1:0712/215912.092250:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/215912.092729:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19fd129
[1:1:0712/215912.093223:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19fd129
[1:1:0712/215912.094170:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19fd129
[1:1:0712/215912.096326:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.096630:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.097069:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.097328:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.098334:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19fd129
[1:1:0712/215912.098795:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff4ac1967ba
[1:1:0712/215912.098993:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff4ac18ddef, 7ff4ac19677a, 7ff4ac1980cf
[1:1:0712/215912.107899:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19fd129
[1:1:0712/215912.108422:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19fd129
[1:1:0712/215912.109567:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19fd129
[1:1:0712/215912.112119:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.112335:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.112534:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.112748:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19fd129
[1:1:0712/215912.114055:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19fd129
[1:1:0712/215912.114429:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff4ac1967ba
[1:1:0712/215912.114564:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff4ac18ddef, 7ff4ac19677a, 7ff4ac1980cf
[1:1:0712/215912.122643:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/215912.123151:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/215912.123297:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdf30e3b78, 0x7ffdf30e3af8)
[1:1:0712/215912.137217:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/215912.141660:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/215912.384827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/215912.389635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2bcf6238e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/215912.389985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/215912.399874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/215912.427121:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x220ef4794220
[1:1:0712/215912.427360:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7573:7573:0712/215912.848010:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215912.854725:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/215912.886446:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[7573:7585:0712/215912.886540:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215912.887067:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ithome.com/
[7573:7573:0712/215912.887176:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.ithome.com/, https://www.ithome.com/0/432/394.htm, 1
[7573:7573:0712/215912.887333:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.ithome.com/, HTTP/1.1 200 OK Server: JSP3/2.0.14 Date: Sat, 13 Jul 2019 04:59:12 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip Age: 336751 Accept-Ranges: bytes Cache-Control: private X-AspNet-Version: 4.0.30319 Ohc-Response-Time: 1 0 0 0 0 18 Ohc-File-Size: 20536 alt-svc: quic="124.192.164.42:443"; ma=2592000; v="44,43,39" Ohc-Cache-HIT: bj2pbs103 [3]  ,7671, 5
[1:7:0712/215912.891452:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/215912.945407:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.ithome.com/
[7573:7573:0712/215913.106457:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.ithome.com/, https://www.ithome.com/, 1
[7573:7573:0712/215913.106556:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215913.129004:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/215913.255433:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215913.357743:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215913.358018:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215913.937625:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/215914.402778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7ff4aa55c080 0x220ef4785600 1 0 0x220ef4785618 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215914.404498:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215914.418470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/215914.418698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215914.532928:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215914.533398:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215914.533769:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215914.537133:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215914.537518:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215915.578397:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 238 0x7ff4aa55c080 0x220ef4785600 1 0 0x220ef4785618 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215915.592485:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0380771, 316, 1
[1:1:0712/215915.592742:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215915.665291:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215915.665568:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215915.668349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7ff493ed2070 0x220ef49535e0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215915.669298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.write('<div style="width:1100px;margin:0 auto;background-color:white"><div style=padding-le
[1:1:0712/215915.669557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215915.673283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7ff493ed2070 0x220ef49535e0 , "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215943.699161:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/215943.758319:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[7573:7573:0712/215943.797309:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=3038304&dri=0&dis=0&dai=0&ps=145x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1100x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993956&prot=2&rw=424&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993956&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215943.862099:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=3038304&dri=0&dis=0&dai=0&ps=145x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1100x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993956&prot=2&rw=424&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993956&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215943.991267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/215943.991551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215944.396903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215944.398097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "15d1c5ae81da799b","tuid" : "3038304_0","placement" : {"basic" : {"sspId
[1:1:0712/215944.398324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215944.612593:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215944.667645:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215944.667903:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215944.669327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 312 0x7ff493ed2070 0x220ef50403e0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215944.670177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , BAIDU_CLB_fillSlot("3052879");
[1:1:0712/215944.670390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[7573:7573:0712/215944.755638:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=3052879&dri=0&dis=0&dai=0&ps=148x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1100x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993984&prot=2&rw=424&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993985&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215944.765072:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=3052879&dri=0&dis=0&dai=0&ps=148x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x409&pss=1100x409&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993984&prot=2&rw=424&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993985&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215944.829938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215944.830985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215944.965327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215944.965596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215944.992683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215944.994068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "c7f0351e11d24acc","tuid" : "3052879_0","placement" : {"basic" : {"sspId
[1:1:0712/215944.994285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "www.ithome.com", 3, 1, , , 0
[1:1:0712/215945.015553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215945.017764:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "www.ithome.com", "ithome.com"
[1:1:0712/215945.024778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 329, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215945.222437:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=5374171&dri=0&dis=0&dai=0&ps=308x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1100x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993985&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993985&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215945.224848:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=5374171&dri=0&dis=0&dai=0&ps=308x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1100x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993985&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993985&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215945.308183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215945.308487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215945.498791:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215945.500116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "2995979fc0f497b2","tuid" : "5374171_0","placement" : {"basic" : {"sspId
[1:1:0712/215945.500332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215945.520255:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215945.612166:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1162592&dri=0&dis=0&dai=0&ps=308x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1100x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993985&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993986&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215945.628125:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1162592&dri=0&dis=0&dai=0&ps=308x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1040x456&pss=1100x456&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993985&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993986&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215945.642406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215945.642680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215945.740251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215945.740504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215945.761254:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215945.762651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "44d9ef9717122112","tuid" : "1162592_0","placement" : {"basic" : {"sspId
[1:1:0712/215945.762871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215945.777850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215945.782391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215945.785725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xf11d0e29c8, 0x220ef43201a0
[1:1:0712/215945.785964:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 800
[1:1:0712/215945.786340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 377
[1:1:0712/215945.786555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7ff493ed2070 0x220ef503d3e0 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 367
[1:1:0712/215945.812233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215946.270323:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1088067&dri=0&dis=0&dai=0&ps=1448x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1487&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993986&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993986&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215946.284310:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1088067&dri=0&dis=0&dai=0&ps=1448x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1487&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993986&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993986&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215946.338267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215946.338546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/215946.671955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215946.672246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215946.701935:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215946.703278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "e85537d864184d4d","tuid" : "1088067_0","placement" : {"basic" : {"sspId
[1:1:0712/215946.703534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215946.715180:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215946.731338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 389, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215946.830867:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1113312&dri=0&dis=0&dai=0&ps=1453x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1487&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993986&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993987&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215946.839118:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1113312&dri=0&dis=0&dai=0&ps=1453x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1487&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993986&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993987&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215947.090028:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 377, 7ff496817881
[1:1:0712/215947.109712:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"367","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215947.110079:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"367","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215947.110536:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215947.111163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/215947.111690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215947.135555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215947.135821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215947.197847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215947.199380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "857c9901a54a4ff4","tuid" : "1113312_0","placement" : {"basic" : {"sspId
[1:1:0712/215947.199600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215947.216008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215947.219346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xf11d0e29c8, 0x220ef43201a0
[1:1:0712/215947.219548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 800
[1:1:0712/215947.219922:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 439
[1:1:0712/215947.220148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 439 0x7ff493ed2070 0x220ef56ad7e0 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 418
[1:1:0712/215947.235360:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215947.317711:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1005747&dri=0&dis=0&dai=0&ps=1548x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1582&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993987&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993987&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215947.328086:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1005747&dri=0&dis=0&dai=0&ps=1548x16&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1582&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993987&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993987&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/215947.338395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7ff495dfa2e0 0x220ef48cf660 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215947.351929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (function(){var l;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:
[1:1:0712/215947.352168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
		remove user.11_b2b1abd6 -> 0
[1:1:0712/215947.616408:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0xf11d0e29c8, 0x220ef43201a8
[1:1:0712/215947.616665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 1000
[1:1:0712/215947.617106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 447
[1:1:0712/215947.617341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 447 0x7ff493ed2070 0x220ef48cbbe0 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 420 0x7ff495dfa2e0 0x220ef48cf660 
[7573:7573:0712/215947.640929:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215947.643030:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x220ef5343820
[1:1:0712/215947.643255:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7573:7573:0712/215947.647448:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[7573:7573:0712/215947.688433:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.ithome.com/, https://www.ithome.com/, 4
[7573:7573:0712/215947.688607:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215947.752249:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 13976d352738, 5:3_https://www.ithome.com/, 5:4_https://www.ithome.com/, about:blank
[1:1:0712/215947.752517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, open, 
[1:1:0712/215947.752812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "ithome.com", 4, 2, https://www.ithome.com, ithome.com, 3
[1:1:0712/215947.754207:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	rj (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Uj (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Tj (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	bk (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	ak (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/215947.759889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7ff495dfa2e0 0x220ef48cf660 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215947.767251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, Yj, (a){if(a){if(!Kj(a)&&(a.id?a=Oj(a.id):a=null,!a))throw new M("'element' has already been filled.");i
[1:1:0712/215947.767533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 3, , , 0
[1:1:0712/215947.768855:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Uj (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Tj (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	bk (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	ak (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/215947.837851:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215947.840544:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215947.843099:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x220ef4791a20
[1:1:0712/215947.843397:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[7573:7573:0712/215947.848635:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: aswift_0, 5, 5, 
[1:1:0712/215947.878791:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215947.881137:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://www.ithome.com/, https://www.ithome.com/, 5
[7573:7573:0712/215947.881266:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215947.933163:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x220ef5341020
[1:1:0712/215947.933741:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/215947.946255:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/215947.946475:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/215947.946896:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7573:7573:0712/215947.955206:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_esf, 6, 6, 
[7573:7573:0712/215947.973242:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[7573:7573:0712/215947.993953:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215947.999426:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/215948.015710:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/215948.020169:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x220ef5652820
[1:1:0712/215948.020746:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[7573:7573:0712/215948.042224:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://googleads.g.doubleclick.net/
[7573:7585:0712/215948.042281:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[7573:7573:0712/215948.042310:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#, 6
[7573:7585:0712/215948.042362:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215948.042447:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://googleads.g.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* vary:Accept-Encoding date:Thu, 11 Jul 2019 01:03:35 GMT expires:Thu, 25 Jul 2019 01:03:35 GMT content-type:text/html; charset=UTF-8 etag:6832606795824562093 x-content-type-options:nosniff content-encoding:gzip server:cafe content-length:7008 x-xss-protection:0 cache-control:public, max-age=1209600 age:185039 alt-svc:quic="googleads.g.doubleclick.net:443"; ma=2592000; v="46,43,39",quic=":443"; ma=2592000; v="46,43,39"  ,7671, 5
[1:7:0712/215948.044644:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[7573:7573:0712/215948.044897:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7573:7573:0712/215948.050656:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: aswift_1, 7, 7, 
[7573:7573:0712/215948.065180:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://www.ithome.com/, https://www.ithome.com/, 7
[7573:7573:0712/215948.065316:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215948.068569:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215948.085954:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/215948.140797:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215948.145021:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215948.145058:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x220ef4791020
[1:1:0712/215948.145581:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[7573:7573:0712/215948.152764:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: aswift_2, 8, 8, 
[1:1:0712/215948.173246:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215948.185561:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://www.ithome.com/, https://www.ithome.com/, 8
[7573:7573:0712/215948.185699:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215948.276444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7ff495dfa2e0 0x220ef55d03e0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215948.282268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (function(){var l;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:
[1:1:0712/215948.282535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215948.370745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7ff495dfa2e0 0x220ef5990ee0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215948.376389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (function(){var l;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:
[1:1:0712/215948.376677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215948.541626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215948.541909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/215948.822901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215948.824295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "3a5c61da2caaeb80","tuid" : "1005747_0","placement" : {"basic" : {"sspId
[1:1:0712/215948.824509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215948.830055:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215948.837237:INFO:CONSOLE(4)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://cpro.baidustatic.com/cpro/ui/c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (4)
[1:1:0712/215948.837895:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xf11d0e29c8, 0x220ef43201a0
[1:1:0712/215948.838101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 800
[1:1:0712/215948.838486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 566
[1:1:0712/215948.838740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 566 0x7ff493ed2070 0x220ef5fccce0 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 444
[7573:7573:0712/215948.844281:INFO:CONSOLE(4)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://cpro.baidustatic.com/cpro/ui/c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (4)
[1:1:0712/215948.859179:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215949.710443:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215949.711069:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/215950.150599:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215950.155690:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215950.156968:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215950.159146:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x220ef52fe420
[1:1:0712/215950.159342:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[7573:7573:0712/215950.161224:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[1:1:0712/215950.183365:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/215950.183607:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/215950.185255:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[1:1:0712/215950.185865:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/215950.189362:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x220ef5300220
[1:1:0712/215950.189560:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[7573:7573:0712/215950.191085:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7573:7573:0712/215950.197686:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[7573:7573:0712/215950.212096:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215950.215802:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/215950.229377:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.085881, 81, 1
[1:1:0712/215950.229615:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[7573:7585:0712/215950.238878:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[7573:7585:0712/215950.238961:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215950.239161:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ithome.com/
[7573:7573:0712/215950.239236:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://www.ithome.com/, https://www.ithome.com/json/hot/dajia.htm, 9
[7573:7573:0712/215950.239367:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_https://www.ithome.com/, HTTP/1.1 200 status:200 etag:W/"e89c8330aae6d41:0" content-encoding:gzip ohc-cache-hit:bj2pbs137 [4] ohc-file-size:3323 age:1309185 server:BD-QuicServer server:JSP3/2.0.14 accept-ranges:bytes alt-svc:quic="124.192.164.42:443"; ma=2592000; v="44,43,39" content-type:text/html expires:Sun, 28 Jul 2019 01:00:06 GMT last-modified:Sat, 30 Mar 2019 03:39:33 GMT date:Sat, 13 Jul 2019 04:40:21 GMT cache-control:max-age=2592000  ,7671, 5
[1:7:0712/215950.242761:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[7573:7573:0712/215950.253183:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://www.ithome.com/, https://www.ithome.com/, 10
[7573:7573:0712/215950.253351:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215951.352877:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://googleads.g.doubleclick.net/
[1:1:0712/215951.977776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215951.978051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215952.086356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 439, 7ff496817881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/215952.113146:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"418","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215952.113508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"418","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215952.113941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215952.114521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/215952.114729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215952.285346:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 447, 7ff496817881
[1:1:0712/215952.299135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"420 0x7ff495dfa2e0 0x220ef48cf660 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215952.299432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"420 0x7ff495dfa2e0 0x220ef48cf660 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215952.299855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215952.300409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){return n.processGoogleToken(d,1)}
[1:1:0712/215952.300619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215953.205468:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215953.205679:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215953.207451:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 592 0x7ff493ed2070 0x220ef67a7de0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215953.208146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.write('<iframe src="//www.ithome.com/block/topnews.htm" scrolling="no" marginwidth="0" marg
[1:1:0712/215953.208303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215953.208805:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215953.210958:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215953.212121:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x220ef65aca20
[1:1:0712/215953.212292:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[7573:7573:0712/215953.218941:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 11, 11, 
[1:1:0712/215953.230369:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/215953.230556:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/215953.233691:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[1:1:0712/215953.235568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 592 0x7ff493ed2070 0x220ef67a7de0 , "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215953.333397:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1005739&dri=0&dis=0&dai=0&ps=619x784&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2493&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993993&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993993&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215953.347021:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=1005739&dri=0&dis=0&dai=0&ps=619x784&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2493&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993993&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993993&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215953.351582:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215953.358793:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/215953.379686:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 11
[7573:7573:0712/215953.379729:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ithome.com/
[7573:7573:0712/215953.379794:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://www.ithome.com/, https://www.ithome.com/block/topnews.htm, 11
[7573:7585:0712/215953.379802:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 11, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215953.379858:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:11_https://www.ithome.com/, HTTP/1.1 200 status:304 date:Sat, 13 Jul 2019 04:59:53 GMT last-modified:Wed, 10 Jul 2019 09:46:46 GMT accept-ranges:bytes server:BD-QuicServer server:JSP3/2.0.14 ohc-cache-hit:bj2pbs137 [4] alt-svc:quic="124.192.164.42:443"; ma=2592000; v="44,43,39" age:241929 ohc-file-size:10603 Ohc-Response-Time: 1 0 0 0 0 0 etag:W/"c4a45863437d51:0" content-type:text/html content-encoding:gzip  ,7671, 5
[1:7:0712/215953.385900:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/215953.404744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 566, 7ff496817881
[1:1:0712/215953.436016:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"444","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215953.436365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"444","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215953.436819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215953.437491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/215953.437711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215953.651980:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:9_https://www.ithome.com/
[1:1:0712/215953.759238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7ff495dfa2e0 0x220ef67e93e0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215953.759825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , try{window.localStorage.setItem('google_pub_config','{"sraConfigs":{"2":{"sraEnabled":true,"sraTimeo
[1:1:0712/215953.759954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215953.790251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 615 0x7ff495dfa2e0 0x220ef67a61e0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215953.791184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , processGoogleToken({"newToken":"NT","validLifetimeSecs":300,"freshLifetimeSecs":300,"1p_jar":"","puc
[1:1:0712/215953.791364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215953.954267:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 620 0x7ff495dfa2e0 0x220ef5fbbbe0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215953.955730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "e21bbe6810c858ee","tuid" : "u2503514_0","placement" : {"basic" : {"sspI
[1:1:0712/215953.955941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215954.014205:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215954.015806:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215954.017886:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 12, 0x220ef52fd020
[1:1:0712/215954.018083:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 12
[7573:7573:0712/215954.024703:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu2503514_0, 12, 12, 
[1:1:0712/215954.042208:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/215954.042397:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/215954.045664:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[1:1:0712/215954.052075:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 500
[1:1:0712/215954.052449:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 706
[1:1:0712/215954.052635:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7ff493ed2070 0x220ef65f07e0 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 620 0x7ff495dfa2e0 0x220ef5fbbbe0 
[1:1:0712/215954.056286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 50
[1:1:0712/215954.056640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 707
[1:1:0712/215954.056825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7ff493ed2070 0x220ef5d785e0 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 620 0x7ff495dfa2e0 0x220ef5fbbbe0 
[1:1:0712/215954.374423:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/215954.377890:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/, 6
[7573:7573:0712/215954.378043:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net
[7573:7573:0712/215954.410129:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215954.416573:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/215954.454477:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 12
[7573:7585:0712/215954.454573:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 12, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215954.461576:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[7573:7573:0712/215954.461659:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_https://pos.baidu.com/, https://pos.baidu.com/ucem?conwid=728&conhei=90&rdid=2503514&dc=3&exps=110011&psi=15a32fada5002fedf291a56451e16747&di=u2503514&dri=0&dis=0&dai=8&ps=1548x16&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x1582&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993990&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993990&qn=e21bbe6810c858ee&tt=1562993954443.35665.39520.39552, 12
[7573:7573:0712/215954.461810:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:12_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 12260 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 04:59:54 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 12:59:54 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,7671, 5
[1:7:0712/215954.463302:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/215954.501730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215954.501889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/215955.578242:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:11_https://www.ithome.com/
[1:1:0712/215955.596973:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215955.597692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "7e181c874870213c","tuid" : "1005739_0","placement" : {"basic" : {"sspId
[1:1:0712/215955.597814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215955.603528:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215955.608014:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xf11d0e29c8, 0x220ef43201a0
[1:1:0712/215955.608128:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 800
[1:1:0712/215955.608292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 791
[1:1:0712/215955.608431:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7ff493ed2070 0x220ef65f3160 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 682
[7573:7573:0712/215955.609629:INFO:CONSOLE(4)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cpro.baidustatic.com/cpro/ui/c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (4)
[1:1:0712/215955.616123:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215955.617919:INFO:CONSOLE(4)] "Mixed Content: The page at 'https://www.ithome.com/0/432/394.htm' was loaded over HTTPS, but requested an insecure script 'http://cpro.baidustatic.com/cpro/ui/c.js'. This request has been blocked; the content must be served over HTTPS.", source: https://dup.baidustatic.com/js/ds.js (4)
[7573:7573:0712/215955.618623:INFO:CONSOLE(4)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cpro.baidustatic.com/cpro/ui/c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (4)
[1:1:0712/215955.620277:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215955.621465:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/215955.623300:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/215955.625125:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 13, 0x220ef5653220
[1:1:0712/215955.625345:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 13
[7573:7573:0712/215955.631582:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 13, 13, 
[1:1:0712/215955.654128:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/215955.654388:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/215955.658131:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[1:1:0712/215955.659508:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215955.663190:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 682, "https://www.ithome.com/0/432/394.htm"
[7573:7573:0712/215955.697182:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/215955.706283:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/215955.733198:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 13
[7573:7585:0712/215955.733291:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 13, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/215955.733481:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ithome.com/
[7573:7573:0712/215955.733557:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:13_https://www.ithome.com/, https://www.ithome.com/html/categoryhot/147.htm, 13
[7573:7573:0712/215955.733690:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:13_https://www.ithome.com/, HTTP/1.1 200 status:200 expires:Wed, 10 Jul 2019 08:15:11 GMT server:BD-QuicServer server:JSP3/2.0.14 date:Sat, 13 Jul 2019 04:59:55 GMT last-modified:Wed, 10 Jul 2019 07:45:11 GMT age:249137 content-encoding:gzip alt-svc:quic="124.192.164.42:443"; ma=2592000; v="44,43,39" x-aspnet-version:4.0.30319 ohc-cache-hit:bj2pbs108 [4] vary:* accept-ranges:bytes content-type:text/html; charset=gb2312 cache-control:public, no-cache="Set-Cookie", max-age=1800 ohc-file-size:4011  ,7671, 5
[1:7:0712/215955.740227:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/215956.289781:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.674788, 12, 0
[1:1:0712/215956.290021:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215956.445414:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/215956.458257:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://www.ithome.com/, https://www.ithome.com/, 9
[7573:7573:0712/215956.458356:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215957.264008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 707, 7ff4968178db
[1:1:0712/215957.284914:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"620 0x7ff495dfa2e0 0x220ef5fbbbe0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215957.285097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"620 0x7ff495dfa2e0 0x220ef5fbbbe0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215957.285333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 849
[1:1:0712/215957.285467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7ff493ed2070 0x220ef6cb00e0 , 5:3_https://www.ithome.com/, 0, , 707 0x7ff493ed2070 0x220ef5d785e0 
[1:1:0712/215957.285630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215957.285929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/215957.286029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215957.423986:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/215957.583254:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:12_https://pos.baidu.com/
[1:1:0712/215957.693249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/215957.693487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215957.733730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 706, 7ff4968178db
[1:1:0712/215957.770584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"620 0x7ff495dfa2e0 0x220ef5fbbbe0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215957.770905:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"620 0x7ff495dfa2e0 0x220ef5fbbbe0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/215957.771307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 865
[1:1:0712/215957.771493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7ff493ed2070 0x220ef6ca4460 , 5:3_https://www.ithome.com/, 0, , 706 0x7ff493ed2070 0x220ef65f07e0 
[1:1:0712/215957.771755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215957.772284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/215957.772455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/215958.958055:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/215958.976206:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://www.ithome.com/, https://www.ithome.com/, 11
[7573:7573:0712/215958.976320:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/215959.753585:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:13_https://www.ithome.com/
[1:1:0712/215959.844920:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/215959.845137:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215959.846482:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 814 0x7ff493ed2070 0x220ef56abee0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/215959.847676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (function() {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id="' 
[1:1:0712/215959.847890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[7573:7573:0712/215959.928209:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=2723650&dri=0&dis=0&dai=0&ps=1133x784&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2583&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993999&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562994000&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[7573:7573:0712/215959.942977:INFO:CONSOLE(3)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://pos.baidu.com/ucem?psi=15a32fada5002fedf291a56451e16747&di=2723650&dri=0&dis=0&dai=0&ps=1133x784&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2583&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993999&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562994000&exps=110011, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://dup.baidustatic.com/js/ds.js (3)
[1:1:0712/220000.115030:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220000.261962:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 791, 7ff496817881
[1:1:0712/220000.300025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d242860","ptid":"682","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220000.300397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.ithome.com/","ptid":"682","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220000.300890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220000.301568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/220000.301788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220000.602585:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220000.626128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.ithome.com/, 13976d352738, , , (function(window,document,location){var p;function aa(a){var b=0;return function(){return b<a.length
[1:1:0712/220000.626445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 1, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.765433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, D.google_process_slots, (){return sj(D)}
[1:1:0712/220000.765761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 2, , , 0
[1:1:0712/220000.768526:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.777246:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0xf11d0e29c8, 0x220ef43201a8
[1:1:0712/220000.777465:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 30000
[1:1:0712/220000.778147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 942
[1:1:0712/220000.778395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 942 0x7ff493ed2070 0x220ef6deb1e0 , 5:3_https://www.ithome.com/, 2, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 
[1:1:0712/220000.791710:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 13976d35cf08, 5:3_https://www.ithome.com/, 5:5_https://www.ithome.com/, about:blank
[1:1:0712/220000.792003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d242860, open, 
[1:1:0712/220000.792318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "ithome.com", 5, 3, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.793832:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.797946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220000.799583:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220000.801054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d35cf08, Mx, (a){var b=a.iframeWin,c=a.vars;b&&(c.google_iframe_start_time=b.google_iframe_start_time);var d=new 
[1:1:0712/220000.801326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 4, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.802649:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.804555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220000.804805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 5, , , 0
[1:1:0712/220000.806345:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.807202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, now, 
[1:1:0712/220000.807488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 6, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.808874:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.810760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, indexOf, 
[1:1:0712/220000.811023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 7, , , 0
[1:1:0712/220000.812488:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	oh (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.812943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, Kh, (a){return Jh(a).eids||[]}
[1:1:0712/220000.813271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 8, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.814658:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.815455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, indexOf, 
[1:1:0712/220000.815783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 9, , , 0
[1:1:0712/220000.817247:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	oh (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.817604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, xj, (a,b){qj(uj,a,b,void 0)}
[1:1:0712/220000.817977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 10, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.819346:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.839637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, , (c){return Oh(a,c)}
[1:1:0712/220000.840009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 11, , , 0
[1:1:0712/220000.842368:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.849758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, Jh, (a){a.google_ad_modifications||(a.google_ad_modifications={});return a.google_ad_modifications}
[1:1:0712/220000.850200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 12, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.852207:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.853038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, call, 
[1:1:0712/220000.853390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 13, , , 0
[1:1:0712/220000.855505:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	v (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.856105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, $a, (a,b){for(var c=a.length,d=Array(c),e=x(a)?a.split(""):a,f=0;f<c;f++)f in e&&(d[f]=b.call(void 0,e[f
[1:1:0712/220000.856515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 14, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.858473:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.954153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getRandomValues, 
[1:1:0712/220000.954413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 15, , , 0
[1:1:0712/220000.955100:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	of (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	vy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.955399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, y, (a){return"number"==typeof a}
[1:1:0712/220000.955623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 16, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.956153:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.981526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220000.982134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 17, , , 0
[1:1:0712/220000.984640:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220000.985131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, Ok, (a){a.google_reactive_ads_global_state||(a.google_reactive_ads_global_state=new Nk);return a.google_
[1:1:0712/220000.985768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 18, https://www.ithome.com, ithome.com, 3
[1:1:0712/220000.988241:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.010264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, addEventListener, 
[1:1:0712/220001.010883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 19, , , 0
[1:1:0712/220001.013708:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.014472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, As, (a,b){var c=this;this.j=a;uk(b,"rctcnf",T(426,function(d,e){return Bs(c,d,e)}),T(427,Ta(Zk,b,"rach::
[1:1:0712/220001.015153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 20, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.017618:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.020061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d352738, addEventListener, 
[1:1:0712/220001.020744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 5, 21, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.023505:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.024157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d35cf08, Vm, (a){return!!Um(a)||null!=a.google_pgb_reactive}
[1:1:0712/220001.024899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 22, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.027040:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.040577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220001.041239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 23, , , 0
[1:1:0712/220001.043129:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.043624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, nv, (){jv=iv();lv=jv.googleToken=jv.googleToken||{};var a=C();lv[1]&&lv[3]>a&&0<lv[2]||(lv[1]="",lv[2]=-
[1:1:0712/220001.044230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 24, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.046150:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.172280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, now, 
[1:1:0712/220001.173090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 25, , , 0
[1:1:0712/220001.175934:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.176368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, round, 
[1:1:0712/220001.177153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 26, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.179948:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.180803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, now, 
[1:1:0712/220001.181509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 27, , , 0
[1:1:0712/220001.184292:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.184769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, dv, (a,b,c){a-=b;return a>=(void 0===c?1E5:c)?"M":0<=a?a:"-M"}
[1:1:0712/220001.185578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 28, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.187841:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.355148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220001.355472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 29, , , 0
[1:1:0712/220001.356242:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.356616:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, De, (a){return a?new Ee(Fe(a)):Va||(Va=new Ee)}
[1:1:0712/220001.356981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 30, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.357686:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.369628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, l.cb, (){return!(!window||!Array)}
[1:1:0712/220001.369919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 31, , , 0
[1:1:0712/220001.370590:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Yu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.370951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, mh, (a){return!(!a||!a.call)&&"function"===typeof a}
[1:1:0712/220001.371237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 32, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.374095:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220001.374343:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220001.380138:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220001.381892:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.383244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, l.Qa, (){return this.i}
[1:1:0712/220001.383708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 33, , , 0
[1:1:0712/220001.384493:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.384877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, as, (a,b){if(!b)return null;var c=Ok(b);if(!c.wasReactiveAdConfigHandlerRegistered)return null;var d=0;N
[1:1:0712/220001.385204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 34, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.385942:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.394245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220001.394522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 35, , , 0
[1:1:0712/220001.395935:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.396554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, xm, (a){return{visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[a.visibilityState||a.webkitVisibilit
[1:1:0712/220001.397027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 36, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.398869:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.404668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.405471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 37, , , 0
[1:1:0712/220001.408042:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.408505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220001.409299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 38, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.412435:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.412896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.413667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 39, , , 0
[1:1:0712/220001.416208:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.416578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 40, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.417393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 40, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.420221:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.420672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 41, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.421463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 41, , , 0
[1:1:0712/220001.423977:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.424363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 42, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.425196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 42, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.427687:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.437550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 43, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220001.438430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 43, , , 0
[1:1:0712/220001.440914:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.441297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 44, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/220001.442160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 44, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.444616:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.445686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 45, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.446629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 45, , , 0
[1:1:0712/220001.449192:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.449687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 46, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220001.450584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 46, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.453056:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.453474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 47, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.454585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 47, , , 0
[1:1:0712/220001.457650:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.458037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 48, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.458946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 48, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.461490:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.461984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 49, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.462918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 49, , , 0
[1:1:0712/220001.465461:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.465887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 50, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.466877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 50, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.469423:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.478039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 51, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220001.479033:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 51, , , 0
[1:1:0712/220001.481482:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.481905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 52, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/220001.482925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 52, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.485382:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.486286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 53, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.487294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 53, , , 0
[1:1:0712/220001.489865:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.490312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 54, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220001.491323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 54, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.493771:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.494113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 55, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.495077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 55, , , 0
[1:1:0712/220001.497674:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.498108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 56, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.499181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 56, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.501737:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.502201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 57, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.503200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 57, , , 0
[1:1:0712/220001.505723:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.506172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 58, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.507617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 58, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.510306:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.521487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 59, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220001.522629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 59, , , 0
[1:1:0712/220001.525112:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.525598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 60, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.526769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 60, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.529295:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.530553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 61, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.531649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 61, , , 0
[1:1:0712/220001.535006:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.535576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 62, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220001.536836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 62, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.539343:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.540044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 63, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.541318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 63, , , 0
[1:1:0712/220001.544334:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.544689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 64, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.545990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 64, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.550120:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.550659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 65, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220001.551887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 65, , , 0
[1:1:0712/220001.554407:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.554784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 66, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220001.555877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 66, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.556658:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.557506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 67, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.557944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 67, , , 0
[1:1:0712/220001.558722:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.559029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 68, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/220001.559457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 68, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.560242:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.560744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 69, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.561176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 69, , , 0
[1:1:0712/220001.561979:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.562271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 70, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/220001.562703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 70, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.563460:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.563989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 71, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.564406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 71, , , 0
[1:1:0712/220001.565231:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.565545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 72, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, xf, (a){return(a=tf.exec(a))?+a[1]:null}
[1:1:0712/220001.566016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 72, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.566733:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.569870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 73, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220001.570311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 73, , , 0
[1:1:0712/220001.571028:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.571215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 74, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, qw, (a){return!!a&&/^left|right$/.test(a.cssFloat||a.styleFloat)}
[1:1:0712/220001.571669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 74, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.572386:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.574717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 75, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220001.575347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 75, , , 0
[1:1:0712/220001.576009:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.576198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 76, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, C, (){return+new Date}
[1:1:0712/220001.576667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 76, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.577356:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.581884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 77, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220001.582333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 77, , , 0
[1:1:0712/220001.582979:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.585277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 78, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, C, (){return+new Date}
[1:1:0712/220001.585747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 78, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.588488:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.593487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 79, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.595359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 79, , , 0
[1:1:0712/220001.596234:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.596488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 80, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.597075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 80, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.597795:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.598545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 81, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.599035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 81, , , 0
[1:1:0712/220001.599735:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.599986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 82, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.600454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 82, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.602782:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.604348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 83, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.604933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 83, , , 0
[1:1:0712/220001.605663:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.605912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 84, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.606453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 84, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.608455:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.609155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 85, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.609663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 85, , , 0
[1:1:0712/220001.610393:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.610617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 86, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.611159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 86, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.611861:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.612403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 87, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.612943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 87, , , 0
[1:1:0712/220001.613656:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.613893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 88, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.614408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 88, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.615098:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.615645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 89, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.616151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 89, , , 0
[1:1:0712/220001.617281:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.617738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 90, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.619668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 90, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.622531:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.624268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 91, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220001.626230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 91, , , 0
[1:1:0712/220001.627224:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.627454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 92, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220001.628017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 92, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.628701:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.898064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 93, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d352738, createElement, 
[1:1:0712/220001.899810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 5, 93, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.902299:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ve (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.903667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 94, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d35cf08, N, (a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b.call(void 0,a[c],c,a)}
[1:1:0712/220001.905476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 94, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.907829:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.908631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 95, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d352738, setAttribute, 
[1:1:0712/220001.910389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 5, 95, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.912967:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.913381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 96, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d35cf08, call, 
[1:1:0712/220001.915004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 96, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.918386:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.919247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 97, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d352738, setAttribute, 
[1:1:0712/220001.921018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 5, 97, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.921738:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.921976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 98, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d35cf08, call, 
[1:1:0712/220001.922562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 98, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.924416:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.925094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 99, -5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d352738, setAttribute, 
[1:1:0712/220001.926707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 5, 99, https://www.ithome.com, ithome.com, 3
[1:1:0712/220001.929154:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220001.930717:INFO:switcher_impl.cc(1415)] 			[ERROR] updated frame chain. The number of frame chain is larger than the thresold, please check it! [num, thresold] = 100, 100
[7573:7573:0712/220001.941102:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220001.943295:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 14, 0x220ef65c8e20
[1:1:0712/220001.943466:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 14
[7573:7573:0712/220001.948207:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_ads_frame1, 14, 14, 
[1:1:0712/220001.973128:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220001.973320:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/220001.977522:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[1:1:0712/220002.466456:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11d0e29c8, 0x220ef43202b0
[1:1:0712/220002.466713:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 0
[1:1:0712/220002.467175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 959
[1:1:0712/220002.467417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7ff493ed2070 0x220ef6dd00e0 , 5:3_https://www.ithome.com/, 100, , 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 
[1:1:0712/220002.470843:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11d0f8e50, 0x220ef43202b0
[1:1:0712/220002.471066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 0
[1:1:0712/220002.471568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 960
[7573:7573:0712/220002.472117:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0712/220002.471802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7ff493ed2070 0x220ef6ee41e0 , 5:3_https://www.ithome.com/, 100, , 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 
[7573:7573:0712/220002.478447:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/220002.479531:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11d0e29c8, 0x220ef43201a8
[1:1:0712/220002.479760:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 0
[1:1:0712/220002.480266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 962
[1:1:0712/220002.480517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7ff493ed2070 0x220ef5cd9a60 , 5:3_https://www.ithome.com/, 100, , 839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 
[7573:7585:0712/220002.522511:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 14
[7573:7585:0712/220002.522610:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 14, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/220002.522777:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://googleads.g.doubleclick.net/
[7573:7573:0712/220002.522856:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:14_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-2801108544222208&output=html&h=280&slotname=8736375397&adk=293271706&adf=3094647431&w=336&lmt=1562994001&guci=2.2.0.0.2.2.0.0&format=336x280&url=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ea=0&flash=0&wgl=1&adsid=NT&dt=1562993987626&bpp=322&bdt=34620&fdt=13173&idt=13183&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=8633212058747&frm=20&pv=2&ga_vid=1547348647.1562994001&ga_sid=1562994001&ga_hid=458394615&ga_fc=0&iag=0&icsg=1521747083460865&dssz=43&mdo=0&mso=8&u_tz=-420&u_his=2&u_java=0&u_h=647&u_w=1276&u_ah=623&u_aw=1211&u_cd=24&u_nplug=2&u_nmime=2&adx=16&ady=308&biw=1025&bih=456&scr_x=0&scr_y=0&oid=3&rx=0&eae=2&fc=656&brdim=95%2C44%2C95%2C44%2C1211%2C24%2C1050%2C603%2C1040%2C471&vis=1&rsz=%7C%7ClE%7C&abl=CS&pfx=0&fu=1048&bc=31&osw_key=1965639968&ifi=1&uci=1.vynorjc8e3uh&fsb=1&dtd=14266, 14
[7573:7573:0712/220002.523043:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:14_https://googleads.g.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* content-type:text/html; charset=UTF-8 x-content-type-options:nosniff content-encoding:br date:Sat, 13 Jul 2019 05:00:02 GMT server:cafe content-length:18619 x-xss-protection:0 alt-svc:quic="googleads.g.doubleclick.net:443"; ma=2592000; v="46,43,39",quic=":443"; ma=2592000; v="46,43,39"  ,7671, 5
[1:7:0712/220002.536563:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220002.730249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 849, 7ff4968178db
[1:1:0712/220002.742758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7ff493ed2070 0x220ef5d785e0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220002.742921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7ff493ed2070 0x220ef5d785e0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220002.743159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 985
[1:1:0712/220002.743269:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7ff493ed2070 0x220ef6b26960 , 5:3_https://www.ithome.com/, 0, , 849 0x7ff493ed2070 0x220ef6cb00e0 
[1:1:0712/220002.743409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220002.743697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/220002.743797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220002.826759:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220002.826911:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/220002.828664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 853 0x7ff493ed2070 0x220ef6cb8ae0 , "https://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/220002.841526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://googleads.g.doubleclick.net/, 13976d327620, , , 
(function(){var m=this||self;
function n(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Arr
[1:1:0712/220002.841849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#", "googleads.g.doubleclick.net", 6, 1, https://www.ithome.com, ithome.com, 3
[1:1:0712/220002.889735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/220003.103569:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/220003.105612:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_https://pos.baidu.com/, https://pos.baidu.com/, 12
[7573:7573:0712/220003.105695:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 12, 12, https://pos.baidu.com/, https://pos.baidu.com
[1:1:0712/220003.315492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/220003.315711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220003.567998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 865, 7ff4968178db
[1:1:0712/220003.617300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"706 0x7ff493ed2070 0x220ef65f07e0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220003.617587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"706 0x7ff493ed2070 0x220ef65f07e0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220003.618013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 1019
[1:1:0712/220003.618212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1019 0x7ff493ed2070 0x220ef76e61e0 , 5:3_https://www.ithome.com/, 0, , 865 0x7ff493ed2070 0x220ef6ca4460 
[1:1:0712/220003.618556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220003.619073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/220003.619249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/220004.626827:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220005.401335:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7573:7573:0712/220005.405395:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:13_https://www.ithome.com/, https://www.ithome.com/, 13
[7573:7573:0712/220005.405449:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 13, 13, https://www.ithome.com/, https://www.ithome.com
[1:1:0712/220005.676800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 926 0x7ff495dfa2e0 0x220ef672e360 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220005.678373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "c480581a9be77c59","tuid" : "u2063380_0","placement" : {"basic" : {"sspI
[1:1:0712/220005.678561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[7573:7573:0712/220005.734952:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/220005.739464:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/220005.742024:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220005.744213:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 15, 0x220ef65b5420
[1:1:0712/220005.744382:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 15
[7573:7573:0712/220005.748980:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu2063380_0, 15, 15, 
[1:1:0712/220005.763110:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220005.763309:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/220005.766817:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[1:1:0712/220005.890774:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 927 0x7ff495dfa2e0 0x220ef6cc1ce0 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220005.891579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "8772851c60264c01","tuid" : "u2575614_0","placement" : {"basic" : {"sspI
[1:1:0712/220005.891701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220005.929182:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/220005.931619:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220005.933990:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 16, 0x220ef71ff820
[1:1:0712/220005.934176:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 16
[7573:7573:0712/220005.938622:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu2575614_0, 16, 16, 
[1:1:0712/220005.956517:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220005.956672:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/220005.960138:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[7573:7573:0712/220005.975324:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/220005.982262:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/220005.996348:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 15
[7573:7573:0712/220005.996392:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[7573:7573:0712/220005.996441:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:15_https://pos.baidu.com/, https://pos.baidu.com/ucem?conwid=300&conhei=300&rdid=2063380&dc=3&exps=110011&psi=15a32fada5002fedf291a56451e16747&di=u2063380&dri=0&dis=0&dai=10&ps=1121x784&coa=at%3D3%26rsi0%3D300%26rsi1%3D300%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2583&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993996&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993996&qn=c480581a9be77c59&tt=1562993954443.41764.51242.51270, 15
[7573:7585:0712/220005.996453:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 15, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/220005.996521:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:15_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 12114 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 05:00:05 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 13:00:05 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,7671, 5
[1:7:0712/220005.999134:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220006.060772:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 928, "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220006.062302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , ___adblockplus({"queryid" : "820fcd333c6232ea","tuid" : "2723650_0","placement" : {"basic" : {"sspId
[1:1:0712/220006.062488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220006.093206:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[7573:7573:0712/220006.096792:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220006.096979:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 17, 0x220ef71fee20
[1:1:0712/220006.097155:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 17
[7573:7573:0712/220006.105569:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframe2723650_0, 17, 17, 
[1:1:0712/220006.121553:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220006.121764:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/220006.123383:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[7573:7573:0712/220006.165184:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/220006.174753:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/220006.189177:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.021199, 148, 1
[1:1:0712/220006.189455:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[7573:7585:0712/220006.221930:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 16
[7573:7585:0712/220006.222035:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 16, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/220006.222285:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[7573:7573:0712/220006.222380:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:16_https://pos.baidu.com/, https://pos.baidu.com/ucem?conwid=300&conhei=250&rdid=2575614&dc=3&exps=110011&psi=15a32fada5002fedf291a56451e16747&di=u2575614&dri=0&dis=0&dai=11&ps=619x784&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2583&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993996&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562993996&qn=8772851c60264c01&tt=1562993954443.41836.51451.51467, 16
[7573:7573:0712/220006.222571:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:16_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 2490 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 05:00:06 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 13:00:06 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,7671, 5
[1:1:0712/220006.242954:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220006.243112:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/json/hot/dajia.htm"
[1:7:0712/220006.243352:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220006.246892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7ff493ed2070 0x220ef67e1760 , "https://www.ithome.com/json/hot/dajia.htm"
[1:1:0712/220006.288851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:9_https://www.ithome.com/, 13976d3028f8, , , var _hmt = _hmt || [];
[1:1:0712/220006.289220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/json/hot/dajia.htm", "www.ithome.com", 9, 1, https://www.ithome.com, ithome.com, 3
[7573:7573:0712/220006.317376:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/220006.324062:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7573:7585:0712/220006.363422:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 17
[7573:7585:0712/220006.363523:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 17, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/220006.363693:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[7573:7573:0712/220006.363777:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:17_https://pos.baidu.com/, https://pos.baidu.com/ucem?conwid=300&conhei=250&rtbid=2483905&rdid=10312210&dc=2&exps=110011&psi=15a32fada5002fedf291a56451e16747&di=2723650&dri=0&dis=0&dai=0&ps=1133x784&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562993955498&ti=5G%E9%80%9F%E5%BA%A6%E8%B0%81%E6%9C%80%E5%BF%AB%EF%BC%8C%E7%BE%8E%E5%9B%BD%2F%E7%91%9E%E5%A3%AB%2F%E9%9F%A9%E5%9B%BD%E4%BD%8D%E5%88%97%E5%89%8D%E4%B8%89%EF%BC%8C%E6%98%8E%E6%98%BE%E9%A2%86%E5%85%88%E5%85%B6%E4%BB%96%E5%B8%82%E5%9C%BA%20-%205G%20-%20IT%E4%B9%8B%E5%AE%B6&ari=2&dbv=2&drs=1&pcs=1025x456&pss=1100x2583&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562993999&prot=2&rw=471&ltu=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ecd=1&uc=1211x623&pis=-1x-1&sr=1276x647&tcn=1562994000&qn=820fcd333c6232ea&dpv=820fcd333c6232ea&tt=1562993954443.45478.51625.51640, 17
[7573:7573:0712/220006.363970:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:17_https://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 11359 Content-Type: text/html;charset=UTF-8 Date: Sat, 13 Jul 2019 05:00:06 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Sat Jul 13 13:00:06 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,7671, 5
[1:7:0712/220006.366791:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220007.705446:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 959, 7ff496817881
[1:1:0712/220007.734210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d35273813976d24286013976d35cf0813976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d35cf0813976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d35cf0813976d35273813976d35cf0813976d35273813976d35cf0813976d35273813976d35cf08","ptid":"839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220007.736736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/","ptid":"839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220007.737210:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220007.737765:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://www.ithome.com/, 5:5_https://www.ithome.com/
[1:1:0712/220007.737936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (f){for(var g=[],h=0;h<arguments.length;++h)g[h]=arguments[h];return Pd(e,a,function(){return b.appl
[1:1:0712/220007.738122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220007.741054:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 962, 7ff496817881
[1:1:0712/220007.788863:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d35273813976d24286013976d35cf0813976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d35cf0813976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d35cf0813976d35273813976d35cf0813976d35273813976d35cf0813976d35273813976d35cf08","ptid":"839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220007.791360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/","ptid":"839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220007.791847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220007.792430:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://www.ithome.com/, 5:5_https://www.ithome.com/
[1:1:0712/220007.792594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){return sj(a)}
[1:1:0712/220007.792765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220007.796814:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0xf11d0e29c8, 0x220ef4320150
[1:1:0712/220007.796981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 30000
[1:1:0712/220007.797386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 1156
[1:1:0712/220007.797580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1156 0x7ff493ed2070 0x220ef7925860 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 962 0x7ff493ed2070 0x220ef5cd9a60 
[1:1:0712/220007.808439:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 13976d32d490, 5:3_https://www.ithome.com/, 5:7_https://www.ithome.com/, about:blank
[1:1:0712/220007.808686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d242860, open, 
[1:1:0712/220007.808923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "ithome.com", 7, 2, https://www.ithome.com, ithome.com, 3
[1:1:0712/220007.809929:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220007.813216:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 962 0x7ff493ed2070 0x220ef5cd9a60 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220007.814844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 962 0x7ff493ed2070 0x220ef5cd9a60 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220007.816362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, Mx, (a){var b=a.iframeWin,c=a.vars;b&&(c.google_iframe_start_time=b.google_iframe_start_time);var d=new 
[1:1:0712/220007.816616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 3, https://www.ithome.com, ithome.com, 3
[1:1:0712/220007.817800:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220007.819860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220007.820093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 4, , , 0
[1:1:0712/220007.821594:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220007.822355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, now, 
[1:1:0712/220007.822642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 5, https://www.ithome.com, ithome.com, 3
[1:1:0712/220007.823870:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.060270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220008.060657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 6, , , 0
[1:1:0712/220008.063226:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Vx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Tx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ox (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.063887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, De, (a){return a?new Ee(Fe(a)):Va||(Va=new Ee)}
[1:1:0712/220008.064241:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 7, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.066483:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Vx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Tx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ox (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.084092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220008.084531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 8, , , 0
[1:1:0712/220008.086407:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.086827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, Ok, (a){a.google_reactive_ads_global_state||(a.google_reactive_ads_global_state=new Nk);return a.google_
[1:1:0712/220008.087209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 9, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.089067:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.096815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, addEventListener, 
[1:1:0712/220008.097256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 10, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.099469:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.100124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, Vm, (a){return!!Um(a)||null!=a.google_pgb_reactive}
[1:1:0712/220008.100768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 11, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.102740:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.112963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220008.113413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 12, , , 0
[1:1:0712/220008.115165:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.115781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, nv, (){jv=iv();lv=jv.googleToken=jv.googleToken||{};var a=C();lv[1]&&lv[3]>a&&0<lv[2]||(lv[1]="",lv[2]=-
[1:1:0712/220008.116306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 13, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.118519:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.207033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, now, 
[1:1:0712/220008.207526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 14, , , 0
[1:1:0712/220008.209673:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.210068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, round, 
[1:1:0712/220008.210561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 15, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.212657:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.213203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, now, 
[1:1:0712/220008.213656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 16, , , 0
[1:1:0712/220008.215737:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.216116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, dv, (a,b,c){a-=b;return a>=(void 0===c?1E5:c)?"M":0<=a?a:"-M"}
[1:1:0712/220008.216666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 17, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.218814:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.354518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220008.355031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 18, , , 0
[1:1:0712/220008.357513:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.358145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, De, (a){return a?new Ee(Fe(a)):Va||(Va=new Ee)}
[1:1:0712/220008.358696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 19, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.360892:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.387467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, l.cb, (){return!(!window||!Array)}
[1:1:0712/220008.388026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 20, , , 0
[1:1:0712/220008.390287:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.390725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, mh, (a){return!(!a||!a.call)&&"function"===typeof a}
[1:1:0712/220008.391275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 21, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.392765:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.393195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, l.Qa, (){return this.i}
[1:1:0712/220008.393752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 22, , , 0
[1:1:0712/220008.395936:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.396414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, as, (a,b){if(!b)return null;var c=Ok(b);if(!c.wasReactiveAdConfigHandlerRegistered)return null;var d=0;N
[1:1:0712/220008.397018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 23, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.399148:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.416002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220008.416669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 24, , , 0
[1:1:0712/220008.419071:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.420262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, xm, (a){return{visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[a.visibilityState||a.webkitVisibilit
[1:1:0712/220008.420948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 25, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.423345:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.427017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.427659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 26, , , 0
[1:1:0712/220008.430051:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.430557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220008.431203:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 27, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.433500:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.433887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.434508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 28, , , 0
[1:1:0712/220008.436849:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.437279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.438000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 29, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.440358:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.440905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.441589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 30, , , 0
[1:1:0712/220008.443994:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.444408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.445101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 31, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.447486:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.455472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220008.456176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 32, , , 0
[1:1:0712/220008.458520:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.458925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/220008.459681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 33, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.462037:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.462811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.463538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 34, , , 0
[1:1:0712/220008.466365:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.466915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220008.467696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 35, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.470020:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.470479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.471226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 36, , , 0
[1:1:0712/220008.474177:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.474759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.475707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 37, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.478108:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.478625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.479376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 38, , , 0
[1:1:0712/220008.481812:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.482210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.483030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 39, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.485376:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.493332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 40, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220008.494182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 40, , , 0
[1:1:0712/220008.496484:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.496934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 41, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/220008.497804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 41, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.500097:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.500869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 42, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.501705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 42, , , 0
[1:1:0712/220008.510245:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.510890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 43, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220008.511822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 43, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.514207:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.514630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 44, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.515498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 44, , , 0
[1:1:0712/220008.518018:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.518427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 45, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.519617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 45, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.522035:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.522568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 46, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.523425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 46, , , 0
[1:1:0712/220008.525820:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.526231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 47, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.527180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 47, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.529745:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.540556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 48, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220008.541564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 48, , , 0
[1:1:0712/220008.543859:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.544355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 49, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.545361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 49, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.547690:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.548866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 50, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.549928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 50, , , 0
[1:1:0712/220008.552481:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.553029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 51, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/220008.554064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 51, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.556396:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.556939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 52, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.557940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 52, , , 0
[1:1:0712/220008.560439:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.561077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 53, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.562401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 53, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.564996:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.565582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 54, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getAttribute, 
[1:1:0712/220008.566776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 54, , , 0
[1:1:0712/220008.569409:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.569855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 55, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/220008.570905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 55, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.573254:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.574781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 56, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.575860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 56, , , 0
[1:1:0712/220008.578377:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.578785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 57, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/220008.579889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 57, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.582400:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.583671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 58, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.584775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 58, , , 0
[1:1:0712/220008.587417:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.587973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 59, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/220008.589257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 59, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.591828:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.592815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 60, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.593987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 60, , , 0
[1:1:0712/220008.596865:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.597577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 61, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/220008.598749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 61, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.601296:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.608894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 62, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, contains, 
[1:1:0712/220008.610117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 62, , , 0
[1:1:0712/220008.612366:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.612855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 63, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, qw, (a){return!!a&&/^left|right$/.test(a.cssFloat||a.styleFloat)}
[1:1:0712/220008.614098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 63, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.616442:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.622062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 64, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getElementById, 
[1:1:0712/220008.623276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 64, , , 0
[1:1:0712/220008.625389:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.625897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 65, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, C, (){return+new Date}
[1:1:0712/220008.627178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 65, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.629335:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.639689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 66, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getBoundingClientRect, 
[1:1:0712/220008.640947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 66, , , 0
[1:1:0712/220008.643101:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.646570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 67, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, C, (){return+new Date}
[1:1:0712/220008.647856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 67, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.650040:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.653445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 68, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.654727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 68, , , 0
[1:1:0712/220008.657020:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.657479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 69, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.658767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 69, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.660951:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.662441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 70, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.663736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 70, , , 0
[1:1:0712/220008.666127:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.666619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 71, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.667979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 71, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.670210:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.671637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 72, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.672962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 72, , , 0
[1:1:0712/220008.675313:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.675790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 73, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.677128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 73, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.679318:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.680762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 74, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.682113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 74, , , 0
[1:1:0712/220008.684459:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.684930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 75, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.686329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 75, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.688604:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.690138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 76, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.691554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 76, , , 0
[1:1:0712/220008.693977:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.694442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 77, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.695871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 77, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.698137:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.699563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 78, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/, 13976d242860, 13976d352738, getComputedStyle, 
[1:1:0712/220008.700939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 78, , , 0
[1:1:0712/220008.703265:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220008.703760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 79, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d242860, test, 
[1:1:0712/220008.705177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 79, https://www.ithome.com, ithome.com, 3
[1:1:0712/220008.707379:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.015644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 80, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, createElement, 
[1:1:0712/220009.017315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 80, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.019639:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ve (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.020941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 81, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, N, (a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b.call(void 0,a[c],c,a)}
[1:1:0712/220009.022442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 81, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.024833:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.025791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 82, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.027307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 82, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.029742:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.030173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 83, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.031797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 83, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.034272:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.035002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 84, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.036474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 84, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.038955:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.039329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 85, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.040851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 85, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.043123:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.043815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 86, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.045307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 86, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.047680:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.048180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 87, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.049707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 87, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.052030:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.052760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 88, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.054321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 88, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.056773:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.057203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 89, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.058765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 89, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.061089:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.061803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 90, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.063365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 90, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.065841:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.066263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 91, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.067884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 91, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.069837:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.070186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 92, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.070804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 92, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.071540:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.071775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 93, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.072323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 93, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.073028:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.073328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 94, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.073884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 94, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.074565:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.074798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 95, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.075334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 95, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.076035:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.076337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 96, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.076996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 96, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.077744:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.077955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 97, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.078515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 97, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.079211:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.079502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 98, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/, 13976d32d490, 13976d352738, setAttribute, 
[1:1:0712/220009.080085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 7, 98, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.084687:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.085178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 99, -5:3_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/-5:7_https://www.ithome.com/-5:4_https://www.ithome.com/, 13976d352738, 13976d32d490, call, 
[1:1:0712/220009.087089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 99, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.089420:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/220009.090154:INFO:switcher_impl.cc(1415)] 			[ERROR] updated frame chain. The number of frame chain is larger than the thresold, please check it! [num, thresold] = 100, 100
[7573:7573:0712/220009.096007:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220009.098475:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 18, 0x220ef7959220
[1:1:0712/220009.098701:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 18
[7573:7573:0712/220009.103182:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_ads_frame2, 18, 18, 
[1:1:0712/220009.112565:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220009.112738:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ithome.com
[7573:7573:0712/220009.121317:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.ithome.com/
[7573:7573:0712/220009.474590:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7573:7573:0712/220009.480670:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/220009.491865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11d0e29c8, 0x220ef4320258
[1:1:0712/220009.492079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 0
[1:1:0712/220009.492434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 1174
[1:1:0712/220009.492632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7ff493ed2070 0x220ef672efe0 , 5:3_https://www.ithome.com/, 100, , 962 0x7ff493ed2070 0x220ef5cd9a60 
[1:1:0712/220009.496021:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11d0fc5c8, 0x220ef4320258
[1:1:0712/220009.496218:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 0
[1:1:0712/220009.496666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 1175
[1:1:0712/220009.496932:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7ff493ed2070 0x220ef79885e0 , 5:3_https://www.ithome.com/, 100, , 962 0x7ff493ed2070 0x220ef5cd9a60 
[1:1:0712/220009.501479:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xf11d0e29c8, 0x220ef4320150
[1:1:0712/220009.501688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 0
[1:1:0712/220009.502107:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 1176
[1:1:0712/220009.502326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7ff493ed2070 0x220ef76aca60 , 5:3_https://www.ithome.com/, 100, , 962 0x7ff493ed2070 0x220ef5cd9a60 
[7573:7585:0712/220009.522857:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 18
[7573:7585:0712/220009.522948:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 18, HandleIncomingMessage, HandleIncomingMessage
[7573:7573:0712/220009.523129:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://googleads.g.doubleclick.net/
[7573:7573:0712/220009.523207:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:18_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-2801108544222208&output=html&h=280&slotname=3552956190&adk=3957689039&adf=4191238081&w=336&lmt=1562994008&guci=2.2.0.0.2.2.0.0&format=336x280&url=https%3A%2F%2Fwww.ithome.com%2F0%2F432%2F394.htm&ea=0&flash=0&wgl=1&adsid=NT&dt=1562993987956&bpp=162&bdt=34953&fdt=19858&idt=19868&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&prev_fmts=336x280&correlator=8633212058747&frm=20&pv=1&ga_vid=1547348647.1562994001&ga_sid=1562994001&ga_hid=458394615&ga_fc=0&iag=0&icsg=1521747083460865&dssz=44&mdo=0&mso=8&u_tz=-420&u_his=2&u_java=0&u_h=647&u_w=1276&u_ah=623&u_aw=1211&u_cd=24&u_nplug=2&u_nmime=2&adx=408&ady=308&biw=1025&bih=456&scr_x=0&scr_y=0&oid=3&rx=0&eae=2&fc=656&brdim=95%2C44%2C95%2C44%2C1211%2C24%2C1050%2C603%2C1040%2C471&vis=1&rsz=%7C%7ClE%7C&abl=CS&pfx=0&fu=1048&bc=31&osw_key=837226333&ifi=2&uci=2.c52mdolmoi7s&fsb=1&dtd=21053, 18
[7573:7573:0712/220009.523374:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:18_https://googleads.g.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* content-type:text/html; charset=UTF-8 x-content-type-options:nosniff content-encoding:br date:Sat, 13 Jul 2019 05:00:09 GMT server:cafe content-length:37764 x-xss-protection:0 alt-svc:quic="googleads.g.doubleclick.net:443"; ma=2592000; v="46,43,39",quic=":443"; ma=2592000; v="46,43,39"  ,7671, 5
[1:7:0712/220009.527738:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220009.630964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.ithome.com/, 960, 7ff496817881
[1:1:0712/220009.682491:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"13976d35273813976d24286013976d35cf0813976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d35cf0813976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d24286013976d35273813976d35cf0813976d35273813976d35cf0813976d35273813976d35cf0813976d35273813976d35cf08","ptid":"839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220009.685079:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:3_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/-5:4_https://www.ithome.com/-5:5_https://www.ithome.com/","ptid":"839 0x7ff4aa55c080 0x220ef5d76560 1 0 0x220ef5d76578 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220009.685583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220009.686159:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.ithome.com/, 5:5_https://www.ithome.com/
[1:1:0712/220009.686363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.ithome.com/, 13976d352738, , , (){b.document.close()}
[1:1:0712/220009.686617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 4, 1, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.687672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.ithome.com/-5:5_https://www.ithome.com/, 13976d35cf08, 13976d352738, close, 
[1:1:0712/220009.688001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 5, 2, https://www.ithome.com, ithome.com, 3
[1:1:0712/220009.688496:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/220009.796285:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:14_https://googleads.g.doubleclick.net/
[1:1:0712/220010.042943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 985, 7ff4968178db
[1:1:0712/220010.070597:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"849 0x7ff493ed2070 0x220ef6cb00e0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220010.070776:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"849 0x7ff493ed2070 0x220ef6cb00e0 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220010.071020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 1201
[1:1:0712/220010.071129:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1201 0x7ff493ed2070 0x220ef598fc60 , 5:3_https://www.ithome.com/, 0, , 985 0x7ff493ed2070 0x220ef6b26960 
[1:1:0712/220010.071312:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220010.071595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/220010.071705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220010.398720:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220010.670456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.readyState
[1:1:0712/220010.670620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220010.881234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 1019, 7ff4968178db
[1:1:0712/220010.919778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"865 0x7ff493ed2070 0x220ef6ca4460 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220010.920063:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"865 0x7ff493ed2070 0x220ef6ca4460 ","rf":"5:3_https://www.ithome.com/"}
[1:1:0712/220010.920496:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 1211
[1:1:0712/220010.920707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1211 0x7ff493ed2070 0x220ef76fd7e0 , 5:3_https://www.ithome.com/, 0, , 1019 0x7ff493ed2070 0x220ef76e61e0 
[1:1:0712/220010.921074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220010.921613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/220010.921788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220011.286775:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220011.286929:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/block/topnews.htm"
[1:1:0712/220011.735459:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220013.840349:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:15_https://pos.baidu.com/
[1:1:0712/220014.521903:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220014.522136:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.523004:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.523857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.ithome.com/, 13976d242860, , , document.write('<a href="http://www.miitbeian.gov.cn" target="_blank" rel ="nofollow">鲁ICP备11016
[1:1:0712/220014.524054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ithome.com/0/432/394.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220014.533665:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.640308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.643171:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.648979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.649973:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "ithome.com", "ithome.com"
[1:1:0712/220014.670974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ithome.com/0/432/394.htm", 500
[1:1:0712/220014.671244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.ithome.com/, 1283
[1:1:0712/220014.671356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1283 0x7ff493ed2070 0x220ef816b760 , 5:3_https://www.ithome.com/, 1, -5:3_https://www.ithome.com/, 1124 0x7ff493ed2070 0x220ef67ed460 
		remove user.12_f849b3c1 -> 0
		remove user.13_f3c88288 -> 0
		remove user.14_1cfd531b -> 0
		remove user.15_ec3c70bc -> 0
		remove user.16_9b7e2ec6 -> 0
[1:1:0712/220014.708762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.717525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.798849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.886941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.895371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.905387:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
[1:1:0712/220014.942752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1124 0x7ff493ed2070 0x220ef67ed460 , "https://www.ithome.com/0/432/394.htm"
