[0712/220131.981852:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220131.982275:INFO:switcher_clone.cc(787)] backtrace rip is 7fd654834891
[0712/220132.983463:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220132.983741:INFO:switcher_clone.cc(787)] backtrace rip is 7fc25eb0b891
[1:1:0712/220132.987760:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/220132.987939:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/220132.992615:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[7857:7857:0712/220134.287922:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f844fc55-bb86-4a3b-aa4a-ed1cc6955271
[0712/220134.464830:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220134.465098:INFO:switcher_clone.cc(787)] backtrace rip is 7f9661078891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[7889:7889:0712/220134.635576:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7889
[7900:7900:0712/220134.636034:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=7900
[7857:7857:0712/220134.883140:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[7857:7885:0712/220134.884013:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/220134.884227:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220134.884422:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220134.884960:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220134.885108:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/220134.888003:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x375ffedd, 1
[1:1:0712/220134.888314:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x143653be, 0
[1:1:0712/220134.888465:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x11fbf0de, 3
[1:1:0712/220134.888617:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2ce994ef, 2
[1:1:0712/220134.888923:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbe533614 ffffffddfffffffe5f37 ffffffefffffff94ffffffe92c ffffffdefffffff0fffffffb11 , 10104, 4
[1:1:0712/220134.889909:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7857:7885:0712/220134.890128:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�S6��_7��,�����s
[1:1:0712/220134.890115:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc25cd460a0, 3
[7857:7885:0712/220134.890302:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �S6��_7��,�������s
[1:1:0712/220134.890387:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc25ced1080, 2
[7857:7885:0712/220134.890654:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/220134.890588:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc246b94d20, -2
[7857:7885:0712/220134.890755:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7908, 4, be533614 ddfe5f37 ef94e92c def0fb11 
[1:1:0712/220134.909062:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220134.909929:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ce994ef
[1:1:0712/220134.910858:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ce994ef
[1:1:0712/220134.912404:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ce994ef
[1:1:0712/220134.913913:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.914099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.914302:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.914493:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.915115:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ce994ef
[1:1:0712/220134.915487:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc25eb0b7ba
[1:1:0712/220134.915625:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc25eb02def, 7fc25eb0b77a, 7fc25eb0d0cf
[1:1:0712/220134.921317:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2ce994ef
[1:1:0712/220134.921656:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2ce994ef
[1:1:0712/220134.922419:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2ce994ef
[1:1:0712/220134.924419:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.924604:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.924784:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.924971:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2ce994ef
[1:1:0712/220134.926403:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2ce994ef
[1:1:0712/220134.926761:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc25eb0b7ba
[1:1:0712/220134.926892:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc25eb02def, 7fc25eb0b77a, 7fc25eb0d0cf
[1:1:0712/220134.934628:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220134.935059:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220134.935219:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5b2cdce8, 0x7ffd5b2cdc68)
[1:1:0712/220134.950372:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220134.956546:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[7857:7857:0712/220135.530556:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7857:7857:0712/220135.532021:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7857:7867:0712/220135.554105:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[7857:7867:0712/220135.554203:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[7857:7857:0712/220135.554457:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[7857:7857:0712/220135.554555:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[7857:7857:0712/220135.554722:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,7908, 4
[1:7:0712/220135.559408:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[7857:7878:0712/220135.582492:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/220135.639896:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1a5af13db220
[1:1:0712/220135.640741:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/220135.962077:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/220137.431968:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220137.435818:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7857:7857:0712/220137.560766:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[7857:7857:0712/220137.560904:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/220138.260814:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220138.461046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ba537e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/220138.461323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220138.490333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ba537e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/220138.490626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220138.651159:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220138.651359:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220139.077960:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220139.085942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ba537e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/220139.086199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220139.119316:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220139.129763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ba537e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/220139.130067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220139.142038:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220139.145422:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a5af13d9e20
[1:1:0712/220139.145605:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[7857:7857:0712/220139.145776:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7857:7857:0712/220139.158693:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[7857:7857:0712/220139.196179:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[7857:7857:0712/220139.196340:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/220139.242250:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220139.993974:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7fc24876f2e0 0x1a5af13e8560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220139.995269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ba537e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/220139.995461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220139.996949:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[7857:7857:0712/220140.068474:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220140.069465:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1a5af13da820
[1:1:0712/220140.069644:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[7857:7857:0712/220140.075534:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/220140.077979:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220140.078100:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[7857:7857:0712/220140.094696:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[7857:7857:0712/220140.101400:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7857:7857:0712/220140.102398:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7857:7867:0712/220140.108344:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[7857:7867:0712/220140.108427:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[7857:7857:0712/220140.108581:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[7857:7857:0712/220140.108656:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[7857:7857:0712/220140.108785:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,7908, 4
[1:7:0712/220140.111793:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220140.553681:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/220140.813979:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fc24876f2e0 0x1a5af1777160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220140.815130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 31ba537e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/220140.815659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220140.816411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220141.118616:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7857:7857:0712/220141.120652:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[7857:7857:0712/220141.120754:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/220141.300960:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220141.919237:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220141.919496:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7857:7857:0712/220141.967719:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[7857:7885:0712/220141.968217:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/220141.968445:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220141.968682:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220141.969134:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220141.969351:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/220141.972810:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x39bd906a, 1
[1:1:0712/220141.973274:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x22eb3214, 0
[1:1:0712/220141.973462:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x646b6dc, 3
[1:1:0712/220141.973641:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e647046, 2
[1:1:0712/220141.973817:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1432ffffffeb22 6affffff90ffffffbd39 4670642e ffffffdcffffffb64606 , 10104, 5
[1:1:0712/220141.974796:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7857:7885:0712/220141.975005:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING2�"j��9Fpd.ܶF�s
[7857:7885:0712/220141.975078:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 2�"j��9Fpd.ܶFX�s
[1:1:0712/220141.975192:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc25cd460a0, 3
[7857:7885:0712/220141.975351:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7953, 5, 1432eb22 6a90bd39 4670642e dcb64606 
[1:1:0712/220141.975371:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc25ced1080, 2
[1:1:0712/220141.975554:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc246b94d20, -2
[1:1:0712/220141.996809:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220141.997267:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e647046
[1:1:0712/220141.997635:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e647046
[1:1:0712/220141.998375:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e647046
[1:1:0712/220142.000030:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.000269:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.000497:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.000707:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.001322:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e647046
[1:1:0712/220142.001472:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc25eb0b7ba
[1:1:0712/220142.001556:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc25eb02def, 7fc25eb0b77a, 7fc25eb0d0cf
[1:1:0712/220142.003025:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e647046
[1:1:0712/220142.003203:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e647046
[1:1:0712/220142.003479:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e647046
[1:1:0712/220142.004135:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.004401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.004642:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.004882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e647046
[1:1:0712/220142.006476:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e647046
[1:1:0712/220142.006931:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc25eb0b7ba
[1:1:0712/220142.007100:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc25eb02def, 7fc25eb0b77a, 7fc25eb0d0cf
[1:1:0712/220142.016785:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220142.017386:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220142.017577:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5b2cdce8, 0x7ffd5b2cdc68)
[1:1:0712/220142.031662:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220142.036399:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/220142.216123:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a5af13b0220
[1:1:0712/220142.216403:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/220142.283136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220142.287795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 31ba5390e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/220142.288097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220142.295889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[7857:7857:0712/220142.779060:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7857:7857:0712/220142.817853:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[7857:7885:0712/220142.818198:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/220142.818445:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220142.818665:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220142.819135:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220142.819325:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/220142.822687:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xc246eec, 1
[1:1:0712/220142.823031:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36049633, 0
[1:1:0712/220142.823275:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3108c79c, 3
[1:1:0712/220142.823484:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3b8f8de, 2
[1:1:0712/220142.823662:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 33ffffff960436 ffffffec6e240c ffffffdefffffff8ffffffb803 ffffff9cffffffc70831 , 10104, 6
[1:1:0712/220142.824854:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[7857:7885:0712/220142.825173:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING3�6�n$�����1F�s
[7857:7885:0712/220142.825265:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 3�6�n$�����1��F�s
[7857:7885:0712/220142.825578:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 7969, 6, 33960436 ec6e240c def8b803 9cc70831 
[1:1:0712/220142.825908:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc25cd460a0, 3
[1:1:0712/220142.826123:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc25ced1080, 2
[1:1:0712/220142.826336:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc246b94d20, -2
[1:1:0712/220142.837262:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220142.837531:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b8f8de
[1:1:0712/220142.837659:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b8f8de
[1:1:0712/220142.837884:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b8f8de
[1:1:0712/220142.838362:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.838488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.838581:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.838676:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.838904:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b8f8de
[1:1:0712/220142.839024:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc25eb0b7ba
[1:1:0712/220142.839097:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc25eb02def, 7fc25eb0b77a, 7fc25eb0d0cf
[1:1:0712/220142.840826:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b8f8de
[1:1:0712/220142.840988:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b8f8de
[1:1:0712/220142.841254:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b8f8de
[1:1:0712/220142.841948:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.842057:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.842152:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.842242:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b8f8de
[1:1:0712/220142.842691:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b8f8de
[1:1:0712/220142.842848:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc25eb0b7ba
[1:1:0712/220142.842922:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc25eb02def, 7fc25eb0b77a, 7fc25eb0d0cf
[7857:7857:0712/220142.844282:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/220142.845148:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220142.845504:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220142.845596:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5b2cdce8, 0x7ffd5b2cdc68)
[7857:7867:0712/220142.856632:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[7857:7867:0712/220142.856733:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[7857:7857:0712/220142.856949:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://live.ithome.com/
[7857:7857:0712/220142.857018:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://live.ithome.com/, https://live.ithome.com/item/431069.htm, 1
[7857:7857:0712/220142.857077:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://live.ithome.com/, HTTP/1.1 200 OK Server: BLB/1.0.170 Date: Sat, 13 Jul 2019 05:01:42 GMT Content-Type: text/html Content-Length: 4814 Connection: keep-alive Content-Encoding: gzip Last-Modified: Tue, 02 Jul 2019 13:45:37 GMT Accept-Ranges: bytes ETag: "8016c76ddc30d51:0" Vary: Accept-Encoding X-Powered-By: ASP.NET Set-Cookie: BEC=b503cb09ba2bd51560fd9fa630f6a218|1562994102|1562994102;Path=/  ,0, 6
[1:1:0712/220142.857946:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[3:3:0712/220142.859804:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/220142.863192:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/220142.936003:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220143.111086:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1a5af13d2220
[1:1:0712/220143.111361:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/220143.212040:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://live.ithome.com/
[1:1:0712/220143.711091:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[7857:7857:0712/220143.765659:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://live.ithome.com/, https://live.ithome.com/, 1
[7857:7857:0712/220143.765759:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://live.ithome.com/, https://live.ithome.com
[1:1:0712/220143.834358:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220144.000216:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220144.000507:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://live.ithome.com/item/431069.htm"
[1:1:0712/220144.449772:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/220144.722140:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220144.726811:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220144.738402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , /*! jQuery v1.10.2 | (c) 2005, 2013 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingU
[1:1:0712/220144.738734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "live.ithome.com", 3, 1, , , 0
[1:1:0712/220144.767545:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220144.771470:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220144.772021:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220144.772422:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220144.772833:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
		remove user.f_9172b4c -> 0
[1:1:0712/220145.066195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.077264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.087695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.146482:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.205557:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.214963:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "live.ithome.com", "ithome.com"
[1:1:0712/220145.239969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.245308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.256725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.265931:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.276577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 193 0x7fc246bafbd0 0x1a5af15717d8 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.293292:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220145.296769:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1a5af14bfe20
[1:1:0712/220145.296969:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/220145.317030:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220145.317257:INFO:render_frame_impl.cc(7019)] 	 [url] = https://live.ithome.com
[1:1:0712/220145.333121:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220145.336555:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1a5af14bf420
[1:1:0712/220145.336807:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/220145.389048:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.326184, 185, 1
[1:1:0712/220145.389336:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220145.948365:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220145.948631:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.949238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7fc246847070 0x1a5af1704860 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.951865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , 
        $.support.fixed = !document.all || document.all && document.compatMode == "CSS1Compat" && w
[1:1:0712/220145.952095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220145.968286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 239 0x7fc246847070 0x1a5af1704860 , "https://live.ithome.com/item/431069.htm"
[1:1:0712/220145.974391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://live.ithome.com/item/431069.htm"
[1:1:0712/220146.646087:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "ithome.com", "ithome.com"
[1:1:0712/220147.225693:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://live.ithome.com/item/431069.htm"
[1:1:0712/220147.226476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , r, (e,i){var s,u,c,p;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=x.noop,$n&&delete 
[1:1:0712/220147.226697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220147.230409:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://live.ithome.com/item/431069.htm"
[1:1:0712/220147.235811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://live.ithome.com/item/431069.htm"
[1:1:0712/220147.236530:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x314b0b3d1718
[1:1:0712/220149.802678:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220149.803171:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220201.979819:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220201.980367:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220201.981132:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[7857:7857:0712/220213.655859:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7857:7857:0712/220213.657800:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[7857:7857:0712/220213.660564:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://live.ithome.com/
[7857:7857:0712/220213.663869:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[7857:7857:0712/220213.665673:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[7857:7857:0712/220213.670923:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://live.ithome.com/, https://live.ithome.com/, 5
[7857:7857:0712/220213.670988:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://live.ithome.com/, https://live.ithome.com
[7857:7857:0712/220213.750305:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/220213.766725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/220213.768122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[3:3:0712/220213.819953:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[7857:7857:0712/220213.903439:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[7857:7857:0712/220213.968297:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[7857:7857:0712/220213.975470:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[7857:7867:0712/220214.010050:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[7857:7867:0712/220214.010152:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[7857:7857:0712/220214.010412:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://dyn.ithome.com/
[7857:7857:0712/220214.010520:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://dyn.ithome.com/, https://dyn.ithome.com/comment/de13de6cafbfe0f2, 4
[7857:7857:0712/220214.010686:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://dyn.ithome.com/, HTTP/1.1 200 OK Server: JSP3/2.0.14 Date: Sat, 13 Jul 2019 05:02:13 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Content-Encoding: gzip Set-Cookie: BEC=131d415399dad871ab194875be114420|1562994133|1562992784;Path=/ Accept-Ranges: bytes Cache-Control: private X-AspNet-Version: 4.0.30319 X-Powered-By: ASP.NET Ohc-File-Size: 4981 Timing-Allow-Origin: * Ohc-Response-Time: 0 0 2 2 119 119  ,7969, 6
[1:7:0712/220214.020503:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220214.399606:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://dyn.ithome.com/
[1:1:0712/220214.679902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220214.681086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[7857:7857:0712/220215.002536:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://dyn.ithome.com/, https://dyn.ithome.com/, 4
[7857:7857:0712/220215.002619:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://dyn.ithome.com/, https://dyn.ithome.com
[1:1:0712/220215.003366:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220215.927673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220215.927902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220215.956554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://live.ithome.com/item/431069.htm"
[1:1:0712/220215.957222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , v.handle, (e){return typeof x===i||e&&x.event.triggered===e.type?t:x.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/220215.957402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220217.786470:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220218.130173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220218.130412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220218.283135:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220218.283381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220218.463015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220218.463247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220218.823744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220218.823910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220219.288602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220219.288770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220219.509213:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 652 0x7fc246bafbd0 0x1a5af73cf358 , "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220219.519103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , , /*! jQuery v1.11.0 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/220219.519379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "dyn.ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220219.741477:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 652 0x7fc246bafbd0 0x1a5af73cf358 , "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220219.750612:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "dyn.ithome.com", "ithome.com"
[1:1:0712/220219.778715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 652 0x7fc246bafbd0 0x1a5af73cf358 , "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220219.816726:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.079288, 58, 1
[1:1:0712/220219.816938:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220220.069252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220220.069496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220220.891996:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220220.892211:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220220.893118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 680 0x7fc246847070 0x1a5af14cfe60 , "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220220.894125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , , var commentpage = 1;var commentpageLatest = 1;var hpage = 1;
[1:1:0712/220220.894462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220220.901565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 680 0x7fc246847070 0x1a5af14cfe60 , "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220221.126432:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686, "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220221.127304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , , var popWin = {
    scrolling: 'no',
    //是否显示滚动条 no,yes,auto

int: function() {

[1:1:0712/220221.127532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220221.131280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686, "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220221.467285:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2ee3605c950, 0x1a5af125d198
[1:1:0712/220221.467499:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dyn.ithome.com/comment/de13de6cafbfe0f2", 0
[1:1:0712/220221.467915:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://dyn.ithome.com/, 740
[1:1:0712/220221.468118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7fc246847070 0x1a5af936b1e0 , 6:4_https://dyn.ithome.com/, 1, -6:4_https://dyn.ithome.com/, 686
[1:1:0712/220221.573051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://dyn.ithome.com/comment/de13de6cafbfe0f2", 13
[1:1:0712/220221.573500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://dyn.ithome.com/, 743
[1:1:0712/220221.573688:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7fc246847070 0x1a5af921eb60 , 6:4_https://dyn.ithome.com/, 1, -6:4_https://dyn.ithome.com/, 686
[1:1:0712/220221.589946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686, "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220221.617273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[7857:7857:0712/220221.980097:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: https://dyn.ithome.com/comment/de13de6cafbfe0f2 (0)
[1:1:0712/220222.051711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220222.052009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
[1:1:0712/220222.191537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://live.ithome.com/item/431069.htm"
[1:1:0712/220222.192290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , v.handle, (e){return typeof x===i||e&&x.event.triggered===e.type?t:x.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/220222.192516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/220222.928769:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220222.929555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Yc[g],b=void 0,f.onreadystatechange=n.noop,e)4
[1:1:0712/220222.929816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220222.930923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220222.933647:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220222.934404:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x314b0b3de720
[1:1:0712/220223.003286:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.003997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Yc[g],b=void 0,f.onreadystatechange=n.noop,e)4
[1:1:0712/220223.004269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220223.004871:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.007276:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.007991:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x314b0b3de720
[1:1:0712/220223.142647:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.143423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , b, (c,e){var h,i,j;if(b&&(e||4===f.readyState))if(delete Yc[g],b=void 0,f.onreadystatechange=n.noop,e)4
[1:1:0712/220223.143682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220223.144190:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.144858:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x314b0b3de720
[1:1:0712/220223.220328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:4_https://dyn.ithome.com/, 740, 7fc24918c881
[1:1:0712/220223.251054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"176782013a60","ptid":"686","rf":"6:4_https://dyn.ithome.com/"}
[1:1:0712/220223.251359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:4_https://dyn.ithome.com/","ptid":"686","rf":"6:4_https://dyn.ithome.com/"}
[1:1:0712/220223.251680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.252264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , , (){_b=void 0}
[1:1:0712/220223.252518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220223.254340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://dyn.ithome.com/, 743, 7fc24918c8db
[1:1:0712/220223.284718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"176782013a60","ptid":"686","rf":"6:4_https://dyn.ithome.com/"}
[1:1:0712/220223.284993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:4_https://dyn.ithome.com/","ptid":"686","rf":"6:4_https://dyn.ithome.com/"}
[1:1:0712/220223.285363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:4_https://dyn.ithome.com/, 787
[1:1:0712/220223.285586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 787 0x7fc246847070 0x1a5af95fa2e0 , 6:4_https://dyn.ithome.com/, 0, , 743 0x7fc246847070 0x1a5af921eb60 
[1:1:0712/220223.285883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://dyn.ithome.com/comment/de13de6cafbfe0f2"
[1:1:0712/220223.286428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:4_https://dyn.ithome.com/, 176782013a60, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/220223.286682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 1, https://live.ithome.com, ithome.com, 3
[1:1:0712/220223.297547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -6:4_https://dyn.ithome.com/-6:3_https://live.ithome.com/, 176781ee2860, 176782013a60, getElementById, 
[1:1:0712/220223.297791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 2, , , 0
[1:1:0712/220223.304863:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	AutoifHeight (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.<anonymous> (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.d.complete (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	j (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	Object.fireWith [as resolveWith] (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	i (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	n.fx.tick (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)

[1:1:0712/220223.306568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -6:4_https://dyn.ithome.com/-6:3_https://live.ithome.com/-6:4_https://dyn.ithome.com/, 176782013a60, 176781ee2860, n, (a,b){return new n.fn.init(a,b)}
[1:1:0712/220223.306858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 3, https://live.ithome.com, ithome.com, 3
[1:1:0712/220223.310434:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	AutoifHeight (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.<anonymous> (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.d.complete (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	j (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	Object.fireWith [as resolveWith] (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	i (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	n.fx.tick (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)

[1:1:0712/220223.314493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -6:4_https://dyn.ithome.com/-6:3_https://live.ithome.com/-6:4_https://dyn.ithome.com/-6:3_https://live.ithome.com/, 176781ee2860, 176782013a60, setAttribute, 
[1:1:0712/220223.314752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 4, , , 0
[1:1:0712/220223.321296:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Function.attr (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	Function.removeAttr (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	HTMLIFrameElement.<anonymous> (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	Function.each (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	n.fn.init.each (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	n.fn.init.removeAttr (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	AutoifHeight (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.<anonymous> (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.d.complete (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	j (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	Object.fireWith [as resolveWith] (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	i (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	n.fx.tick (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)

[1:1:0712/220223.321941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -6:4_https://dyn.ithome.com/-6:3_https://live.ithome.com/-6:4_https://dyn.ithome.com/-6:3_https://live.ithome.com/-6:4_https://dyn.ithome.com/, 176782013a60, 176781ee2860, n, (a,b){return new n.fn.init(a,b)}
[1:1:0712/220223.322277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://dyn.ithome.com/comment/de13de6cafbfe0f2", "ithome.com", 4, 5, https://live.ithome.com, ithome.com, 3
[1:1:0712/220223.325779:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	AutoifHeight (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.<anonymous> (https://img.ithome.com/file/js/comment.js?r=7:1:1)
	HTMLDivElement.d.complete (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	j (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	Object.fireWith [as resolveWith] (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	i (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)
	n.fx.tick (https://cdn.jsdelivr.net/npm/jquery@1.11.0/dist/jquery.min.js:1:1)

[1:1:0712/220223.878566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://live.ithome.com/, 176781ee2860, , , document.readyState
[1:1:0712/220223.878831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://live.ithome.com/item/431069.htm", "ithome.com", 3, 1, , , 0
