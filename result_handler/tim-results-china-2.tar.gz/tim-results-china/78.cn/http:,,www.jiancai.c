[0712/105709.599712:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105709.600023:INFO:switcher_clone.cc(787)] backtrace rip is 7f2f6dd81891
[0712/105710.510420:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105710.510687:INFO:switcher_clone.cc(787)] backtrace rip is 7f93e0a23891
[1:1:0712/105710.514771:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/105710.514946:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/105710.520301:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/105711.927775:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105711.928161:INFO:switcher_clone.cc(787)] backtrace rip is 7fb3b6527891
[127462:127462:0712/105712.057647:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/781934ea-4c24-48e8-9924-8ae210937d20
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[127495:127495:0712/105712.185785:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=127495
[127507:127507:0712/105712.186234:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=127507
[127462:127462:0712/105712.502738:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[127462:127493:0712/105712.503543:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/105712.503773:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/105712.503998:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/105712.504577:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/105712.504747:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/105712.507713:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x29c5e28b, 1
[1:1:0712/105712.508100:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x31f2dee3, 0
[1:1:0712/105712.508304:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3377ce56, 3
[1:1:0712/105712.508586:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x33557b11, 2
[1:1:0712/105712.508824:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe3ffffffdefffffff231 ffffff8bffffffe2ffffffc529 117b5533 56ffffffce7733 , 10104, 4
[1:1:0712/105712.510072:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[127462:127493:0712/105712.510316:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���1���){U3V�w3��K7
[127462:127493:0712/105712.510431:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���1���){U3V�w3���K7
[1:1:0712/105712.510588:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f93dec5e0a0, 3
[127462:127493:0712/105712.510759:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[127462:127493:0712/105712.510839:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 127515, 4, e3def231 8be2c529 117b5533 56ce7733 
[1:1:0712/105712.510850:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f93dede9080, 2
[1:1:0712/105712.511046:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f93c8aacd20, -2
[1:1:0712/105712.533273:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/105712.534156:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33557b11
[1:1:0712/105712.535128:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33557b11
[1:1:0712/105712.536776:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33557b11
[1:1:0712/105712.538283:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.538492:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.538678:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.538864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.539508:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33557b11
[1:1:0712/105712.539832:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f93e0a237ba
[1:1:0712/105712.539964:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f93e0a1adef, 7f93e0a2377a, 7f93e0a250cf
[1:1:0712/105712.545604:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33557b11
[1:1:0712/105712.545951:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33557b11
[1:1:0712/105712.546749:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33557b11
[1:1:0712/105712.549274:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.549546:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.549787:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.550015:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33557b11
[1:1:0712/105712.551571:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33557b11
[1:1:0712/105712.552023:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f93e0a237ba
[1:1:0712/105712.552192:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f93e0a1adef, 7f93e0a2377a, 7f93e0a250cf
[1:1:0712/105712.560288:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/105712.560829:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/105712.560980:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff129b6d38, 0x7fff129b6cb8)
[1:1:0712/105712.577051:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/105712.583652:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[127462:127462:0712/105713.147691:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[127462:127462:0712/105713.149079:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[127462:127474:0712/105713.169690:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[127462:127474:0712/105713.169815:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[127462:127462:0712/105713.169939:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[127462:127462:0712/105713.170035:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[127462:127462:0712/105713.170212:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,127515, 4
[1:7:0712/105713.172409:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105713.239270:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x301aa6f96220
[1:1:0712/105713.239428:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[127462:127487:0712/105713.245464:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/105713.602915:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[127462:127462:0712/105715.374409:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[127462:127462:0712/105715.374562:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/105715.378619:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105715.381983:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105716.366585:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105716.388551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/105716.388826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105716.404815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/105716.405065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105716.743581:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105716.743884:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105717.211882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105717.219968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/105717.220249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105717.247266:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105717.257108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/105717.257337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105717.268505:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[127462:127462:0712/105717.271022:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/105717.271878:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x301aa6f94e20
[1:1:0712/105717.272134:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[127462:127462:0712/105717.277523:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[127462:127462:0712/105717.312793:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[127462:127462:0712/105717.312997:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/105717.314623:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105718.031035:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f93ca6872e0 0x301aa70ce9e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105718.032404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/105718.032660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105718.034081:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[127462:127462:0712/105718.066639:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/105718.068353:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x301aa6f95820
[1:1:0712/105718.068608:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[127462:127462:0712/105718.073431:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/105718.077091:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/105718.077307:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[127462:127462:0712/105718.091067:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[127462:127462:0712/105718.103434:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[127462:127462:0712/105718.104676:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[127462:127474:0712/105718.111993:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[127462:127474:0712/105718.112077:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[127462:127462:0712/105718.112320:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[127462:127462:0712/105718.112412:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[127462:127462:0712/105718.112576:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,127515, 4
[1:7:0712/105718.119416:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105718.712498:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/105719.230364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f93ca6872e0 0x301aa723ea60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105719.231422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/105719.231711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105719.232487:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[127462:127462:0712/105719.277212:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[127462:127462:0712/105719.277285:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/105719.279817:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105719.659050:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[127462:127462:0712/105719.830622:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[127462:127493:0712/105719.831087:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/105719.831279:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/105719.831550:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/105719.831921:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/105719.832184:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/105719.835234:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b57d04b, 1
[1:1:0712/105719.835588:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3a534bfb, 0
[1:1:0712/105719.835743:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3c56f9a8, 3
[1:1:0712/105719.835889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x710d8e5, 2
[1:1:0712/105719.836162:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffb4b533a 4bffffffd0573b ffffffe5ffffffd81007 ffffffa8fffffff9563c , 10104, 5
[1:1:0712/105719.837395:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[127462:127493:0712/105719.837705:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�KS:K�W;����V<ݜK7
[127462:127493:0712/105719.837773:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �KS:K�W;����V<(ݜK7
[1:1:0712/105719.837697:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f93dec5e0a0, 3
[1:1:0712/105719.837946:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f93dede9080, 2
[127462:127493:0712/105719.838043:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 127558, 5, fb4b533a 4bd0573b e5d81007 a8f9563c 
[1:1:0712/105719.838135:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f93c8aacd20, -2
[1:1:0712/105719.848248:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/105719.848453:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 710d8e5
[1:1:0712/105719.848622:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 710d8e5
[1:1:0712/105719.848871:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 710d8e5
[1:1:0712/105719.849317:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.849421:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.849508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.849600:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.849828:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 710d8e5
[1:1:0712/105719.849953:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f93e0a237ba
[1:1:0712/105719.850051:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f93e0a1adef, 7f93e0a2377a, 7f93e0a250cf
[1:1:0712/105719.851419:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 710d8e5
[1:1:0712/105719.851576:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 710d8e5
[1:1:0712/105719.851830:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 710d8e5
[1:1:0712/105719.852552:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.852677:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.852780:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.852882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 710d8e5
[1:1:0712/105719.853325:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 710d8e5
[1:1:0712/105719.853484:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f93e0a237ba
[1:1:0712/105719.853559:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f93e0a1adef, 7f93e0a2377a, 7f93e0a250cf
[1:1:0712/105719.855641:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/105719.855984:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/105719.856105:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff129b6d38, 0x7fff129b6cb8)
[1:1:0712/105719.869058:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/105719.873567:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/105720.083708:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x301aa6f67220
[1:1:0712/105720.083984:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/105720.188925:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105720.189216:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105720.775081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105720.780084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d8e47c8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/105720.780407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105720.788414:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[127462:127462:0712/105720.951178:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[127462:127462:0712/105720.957990:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[127462:127462:0712/105720.996138:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.jiancai.com/
[127462:127462:0712/105720.996250:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.jiancai.com/, http://www.jiancai.com/, 1
[127462:127462:0712/105720.996434:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.jiancai.com/, HTTP/1.1 200 OK Server: openresty/1.13.6.2 Date: Fri, 12 Jul 2019 17:57:20 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: security_session_verify=1ab1164538737cf335d3dc948067cffb; expires=Tue, 16-Jul-19 01:57:20 GMT; path=/; HttpOnly Cache-Control: max-age=900 Expires: Fri, 12 Jul 2019 18:12:20 GMT Last-Modified: Fri, 12 Jul 2019 17:57:20 GMT Vary: Accept-Encoding, Bccept-Encoding X-AspNet-Version: 4.0.30319 Set-Cookie: ASP.NET_SessionId=zigivndp14httglcqokr4aco; path=/; HttpOnly X-Powered-By: ASP.NET Content-Encoding: gzip  ,127558, 5
[127462:127474:0712/105720.999161:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[127462:127474:0712/105720.999244:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/105721.000181:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105721.008876:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105721.011424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2d8e47b61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/105721.011669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105721.052307:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.jiancai.com/
[1:1:0712/105721.169515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[127462:127462:0712/105721.185020:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.jiancai.com/, http://www.jiancai.com/, 1
[127462:127462:0712/105721.185145:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.jiancai.com/, http://www.jiancai.com
[1:1:0712/105721.223859:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105721.235024:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105721.236805:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/105721.237032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d8e47c8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/105721.237305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105721.289428:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105721.334491:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105721.334759:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jiancai.com/"
[1:1:0712/105721.337822:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105721.338684:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/105721.338896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2d8e47c8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/105721.339175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105721.536513:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105721.714167:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105722.116207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f93c8ac7bd0 0x301aa70825d8 , "http://www.jiancai.com/"
[1:1:0712/105722.130613:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105722.147154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , /*!
 * jQuery JavaScript Library v1.9.1
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://siz
[1:1:0712/105722.147456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/105722.323944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f93c8ac7bd0 0x301aa70825d8 , "http://www.jiancai.com/"
[1:1:0712/105722.330882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f93c8ac7bd0 0x301aa70825d8 , "http://www.jiancai.com/"
[1:1:0712/105722.369996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7f93c8ac7bd0 0x301aa70825d8 , "http://www.jiancai.com/"
[1:1:0712/105722.596955:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105722.600382:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105722.600785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105722.601219:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105722.601586:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105723.667234:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.34472, 0, 0
[1:1:0712/105723.667504:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105723.766492:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105723.766741:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.jiancai.com/"
[1:1:0712/105723.767730:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 200 0x7f93c875f070 0x301aa77b1b60 , "http://www.jiancai.com/"
[1:1:0712/105723.768922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , 
        var m_TopAdHeight = 0;
        $(function() {
            IndexReady();
        });
       
[1:1:0712/105723.769138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105724.126825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jiancai.com/"
[1:1:0712/105724.145640:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.jiancai.com/"
[1:1:0712/105733.408055:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 448 0x7f93ca6872e0 0x301aa7962ee0 , "http://www.jiancai.com/"
[1:1:0712/105733.408959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , ___baidu_union_callback_("auto","7cb944dc9ea1a3fd5877f3bc2409932c",[])
[1:1:0712/105733.409167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105733.438535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 449 0x7f93ca6872e0 0x301aa6fc6ee0 , "http://www.jiancai.com/"
[1:1:0712/105733.447436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , (function(){var h={},mt={},c={id:"a050acafa89aa597e348d6efb3211ed2",dm:["jiancai.com"],js:"tongji.ba
[1:1:0712/105733.447677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105733.484926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28f48a8229c8, 0x301aa6de5148
[1:1:0712/105733.485205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jiancai.com/", 100
[1:1:0712/105733.485539:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 543
[1:1:0712/105733.485732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 543 0x7f93c875f070 0x301aa79b87e0 , 5:3_http://www.jiancai.com/, 1, -5:3_http://www.jiancai.com/, 449 0x7f93ca6872e0 0x301aa6fc6ee0 
[1:1:0712/105745.952965:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105745.953477:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[127462:127462:0712/105746.035534:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/105746.048042:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/105747.943301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/105747.943616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105748.758346:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 543, 7f93cb0a4881
[1:1:0712/105748.786984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08bb88d02860","ptid":"449 0x7f93ca6872e0 0x301aa6fc6ee0 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105748.787356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jiancai.com/","ptid":"449 0x7f93ca6872e0 0x301aa6fc6ee0 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105748.787822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jiancai.com/"
[1:1:0712/105748.788397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/105748.788640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105748.789436:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28f48a8229c8, 0x301aa6de5150
[1:1:0712/105748.789643:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jiancai.com/", 100
[1:1:0712/105748.790002:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 604
[1:1:0712/105748.790236:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f93c875f070 0x301aa7a38560 , 5:3_http://www.jiancai.com/, 1, -5:3_http://www.jiancai.com/, 543 0x7f93c875f070 0x301aa79b87e0 
[1:1:0712/105749.256403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , document.readyState
[1:1:0712/105749.256727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105750.139553:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 604, 7f93cb0a4881
[1:1:0712/105750.171062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08bb88d02860","ptid":"543 0x7f93c875f070 0x301aa79b87e0 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105750.171403:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jiancai.com/","ptid":"543 0x7f93c875f070 0x301aa79b87e0 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105750.171852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jiancai.com/"
[1:1:0712/105750.172481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/105750.172746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105750.173501:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28f48a8229c8, 0x301aa6de5150
[1:1:0712/105750.173700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jiancai.com/", 100
[1:1:0712/105750.174116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 641
[1:1:0712/105750.174395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f93c875f070 0x301aa83469e0 , 5:3_http://www.jiancai.com/, 1, -5:3_http://www.jiancai.com/, 604 0x7f93c875f070 0x301aa7a38560 
[1:1:0712/105750.661709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , document.readyState
[1:1:0712/105750.662059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105751.692697:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jiancai.com/"
[1:1:0712/105751.693392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/105751.693592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105751.701644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.jiancai.com/"
[1:1:0712/105751.704290:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jiancai.com/"
[127462:127462:0712/105751.714654:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/105751.717440:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x301aa6f66820
[1:1:0712/105751.717726:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[127462:127462:0712/105751.721745:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/105751.732649:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/105751.732872:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.jiancai.com
[1:1:0712/105751.735006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.jiancai.com/"
[1:1:0712/105751.738254:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.jiancai.com/"
[1:1:0712/105751.739599:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28f48a8229c8, 0x301aa6de52f0
[1:1:0712/105751.739771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jiancai.com/", 100
[1:1:0712/105751.740163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 737
[1:1:0712/105751.740362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7f93c875f070 0x301aa81eac60 , 5:3_http://www.jiancai.com/, 1, -5:3_http://www.jiancai.com/, 648 0x7f93c875f070 0x301aa761e060 
[127462:127462:0712/105751.745474:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.jiancai.com/
[127462:127462:0712/105751.871201:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[127462:127462:0712/105751.879661:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[127462:127474:0712/105751.914361:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[127462:127474:0712/105751.914461:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[127462:127462:0712/105751.914626:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pos.baidu.com/
[127462:127462:0712/105751.914716:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://pos.baidu.com/, https://pos.baidu.com/wh/o.htm?ltr=, 4
[127462:127462:0712/105751.914848:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://pos.baidu.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:57:51 GMT Last-Modified: Fri, 12 Jul 2019 03:18:19 GMT P3p: CP=" OTI DSP COR IVA OUR IND COM " Server: nginx Accept-Ranges: bytes Content-Length: 553 Content-Type: text/html Etag: "5d27fbfb-229"  ,127558, 5
[1:7:0712/105751.921414:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105753.106944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , , document.readyState
[1:1:0712/105753.107143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105753.756578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.jiancai.com/"
[1:1:0712/105753.757260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , elemData.handle, ( e ) {
				// Discard the second event of a jQuery.event.trigger() and
				// when an event is call
[1:1:0712/105753.757448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/105754.660976:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 737, 7f93cb0a4881
[1:1:0712/105754.679811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08bb88d02860","ptid":"648 0x7f93c875f070 0x301aa761e060 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105754.680178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jiancai.com/","ptid":"648 0x7f93c875f070 0x301aa761e060 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105754.680555:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jiancai.com/"
[1:1:0712/105754.681132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/105754.681394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0712/105754.682076:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28f48a8229c8, 0x301aa6de5150
[1:1:0712/105754.682276:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.jiancai.com/", 100
[1:1:0712/105754.682688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 841
[1:1:0712/105754.682934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f93c875f070 0x301aa81c1d60 , 5:3_http://www.jiancai.com/, 1, -5:3_http://www.jiancai.com/, 737 0x7f93c875f070 0x301aa81eac60 
[1:1:0712/105754.849028:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://pos.baidu.com/
[1:1:0712/105758.083405:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.jiancai.com/, 841, 7f93cb0a4881
[1:1:0712/105758.121532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"08bb88d02860","ptid":"737 0x7f93c875f070 0x301aa81eac60 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105758.121915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.jiancai.com/","ptid":"737 0x7f93c875f070 0x301aa81eac60 ","rf":"5:3_http://www.jiancai.com/"}
[1:1:0712/105758.122374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.jiancai.com/"
[1:1:0712/105758.122978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.jiancai.com/, 08bb88d02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/105758.123258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.jiancai.com/", "www.jiancai.com", 3, 1, , , 0
[1:1:0100/000000.123927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x28f48a8229c8, 0x301aa6de5150
