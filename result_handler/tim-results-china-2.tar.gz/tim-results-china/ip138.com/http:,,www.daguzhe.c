[0712/130939.189850:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/130939.190273:INFO:switcher_clone.cc(787)] backtrace rip is 7f26ff361891
[0712/130940.193146:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/130940.193513:INFO:switcher_clone.cc(787)] backtrace rip is 7f7b32bd7891
[1:1:0712/130940.205253:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/130940.205515:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/130940.211730:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[13077:13077:0712/130941.255877:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0e68dfa0-4bbb-4de4-9934-c95aa1511c1b
[13077:13077:0712/130941.675068:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[13077:13105:0712/130941.675759:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/130941.675952:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/130941.676188:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/130941.676891:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/130941.677038:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/130941.679938:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33e85a74, 1
[1:1:0712/130941.680312:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2cfaa757, 0
[1:1:0712/130941.680518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x826e90e, 3
[1:1:0712/130941.680727:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x207c6e61, 2
[1:1:0712/130941.680950:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 57ffffffa7fffffffa2c 745affffffe833 616e7c20 0effffffe92608 , 10104, 4
[1:1:0712/130941.681903:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[13077:13105:0712/130941.682264:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGW��,tZ�3an| �&u��
[1:1:0712/130941.682165:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7b30e120a0, 3
[13077:13105:0712/130941.682338:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is W��,tZ�3an| �&(+u��
[1:1:0712/130941.682399:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7b30f9d080, 2
[13077:13105:0712/130941.682607:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/130941.682559:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7b1ac60d20, -2
[13077:13105:0712/130941.682668:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13122, 4, 57a7fa2c 745ae833 616e7c20 0ee92608 
[1:1:0712/130941.698973:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/130941.700102:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 207c6e61
[1:1:0712/130941.701281:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 207c6e61
[1:1:0712/130941.702371:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 207c6e61
[1:1:0712/130941.702907:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.703018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.703114:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.703243:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.703478:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 207c6e61
[1:1:0712/130941.703629:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7b32bd77ba
[1:1:0712/130941.703711:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7b32bcedef, 7f7b32bd777a, 7f7b32bd90cf
[1:1:0712/130941.705219:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 207c6e61
[1:1:0712/130941.705404:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 207c6e61
[1:1:0712/130941.705678:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 207c6e61
[1:1:0712/130941.706397:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.706509:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.706615:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.706716:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 207c6e61
[1:1:0712/130941.707192:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 207c6e61
[1:1:0712/130941.707360:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7b32bd77ba
[1:1:0712/130941.707441:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7b32bcedef, 7f7b32bd777a, 7f7b32bd90cf
[1:1:0712/130941.709693:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/130941.709988:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/130941.710083:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff60288458, 0x7fff602883d8)
[1:1:0712/130941.724876:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[0712/130941.726033:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/130941.726358:INFO:switcher_clone.cc(787)] backtrace rip is 7faacedd7891
[1:1:0712/130941.730938:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[13108:13108:0712/130942.089166:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13108
[13148:13148:0712/130942.089669:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=13148
[13077:13077:0712/130942.174928:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13077:13077:0712/130942.176435:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13077:13088:0712/130942.199552:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[13077:13088:0712/130942.199692:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[13077:13077:0712/130942.199836:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[13077:13077:0712/130942.199935:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[13077:13077:0712/130942.200122:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,13122, 4
[1:7:0712/130942.205817:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[13077:13101:0712/130942.255000:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/130942.367220:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1dd624aa220
[1:1:0712/130942.367525:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/130942.659708:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/130944.343099:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130944.347361:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[13077:13077:0712/130944.581157:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[13077:13077:0712/130944.581316:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/130945.272913:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130945.539391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2dd0328c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/130945.539765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130945.570081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2dd0328c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/130945.570376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130945.632868:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130945.633135:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130946.135074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 352, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130946.143349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2dd0328c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/130946.143612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130946.193145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 353, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130946.203639:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2dd0328c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/130946.203945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130946.215343:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[13077:13077:0712/130946.217971:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/130946.218566:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1dd624a8e20
[1:1:0712/130946.218782:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[13077:13077:0712/130946.224988:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[13077:13077:0712/130946.253787:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[13077:13077:0712/130946.253966:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/130946.309314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130946.915753:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f7b1c83b2e0 0x1dd62657f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130946.917103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2dd0328c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/130946.917386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130946.918863:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[13077:13077:0712/130946.987696:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/130946.990261:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1dd624a9820
[1:1:0712/130946.990512:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[13077:13077:0712/130946.995914:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/130947.010225:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/130947.010378:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[13077:13077:0712/130947.011769:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[13077:13077:0712/130947.023250:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13077:13077:0712/130947.023609:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13077:13088:0712/130947.025272:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[13077:13077:0712/130947.025320:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[13077:13077:0712/130947.025357:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[13077:13088:0712/130947.025355:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[13077:13077:0712/130947.025415:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,13122, 4
[1:7:0712/130947.030754:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/130947.476228:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/130947.884739:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f7b1c83b2e0 0x1dd628510e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/130947.885876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2dd0328c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/130947.886118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/130947.886873:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[13077:13077:0712/130948.278532:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[13077:13077:0712/130948.278676:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/130948.325170:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/130948.613238:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130949.093509:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130949.093759:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[13077:13077:0712/130949.173845:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[13077:13105:0712/130949.174338:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/130949.174526:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/130949.174791:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/130949.175234:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/130949.175424:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/130949.178626:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26412499, 1
[1:1:0712/130949.179066:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x26e836fe, 0
[1:1:0712/130949.179269:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1a6a1128, 3
[1:1:0712/130949.179468:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x9f566c7, 2
[1:1:0712/130949.179674:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffe36ffffffe826 ffffff99244126 ffffffc766fffffff509 28116a1a , 10104, 5
[1:1:0712/130949.180688:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[13077:13105:0712/130949.180948:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�6�&�$A&�f�	(jY��
[13077:13105:0712/130949.181055:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �6�&�$A&�f�	(j(Y��
[13077:13105:0712/130949.181276:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 13173, 5, fe36e826 99244126 c766f509 28116a1a 
[1:1:0712/130949.181606:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7b30e120a0, 3
[1:1:0712/130949.181854:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7b30f9d080, 2
[1:1:0712/130949.182090:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7b1ac60d20, -2
[1:1:0712/130949.208197:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/130949.208634:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9f566c7
[1:1:0712/130949.209032:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9f566c7
[1:1:0712/130949.209802:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9f566c7
[1:1:0712/130949.211560:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.211813:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.212094:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.212330:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.213167:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9f566c7
[1:1:0712/130949.213528:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7b32bd77ba
[1:1:0712/130949.213696:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7b32bcedef, 7f7b32bd777a, 7f7b32bd90cf
[1:1:0712/130949.220771:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 9f566c7
[1:1:0712/130949.221245:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 9f566c7
[1:1:0712/130949.222166:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 9f566c7
[1:1:0712/130949.224708:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.224996:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.225238:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.225481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 9f566c7
[1:1:0712/130949.227048:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 9f566c7
[1:1:0712/130949.227503:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7b32bd77ba
[1:1:0712/130949.227668:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7b32bcedef, 7f7b32bd777a, 7f7b32bd90cf
[1:1:0712/130949.237391:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/130949.237875:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/130949.238090:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff60288458, 0x7fff602883d8)
[1:1:0712/130949.254358:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/130949.259546:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/130949.474307:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1dd6247b220
[1:1:0712/130949.474534:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/130949.568196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/130949.573069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2dd0329ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/130949.573392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/130949.578263:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[13077:13077:0712/130950.611008:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[13077:13077:0712/130950.615925:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[13077:13088:0712/130950.657072:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[13077:13088:0712/130950.657175:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[13077:13077:0712/130950.657737:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.daguzhe.com/
[13077:13077:0712/130950.657855:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.daguzhe.com/, http://www.daguzhe.com/, 1
[13077:13077:0712/130950.658019:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.daguzhe.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 20:09:50 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Server: nginx Set-Cookie: PHPSESSID=8dbjnalah0mn74e7ium5g6cv51; path=/; domain=.daguzhe.com Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Set-Cookie: Ym_r=deleted; expires=Thu, 01-Jan-1970 00:00:01 GMT; Max-Age=0; path=/; domain=.daguzhe.com; httponly Content-Encoding: gzip  ,13173, 5
[1:7:0712/130950.661065:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/130950.685371:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.daguzhe.com/
[1:1:0712/130950.837442:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[13077:13077:0712/130950.840274:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.daguzhe.com/, http://www.daguzhe.com/, 1
[13077:13077:0712/130950.840375:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.daguzhe.com/, http://www.daguzhe.com
[1:1:0712/130950.872102:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130950.907118:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/130950.926106:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130950.926321:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.daguzhe.com/"
[1:1:0712/130951.204349:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/130951.661362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f7b1a913070 0x1dd625990e0 , "http://www.daguzhe.com/"
[1:1:0712/130951.663410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , 
var uAgent = window.navigator.userAgent.toLowerCase();
var isMobile = /android|ip(ad|hone|od)|windo
[1:1:0712/130951.663592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/130951.670964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f7b1a913070 0x1dd625990e0 , "http://www.daguzhe.com/"
[1:1:0712/130951.678446:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130951.690390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f7b1a913070 0x1dd625990e0 , "http://www.daguzhe.com/"
[1:1:0712/130951.727669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 161 0x7f7b1a913070 0x1dd625990e0 , "http://www.daguzhe.com/"
[1:1:0712/130952.197603:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.530028, 5195, 0
[1:1:0712/130952.197841:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130952.602487:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130952.602648:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.daguzhe.com/"
[1:1:0712/130952.806906:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.204345, 1451, 1
[1:1:0712/130952.807192:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/130956.165264:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/130956.165532:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.daguzhe.com/"
[1:1:0712/130956.239900:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130956.330173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f7b1ac7bbd0 0x1dd625a84d8 , "http://www.daguzhe.com/"
[1:1:0712/130956.338196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0712/130956.338446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/130956.655071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f7b1ac7bbd0 0x1dd625a84d8 , "http://www.daguzhe.com/"
[1:1:0712/130956.680877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f7b1ac7bbd0 0x1dd625a84d8 , "http://www.daguzhe.com/"
[1:1:0712/130956.710472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 398 0x7f7b1ac7bbd0 0x1dd625a84d8 , "http://www.daguzhe.com/"
[1:1:0712/130956.729844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.daguzhe.com/"
[1:1:0712/130958.754700:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130958.759111:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130958.771437:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130958.784556:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/130958.791332:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131001.759462:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 431 0x7f7b1c83b2e0 0x1dd6259f960 , "http://www.daguzhe.com/"
[1:1:0712/131001.767958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , define("common/index",["./mod/getUserInfo","./mod/screenResponsive","./mod/loginbox","./mod/captcha"
[1:1:0712/131001.768195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131001.867006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131003.613110:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 432 0x7f7b1c83b2e0 0x1dd626f2460 , "http://www.daguzhe.com/"
[1:1:0712/131003.622301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (function(){var h={},mt={},c={id:"00d273bdc32b990f56a54644589471cc",dm:["daguzhe.com"],js:"tongji.ba
[1:1:0712/131003.622586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131003.645264:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251148
[1:1:0712/131003.645538:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131003.645918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 462
[1:1:0712/131003.646146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 462 0x7f7b1a913070 0x1dd6374cae0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 432 0x7f7b1c83b2e0 0x1dd626f2460 
[13077:13077:0712/131018.150103:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/131018.599604:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.daguzhe.com/"
[1:1:0712/131018.600364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , c, (a,d){var f,i,j;if(c&&(d||4===g.readyState))if(delete fc[h],c=void 0,g.onreadystatechange=n.noop,d)4
[1:1:0712/131018.600558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131018.601605:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.daguzhe.com/"
[1:1:0712/131018.604283:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.daguzhe.com/"
[1:1:0712/131018.604985:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b254f13aaa8
[1:1:0712/131018.695358:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.daguzhe.com/"
[1:1:0712/131018.696073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , c, (a,d){var f,i,j;if(c&&(d||4===g.readyState))if(delete fc[h],c=void 0,g.onreadystatechange=n.noop,d)4
[1:1:0712/131018.696261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131018.696686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.daguzhe.com/"
[1:1:0712/131018.699268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.daguzhe.com/"
[1:1:0712/131018.699900:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3b254f13aaa8
[1:1:0712/131018.773360:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131018.774157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , r.handle, (a){return"undefined"==typeof n||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,
[1:1:0712/131018.774301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131019.083287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/131019.083602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[3:3:0712/131019.210079:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/131019.702332:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 462, 7f7b1d258881
[1:1:0712/131019.726972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"432 0x7f7b1c83b2e0 0x1dd626f2460 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131019.727411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"432 0x7f7b1c83b2e0 0x1dd626f2460 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131019.727860:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131019.728463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131019.728686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131019.729467:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131019.729674:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131019.730056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 544
[1:1:0712/131019.730391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 544 0x7f7b1a913070 0x1dd62afd760 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 462 0x7f7b1a913070 0x1dd6374cae0 
[1:1:0712/131019.880440:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 508 0x7f7b1c83b2e0 0x1dd62318de0 , "http://www.daguzhe.com/"
[1:1:0712/131019.883663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/131019.883937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131019.934009:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd622511c8
[1:1:0712/131019.934287:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131019.934688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 548
[1:1:0712/131019.934921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 548 0x7f7b1a913070 0x1dd6374cd60 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 508 0x7f7b1c83b2e0 0x1dd62318de0 
[1:1:0712/131019.957534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd622511c8
[1:1:0712/131019.957815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131019.958271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 550
[1:1:0712/131019.958530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7f7b1a913070 0x1dd62e7dbe0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 508 0x7f7b1c83b2e0 0x1dd62318de0 
[1:1:0712/131019.977615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x166b0d6429c8, 0x1dd622511c8
[1:1:0712/131019.977891:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 3000
[1:1:0712/131019.978268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 552
[1:1:0712/131019.978515:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 552 0x7f7b1a913070 0x1dd62e7d3e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 508 0x7f7b1c83b2e0 0x1dd62318de0 
[1:1:0712/131020.012808:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7f7b1c83b2e0 0x1dd63749c60 , "http://www.daguzhe.com/"
[1:1:0712/131020.015630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , define("index/index",["./mod/lift","./mod/banner"],function(t,i,e){t("./mod/lift"),t("./mod/banner")
[1:1:0712/131020.015900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131020.036677:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131020.152036:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x166b0d6429c8, 0x1dd62251210
[1:1:0712/131020.152317:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 0
[1:1:0712/131020.152698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 556
[1:1:0712/131020.152929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 556 0x7f7b1a913070 0x1dd638f6ce0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 509 0x7f7b1c83b2e0 0x1dd63749c60 
[1:1:0712/131020.324450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 13
[1:1:0712/131020.324946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 557
[1:1:0712/131020.325187:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7f7b1a913070 0x1dd63978060 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 509 0x7f7b1c83b2e0 0x1dd63749c60 
[1:1:0712/131020.427014:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 5000
[1:1:0712/131020.427466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 558
[1:1:0712/131020.427768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7f7b1a913070 0x1dd63993860 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 509 0x7f7b1c83b2e0 0x1dd63749c60 
		remove user.10_15a86e86 -> 0
[1:1:0712/131020.619385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519 0x7f7b1c83b2e0 0x1dd629ad4e0 , "http://www.daguzhe.com/"
[1:1:0712/131020.620556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , geetest_1562962219697({"status": "success", "data": {"slide": "/static/js/slide.7.6.0.js", "maze": "
[1:1:0712/131020.620811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131020.633512:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131020.634103:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131020.638666:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131020.639865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x166b0d6429c8, 0x1dd62251210
[1:1:0712/131020.640082:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 0
[1:1:0712/131020.640455:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 567
[1:1:0712/131020.640718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 567 0x7f7b1a913070 0x1dd638f64e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 519 0x7f7b1c83b2e0 0x1dd629ad4e0 
[1:1:0712/131022.086008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131022.086426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.201854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131022.202768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/131022.203061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.211219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 544, 7f7b1d258881
[1:1:0712/131022.229864:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"462 0x7f7b1a913070 0x1dd6374cae0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.230330:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"462 0x7f7b1a913070 0x1dd6374cae0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.230847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131022.231566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131022.231872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.232858:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131022.233132:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131022.233636:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 619
[1:1:0712/131022.233912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f7b1a913070 0x1dd63a3f7e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 544 0x7f7b1a913070 0x1dd62afd760 
[1:1:0712/131022.400802:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 556, 7f7b1d258881
[1:1:0712/131022.422662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"509 0x7f7b1c83b2e0 0x1dd63749c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.423061:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"509 0x7f7b1c83b2e0 0x1dd63749c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.423496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131022.424079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){hb=void 0}
[1:1:0712/131022.424355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.426040:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 557, 7f7b1d2588db
[1:1:0712/131022.456388:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"509 0x7f7b1c83b2e0 0x1dd63749c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.456769:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"509 0x7f7b1c83b2e0 0x1dd63749c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.457227:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 629
[1:1:0712/131022.457497:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f7b1a913070 0x1dd63978f60 , 5:3_http://www.daguzhe.com/, 0, , 557 0x7f7b1a913070 0x1dd63978060 
[1:1:0712/131022.457864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131022.458424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , n.fx.tick, (){var a,b=n.timers,c=0;for(hb=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/131022.458661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.516686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f7b1c83b2e0 0x1dd6387ca60 , "http://www.daguzhe.com/"
[1:1:0712/131022.518555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/131022.518856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.536621:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd62251190
[1:1:0712/131022.536908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131022.537289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 631
[1:1:0712/131022.537550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f7b1a913070 0x1dd638f6ce0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 564 0x7f7b1c83b2e0 0x1dd6387ca60 
[1:1:0712/131022.580173:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd62251190
[1:1:0712/131022.580538:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131022.581058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 634
[1:1:0712/131022.581371:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f7b1a913070 0x1dd638855e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 564 0x7f7b1c83b2e0 0x1dd6387ca60 
[1:1:0712/131022.590084:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131022.671041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f7b1c83b2e0 0x1dd63885c60 , "http://www.daguzhe.com/"
[1:1:0712/131022.672246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/131022.672573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131022.705633:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd62251190
[1:1:0712/131022.705915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131022.706292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 638
[1:1:0712/131022.706535:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 638 0x7f7b1a913070 0x1dd62d56e60 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 565 0x7f7b1c83b2e0 0x1dd63885c60 
[1:1:0712/131022.712401:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131022.846718:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 567, 7f7b1d258881
[1:1:0712/131022.864251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"519 0x7f7b1c83b2e0 0x1dd629ad4e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.864601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"519 0x7f7b1c83b2e0 0x1dd629ad4e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131022.865053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131022.865663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , () {
                cb(false);
            }
[1:1:0712/131022.865838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131024.482413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131024.482601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131024.638808:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 619, 7f7b1d258881
[1:1:0712/131024.666565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"544 0x7f7b1a913070 0x1dd62afd760 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131024.666879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"544 0x7f7b1a913070 0x1dd62afd760 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131024.667296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131024.667879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131024.668063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131024.668892:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131024.669090:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131024.669494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 656
[1:1:0712/131024.669687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7f7b1a913070 0x1dd62b79260 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 619 0x7f7b1a913070 0x1dd63a3f7e0 
[1:1:0712/131024.820353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.daguzhe.com/"
[1:1:0712/131024.821025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , r.handle, (a){return"undefined"==typeof n||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,
[1:1:0712/131024.821227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131025.253703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 552, 7f7b1d258881
[1:1:0712/131025.282302:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"508 0x7f7b1c83b2e0 0x1dd62318de0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131025.282656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"508 0x7f7b1c83b2e0 0x1dd62318de0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131025.283018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131025.283551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/131025.283736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131025.290662:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131025.290845:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131025.291177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 683
[1:1:0712/131025.291395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7f7b1a913070 0x1dd63afc560 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 552 0x7f7b1a913070 0x1dd62e7d3e0 
[1:1:0712/131025.367238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131025.367508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131025.430327:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 656, 7f7b1d258881
[1:1:0712/131025.459369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"619 0x7f7b1a913070 0x1dd63a3f7e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131025.459703:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"619 0x7f7b1a913070 0x1dd63a3f7e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131025.460055:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131025.460606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131025.460797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131025.461447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131025.461612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131025.461931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 691
[1:1:0712/131025.462119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f7b1a913070 0x1dd62f482e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 656 0x7f7b1a913070 0x1dd62b79260 
[1:1:0712/131025.869434:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 673 0x7f7b1c83b2e0 0x1dd63bc34e0 , "http://www.daguzhe.com/"
[1:1:0712/131025.871097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0712/131025.871290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131025.885484:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131025.923854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 674 0x7f7b1c83b2e0 0x1dd629c2860 , "http://www.daguzhe.com/"
[1:1:0712/131025.924807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0712/131025.925002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131025.944675:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131026.023162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 677 0x7f7b1c83b2e0 0x1dd61fcbb60 , "http://www.daguzhe.com/"
[1:1:0712/131026.033597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0712/131026.033869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
		remove user.11_c347d5bd -> 0
		remove user.12_f197d03 -> 0
[1:1:0712/131026.774785:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd62251190
[1:1:0712/131026.775049:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131026.775401:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 703
[1:1:0712/131026.775600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f7b1a913070 0x1dd644f6560 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 677 0x7f7b1c83b2e0 0x1dd61fcbb60 
[1:1:0712/131026.849202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x166b0d6429c8, 0x1dd62251190
[1:1:0712/131026.849440:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 0
[1:1:0712/131026.849747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 706
[1:1:0712/131026.849948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7f7b1a913070 0x1dd643a9c60 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 677 0x7f7b1c83b2e0 0x1dd61fcbb60 
[1:1:0712/131026.850404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x166b0d6429c8, 0x1dd62251190
[1:1:0712/131026.850564:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 15000
[1:1:0712/131026.850851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 707
[1:1:0712/131026.851055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f7b1a913070 0x1dd643a9160 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 677 0x7f7b1c83b2e0 0x1dd61fcbb60 
[1:1:0712/131026.870523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131027.147665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131027.147873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.159374:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 558, 7f7b1d2588db
[1:1:0712/131027.173756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"509 0x7f7b1c83b2e0 0x1dd63749c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.174161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"509 0x7f7b1c83b2e0 0x1dd63749c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.174672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 728
[1:1:0712/131027.174915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f7b1a913070 0x1dd63ddf560 , 5:3_http://www.daguzhe.com/, 0, , 558 0x7f7b1a913070 0x1dd63993860 
[1:1:0712/131027.175296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131027.175903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){t.next()}
[1:1:0712/131027.176165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.203382:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131027.203565:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 0
[1:1:0712/131027.203755:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 729
[1:1:0712/131027.203869:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f7b1a913070 0x1dd6278f4e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 558 0x7f7b1a913070 0x1dd63993860 
[1:1:0712/131027.217142:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 691, 7f7b1d258881
[1:1:0712/131027.227622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"656 0x7f7b1a913070 0x1dd62b79260 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.227833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"656 0x7f7b1a913070 0x1dd62b79260 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.228228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131027.228544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131027.228657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.229055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131027.229167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131027.229384:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 732
[1:1:0712/131027.229501:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f7b1a913070 0x1dd640887e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 691 0x7f7b1a913070 0x1dd62f482e0 
[1:1:0712/131027.257481:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 696 0x7f7b1c83b2e0 0x1dd642e1ee0 , "http://www.daguzhe.com/"
[1:1:0712/131027.258035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("trans/logger",function(e,t){var n=e("base/tangram").T,r=e("component
[1:1:0712/131027.258181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.307053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 1000
[1:1:0712/131027.307665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 733
[1:1:0712/131027.308053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f7b1a913070 0x1dd63ddf8e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 696 0x7f7b1c83b2e0 0x1dd642e1ee0 
[1:1:0712/131027.333590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131027.543483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 706, 7f7b1d258881
[1:1:0712/131027.555653:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"677 0x7f7b1c83b2e0 0x1dd61fcbb60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.555865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"677 0x7f7b1c83b2e0 0x1dd61fcbb60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.556076:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131027.556610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){l(e,t)}
[1:1:0712/131027.556806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.559991:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131027.560271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 1
[1:1:0712/131027.560678:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 748
[1:1:0712/131027.560915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 748 0x7f7b1a913070 0x1dd644f6060 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 706 0x7f7b1a913070 0x1dd643a9c60 
[1:1:0712/131027.753313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 723 0x7f7b1c83b2e0 0x1dd645a6d60 , "http://www.daguzhe.com/"
[1:1:0712/131027.754054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0712/131027.754223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.777022:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131027.906889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131027.907075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131027.919015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 729, 7f7b1d258881
[1:1:0712/131027.929428:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"558 0x7f7b1a913070 0x1dd63993860 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.929623:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"558 0x7f7b1a913070 0x1dd63993860 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131027.929815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131027.930123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){hb=void 0}
[1:1:0712/131027.930228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.005478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 732, 7f7b1d258881
[1:1:0712/131028.017401:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"691 0x7f7b1a913070 0x1dd62f482e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.017617:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"691 0x7f7b1a913070 0x1dd62f482e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.017830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131028.018139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131028.018264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.018593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131028.018699:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131028.018874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 763
[1:1:0712/131028.018991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 763 0x7f7b1a913070 0x1dd642c7de0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 732 0x7f7b1a913070 0x1dd640887e0 
[1:1:0712/131028.346478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 748, 7f7b1d258881
[1:1:0712/131028.377723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"706 0x7f7b1a913070 0x1dd643a9c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.377952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"706 0x7f7b1a913070 0x1dd643a9c60 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.378245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131028.378734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){n?t&&t():l(e,t)}
[1:1:0712/131028.378963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.467580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131028.467891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.616530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.daguzhe.com/"
[1:1:0712/131028.617423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/131028.617683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.684452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.daguzhe.com/"
[1:1:0712/131028.685327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , t.onload.t.onerror.t.onabort, (){t.onload=t.onerror=t.onabort=null,window[n]=null,t=null}
[1:1:0712/131028.685566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.687530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 763, 7f7b1d258881
[1:1:0712/131028.720164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"732 0x7f7b1a913070 0x1dd640887e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.720532:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"732 0x7f7b1a913070 0x1dd640887e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.720906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131028.721447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131028.721637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131028.722258:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131028.722415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131028.722751:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 789
[1:1:0712/131028.722952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f7b1a913070 0x1dd62d553e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 763 0x7f7b1a913070 0x1dd642c7de0 
[1:1:0712/131028.847013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 733, 7f7b1d2588db
[1:1:0712/131028.884100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"696 0x7f7b1c83b2e0 0x1dd642e1ee0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.884474:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"696 0x7f7b1c83b2e0 0x1dd642e1ee0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131028.885027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 795
[1:1:0712/131028.885281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7f7b1a913070 0x1dd645a6be0 , 5:3_http://www.daguzhe.com/, 0, , 733 0x7f7b1a913070 0x1dd63ddf8e0 
[1:1:0712/131028.885669:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131028.886298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){document.hasFocus()&&s++}
[1:1:0712/131028.886561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131029.076950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 784 0x7f7b1c83b2e0 0x1dd644f6460 , "http://www.daguzhe.com/"
[1:1:0712/131029.083112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , $_At.$_B_=function(){var $_DDDFt=2;for(;$_DDDFt!==1;){switch($_DDDFt){case 2:return{$_DDDGD:function
[1:1:0712/131029.083313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131030.057701:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131030.057992:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131030.058971:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:20:0712/131030.064869:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[13077:13077:0712/131030.107435:INFO:CONSOLE(1)] "The deviceorientation event is deprecated on insecure origins, and support will be removed in the future. You should consider switching your application to a secure origin, such as HTTPS. See https://goo.gl/rStTGz for more details.", source: http://static.geetest.com/static/js/fullpage.8.7.9.js (1)
[1:1:0712/131030.147376:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131030.148410:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x166b0d6429c8, 0x1dd62251210
[1:1:0712/131030.148664:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 0
[1:1:0712/131030.149170:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 809
[1:1:0712/131030.149468:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f7b1a913070 0x1dd6432cee0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 784 0x7f7b1c83b2e0 0x1dd644f6460 
[1:1:0712/131030.334022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , document.readyState
[1:1:0712/131030.334361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131030.498340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 789, 7f7b1d258881
[1:1:0712/131030.511418:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"763 0x7f7b1a913070 0x1dd642c7de0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131030.511814:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"763 0x7f7b1a913070 0x1dd642c7de0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131030.512306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131030.512917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/131030.513313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131030.514348:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd62251150
[1:1:0712/131030.514861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131030.515219:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 830
[1:1:0712/131030.515464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7f7b1a913070 0x1dd6374a560 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 789 0x7f7b1a913070 0x1dd62d553e0 
[1:1:0712/131030.791822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (e){var $_CAIBf=$_At.$_Dj,$_CAIAF=['$_CAIEl'].concat($_CAIBf),$_CAICi=$_CAIAF[1];$_CAIAF.shift();var
[1:1:0712/131030.792166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131030.938740:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131030.939520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , a, (){if(!a.U){a.U=t;for(var d=0,b=g.length;d<b;d++)g[d]()}}
[1:1:0712/131030.939805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131030.940702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.daguzhe.com/"
[1:1:0712/131031.023739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://www.daguzhe.com/"
[1:1:0712/131031.025643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x166b0d6429c8, 0x1dd622512f0
[1:1:0712/131031.025888:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.daguzhe.com/", 100
[1:1:0712/131031.026294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 848
[1:1:0712/131031.026586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 848 0x7f7b1a913070 0x1dd6406e8e0 , 5:3_http://www.daguzhe.com/, 1, -5:3_http://www.daguzhe.com/, 810 0x7f7b1a913070 0x1dd642e1e60 
[1:1:0712/131031.055294:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 795, 7f7b1d2588db
[1:1:0712/131031.071054:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"733 0x7f7b1a913070 0x1dd63ddf8e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131031.071379:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"733 0x7f7b1a913070 0x1dd63ddf8e0 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131031.071962:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.daguzhe.com/, 850
[1:1:0712/131031.072209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f7b1a913070 0x1dd62d561e0 , 5:3_http://www.daguzhe.com/, 0, , 795 0x7f7b1a913070 0x1dd645a6be0 
[1:1:0712/131031.072530:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131031.073109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , (){document.hasFocus()&&s++}
[1:1:0712/131031.073329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:1:0712/131031.099664:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.daguzhe.com/, 809, 7f7b1d258881
[1:1:0712/131031.128245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0295e5902860","ptid":"784 0x7f7b1c83b2e0 0x1dd644f6460 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131031.128658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.daguzhe.com/","ptid":"784 0x7f7b1c83b2e0 0x1dd644f6460 ","rf":"5:3_http://www.daguzhe.com/"}
[1:1:0712/131031.129148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.daguzhe.com/"
[1:1:0712/131031.129729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.daguzhe.com/, 0295e5902860, , , () {
                cb(false);
            }
[1:1:0712/131031.129950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.daguzhe.com/", "www.daguzhe.com", 3, 1, , , 0
[1:22:0712/131032.298494:WARNING:paced_sender.cc(261)] Elapsed time (2195 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131032.800160:WARNING:paced_sender.cc(261)] Elapsed time (2696 ms) longer than expected, limiting to 2000 ms
		remove user.13_4524a178 -> 0
		remove user.14_eb14fb6f -> 0
		remove user.15_35850b5d -> 0
		remove user.16_b66a2758 -> 0
		remove user.17_e1510e51 -> 0
[1:22:0712/131033.303337:WARNING:paced_sender.cc(261)] Elapsed time (3200 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131033.805519:WARNING:paced_sender.cc(261)] Elapsed time (3702 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131034.307696:WARNING:paced_sender.cc(261)] Elapsed time (4204 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131034.809879:WARNING:paced_sender.cc(261)] Elapsed time (4706 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131035.312105:WARNING:paced_sender.cc(261)] Elapsed time (5208 ms) longer than expected, limiting to 2000 ms
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:22:0712/131035.814244:WARNING:paced_sender.cc(261)] Elapsed time (5711 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131036.317432:WARNING:paced_sender.cc(261)] Elapsed time (6214 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131036.819620:WARNING:paced_sender.cc(261)] Elapsed time (6716 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131037.321827:WARNING:paced_sender.cc(261)] Elapsed time (7218 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131037.820977:WARNING:paced_sender.cc(261)] Elapsed time (7717 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131038.323165:WARNING:paced_sender.cc(261)] Elapsed time (8219 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131038.825362:WARNING:paced_sender.cc(261)] Elapsed time (8722 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131039.327574:WARNING:paced_sender.cc(261)] Elapsed time (9224 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131039.829708:WARNING:paced_sender.cc(261)] Elapsed time (9726 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131040.331898:WARNING:paced_sender.cc(261)] Elapsed time (10228 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131040.834077:WARNING:paced_sender.cc(261)] Elapsed time (10730 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131041.336246:WARNING:paced_sender.cc(261)] Elapsed time (11233 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131041.836445:WARNING:paced_sender.cc(261)] Elapsed time (11733 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131042.338626:WARNING:paced_sender.cc(261)] Elapsed time (12235 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131042.840823:WARNING:paced_sender.cc(261)] Elapsed time (12737 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131043.342988:WARNING:paced_sender.cc(261)] Elapsed time (13239 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131043.845160:WARNING:paced_sender.cc(261)] Elapsed time (13741 ms) longer than expected, limiting to 2000 ms
[13077:13077:0712/131044.320755:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:22:0712/131044.346376:WARNING:paced_sender.cc(261)] Elapsed time (14243 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131044.848580:WARNING:paced_sender.cc(261)] Elapsed time (14745 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131045.349781:WARNING:paced_sender.cc(261)] Elapsed time (15246 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131045.850938:WARNING:paced_sender.cc(261)] Elapsed time (15747 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131046.351129:WARNING:paced_sender.cc(261)] Elapsed time (16247 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131046.853251:WARNING:paced_sender.cc(261)] Elapsed time (16750 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131047.356528:WARNING:paced_sender.cc(261)] Elapsed time (17253 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131047.857688:WARNING:paced_sender.cc(261)] Elapsed time (17754 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131048.358828:WARNING:paced_sender.cc(261)] Elapsed time (18255 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131048.860071:WARNING:paced_sender.cc(261)] Elapsed time (18756 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131049.362243:WARNING:paced_sender.cc(261)] Elapsed time (19259 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131049.864341:WARNING:paced_sender.cc(261)] Elapsed time (19761 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131050.365555:WARNING:paced_sender.cc(261)] Elapsed time (20262 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131050.866741:WARNING:paced_sender.cc(261)] Elapsed time (20763 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131051.367947:WARNING:paced_sender.cc(261)] Elapsed time (21264 ms) longer than expected, limiting to 2000 ms
[1:1:0712/131051.667571:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131051.668143:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131051.668577:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/131051.669064:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:22:0712/131051.870071:WARNING:paced_sender.cc(261)] Elapsed time (21766 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131052.370263:WARNING:paced_sender.cc(261)] Elapsed time (22267 ms) longer than expected, limiting to 2000 ms
[1:22:0712/131052.873508:WARNING:paced_sender.cc(261)] Elapsed time (22770 ms) longer than expected, limiting to 2000 ms
