[0712/082341.147872:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/082341.148284:INFO:switcher_clone.cc(787)] backtrace rip is 7fa235154891
[0712/082342.251982:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/082342.252343:INFO:switcher_clone.cc(787)] backtrace rip is 7f9e19cf6891
[1:1:0712/082342.264718:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/082342.264970:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/082342.272716:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[107882:107882:0712/082343.662951:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/cb2fc619-4163-4cbc-bf9f-8914e42b2149
[0712/082343.878621:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/082343.879077:INFO:switcher_clone.cc(787)] backtrace rip is 7f44ea9ab891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[107912:107912:0712/082344.112534:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=107912
[107925:107925:0712/082344.112975:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=107925
[107882:107882:0712/082344.268331:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[107882:107910:0712/082344.269167:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/082344.269433:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/082344.269691:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/082344.270449:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/082344.270624:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/082344.273984:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x111345c0, 1
[1:1:0712/082344.274387:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x276655da, 0
[1:1:0712/082344.274691:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xacbac42, 3
[1:1:0712/082344.275010:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3d207ee8, 2
[1:1:0712/082344.275287:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffda556627 ffffffc0451311 ffffffe87e203d 42ffffffacffffffcb0a , 10104, 4
[1:1:0712/082344.276351:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[107882:107910:0712/082344.276627:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Uf'�E�~ =B��
p	'
[107882:107910:0712/082344.276704:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Uf'�E�~ =B��
({p	'
[1:1:0712/082344.276621:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e17f310a0, 3
[107882:107910:0712/082344.277003:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/082344.276808:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e180bc080, 2
[107882:107910:0712/082344.277077:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 107933, 4, da556627 c0451311 e87e203d 42accb0a 
[1:1:0712/082344.277136:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e01d7fd20, -2
[1:1:0712/082344.299705:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/082344.300461:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d207ee8
[1:1:0712/082344.301221:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d207ee8
[1:1:0712/082344.302295:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d207ee8
[1:1:0712/082344.302836:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.302972:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.303072:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.303181:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.303398:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d207ee8
[1:1:0712/082344.303545:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e19cf67ba
[1:1:0712/082344.303626:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e19ceddef, 7f9e19cf677a, 7f9e19cf80cf
[1:1:0712/082344.305248:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d207ee8
[1:1:0712/082344.305412:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d207ee8
[1:1:0712/082344.305671:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d207ee8
[1:1:0712/082344.306378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.306489:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.306581:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.306672:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d207ee8
[1:1:0712/082344.307126:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d207ee8
[1:1:0712/082344.307282:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e19cf67ba
[1:1:0712/082344.307352:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e19ceddef, 7f9e19cf677a, 7f9e19cf80cf
[1:1:0712/082344.309544:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/082344.309818:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/082344.309928:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc12dc1018, 0x7ffc12dc0f98)
[1:1:0712/082344.325812:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/082344.331727:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[107882:107882:0712/082344.894031:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107882:107882:0712/082344.894799:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107882:107892:0712/082344.904303:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[107882:107892:0712/082344.904426:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[107882:107882:0712/082344.904604:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[107882:107882:0712/082344.904697:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[107882:107882:0712/082344.904871:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,107933, 4
[1:7:0712/082344.913765:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[107882:107904:0712/082344.985078:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/082345.062979:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3f1e53ce8220
[1:1:0712/082345.063475:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/082345.522138:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[107882:107882:0712/082347.442652:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[107882:107882:0712/082347.442800:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/082347.465769:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082347.469868:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/082348.490745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/082348.491085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082348.506559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/082348.506744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082348.520339:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082348.811592:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082348.811839:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082349.193941:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082349.211517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/082349.211832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082349.239851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082349.251033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/082349.251360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082349.263139:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/082349.266693:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f1e53ce6e20
[1:1:0712/082349.266898:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[107882:107882:0712/082349.268147:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[107882:107882:0712/082349.280215:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[107882:107882:0712/082349.310325:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[107882:107882:0712/082349.310495:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/082349.352345:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082350.179459:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f9e0395a2e0 0x3f1e53f67b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082350.181820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/082350.182039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082350.183548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[107882:107882:0712/082350.252777:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/082350.254217:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3f1e53ce7820
[1:1:0712/082350.254460:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/082350.263668:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/082350.263845:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[107882:107882:0712/082350.266132:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[107882:107882:0712/082350.277922:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[107882:107882:0712/082350.289156:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107882:107882:0712/082350.290803:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107882:107892:0712/082350.292909:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[107882:107882:0712/082350.292960:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[107882:107882:0712/082350.293001:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[107882:107892:0712/082350.293000:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[107882:107882:0712/082350.293070:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,107933, 4
[1:7:0712/082350.294411:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082350.860026:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/082351.401691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f9e0395a2e0 0x3f1e5405f1e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082351.402741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/082351.402979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082351.403790:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[107882:107882:0712/082351.516051:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[107882:107882:0712/082351.516212:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/082351.540470:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[107882:107882:0712/082351.612176:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[107882:107910:0712/082351.612668:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/082351.612920:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/082351.613210:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/082351.613700:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/082351.613917:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/082351.617236:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xf162e70, 1
[1:1:0712/082351.617594:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x29bd2757, 0
[1:1:0712/082351.617749:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x255388b9, 3
[1:1:0712/082351.617918:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1521d23d, 2
[1:1:0712/082351.618057:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5727ffffffbd29 702e160f 3dffffffd22115 ffffffb9ffffff885325 , 10104, 5
[1:1:0712/082351.619122:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[107882:107910:0712/082351.619442:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGW'�)p.=�!��S%~	'
[107882:107910:0712/082351.619509:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is W'�)p.=�!��S%�m~	'
[1:1:0712/082351.619703:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e17f310a0, 3
[107882:107910:0712/082351.619873:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 107977, 5, 5727bd29 702e160f 3dd22115 b9885325 
[1:1:0712/082351.619954:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e180bc080, 2
[1:1:0712/082351.620117:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9e01d7fd20, -2
[1:1:0712/082351.635713:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/082351.636182:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1521d23d
[1:1:0712/082351.636525:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1521d23d
[1:1:0712/082351.637138:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1521d23d
[1:1:0712/082351.638683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.638945:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.639170:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.639387:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.640233:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1521d23d
[1:1:0712/082351.640602:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e19cf67ba
[1:1:0712/082351.640764:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e19ceddef, 7f9e19cf677a, 7f9e19cf80cf
[1:1:0712/082351.647762:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1521d23d
[1:1:0712/082351.648251:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1521d23d
[1:1:0712/082351.649207:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1521d23d
[1:1:0712/082351.651774:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.652081:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.652335:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.652585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1521d23d
[1:1:0712/082351.654162:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1521d23d
[1:1:0712/082351.654631:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f9e19cf67ba
[1:1:0712/082351.654828:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9e19ceddef, 7f9e19cf677a, 7f9e19cf80cf
[1:1:0712/082351.664145:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/082351.664793:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/082351.665016:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc12dc1018, 0x7ffc12dc0f98)
[1:1:0712/082351.681361:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/082351.685569:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/082351.927781:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082351.935494:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3f1e53cab220
[1:1:0712/082351.935831:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/082352.756188:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082352.756505:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082353.078021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082353.082732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/082353.083137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082353.091058:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082353.165251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082353.166041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0ccb34b61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/082353.166281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082353.283851:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082353.285547:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/082353.285790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/082353.286063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082353.428803:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082353.429913:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/082353.430166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/082353.430453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082353.926053:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/082354.283080:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/082354.386157:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/082354.446061:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/082354.543780:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/082354.609765:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/082354.689529:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/082354.750745:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/082354.854520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082354.855770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082354.856092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.048690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.049641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082355.049908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.103252:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.104137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082355.104347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.198541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.199652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082355.199989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.350592:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.351547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082355.351839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.560463:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.561404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082355.561646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.649304:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.650228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082355.650481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.715242:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.715758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082355.715976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.795682:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.796685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082355.796950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.853770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.854569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082355.854719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.901100:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.901585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082355.901725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082355.926722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082355.927248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082355.927392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082356.012971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082356.013876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082356.014135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082356.116614:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082356.117131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082356.117275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082356.171421:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082356.171910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/082356.172097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082356.236038:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082356.236943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0ccb34c8e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/082356.237247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[107882:107882:0712/082356.546458:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('https://gaokao.eol.cn') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[107882:107882:0712/082357.199695:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107882:107882:0712/082357.206226:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107882:107892:0712/082357.232011:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[107882:107892:0712/082357.232113:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[107882:107882:0712/082357.232679:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://gaokao.eol.cn/
[107882:107882:0712/082357.232783:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://gaokao.eol.cn/, https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml, 1
[107882:107882:0712/082357.232955:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://gaokao.eol.cn/, HTTP/1.1 200 OK Content-Type: text/html Connection: keep-alive X-Cache: MISS from cache-34-239 Vary: Accept-Encoding Powered-By-ChinaCache: MISS from CHN-LN-u-3OU CACHE: TCP_REFRESH_MISS Content-Length: 14531 Date: Fri, 12 Jul 2019 15:23:57 GMT Content-Encoding: gzip Server: nginx Powered-By-ChinaCache: MISS from GWB-FS-2-3WZ CC_CACHE: TCP_REFRESH_MISS Accept-Ranges: bytes  ,107977, 5
[1:7:0712/082357.237336:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082357.278556:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://gaokao.eol.cn/
[107882:107882:0712/082357.457175:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://gaokao.eol.cn/, https://gaokao.eol.cn/, 1
[107882:107882:0712/082357.457310:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://gaokao.eol.cn/, https://gaokao.eol.cn
[1:1:0712/082357.474581:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/082357.596039:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082357.709866:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082357.710202:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082357.973906:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082358.176409:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7f9e180bc080 0x3f1e53e77560 1 0 0x3f1e53e77578 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082358.178653:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082358.189198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0712/082358.189493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
		remove user.f_89b92d49 -> 0
[1:1:0712/082358.438456:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 170 0x7f9e180bc080 0x3f1e53e77560 1 0 0x3f1e53e77578 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082358.569218:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.137919, 394, 1
[1:1:0712/082358.569463:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082358.953578:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082358.953887:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082358.955061:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 207 0x7f9e01a32070 0x3f1e53fdfde0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082358.957798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , 
  $(function() {
      $('.gaunzhu').click(function(event) {
          event.stopPropagation();

  
[1:1:0712/082358.958037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082359.002612:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0485032, 158, 1
[1:1:0712/082359.002872:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082400.091651:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082400.091877:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082400.092788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f9e01a32070 0x3f1e540d95e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082400.093810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , 
                    var _PAGE_COUNT = "6";
                    var _PAGE_INDEX = "0";
             
[1:1:0712/082400.094059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082400.100062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 269 0x7f9e01a32070 0x3f1e540d95e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082400.130472:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0384421, 124, 1
[1:1:0712/082400.130776:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082401.079402:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082401.079589:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082401.080050:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7f9e01a32070 0x3f1e53de8460 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082401.080720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , 
        var pkBaseURL = (("https:" == document.location.protocol) ? "https://stat.eol.cn/" : "//sta
[1:1:0712/082401.080852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082401.193533:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346, "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082401.194624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , function setCookies(a,b,c){var d=new Date;d.setDate(d.getDate()+c),document.cookie=a+"="+escape(b)+(
[1:1:0712/082401.194804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082401.228052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346, "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082401.261765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 346, "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082402.406414:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082402.406891:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082402.407256:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082402.407650:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082402.407957:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082402.608159:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 376, "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082402.609606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/082402.609754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082402.635112:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 376, "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082403.263827:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082403.267543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/082403.267737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082404.947319:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 400 0x7f9e180bc080 0x3f1e540ab9c0 1 0 0x3f1e540ab9d8 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082404.958460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , !function(t){var e={};function r(n){if(e[n])return e[n].exports;var i=e[n]={i:n,l:!1,exports:{}};ret
[1:1:0712/082404.958747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082405.354616:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082405.356321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , r, (r){r.source===t&&"string"==typeof r.data&&0===r.data.indexOf(e)&&l(+r.data.slice(e.length))}
[1:1:0712/082405.356566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082405.530755:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082405.778514:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082405.778803:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082405.779830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 432 0x7f9e01a32070 0x3f1e53fb4960 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082405.780907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , ParadigmSDKv3.init("47ff618e783f4924b9dd2c04f85716f3");ParadigmSDKv3.trackDetailPageShow(496);
[1:1:0712/082405.781139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[107882:107882:0712/082418.965201:INFO:CONSOLE(445)] "Mixed Content: The page at 'https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml' was loaded over HTTPS, but requested an insecure image 'http://img.eol.cn/e_images/gk/2019/zytb285.jpg'. This content should also be served over HTTPS.", source: https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml (445)
[107882:107882:0712/082419.037512:INFO:CONSOLE(565)] "Mixed Content: The page at 'https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml' was loaded over HTTPS, but requested an insecure image 'http://img.eol.cn/e_images/gk/2019/gzbg160.jpg'. This content should also be served over HTTPS.", source: https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml (565)
[107882:107882:0712/082419.062702:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=4696180&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s6.cnzz.com/stat.php?id=4696180&web_id=4696180 (17)
[107882:107882:0712/082419.064137:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=4696180&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s6.cnzz.com/stat.php?id=4696180&web_id=4696180 (17)
[107882:107882:0712/082419.067697:INFO:CONSOLE(587)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://nbrecsys.4paradigm.com/sdk/js/ParadigmSDK_v3.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml (587)
[107882:107882:0712/082419.068589:INFO:CONSOLE(587)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://nbrecsys.4paradigm.com/sdk/js/ParadigmSDK_v3.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml (587)
[107882:107882:0712/082419.085116:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/082419.094972:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/082419.164547:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6541c29c8, 0x3f1e53b34198
[1:1:0712/082419.165506:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 0
[1:1:0712/082419.166139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gaokao.eol.cn/, 465
[1:1:0712/082419.166438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 465 0x7f9e01a32070 0x3f1e53a1f760 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 432 0x7f9e01a32070 0x3f1e53fb4960 
[1:1:0712/082419.191283:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.4123, 0, 0
[1:1:0712/082419.191576:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082419.494421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/082419.494760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082420.072468:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082420.072765:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082420.076686:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[107882:107882:0712/082420.079170:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/082420.081415:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3f1e53caa820
[1:1:0712/082420.081740:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[107882:107882:0712/082420.087594:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/082420.101827:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/082420.102111:INFO:render_frame_impl.cc(7019)] 	 [url] = https://gaokao.eol.cn
[1:1:0712/082420.107297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f9e01a32070 0x3f1e54397e60 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[107882:107882:0712/082420.107768:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://gaokao.eol.cn/
[1:1:0712/082420.107976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , 
      var mpc = window.navigator.userAgent;
      if(!/Mobile|iP(hone|ad)|Android|BlackBerry|IEMobi
[1:1:0712/082420.108210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082420.118314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f9e01a32070 0x3f1e54397e60 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[107882:107882:0712/082420.124855:INFO:CONSOLE(636)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://nbrecsys.4paradigm.com/sdk/js/ParadigmSDK_v3.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml (636)
[107882:107882:0712/082420.128616:INFO:CONSOLE(636)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://nbrecsys.4paradigm.com/sdk/js/ParadigmSDK_v3.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml (636)
[107882:107882:0712/082420.130963:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107882:107882:0712/082420.133089:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107882:107892:0712/082420.153112:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[107882:107882:0712/082420.153157:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://gkcx.eol.cn/
[107882:107882:0712/082420.153199:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://gkcx.eol.cn/, https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml, 4
[107882:107892:0712/082420.153213:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[107882:107882:0712/082420.153261:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://gkcx.eol.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 15:17:59 GMT Content-Type: text/html Content-Length: 3637 Expires: Fri, 12 Jul 2019 15:58:22 GMT Server: eolweb Vary: Accept-Encoding Cache-Control: max-age=7200 Content-Encoding: gzip X-Ser: BC18_dx-lt-yd-jiangsu-zhenjiang-3-cache-9, BC80_yatx-beijing-beijing-2-cache-1, BC42_ck-beijing-beijing-1-cache-1, BC89_ck-tianjin-tianjin-1-cache-4  ,107977, 5
[1:7:0712/082420.157798:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082420.434890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gaokao.eol.cn/, 465, 7f9e04377881
[1:1:0712/082420.442077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"432 0x7f9e01a32070 0x3f1e53fb4960 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082420.442267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"432 0x7f9e01a32070 0x3f1e53fb4960 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082420.442506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082420.442832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , (){n.crossStore.connect(o)}
[1:1:0712/082420.442939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[107882:107882:0712/082420.449563:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/082420.451523:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x3f1e54522020
[1:1:0712/082420.451735:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[107882:107882:0712/082420.455215:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/082420.472751:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/082420.472964:INFO:render_frame_impl.cc(7019)] 	 [url] = https://gaokao.eol.cn
[107882:107882:0712/082420.475396:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://gaokao.eol.cn/
[107882:107882:0712/082420.512391:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107882:107882:0712/082420.517313:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/082420.527849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082420.528634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/082420.528817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[107882:107892:0712/082420.548571:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[107882:107892:0712/082420.548664:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[107882:107882:0712/082420.552677:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://nbrecsys.4paradigm.com/
[107882:107882:0712/082420.552759:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://nbrecsys.4paradigm.com/, https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html, 5
[107882:107882:0712/082420.552893:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_https://nbrecsys.4paradigm.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 15:24:20 GMT Server: openresty Last-Modified: Thu, 09 Aug 2018 18:39:56 GMT Cache-Control: no-cache Content-Type: text/html ETag: W/"5b6c8a7c-4e4a" Content-Encoding: gzip  ,107977, 5
[1:7:0712/082420.554320:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082423.011752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082423.012089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082423.692959:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://gkcx.eol.cn/
[1:1:0712/082423.712467:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082424.187342:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_https://nbrecsys.4paradigm.com/
[1:1:0712/082424.990385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082424.990789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082425.268900:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[107882:107882:0712/082425.285839:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://gkcx.eol.cn/, https://gkcx.eol.cn/, 4
[107882:107882:0712/082425.285924:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://gkcx.eol.cn/, https://gkcx.eol.cn
[1:1:0712/082425.334867:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082425.335172:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082425.336160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562 0x7f9e01a32070 0x3f1e54151ce0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082425.337074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , ParadigmSDKv3.init("47ff618e783f4924b9dd2c04f85716f3");ParadigmSDKv3.renderArticle("8705362ca52a44e7
[1:1:0712/082425.337318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082425.345692:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6541c29c8, 0x3f1e53b34198
[1:1:0712/082425.346037:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 0
[1:1:0712/082425.346544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gaokao.eol.cn/, 604
[1:1:0712/082425.346958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f9e01a32070 0x3f1e543985e0 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 562 0x7f9e01a32070 0x3f1e54151ce0 
[1:1:0712/082425.429133:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.093822, 152, 1
[1:1:0712/082425.429504:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082425.505093:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[107882:107882:0712/082425.508922:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://nbrecsys.4paradigm.com/, https://nbrecsys.4paradigm.com/, 5
[107882:107882:0712/082425.509025:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://nbrecsys.4paradigm.com/, https://nbrecsys.4paradigm.com
[1:1:0712/082425.709377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082425.709724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082426.054451:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082426.655534:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082426.655838:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082426.659521:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f9e01a32070 0x3f1e54b3a6e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082426.662111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , var toplist = '<div class="yxphb mtT_15">' +
'<div class="gkbk-head"><a href="http://gkcx.eol.cn/sc
[1:1:0712/082426.662347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082426.680529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f9e01a32070 0x3f1e54b3a6e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082426.707798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 611 0x7f9e01a32070 0x3f1e54b3a6e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082426.721824:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 2000
[1:1:0712/082426.722463:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 664
[1:1:0712/082426.722739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f9e01a32070 0x3f1e543ab9e0 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 611 0x7f9e01a32070 0x3f1e54b3a6e0 
[1:1:0712/082426.764908:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.108886, 180, 1
[1:1:0712/082426.765162:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082426.834246:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://gaokao.eol.cn/, 604, 7f9e04377881
[1:1:0712/082426.870690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"562 0x7f9e01a32070 0x3f1e54151ce0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082426.871091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"562 0x7f9e01a32070 0x3f1e54151ce0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082426.871520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082426.872199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , (){n.crossStore.connect(o)}
[1:1:0712/082426.872420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[107882:107882:0712/082426.878884:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/082426.882020:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x3f1e54996e20
[1:1:0712/082426.882283:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[107882:107882:0712/082426.886932:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/082426.907120:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/082426.907380:INFO:render_frame_impl.cc(7019)] 	 [url] = https://gaokao.eol.cn
[107882:107882:0712/082426.909511:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://gaokao.eol.cn/
[107882:107882:0712/082426.948189:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107882:107882:0712/082426.952835:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107882:107892:0712/082426.974733:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[107882:107882:0712/082426.974800:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://nbrecsys.4paradigm.com/
[107882:107882:0712/082426.974857:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://nbrecsys.4paradigm.com/, https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html, 6
[107882:107892:0712/082426.974861:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[107882:107882:0712/082426.974925:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://nbrecsys.4paradigm.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 15:24:26 GMT Server: openresty Last-Modified: Thu, 09 Aug 2018 18:39:56 GMT Cache-Control: no-cache Content-Type: text/html ETag: W/"5b6c8a7c-4e4a" Content-Encoding: gzip  ,107977, 5
[1:7:0712/082426.979354:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082427.003096:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082427.004119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082427.004377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082427.005541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082427.008735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082427.028062:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082427.028560:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082427.116027:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082427.216236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082427.216521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082427.403572:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082427.403875:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/082428.313889:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082428.314203:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082428.318344:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670 0x7f9e01a32070 0x3f1e5438d5e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082428.319455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , if(typeof(jQuery)=="undefined"&&typeof(Zepto)=="undefined"){document.write("<script src='https://sta
[1:1:0712/082428.319642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082428.322853:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670 0x7f9e01a32070 0x3f1e5438d5e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082428.335717:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670 0x7f9e01a32070 0x3f1e5438d5e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082428.344313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670 0x7f9e01a32070 0x3f1e5438d5e0 , "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082428.345193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 2000
[1:1:0712/082428.345394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 728
[1:1:0712/082428.345513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f9e01a32070 0x3f1e55120a60 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 670 0x7f9e01a32070 0x3f1e5438d5e0 
[1:1:0712/082428.345736:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 2000
[1:1:0712/082428.345909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 729
[1:1:0712/082428.346012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f9e01a32070 0x3f1e55122ae0 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 670 0x7f9e01a32070 0x3f1e5438d5e0 
[1:1:0712/082428.346260:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 2000
[1:1:0712/082428.346442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 730
[1:1:0712/082428.346547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f9e01a32070 0x3f1e53f7df60 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 670 0x7f9e01a32070 0x3f1e5438d5e0 
[1:1:0712/082428.346774:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", 2000
[1:1:0712/082428.346948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 731
[1:1:0712/082428.347048:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f9e01a32070 0x3f1e55115260 , 5:3_https://gaokao.eol.cn/, 1, -5:3_https://gaokao.eol.cn/, 670 0x7f9e01a32070 0x3f1e5438d5e0 
[1:1:0712/082428.375777:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
		remove user.11_a4000a64 -> 0
		remove user.12_6d7f8d0b -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[107882:107882:0712/082437.890674:INFO:CONSOLE(4)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://gaokao.eol.cn/e_css/index/2018/fonts/iconfont.woff", source: https://www.eol.cn/e_js/index/2018/jquery.min.js (4)
[1:1:0712/082437.945985:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082438.211825:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://nbrecsys.4paradigm.com/
[1:1:0712/082438.358187:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082438.358407:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082438.362406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7f9e01a32070 0x3f1e53f99de0 , "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082438.409221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://nbrecsys.4paradigm.com/, 3b4d4479a020, , , 
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typ
[1:1:0712/082438.409537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 5, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082438.456125:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7f9e01a32070 0x3f1e53f99de0 , "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082438.475757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082438.476661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_https://nbrecsys.4paradigm.com/-5:3_https://gaokao.eol.cn/, 3b4d44682860, 3b4d4479a020, r.onload, (){e._serverWin=r.contentWindow,e._isConnected=!0,e._iframeBeforeFuns.forEach(function(t){return t()
[1:1:0712/082438.476948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 2, , , 0
[1:1:0712/082438.477487:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/082438.541257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082438.541435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082439.682546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 664, 7f9e043778db
[1:1:0712/082439.692981:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"611 0x7f9e01a32070 0x3f1e54b3a6e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.693224:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"611 0x7f9e01a32070 0x3f1e54b3a6e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.693443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 800
[1:1:0712/082439.693559:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f9e01a32070 0x3f1e5393b360 , 5:3_https://gaokao.eol.cn/, 0, , 664 0x7f9e01a32070 0x3f1e543ab9e0 
[1:1:0712/082439.693714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082439.694041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
		switchAd($('.adbox a'));
		switchAd($('.adbox2 a'));
	}
[1:1:0712/082439.694163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082439.763947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 728, 7f9e043778db
[1:1:0712/082439.797202:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.797448:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.797734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 803
[1:1:0712/082439.797859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7f9e01a32070 0x3f1e540b91e0 , 5:3_https://gaokao.eol.cn/, 0, , 728 0x7f9e01a32070 0x3f1e55120a60 
[1:1:0712/082439.798021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082439.798356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082439.798468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082439.823634:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 729, 7f9e043778db
[1:1:0712/082439.844017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.844402:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.844824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 804
[1:1:0712/082439.845026:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f9e01a32070 0x3f1e57f103e0 , 5:3_https://gaokao.eol.cn/, 0, , 729 0x7f9e01a32070 0x3f1e55122ae0 
[1:1:0712/082439.845302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082439.845915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082439.846146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082439.859001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 730, 7f9e043778db
[1:1:0712/082439.874220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.874434:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.874745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 805
[1:1:0712/082439.874865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7f9e01a32070 0x3f1e5503dfe0 , 5:3_https://gaokao.eol.cn/, 0, , 730 0x7f9e01a32070 0x3f1e53f7df60 
[1:1:0712/082439.875022:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082439.875375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082439.875494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082439.923678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 731, 7f9e043778db
[1:1:0712/082439.959780:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3b4d44682860","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082439.960136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://gaokao.eol.cn/","ptid":"670 0x7f9e01a32070 0x3f1e5438d5e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082440.089847:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 806
[1:1:0712/082440.090380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 806 0x7f9e01a32070 0x3f1e57fb7660 , 5:3_https://gaokao.eol.cn/, 0, , 731 0x7f9e01a32070 0x3f1e55115260 
[1:1:0712/082440.090674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082440.091369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082440.091598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082440.192021:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[107882:107882:0712/082440.211537:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://nbrecsys.4paradigm.com/, https://nbrecsys.4paradigm.com/, 6
[107882:107882:0712/082440.211665:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://nbrecsys.4paradigm.com/, https://nbrecsys.4paradigm.com
[1:1:0712/082440.446742:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082440.448588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://nbrecsys.4paradigm.com/, 3b4d4479a020, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082440.448825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 5, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082440.450085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082440.488838:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082440.489300:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:5_https://nbrecsys.4paradigm.com/, 5:3_https://gaokao.eol.cn/
[1:1:0712/082440.489413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://nbrecsys.4paradigm.com/, 3b4d4479a020, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082440.489539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 5, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082440.489841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082440.614364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082440.614560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[107882:107882:0712/082440.918841:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/082442.627533:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082442.867662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 803, 7f9e043778db
[1:1:0712/082442.878680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"728 0x7f9e01a32070 0x3f1e55120a60 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082442.878873:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"728 0x7f9e01a32070 0x3f1e55120a60 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082442.879097:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 862
[1:1:0712/082442.879216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f9e01a32070 0x3f1e545c07e0 , 5:3_https://gaokao.eol.cn/, 0, , 803 0x7f9e01a32070 0x3f1e540b91e0 
[1:1:0712/082442.879369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082442.879736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082442.879909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082442.884743:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 804, 7f9e043778db
[1:1:0712/082442.911829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"729 0x7f9e01a32070 0x3f1e55122ae0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082442.912140:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"729 0x7f9e01a32070 0x3f1e55122ae0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082442.912545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 864
[1:1:0712/082442.912747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f9e01a32070 0x3f1e540b91e0 , 5:3_https://gaokao.eol.cn/, 0, , 804 0x7f9e01a32070 0x3f1e57f103e0 
[1:1:0712/082442.913022:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082442.913605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082442.913780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082442.926269:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 805, 7f9e043778db
[1:1:0712/082442.963062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"730 0x7f9e01a32070 0x3f1e53f7df60 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082442.963353:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"730 0x7f9e01a32070 0x3f1e53f7df60 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082442.963773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 865
[1:1:0712/082442.963990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7f9e01a32070 0x3f1e56d837e0 , 5:3_https://gaokao.eol.cn/, 0, , 805 0x7f9e01a32070 0x3f1e5503dfe0 
[1:1:0712/082442.964245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082442.964816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082442.965014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082443.075390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 806, 7f9e043778db
[1:1:0712/082443.116847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"731 0x7f9e01a32070 0x3f1e55115260 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082443.117149:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"731 0x7f9e01a32070 0x3f1e55115260 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082443.117552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 867
[1:1:0712/082443.117751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 867 0x7f9e01a32070 0x3f1e5366b2e0 , 5:3_https://gaokao.eol.cn/, 0, , 806 0x7f9e01a32070 0x3f1e57fb7660 
[1:1:0712/082443.118032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082443.118610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082443.118786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082443.293007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082443.293441:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://gaokao.eol.cn/, 5:5_https://nbrecsys.4paradigm.com/
[1:1:0712/082443.293548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , r, (r){r.source===t&&"string"==typeof r.data&&0===r.data.indexOf(e)&&l(+r.data.slice(e.length))}
[1:1:0712/082443.293646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082443.293933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082443.347541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082443.399690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082443.399873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082443.507109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 800, 7f9e043778db
[1:1:0712/082443.523400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"664 0x7f9e01a32070 0x3f1e543ab9e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082443.523581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"664 0x7f9e01a32070 0x3f1e543ab9e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082443.523815:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 880
[1:1:0712/082443.523940:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7f9e01a32070 0x3f1e56c5e360 , 5:3_https://gaokao.eol.cn/, 0, , 800 0x7f9e01a32070 0x3f1e5393b360 
[1:1:0712/082443.524106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082443.524418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
		switchAd($('.adbox a'));
		switchAd($('.adbox2 a'));
	}
[1:1:0712/082443.524525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082444.245041:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082444.245280:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082444.249884:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 860 0x7f9e01a32070 0x3f1e546f5560 , "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082444.298928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://nbrecsys.4paradigm.com/, 3b4d4477a908, , , 
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typ
[1:1:0712/082444.299242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 6, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082444.327623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 860 0x7f9e01a32070 0x3f1e546f5560 , "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082444.342817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082444.343492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:6_https://nbrecsys.4paradigm.com/-5:3_https://gaokao.eol.cn/, 3b4d44682860, 3b4d4477a908, r.onload, (){e._serverWin=r.contentWindow,e._isConnected=!0,e._iframeBeforeFuns.forEach(function(t){return t()
[1:1:0712/082444.343703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 2, , , 0
[1:1:0712/082444.344112:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/082444.645451:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082444.646230:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:5_https://nbrecsys.4paradigm.com/, 5:3_https://gaokao.eol.cn/
[1:1:0712/082444.646424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://nbrecsys.4paradigm.com/, 3b4d4479a020, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082444.646655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 5, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082444.647155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082444.690215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082444.690504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082444.818057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082444.818873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082444.819059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082444.819628:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082444.821749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082444.878687:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 879 0x7f9e01d9abd0 0x3f1e54a6fe58 , "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml"
[1:1:0712/082444.907567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://gkcx.eol.cn/, 3b4d44794540, , , /*! jQuery v1.8.3 jquery.com | jquery.org/license */
(function(e, t) {
    function _(e) {
        v
[1:1:0712/082444.907943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml", "gkcx.eol.cn", 4, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082445.124373:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 879 0x7f9e01d9abd0 0x3f1e54a6fe58 , "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml"
[1:1:0712/082445.142732:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml"
[1:1:0712/082445.486118:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082445.488532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://nbrecsys.4paradigm.com/, 3b4d4477a908, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082445.488832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 6, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082445.489683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082445.534159:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082445.535062:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:6_https://nbrecsys.4paradigm.com/, 5:3_https://gaokao.eol.cn/
[1:1:0712/082445.536188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://nbrecsys.4paradigm.com/, 3b4d4477a908, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082445.536452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 6, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082445.537193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082445.678900:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 862, 7f9e043778db
[1:1:0712/082445.697329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"803 0x7f9e01a32070 0x3f1e540b91e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.697674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"803 0x7f9e01a32070 0x3f1e540b91e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.698130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 944
[1:1:0712/082445.698365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 944 0x7f9e01a32070 0x3f1e5434c160 , 5:3_https://gaokao.eol.cn/, 0, , 862 0x7f9e01a32070 0x3f1e545c07e0 
[1:1:0712/082445.698697:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082445.699331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082445.699543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082445.711943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 864, 7f9e043778db
[1:1:0712/082445.753294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"804 0x7f9e01a32070 0x3f1e57f103e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.753685:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"804 0x7f9e01a32070 0x3f1e57f103e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.754207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 945
[1:1:0712/082445.754493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 945 0x7f9e01a32070 0x3f1e583583e0 , 5:3_https://gaokao.eol.cn/, 0, , 864 0x7f9e01a32070 0x3f1e540b91e0 
[1:1:0712/082445.755150:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082445.755769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082445.756000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082445.810249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 865, 7f9e043778db
[1:1:0712/082445.834670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"805 0x7f9e01a32070 0x3f1e5503dfe0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.834972:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"805 0x7f9e01a32070 0x3f1e5503dfe0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.835435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 947
[1:1:0712/082445.835731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f9e01a32070 0x3f1e54363ce0 , 5:3_https://gaokao.eol.cn/, 0, , 865 0x7f9e01a32070 0x3f1e56d837e0 
[1:1:0712/082445.836032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082445.836683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082445.836912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082445.882222:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 867, 7f9e043778db
[1:1:0712/082445.923081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"806 0x7f9e01a32070 0x3f1e57fb7660 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.923393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"806 0x7f9e01a32070 0x3f1e57fb7660 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082445.923882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 951
[1:1:0712/082445.924128:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f9e01a32070 0x3f1e545af960 , 5:3_https://gaokao.eol.cn/, 0, , 867 0x7f9e01a32070 0x3f1e5366b2e0 
[1:1:0712/082445.924457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082445.925082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082445.925297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082446.026546:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.027348:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://gaokao.eol.cn/, 5:5_https://nbrecsys.4paradigm.com/
[1:1:0712/082446.027596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , r, (r){r.source===t&&"string"==typeof r.data&&0===r.data.indexOf(e)&&l(+r.data.slice(e.length))}
[1:1:0712/082446.027833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082446.028340:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.051366:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.187459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082446.187799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082446.191312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 880, 7f9e043778db
[1:1:0712/082446.231806:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"800 0x7f9e01a32070 0x3f1e5393b360 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082446.232127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"800 0x7f9e01a32070 0x3f1e5393b360 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082446.232587:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 962
[1:1:0712/082446.232849:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7f9e01a32070 0x3f1e5836ef60 , 5:3_https://gaokao.eol.cn/, 0, , 880 0x7f9e01a32070 0x3f1e56c5e360 
[1:1:0712/082446.233142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.233810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
		switchAd($('.adbox a'));
		switchAd($('.adbox2 a'));
	}
[1:1:0712/082446.234077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082446.429880:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.430720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082446.430968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082446.431643:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.434279:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.585904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml"
[1:1:0712/082446.586795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://gkcx.eol.cn/, 3b4d44794540, , ready, (e) {
            if (e === !0 ? --v.readyWait: v.isReady) return;
            if (!i.body) return s
[1:1:0712/082446.587072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gkcx.eol.cn/interface/gaokao.eol.cn/searchmes.shtml", "gkcx.eol.cn", 4, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082446.610124:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.610953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://gkcx.eol.cn/-5:3_https://gaokao.eol.cn/, 3b4d44682860, 3b4d44794540, loadHandler, (){if(!hasLoaded){hasLoaded=!0,executePluginMethod("load");for(var b=0;b<registeredOnLoadHandlers.le
[1:1:0712/082446.611199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 2, , , 0
[1:1:0712/082446.611662:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/082446.797530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.799043:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://gaokao.eol.cn/, 5:6_https://nbrecsys.4paradigm.com/
[1:1:0712/082446.799404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , r, (r){r.source===t&&"string"==typeof r.data&&0===r.data.indexOf(e)&&l(+r.data.slice(e.length))}
[1:1:0712/082446.799824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082446.800804:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082446.803005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.001218:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.002392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082447.003029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.003967:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.007425:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.092641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , document.readyState
[1:1:0712/082447.092971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.096434:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 944, 7f9e043778db
[1:1:0712/082447.137090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"862 0x7f9e01a32070 0x3f1e545c07e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.137467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"862 0x7f9e01a32070 0x3f1e545c07e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.137907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1004
[1:1:0712/082447.138163:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1004 0x7f9e01a32070 0x3f1e584007e0 , 5:3_https://gaokao.eol.cn/, 0, , 944 0x7f9e01a32070 0x3f1e5434c160 
[1:1:0712/082447.138535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.139175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082447.139390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.144682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 945, 7f9e043778db
[1:1:0712/082447.170897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"864 0x7f9e01a32070 0x3f1e540b91e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.171241:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"864 0x7f9e01a32070 0x3f1e540b91e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.171777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1006
[1:1:0712/082447.172063:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1006 0x7f9e01a32070 0x3f1e583e0760 , 5:3_https://gaokao.eol.cn/, 0, , 945 0x7f9e01a32070 0x3f1e583583e0 
[1:1:0712/082447.172425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.173065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082447.173283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.182407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 947, 7f9e043778db
[1:1:0712/082447.226259:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"865 0x7f9e01a32070 0x3f1e56d837e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.226603:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"865 0x7f9e01a32070 0x3f1e56d837e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.227032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1007
[1:1:0712/082447.227283:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7f9e01a32070 0x3f1e582abae0 , 5:3_https://gaokao.eol.cn/, 0, , 947 0x7f9e01a32070 0x3f1e54363ce0 
[1:1:0712/082447.227657:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.228344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082447.228568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.280656:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 951, 7f9e043778db
[1:1:0712/082447.307409:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"867 0x7f9e01a32070 0x3f1e5366b2e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.307716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"867 0x7f9e01a32070 0x3f1e5366b2e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.308173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1009
[1:1:0712/082447.308410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7f9e01a32070 0x3f1e5366b2e0 , 5:3_https://gaokao.eol.cn/, 0, , 951 0x7f9e01a32070 0x3f1e545af960 
[1:1:0712/082447.308760:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.309433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082447.309664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.856383:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 962, 7f9e043778db
[1:1:0712/082447.898162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"880 0x7f9e01a32070 0x3f1e56c5e360 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.898508:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"880 0x7f9e01a32070 0x3f1e56c5e360 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082447.898957:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1018
[1:1:0712/082447.899229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1018 0x7f9e01a32070 0x3f1e53899de0 , 5:3_https://gaokao.eol.cn/, 0, , 962 0x7f9e01a32070 0x3f1e5836ef60 
[1:1:0712/082447.899589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.900282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
		switchAd($('.adbox a'));
		switchAd($('.adbox2 a'));
	}
[1:1:0712/082447.900507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.953833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.954654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082447.954891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082447.955558:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082447.958733:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082448.152500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082448.153325:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:5_https://nbrecsys.4paradigm.com/, 5:3_https://gaokao.eol.cn/
[1:1:0712/082448.153536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://nbrecsys.4paradigm.com/, 3b4d4479a020, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082448.153796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 5, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082448.154369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082448.717854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082448.718708:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_https://gaokao.eol.cn/, 5:5_https://nbrecsys.4paradigm.com/
[1:1:0712/082448.718928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , r, (r){r.source===t&&"string"==typeof r.data&&0===r.data.indexOf(e)&&l(+r.data.slice(e.length))}
[1:1:0712/082448.719149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082448.719689:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082448.741990:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082448.817304:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082448.818175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082448.818432:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082448.819679:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082448.822367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.540215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1004, 7f9e043778db
[1:1:0712/082450.575923:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"944 0x7f9e01a32070 0x3f1e5434c160 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.576230:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"944 0x7f9e01a32070 0x3f1e5434c160 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.576664:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1084
[1:1:0712/082450.576912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f9e01a32070 0x3f1e58490ce0 , 5:3_https://gaokao.eol.cn/, 0, , 1004 0x7f9e01a32070 0x3f1e584007e0 
[1:1:0712/082450.577280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.577938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082450.578183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082450.587746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1006, 7f9e043778db
[1:1:0712/082450.604821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"945 0x7f9e01a32070 0x3f1e583583e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.605119:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"945 0x7f9e01a32070 0x3f1e583583e0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.605561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1085
[1:1:0712/082450.605791:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7f9e01a32070 0x3f1e5866ff60 , 5:3_https://gaokao.eol.cn/, 0, , 1006 0x7f9e01a32070 0x3f1e583e0760 
[1:1:0712/082450.606157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.606739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082450.606977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082450.619062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1007, 7f9e043778db
[1:1:0712/082450.663782:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"947 0x7f9e01a32070 0x3f1e54363ce0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.664136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"947 0x7f9e01a32070 0x3f1e54363ce0 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.664575:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1087
[1:1:0712/082450.664804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7f9e01a32070 0x3f1e586bad60 , 5:3_https://gaokao.eol.cn/, 0, , 1007 0x7f9e01a32070 0x3f1e582abae0 
[1:1:0712/082450.665177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.665773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082450.665996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082450.705047:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1009, 7f9e043778db
[1:1:0712/082450.744317:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"951 0x7f9e01a32070 0x3f1e545af960 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.744650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"951 0x7f9e01a32070 0x3f1e545af960 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.745169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1089
[1:1:0712/082450.745602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f9e01a32070 0x3f1e58a81260 , 5:3_https://gaokao.eol.cn/, 0, , 1009 0x7f9e01a32070 0x3f1e5366b2e0 
[1:1:0712/082450.746254:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.747366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082450.747791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082450.888069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.889493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , o.onreadystatechange, (){if(4===o.readyState)if(200===o.status){var e=JSON.parse(o.responseText);t(e)}else r(o)}
[1:1:0712/082450.889873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082450.891039:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.895367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.901536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1018, 7f9e043778db
[1:1:0712/082450.932674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"962 0x7f9e01a32070 0x3f1e5836ef60 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.933183:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"962 0x7f9e01a32070 0x3f1e5836ef60 ","rf":"5:3_https://gaokao.eol.cn/"}
[1:1:0712/082450.933677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://gaokao.eol.cn/, 1100
[1:1:0712/082450.933929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f9e01a32070 0x3f1e58b1aae0 , 5:3_https://gaokao.eol.cn/, 0, , 1018 0x7f9e01a32070 0x3f1e53899de0 
[1:1:0712/082450.934268:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml"
[1:1:0712/082450.934826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://gaokao.eol.cn/, 3b4d44682860, , , () {
		switchAd($('.adbox a'));
		switchAd($('.adbox2 a'));
	}
[1:1:0712/082450.935056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://gaokao.eol.cn/news/201904/t20190415_1654652.shtml", "gaokao.eol.cn", 3, 1, , , 0
[1:1:0712/082451.223695:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
[1:1:0712/082451.225110:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:6_https://nbrecsys.4paradigm.com/, 5:3_https://gaokao.eol.cn/
[1:1:0712/082451.225479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://nbrecsys.4paradigm.com/, 3b4d4477a908, , n, (n){n.source===e&&"string"==typeof n.data&&0===n.data.indexOf(t)&&l(+n.data.slice(t.length))}
[1:1:0712/082451.225924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html", "nbrecsys.4paradigm.com", 6, 1, https://gaokao.eol.cn, gaokao.eol.cn, 3
[1:1:0712/082451.226594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://nbrecsys.4paradigm.com/sdk/html/cross-store-server.html"
