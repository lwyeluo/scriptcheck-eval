[0712/082220.737131:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/082220.737396:INFO:switcher_clone.cc(787)] backtrace rip is 7f1665e46891
[0712/082221.695465:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/082221.695856:INFO:switcher_clone.cc(787)] backtrace rip is 7f7872e5c891
[1:1:0712/082221.707546:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/082221.707836:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/082221.715551:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[107615:107615:0712/082223.162223:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/082223.241476:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/082223.241900:INFO:switcher_clone.cc(787)] backtrace rip is 7f4b30383891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/685015f6-e2b2-4daa-96b5-067a8300db95
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[107646:107646:0712/082223.457862:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=107646
[107659:107659:0712/082223.458328:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=107659
[107615:107615:0712/082223.806422:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[107615:107644:0712/082223.807117:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/082223.807334:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/082223.807568:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/082223.808129:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/082223.808284:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/082223.811592:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2336ec5a, 1
[1:1:0712/082223.812270:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x4af0a41, 0
[1:1:0712/082223.812495:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x22e4cd99, 3
[1:1:0712/082223.812814:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1abd074e, 2
[1:1:0712/082223.813155:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 410affffffaf04 5affffffec3623 4e07ffffffbd1a ffffff99ffffffcdffffffe422 , 10104, 4
[1:1:0712/082223.814206:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[107615:107644:0712/082223.814632:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGA
�Z�6#N����"3k-
[107615:107644:0712/082223.814698:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is A
�Z�6#N����"�X3k-
[1:1:0712/082223.814834:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f78710970a0, 3
[1:1:0712/082223.815048:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7871222080, 2
[1:1:0712/082223.815205:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f785aee5d20, -2
[107615:107644:0712/082223.815244:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[107615:107644:0712/082223.815506:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 107667, 4, 410aaf04 5aec3623 4e07bd1a 99cde422 
[1:1:0712/082223.834049:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/082223.834900:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1abd074e
[1:1:0712/082223.835847:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1abd074e
[1:1:0712/082223.837468:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1abd074e
[1:1:0712/082223.838937:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.839144:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.839332:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.839553:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.840189:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1abd074e
[1:1:0712/082223.840545:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7872e5c7ba
[1:1:0712/082223.840687:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7872e53def, 7f7872e5c77a, 7f7872e5e0cf
[1:1:0712/082223.846310:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1abd074e
[1:1:0712/082223.846672:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1abd074e
[1:1:0712/082223.847418:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1abd074e
[1:1:0712/082223.849442:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.849638:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.849820:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.850006:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1abd074e
[1:1:0712/082223.851235:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1abd074e
[1:1:0712/082223.851613:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7872e5c7ba
[1:1:0712/082223.851792:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7872e53def, 7f7872e5c77a, 7f7872e5e0cf
[1:1:0712/082223.859441:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/082223.859854:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/082223.860001:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd8dcb4588, 0x7ffd8dcb4508)
[1:1:0712/082223.876516:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/082223.882175:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[107615:107615:0712/082224.481696:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107615:107615:0712/082224.483051:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107615:107626:0712/082224.503345:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[107615:107626:0712/082224.503449:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[107615:107615:0712/082224.503570:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[107615:107615:0712/082224.503655:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[107615:107615:0712/082224.503798:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,107667, 4
[1:7:0712/082224.509498:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[107615:107637:0712/082224.564415:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/082224.607071:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3c7cbbbcd220
[1:1:0712/082224.607778:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/082224.864796:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/082226.064976:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082226.066843:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[107615:107615:0712/082226.431443:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[107615:107615:0712/082226.431547:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/082227.033645:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082227.250117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b6c443e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/082227.250402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082227.266460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b6c443e1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/082227.266660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082227.378751:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082227.378983:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082227.835880:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082227.844256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b6c443e1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/082227.844595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082227.876892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082227.888128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b6c443e1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/082227.888536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082227.900797:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[107615:107615:0712/082227.902156:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/082227.904487:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c7cbbbcbe20
[1:1:0712/082227.905202:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[107615:107615:0712/082227.911995:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[107615:107615:0712/082227.967510:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[107615:107615:0712/082227.967610:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/082227.981931:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082228.740144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f785cac02e0 0x3c7cbbc7b8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082228.741510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b6c443e1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/082228.741743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082228.743236:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[107615:107615:0712/082228.804284:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/082228.806353:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3c7cbbbcc820
[1:1:0712/082228.806613:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[107615:107615:0712/082228.810911:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/082228.825418:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/082228.825692:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[107615:107615:0712/082228.829740:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[107615:107615:0712/082228.842324:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107615:107615:0712/082228.843675:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107615:107626:0712/082228.851843:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[107615:107626:0712/082228.851935:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[107615:107615:0712/082228.852213:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[107615:107615:0712/082228.852316:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[107615:107615:0712/082228.852504:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,107667, 4
[1:7:0712/082228.856000:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082229.353989:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/082229.675835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7f785cac02e0 0x3c7cbbf7fd60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/082229.676951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3b6c443e1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/082229.677268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/082229.678103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[107615:107615:0712/082229.811450:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[107615:107615:0712/082229.811522:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/082229.826375:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/082230.179591:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082230.801861:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082230.802181:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[107615:107615:0712/082230.856756:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[107615:107644:0712/082230.857273:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/082230.857472:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/082230.857746:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/082230.858188:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/082230.858381:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/082230.861693:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x25147d5d, 1
[1:1:0712/082230.862104:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x274b4e09, 0
[1:1:0712/082230.862323:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38862a7, 3
[1:1:0712/082230.862523:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3af03e9f, 2
[1:1:0712/082230.862715:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 094e4b27 5d7d1425 ffffff9f3efffffff03a ffffffa762ffffff8803 , 10104, 5
[1:1:0712/082230.863775:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[107615:107644:0712/082230.864057:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING	NK']}%�>�:�b��m-
[107615:107644:0712/082230.864129:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 	NK']}%�>�:�b���m-
[107615:107644:0712/082230.864440:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 107713, 5, 094e4b27 5d7d1425 9f3ef03a a7628803 
[1:1:0712/082230.864272:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f78710970a0, 3
[1:1:0712/082230.864853:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7871222080, 2
[1:1:0712/082230.865105:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f785aee5d20, -2
[1:1:0712/082230.887500:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/082230.887948:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3af03e9f
[1:1:0712/082230.888389:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3af03e9f
[1:1:0712/082230.889076:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3af03e9f
[1:1:0712/082230.890520:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.890779:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.891067:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.891345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.892234:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3af03e9f
[1:1:0712/082230.892597:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7872e5c7ba
[1:1:0712/082230.892773:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7872e53def, 7f7872e5c77a, 7f7872e5e0cf
[1:1:0712/082230.899646:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3af03e9f
[1:1:0712/082230.900341:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3af03e9f
[1:1:0712/082230.901221:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3af03e9f
[1:1:0712/082230.903220:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.903566:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.903810:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.904036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3af03e9f
[1:1:0712/082230.905270:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3af03e9f
[1:1:0712/082230.905663:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7872e5c7ba
[1:1:0712/082230.905853:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7872e53def, 7f7872e5c77a, 7f7872e5e0cf
[1:1:0712/082230.913238:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/082230.913739:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/082230.913925:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd8dcb4588, 0x7ffd8dcb4508)
[1:1:0712/082230.928551:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/082230.933492:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/082231.102658:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3c7cbbb81220
[1:1:0712/082231.103003:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/082231.235719:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/082231.240476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3b6c4450e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/082231.240784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/082231.248596:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[107615:107615:0712/082232.230218:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[107615:107615:0712/082232.237200:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[107615:107626:0712/082232.281857:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[107615:107615:0712/082232.281977:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://kaoyan.eol.cn/
[107615:107615:0712/082232.282040:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kaoyan.eol.cn/, https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml, 1
[107615:107626:0712/082232.281999:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[107615:107615:0712/082232.282104:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://kaoyan.eol.cn/, HTTP/1.1 200 OK Content-Type: text/html Connection: keep-alive X-Cache: HIT from cache-34-235 Date: Fri, 12 Jul 2019 15:22:31 GMT Cache-Control: max-age=120 CACHE: TCP_REFRESH_MISS Expires: Fri, 12 Jul 2019 15:24:31 GMT Content-Length: 16309 Powered-By-ChinaCache: MISS from CHN-LN-u-3OU Vary: Accept-Encoding Content-Encoding: gzip Server: nginx Powered-By-ChinaCache: MISS from GWB-FS-2-3WY CC_CACHE: TCP_REFRESH_MISS Accept-Ranges: bytes  ,107713, 5
[1:7:0712/082232.285370:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/082232.323887:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://kaoyan.eol.cn/
[107615:107615:0712/082232.469690:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kaoyan.eol.cn/, https://kaoyan.eol.cn/, 1
[107615:107615:0712/082232.469825:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://kaoyan.eol.cn/, https://kaoyan.eol.cn
[1:1:0712/082232.522538:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/082232.612418:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082232.653142:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/082232.729290:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082232.729628:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082233.145716:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/082233.407766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 176 0x7f785af00bd0 0x3c7cbbc15dd8 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082233.415498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0712/082233.415697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082233.422728:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082233.601552:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082233.602128:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082233.602540:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082233.603024:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082233.603440:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082233.847919:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f785af00bd0 0x3c7cbc00f7d8 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082233.853035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , var mpc = window.navigator.userAgent;
if(/Mobile|iP(hone|ad)|Android|BlackBerry|IEMobile/.test(mpc))
[1:1:0712/082233.853270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082234.039874:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.150347, 522, 1
[1:1:0712/082234.040152:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082234.647808:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082234.647980:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082234.648507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7f785ab98070 0x3c7cbc0c4160 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082234.649037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , 
                    var _PAGE_COUNT = "1";
                    var _PAGE_INDEX = "0";
             
[1:1:0712/082234.649225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082234.654798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7f785ab98070 0x3c7cbc0c4160 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082234.685262:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0373321, 124, 1
[1:1:0712/082234.685571:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082235.553535:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082235.553802:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082235.554700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7f785ab98070 0x3c7cbc0a0ce0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082235.555801:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , 
var pkBaseURL = (("https:" == document.location.protocol) ? "https://stat.eol.cn/" : "//stat.eol.cn
[1:1:0712/082235.556053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082236.639192:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082236.641453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , function setCookies(a,b,c){var d=new Date;d.setDate(d.getDate()+c),document.cookie=a+"="+escape(b)+(
[1:1:0712/082236.641721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082236.674951:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082236.714766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082237.516559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 407, "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082237.519809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/082237.520072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082237.737503:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.192942, 781, 1
[1:1:0712/082237.737763:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082238.018324:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082238.018509:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.019204:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f785ab98070 0x3c7cbbfa93e0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.021749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , 
    //搜学校
    function searchschool() {
        var schname = document.getElementById("school
[1:1:0712/082238.022021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082238.054703:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0362411, 130, 1
[1:1:0712/082238.054962:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082238.141636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.144210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/082238.144467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082238.426627:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082238.426865:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.428233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 439 0x7f785ab98070 0x3c7cbba7b5e0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.430046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , 
        $('.paiH-qieH-paiH>div').on('mouseover', function() {
            $('.paiH-qieH-paiH>div').
[1:1:0712/082238.430275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082238.647076:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.220063, 116, 1
[1:1:0712/082238.647369:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/082238.788762:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/082238.788993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.792256:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f785ab98070 0x3c7cbc18e0e0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.793493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , if(typeof(jQuery)=="undefined"&&typeof(Zepto)=="undefined"){document.write("<script src='https://sta
[1:1:0712/082238.793681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082238.797147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f785ab98070 0x3c7cbc18e0e0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.814412:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f785ab98070 0x3c7cbc18e0e0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.818846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 447 0x7f785ab98070 0x3c7cbc18e0e0 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082238.820532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", 2000
[1:1:0712/082238.820747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 463
[1:1:0712/082238.820864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 463 0x7f785ab98070 0x3c7cbc13c4e0 , 5:3_https://kaoyan.eol.cn/, 1, -5:3_https://kaoyan.eol.cn/, 447 0x7f785ab98070 0x3c7cbc18e0e0 
[1:1:0712/082238.821115:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", 2000
[1:1:0712/082238.821335:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 464
[1:1:0712/082238.821454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 464 0x7f785ab98070 0x3c7cbc1668e0 , 5:3_https://kaoyan.eol.cn/, 1, -5:3_https://kaoyan.eol.cn/, 447 0x7f785ab98070 0x3c7cbc18e0e0 
[1:1:0712/082238.821702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", 2000
[1:1:0712/082238.821920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 465
[1:1:0712/082238.822057:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 465 0x7f785ab98070 0x3c7cbc166de0 , 5:3_https://kaoyan.eol.cn/, 1, -5:3_https://kaoyan.eol.cn/, 447 0x7f785ab98070 0x3c7cbc18e0e0 
[1:1:0712/082238.822351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", 2000
[1:1:0712/082238.822547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 466
[1:1:0712/082238.822661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7f785ab98070 0x3c7cbc1669e0 , 5:3_https://kaoyan.eol.cn/, 1, -5:3_https://kaoyan.eol.cn/, 447 0x7f785ab98070 0x3c7cbc18e0e0 
[1:1:0712/082238.869970:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082249.783629:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082250.192673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7f785cac02e0 0x3c7cbba7b360 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082250.194310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , jQuery112409491578193894432_1562944953598({"school":[{"school_id":"1115","name":"南京师范大学"
[1:1:0712/082250.194562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082250.196750:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082250.430127:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 455 0x7f785cac02e0 0x3c7cbc05d560 , "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082250.431548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , jQuery112409491578193894432_1562944953600({"special":[{"special_id":"457","name":"会计学","click"
[1:1:0712/082250.431836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082250.433491:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082250.891897:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 463, 7f785d4dd8db
[1:1:0712/082250.902022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27bb3c522860","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082250.902382:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kaoyan.eol.cn/","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082250.902727:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 517
[1:1:0712/082250.902962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 517 0x7f785ab98070 0x3c7cbc1a4760 , 5:3_https://kaoyan.eol.cn/, 0, , 463 0x7f785ab98070 0x3c7cbc13c4e0 
[1:1:0712/082250.903367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082250.904038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082250.904264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082251.053541:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 464, 7f785d4dd8db
[1:1:0712/082251.077880:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27bb3c522860","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082251.078251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kaoyan.eol.cn/","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082251.078645:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 522
[1:1:0712/082251.078884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 522 0x7f785ab98070 0x3c7cbf3f99e0 , 5:3_https://kaoyan.eol.cn/, 0, , 464 0x7f785ab98070 0x3c7cbc1668e0 
[1:1:0712/082251.079183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082251.079953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082251.080278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082251.097649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 465, 7f785d4dd8db
[1:1:0712/082251.116534:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27bb3c522860","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082251.116954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kaoyan.eol.cn/","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082251.117299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 523
[1:1:0712/082251.117528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 523 0x7f785ab98070 0x3c7cbf3f81e0 , 5:3_https://kaoyan.eol.cn/, 0, , 465 0x7f785ab98070 0x3c7cbc166de0 
[1:1:0712/082251.117817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082251.118453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082251.118705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082251.141527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 466, 7f785d4dd8db
[1:1:0712/082251.165437:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"27bb3c522860","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082251.165783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kaoyan.eol.cn/","ptid":"447 0x7f785ab98070 0x3c7cbc18e0e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082251.166167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 524
[1:1:0712/082251.166444:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7f785ab98070 0x3c7cbf3fa7e0 , 5:3_https://kaoyan.eol.cn/, 0, , 466 0x7f785ab98070 0x3c7cbc1669e0 
[1:1:0712/082251.166750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082251.167374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082251.167696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082252.995978:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082252.996796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , loadHandler, (){if(!hasLoaded){hasLoaded=!0,executePluginMethod("load");for(var b=0;b<registeredOnLoadHandlers.le
[1:1:0712/082252.997078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.165254:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 517, 7f785d4dd8db
[1:1:0712/082254.175432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"463 0x7f785ab98070 0x3c7cbc13c4e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.175831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"463 0x7f785ab98070 0x3c7cbc13c4e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.176218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 610
[1:1:0712/082254.176486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f785ab98070 0x3c7cbc18ad60 , 5:3_https://kaoyan.eol.cn/, 0, , 517 0x7f785ab98070 0x3c7cbc1a4760 
[1:1:0712/082254.176808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082254.177438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082254.177659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.192374:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 522, 7f785d4dd8db
[1:1:0712/082254.221089:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"464 0x7f785ab98070 0x3c7cbc1668e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.221455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"464 0x7f785ab98070 0x3c7cbc1668e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.221844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 611
[1:1:0712/082254.222094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7f785ab98070 0x3c7cbc1cd260 , 5:3_https://kaoyan.eol.cn/, 0, , 522 0x7f785ab98070 0x3c7cbf3f99e0 
[1:1:0712/082254.222429:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082254.223077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082254.223309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.263224:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 523, 7f785d4dd8db
[1:1:0712/082254.290677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"465 0x7f785ab98070 0x3c7cbc166de0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.291046:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"465 0x7f785ab98070 0x3c7cbc166de0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.291413:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 612
[1:1:0712/082254.291703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7f785ab98070 0x3c7cbb7fbb60 , 5:3_https://kaoyan.eol.cn/, 0, , 523 0x7f785ab98070 0x3c7cbf3f81e0 
[1:1:0712/082254.292026:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082254.292684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082254.292916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.311848:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 524, 7f785d4dd8db
[1:1:0712/082254.342993:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"466 0x7f785ab98070 0x3c7cbc1669e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.343359:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"466 0x7f785ab98070 0x3c7cbc1669e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.343729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 613
[1:1:0712/082254.344020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f785ab98070 0x3c7cbf2cd6e0 , 5:3_https://kaoyan.eol.cn/, 0, , 524 0x7f785ab98070 0x3c7cbf3fa7e0 
[1:1:0712/082254.344340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082254.344973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082254.345220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.702404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/082254.702770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.908237:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 610, 7f785d4dd8db
[1:1:0712/082254.929977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"517 0x7f785ab98070 0x3c7cbc1a4760 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.930365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"517 0x7f785ab98070 0x3c7cbc1a4760 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.930763:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 627
[1:1:0712/082254.931011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f785ab98070 0x3c7cbc1a4960 , 5:3_https://kaoyan.eol.cn/, 0, , 610 0x7f785ab98070 0x3c7cbc18ad60 
[1:1:0712/082254.931377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082254.932133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082254.932443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082254.964856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 611, 7f785d4dd8db
[1:1:0712/082254.997038:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"522 0x7f785ab98070 0x3c7cbf3f99e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.997336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"522 0x7f785ab98070 0x3c7cbf3f99e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082254.997706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 634
[1:1:0712/082254.997968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 634 0x7f785ab98070 0x3c7cbb89fae0 , 5:3_https://kaoyan.eol.cn/, 0, , 611 0x7f785ab98070 0x3c7cbc1cd260 
[1:1:0712/082254.998312:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082254.999127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082254.999385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082255.044285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 612, 7f785d4dd8db
[1:1:0712/082255.059139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"523 0x7f785ab98070 0x3c7cbf3f81e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082255.059395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"523 0x7f785ab98070 0x3c7cbf3f81e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082255.059652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 635
[1:1:0712/082255.059817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f785ab98070 0x3c7cbf3cdfe0 , 5:3_https://kaoyan.eol.cn/, 0, , 612 0x7f785ab98070 0x3c7cbb7fbb60 
[1:1:0712/082255.060017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082255.060490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082255.060633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082255.068137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 613, 7f785d4dd8db
[1:1:0712/082255.098632:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"524 0x7f785ab98070 0x3c7cbf3fa7e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082255.098988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"524 0x7f785ab98070 0x3c7cbf3fa7e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082255.099374:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 640
[1:1:0712/082255.099623:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7f785ab98070 0x3c7cbc1dfee0 , 5:3_https://kaoyan.eol.cn/, 0, , 613 0x7f785ab98070 0x3c7cbf2cd6e0 
[1:1:0712/082255.099945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082255.100717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082255.100943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[107615:107615:0712/082255.111898:INFO:CONSOLE(327)] "Mixed Content: The page at 'https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml' was loaded over HTTPS, but requested an insecure image 'http://www.eol.cn/e_ky/zt/2019/2019yz/images/yanzhaohui285.jpg'. This content should also be served over HTTPS.", source: https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml (327)
[107615:107615:0712/082255.138972:INFO:CONSOLE(404)] "Mixed Content: The page at 'https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml' was loaded over HTTPS, but requested an insecure image 'http://www.eol.cn/html/ky/kybk/images/kybk160.jpg'. This content should also be served over HTTPS.", source: https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml (404)
[107615:107615:0712/082255.140248:INFO:CONSOLE(418)] "Mixed Content: The page at 'https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml' was loaded over HTTPS, but requested an insecure image 'http://www.eol.cn/html/ky/2019report/images/bg160.jpg'. This content should also be served over HTTPS.", source: https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml (418)
[107615:107615:0712/082255.256537:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=4696648&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s6.cnzz.com/stat.php?id=4696648&web_id=4696648 (17)
[107615:107615:0712/082255.260897:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=4696648&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s6.cnzz.com/stat.php?id=4696648&web_id=4696648 (17)
[107615:107615:0712/082255.292480:INFO:CONSOLE(1554)] "Mixed Content: The page at 'https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml' was loaded over HTTPS, but requested an insecure image 'http://img.eol.cn/images/ed/kaoyan/2012/dxphb300.jpg'. This content should also be served over HTTPS.", source: https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml (1554)
[107615:107615:0712/082255.324688:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/082255.637067:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/082256.846040:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 627, 7f785d4dd8db
[1:1:0712/082256.856578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"610 0x7f785ab98070 0x3c7cbc18ad60 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.856906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"610 0x7f785ab98070 0x3c7cbc18ad60 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.857252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 685
[1:1:0712/082256.857479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7f785ab98070 0x3c7cbf71e6e0 , 5:3_https://kaoyan.eol.cn/, 0, , 627 0x7f785ab98070 0x3c7cbc1a4960 
[1:1:0712/082256.857785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082256.858446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082256.858683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082256.874643:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 634, 7f785d4dd8db
[1:1:0712/082256.888366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"611 0x7f785ab98070 0x3c7cbc1cd260 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.888699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"611 0x7f785ab98070 0x3c7cbc1cd260 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.889095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 688
[1:1:0712/082256.889327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 688 0x7f785ab98070 0x3c7cbb866ce0 , 5:3_https://kaoyan.eol.cn/, 0, , 634 0x7f785ab98070 0x3c7cbb89fae0 
[1:1:0712/082256.889619:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082256.890430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082256.890677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082256.900113:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 635, 7f785d4dd8db
[1:1:0712/082256.928779:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7f785ab98070 0x3c7cbb7fbb60 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.929137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7f785ab98070 0x3c7cbb7fbb60 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.929548:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 690
[1:1:0712/082256.929803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f785ab98070 0x3c7cbf6d0760 , 5:3_https://kaoyan.eol.cn/, 0, , 635 0x7f785ab98070 0x3c7cbf3cdfe0 
[1:1:0712/082256.930162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082256.930841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082256.931099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082256.945377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 640, 7f785d4dd8db
[1:1:0712/082256.979606:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"613 0x7f785ab98070 0x3c7cbf2cd6e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.979973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"613 0x7f785ab98070 0x3c7cbf2cd6e0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082256.980324:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 700
[1:1:0712/082256.980555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 700 0x7f785ab98070 0x3c7cbf3fcce0 , 5:3_https://kaoyan.eol.cn/, 0, , 640 0x7f785ab98070 0x3c7cbc1dfee0 
[1:1:0712/082256.980899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082256.981566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082256.981818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082258.055197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082258.055782:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/082258.853741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 685, 7f785d4dd8db
[1:1:0712/082258.870435:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7f785ab98070 0x3c7cbc1a4960 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082258.870783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7f785ab98070 0x3c7cbc1a4960 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082258.871207:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 735
[1:1:0712/082258.871446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f785ab98070 0x3c7cbc1f84e0 , 5:3_https://kaoyan.eol.cn/, 0, , 685 0x7f785ab98070 0x3c7cbf71e6e0 
[1:1:0712/082258.871743:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082258.872360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad1 a'));
    }
[1:1:0712/082258.872630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082258.902659:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 688, 7f785d4dd8db
[1:1:0712/082258.936087:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"634 0x7f785ab98070 0x3c7cbb89fae0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082258.936488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"634 0x7f785ab98070 0x3c7cbb89fae0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082258.936967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 737
[1:1:0712/082258.937242:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7f785ab98070 0x3c7cbf66a460 , 5:3_https://kaoyan.eol.cn/, 0, , 688 0x7f785ab98070 0x3c7cbb866ce0 
[1:1:0712/082258.937566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082258.938221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad2 a'));
    }
[1:1:0712/082258.938494:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082258.951629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 690, 7f785d4dd8db
[1:1:0712/082258.969824:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"635 0x7f785ab98070 0x3c7cbf3cdfe0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082258.970153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"635 0x7f785ab98070 0x3c7cbf3cdfe0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082258.970635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 738
[1:1:0712/082258.970871:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7f785ab98070 0x3c7cbc1e3a60 , 5:3_https://kaoyan.eol.cn/, 0, , 690 0x7f785ab98070 0x3c7cbf6d0760 
[1:1:0712/082258.971165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082258.971815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad3 a'));
    }
[1:1:0712/082258.972081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
[1:1:0712/082258.987303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 700, 7f785d4dd8db
[1:1:0712/082259.019834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"640 0x7f785ab98070 0x3c7cbc1dfee0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082259.020178:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"640 0x7f785ab98070 0x3c7cbc1dfee0 ","rf":"5:3_https://kaoyan.eol.cn/"}
[1:1:0712/082259.020793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kaoyan.eol.cn/, 739
[1:1:0712/082259.021069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7f785ab98070 0x3c7cbf3fad60 , 5:3_https://kaoyan.eol.cn/, 0, , 700 0x7f785ab98070 0x3c7cbf3fcce0 
[1:1:0712/082259.021432:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml"
[1:1:0712/082259.022105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kaoyan.eol.cn/, 27bb3c522860, , , () {
        switchAd($('.switchad4 a'));
    }
[1:1:0712/082259.022313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kaoyan.eol.cn/yanzaozx/201904/t20190422_1655637.shtml", "kaoyan.eol.cn", 3, 1, , , 0
