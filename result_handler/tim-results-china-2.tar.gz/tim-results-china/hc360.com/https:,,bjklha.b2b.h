[0712/230439.805201:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/230439.805535:INFO:switcher_clone.cc(787)] backtrace rip is 7fc89ff19891
[0712/230440.796228:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/230440.796573:INFO:switcher_clone.cc(787)] backtrace rip is 7f717801d891
[1:1:0712/230440.808096:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/230440.808324:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/230440.820813:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[15304:15304:0712/230442.256959:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/69cdf5d0-1e5d-4cbf-8dcd-accd3364f7bd
[0712/230442.357041:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/230442.357406:INFO:switcher_clone.cc(787)] backtrace rip is 7f46cfe78891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[15336:15336:0712/230442.590875:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=15336
[15349:15349:0712/230442.591355:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=15349
[15304:15304:0712/230442.827566:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[15304:15334:0712/230442.829022:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/230442.829466:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/230442.829854:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/230442.831075:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/230442.831382:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/230442.836760:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x10777fcf, 1
[1:1:0712/230442.837519:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x106f45ce, 0
[1:1:0712/230442.837923:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x139cb9a1, 3
[1:1:0712/230442.838335:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2097449d, 2
[1:1:0712/230442.838796:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffce456f10 ffffffcf7f7710 ffffff9d44ffffff9720 ffffffa1ffffffb9ffffff9c13 , 10104, 4
[1:1:0712/230442.840889:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[15304:15334:0712/230442.841481:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Eo�w�D� ����5�:
[15304:15334:0712/230442.841623:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Eo�w�D� ���X��5�:
[15304:15334:0712/230442.842209:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[15304:15334:0712/230442.842369:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 15357, 4, ce456f10 cf7f7710 9d449720 a1b99c13 
[1:1:0712/230442.843277:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71762580a0, 3
[1:1:0712/230442.843798:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71763e3080, 2
[1:1:0712/230442.844195:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71600a6d20, -2
[1:1:0712/230442.863176:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/230442.864110:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2097449d
[1:1:0712/230442.865133:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2097449d
[1:1:0712/230442.866635:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2097449d
[1:1:0712/230442.868082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.868320:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.868540:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.868754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.869448:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2097449d
[1:1:0712/230442.869788:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f717801d7ba
[1:1:0712/230442.869959:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7178014def, 7f717801d77a, 7f717801f0cf
[1:1:0712/230442.876274:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2097449d
[1:1:0712/230442.876813:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2097449d
[1:1:0712/230442.877955:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2097449d
[1:1:0712/230442.880242:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.880486:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.880768:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.881033:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2097449d
[1:1:0712/230442.882333:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2097449d
[1:1:0712/230442.882864:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f717801d7ba
[1:1:0712/230442.883109:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7178014def, 7f717801d77a, 7f717801f0cf
[1:1:0712/230442.894221:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/230442.894805:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/230442.895035:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff01ccfe48, 0x7fff01ccfdc8)
[1:1:0712/230442.912885:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/230442.918561:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[15304:15304:0712/230443.420940:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15304:15304:0712/230443.422037:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[15304:15316:0712/230443.434264:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[15304:15304:0712/230443.434324:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[15304:15304:0712/230443.434364:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[15304:15316:0712/230443.434363:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[15304:15304:0712/230443.434427:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,15357, 4
[1:7:0712/230443.436304:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/230443.480986:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1b3608f40220
[1:1:0712/230443.481127:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[15304:15327:0712/230443.497059:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/230443.599041:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/230444.810944:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230444.815145:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[15304:15304:0712/230445.536514:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[15304:15304:0712/230445.536621:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/230445.910051:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/230446.496626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/230446.496912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/230446.512887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/230446.513125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/230446.639301:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/230446.639554:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230447.088073:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230447.095748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/230447.095931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/230447.128290:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230447.137975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/230447.138148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/230447.149143:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/230447.153514:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1b3608f3ee20
[1:1:0712/230447.153822:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[15304:15304:0712/230447.154677:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[15304:15304:0712/230447.164935:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[15304:15304:0712/230447.198753:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[15304:15304:0712/230447.198899:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/230447.222726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230448.205264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f7161c812e0 0x1b36090fed60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230448.206534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/230448.206742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/230448.208187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[15304:15304:0712/230448.277928:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/230448.278604:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1b3608f3f820
[1:1:0712/230448.278812:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[15304:15304:0712/230448.287077:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/230448.297830:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/230448.298040:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[15304:15304:0712/230448.327417:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[15304:15304:0712/230448.342991:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15304:15304:0712/230448.344031:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[15304:15316:0712/230448.350212:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[15304:15316:0712/230448.350294:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[15304:15304:0712/230448.353396:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[15304:15304:0712/230448.353475:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[15304:15304:0712/230448.353606:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,15357, 4
[1:7:0712/230448.355004:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/230449.074503:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/230449.616113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f7161c812e0 0x1b36092f6260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230449.617212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/230449.617506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/230449.618327:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[15304:15304:0712/230449.896751:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[15304:15304:0712/230449.896874:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/230449.916571:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[15304:15304:0712/230450.334695:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[15304:15334:0712/230450.335211:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/230450.335497:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/230450.335940:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/230450.336784:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/230450.337085:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/230450.342339:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3d2a9591, 1
[1:1:0712/230450.342988:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x58599ae, 0
[1:1:0712/230450.343350:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xeb7f64e, 3
[1:1:0712/230450.343818:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3b3c12a0, 2
[1:1:0712/230450.344093:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffaeffffff99ffffff8505 ffffff91ffffff952a3d ffffffa0123c3b 4efffffff6ffffffb70e , 10104, 5
[1:1:0712/230450.345488:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[15304:15334:0712/230450.345914:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�����*=�<;N���7�:
[15304:15334:0712/230450.345992:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �����*=�<;N���Ć7�:
[1:1:0712/230450.345888:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71762580a0, 3
[1:1:0712/230450.346196:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71763e3080, 2
[15304:15334:0712/230450.346329:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 15401, 5, ae998505 91952a3d a0123c3b 4ef6b70e 
[1:1:0712/230450.346479:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f71600a6d20, -2
[1:1:0712/230450.371978:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/230450.372444:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b3c12a0
[1:1:0712/230450.372974:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b3c12a0
[1:1:0712/230450.373883:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b3c12a0
[1:1:0712/230450.375893:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.376180:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.376486:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.376773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.377708:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b3c12a0
[1:1:0712/230450.378118:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f717801d7ba
[1:1:0712/230450.378337:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7178014def, 7f717801d77a, 7f717801f0cf
[1:1:0712/230450.386228:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3b3c12a0
[1:1:0712/230450.386664:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3b3c12a0
[1:1:0712/230450.387506:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3b3c12a0
[1:1:0712/230450.388305:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/230450.389695:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.389971:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.390224:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.390500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3b3c12a0
[1:1:0712/230450.391859:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3b3c12a0
[1:1:0712/230450.392288:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f717801d7ba
[1:1:0712/230450.392515:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7178014def, 7f717801d77a, 7f717801f0cf
[1:1:0712/230450.400702:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/230450.401264:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/230450.401513:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff01ccfe48, 0x7fff01ccfdc8)
[1:1:0712/230450.415843:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/230450.420430:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/230450.623664:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1b3608ef5220
[1:1:0712/230450.623926:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/230450.826231:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/230450.826465:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/230451.137469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/230451.142152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f0654f4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/230451.142436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/230451.150537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/230451.417377:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/230451.418241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0f0654e21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/230451.418476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[15304:15304:0712/230451.487648:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15304:15304:0712/230451.490323:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[15304:15316:0712/230451.506094:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[15304:15316:0712/230451.506196:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[15304:15304:0712/230451.506270:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bjklha.b2b.hc360.com/
[15304:15304:0712/230451.506312:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bjklha.b2b.hc360.com/, https://bjklha.b2b.hc360.com/, 1
[15304:15304:0712/230451.506369:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://bjklha.b2b.hc360.com/, HTTP/1.1 200 Date: Sat, 13 Jul 2019 06:04:51 GMT Server: nginx Content-Type: text/html;charset=UTF-8 Vary: Accept-Encoding X-Application-Context: msdhomes:80 Content-Language: zh-CN,en-us Content-Encoding: gzip Keep-Alive: timeout=15, max=10000 Connection: Keep-Alive Transfer-Encoding: chunked  ,15401, 5
[1:7:0712/230451.511349:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/230451.568095:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://bjklha.b2b.hc360.com/
[15304:15304:0712/230451.745845:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://bjklha.b2b.hc360.com/, https://bjklha.b2b.hc360.com/, 1
[15304:15304:0712/230451.745977:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://bjklha.b2b.hc360.com/, https://bjklha.b2b.hc360.com
[1:1:0712/230451.759141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/230451.760799:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/230451.761079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f0654f4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/230451.761362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/230451.786876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/230451.921129:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/230451.909727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/230451.921773:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/230451.921963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0f0654f4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/230451.922292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/230451.973372:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/230452.064713:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/230452.064991:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bjklha.b2b.hc360.com/"
[1:1:0712/230452.896663:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f715fd59070 0x1b3609026ae0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230452.899966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(e){function t(o){if(n[o])return n[o].exports;var i=n[o]={exports:{},id:o,loaded:!1};return
[1:1:0712/230452.900155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230452.905694:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230452.962744:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 180 0x7f715fd59070 0x1b3609026ae0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230453.090767:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.12849, 1461, 1
[1:1:0712/230453.090920:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/230453.768556:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/230453.768794:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bjklha.b2b.hc360.com/"
[1:1:0712/230453.838616:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230454.258729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f71763e3080 0x1b36092d42e0 1 0 0x1b36092d42f8 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230454.268271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(e){function t(n){if(r[n])return r[n].exports;var i=r[n]={exports:{},id:n,loaded:!1};return
[1:1:0712/230454.268471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230454.320498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7f71763e3080 0x1b36092cc740 1 0 0x1b36092cc758 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230454.326623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , webpackJsonp([43],{0:function(C,B,D){function E(C){var B=l.includedMod,D=C.attr("id"),E={listType:f[
[1:1:0712/230454.326828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230457.047865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x6d6c4b629c8, 0x1b3608ccd1b0
[1:1:0712/230457.048152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 300
[1:1:0712/230457.048571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 409
[1:1:0712/230457.048823:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 409 0x7f715fd59070 0x1b36093a7560 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 287 0x7f71763e3080 0x1b36092cc740 1 0 0x1b36092cc758 
[1:1:0712/230457.791056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6d6c4b629c8, 0x1b3608ccd1b0
[1:1:0712/230457.791315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230457.791694:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 424
[1:1:0712/230457.791921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 424 0x7f715fd59070 0x1b3609efeee0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 287 0x7f71763e3080 0x1b36092cc740 1 0 0x1b36092cc758 
[1:1:0712/230457.799805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7f71763e3080 0x1b36092cc740 1 0 0x1b36092cc758 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230500.476556:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230500.477141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230500.477519:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230500.477961:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230500.478333:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230500.749942:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 409, 7f716269e881
[1:1:0712/230500.773721:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"287 0x7f71763e3080 0x1b36092cc740 1 0 0x1b36092cc758 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230500.774067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"287 0x7f71763e3080 0x1b36092cc740 1 0 0x1b36092cc758 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230500.774448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230500.775026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){C()}
[1:1:0712/230500.775239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230501.019745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 434, "https://bjklha.b2b.hc360.com/"
[1:1:0712/230501.028936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*! 2018-12-06 06:12:29 */

var _hcuba_=_hcuba_||[];!function(){_hcuba_.push(["setAccountId","B00558
[1:1:0712/230501.029157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230501.149586:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/230501.163046:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1b3608ef2a20
[1:1:0712/230501.163251:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/230501.476990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 434, "https://bjklha.b2b.hc360.com/"
[1:1:0712/230501.531909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x6d6c4b629c8, 0x1b3608ccd1c0
[1:1:0712/230501.532182:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 1000
[1:1:0712/230501.532572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 609
[1:1:0712/230501.532836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f715fd59070 0x1b360a13efe0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 434
[1:1:0712/230501.581977:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 434, "https://bjklha.b2b.hc360.com/"
[1:1:0712/230501.589673:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 434, "https://bjklha.b2b.hc360.com/"
[1:1:0712/230501.596817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230501.599526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230501.840368:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230501.981637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6d6c4b629c8, 0x1b3608ccd1e0
[1:1:0712/230501.981898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230501.982298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 618
[1:1:0712/230501.982518:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f715fd59070 0x1b36091c71e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 434
[1:1:0712/230502.055514:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x6d6c4b629c8, 0x1b3608ccd1e0
[1:1:0712/230502.055776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230502.056186:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 620
[1:1:0712/230502.056412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7f715fd59070 0x1b360a1d1760 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 434
[1:1:0712/230502.072628:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230504.829085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230504.829834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/230504.830059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230504.908568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 530 0x7f7161c812e0 0x1b360a149c60 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230504.909659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /**
 * Created by ������ on 2016/8/9.
 */
HC.W.searchModuleUrls = [
    {
        c
[1:1:0712/230504.909846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230504.910768:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230504.952804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531 0x7f7161c812e0 0x1b36092e48e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230504.953970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , webpackJsonp([11],{96:function(e,o){e.exports=function(){var e="ignoreIELowVersionPrompt",o=HC.util.
[1:1:0712/230504.954185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.082421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 533 0x7f7161c812e0 0x1b360a1de5e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.085590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*! 2019-04-23 05:04:49 */

var hcflowconfig={dsp:100,exp:100,performance:30},sideToolConfig={_defau
[1:1:0712/230505.085861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.091036:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.121285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 534 0x7f7161c812e0 0x1b36093b8260 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.122725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*! 姜艳云 2018-03-21 */

HC.HUB.addCss("//style.org.hc360.com/css/my/style/regist/loginAlert2018
[1:1:0712/230505.122954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.134710:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.221839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 536 0x7f7161c812e0 0x1b36093b7f60 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.226284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*! 2019-04-12 02:04:42 */

!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):
[1:1:0712/230505.226504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.233818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.273208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537 0x7f7161c812e0 0x1b360a1dd460 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.276688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , webpackJsonp([6],{59:function(t,e,o){(function(e){t.exports=e.OwlCarousel=o(60)}).call(e,function(){
[1:1:0712/230505.276892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.797198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230505.797880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 667
[1:1:0712/230505.798125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f715fd59070 0x1b360939e9e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 537 0x7f7161c812e0 0x1b360a1dd460 
[1:1:0712/230505.861100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539 0x7f7161c812e0 0x1b36094148e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.861695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896207({"code":-1,"openId":"","nickname":"","headImgUrl":""})
[1:1:0712/230505.861810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.862256:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.888437:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540 0x7f7161c812e0 0x1b36091c73e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230505.891651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (function(q){function w(a){this.mode=r.MODE_8BIT_BYTE;this.data=a}function t(a,d){this.typeNumber=a;
[1:1:0712/230505.891780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230505.894999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
		remove user.10_6e8686ca -> 0
		remove user.11_3e27cd83 -> 0
		remove user.13_f58ba19 -> 0
		remove user.12_be958c79 -> 0
		remove user.14_5fcbe64f -> 0
[1:1:0712/230517.321760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542 0x7f7161c812e0 0x1b36091eeae0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230517.322741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896209({"isQiDian":false,"pageJs":"","qqUrl":"","webImUrl":""})
[1:1:0712/230517.323010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230517.323826:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230517.441317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543 0x7f7161c812e0 0x1b36094182e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230517.446012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , webpackJsonp([33],{136:function(i,e,t){var o,s,n;!function(r){"use strict";s=[t(4)],o=r,n="function"
[1:1:0712/230517.446271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230518.370500:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 2000
[1:1:0712/230518.371027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 693
[1:1:0712/230518.371281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f715fd59070 0x1b360a18d460 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 543 0x7f7161c812e0 0x1b36094182e0 
[1:1:0712/230518.466005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7f7161c812e0 0x1b36091c7be0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230518.466752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , webpackJsonp([1],{45:function(i,t){var e=e||{VER:"0.9.944"};e.bgs_Available=!1,e.bgs_CheckRunned=!1,
[1:1:0712/230518.466863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230518.609446:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547 0x7f7161c812e0 0x1b3609030960 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230518.609990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(a){a.fn.moveXY=function(b){var c=a.extend({},a.fn.moveXY.defaults,b);return this.each(func
[1:1:0712/230518.610095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230518.610743:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230518.654877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 549 0x7f7161c812e0 0x1b3609450ce0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230518.655594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896211(false)
[1:1:0712/230518.655742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230518.656167:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230518.695931:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 550 0x7f7161c812e0 0x1b3609419fe0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230518.704822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (function(){var h={},mt={},c={id:"e1e386be074a459371b2832363c0d7e7",dm:["hc360.com"],js:"tongji.baid
[1:1:0712/230518.705046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230518.746910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd148
[1:1:0712/230518.747136:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230518.747507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 701
[1:1:0712/230518.747701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f715fd59070 0x1b36091d2be0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 550 0x7f7161c812e0 0x1b3609419fe0 
[15304:15304:0712/230523.477933:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://style.org.hc360.cn/js/module/common/logrecordservice.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://style.org.hc360.cn/js/module/shop3.0/dist/common/page.bottom.js (1)
[15304:15304:0712/230523.483006:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://style.org.hc360.cn/js/module/common/logrecordservice.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://style.org.hc360.cn/js/module/shop3.0/dist/common/page.bottom.js (1)
[15304:15304:0712/230523.701080:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[15304:15304:0712/230523.707626:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: UBA_iframe, 4, 4, 
[15304:15304:0712/230523.718193:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://bjklha.b2b.hc360.com/, https://bjklha.b2b.hc360.com/, 4
[15304:15304:0712/230523.718269:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://bjklha.b2b.hc360.com/, https://bjklha.b2b.hc360.com
[15304:15304:0712/230523.796037:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/230523.872772:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[15304:15304:0712/230524.027303:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/230525.458148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7f7161c812e0 0x1b360a1d91e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.459203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , 
[1:1:0712/230525.459481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230525.460089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.519773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 635 0x7f7161c812e0 0x1b360939a8e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.524124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (function(){var h={},mt={},c={id:"c1bfff064e4a03c5b6f2b589e099da36",dm:["b2b.hc360.com"],js:"tongji.
[1:1:0712/230525.524389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230525.542567:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd188
[1:1:0712/230525.542724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230525.542910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 781
[1:1:0712/230525.543020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 781 0x7f715fd59070 0x1b360bcda6e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 635 0x7f7161c812e0 0x1b360939a8e0 
[1:1:0712/230525.788511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7f7161c812e0 0x1b360932aa60 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.789293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , parseIsbuysupershop({"result":"0","info":"1"})
[1:1:0712/230525.789457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230525.790051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.833786:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 641 0x7f7161c812e0 0x1b36091db1e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.834807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , 
[1:1:0712/230525.835049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230525.835680:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.905565:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 609, 7f716269e881
[1:1:0712/230525.939078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"434","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230525.939360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"434","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230525.939724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230525.940282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){v.referrer=l}
[1:1:0712/230525.940471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230526.402821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 620, 7f716269e881
[1:1:0712/230526.436536:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"434","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230526.436878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"434","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230526.437233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230526.437745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){T.abort("timeout")}
[1:1:0712/230526.437986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230527.049929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 667, 7f716269e8db
[1:1:0712/230527.088278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"537 0x7f7161c812e0 0x1b360a1dd460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230527.088682:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"537 0x7f7161c812e0 0x1b360a1dd460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230527.089210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 827
[1:1:0712/230527.089460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 827 0x7f715fd59070 0x1b36091b82e0 , 5:3_https://bjklha.b2b.hc360.com/, 0, , 667 0x7f715fd59070 0x1b360939e9e0 
[1:1:0712/230527.089797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230527.090468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){t.next(!0)}
[1:1:0712/230527.090694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230527.110919:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230527.111215:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 800
[1:1:0712/230527.111652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 828
[1:1:0712/230527.111899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7f715fd59070 0x1b360b9e04e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 667 0x7f715fd59070 0x1b360939e9e0 
[1:1:0712/230527.181854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230527.182376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 829
[1:1:0712/230527.182620:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7f715fd59070 0x1b36090a1260 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 667 0x7f715fd59070 0x1b360939e9e0 
[1:1:0712/230528.279901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/230528.280148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230529.541437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 701, 7f716269e881
[1:1:0712/230529.587259:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"550 0x7f7161c812e0 0x1b3609419fe0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230529.587661:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"550 0x7f7161c812e0 0x1b3609419fe0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230529.588129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230529.588842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230529.589064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230529.590049:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230529.590249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230529.590671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 844
[1:1:0712/230529.590925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 844 0x7f715fd59070 0x1b36091e3d60 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 701 0x7f715fd59070 0x1b36091d2be0 
[1:1:0712/230529.592974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 693, 7f716269e8db
[1:1:0712/230529.638760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"543 0x7f7161c812e0 0x1b36094182e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230529.639223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"543 0x7f7161c812e0 0x1b36094182e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230529.639816:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 846
[1:1:0712/230529.640079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 846 0x7f715fd59070 0x1b360f2d08e0 , 5:3_https://bjklha.b2b.hc360.com/, 0, , 693 0x7f715fd59070 0x1b360a18d460 
[1:1:0712/230529.640412:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230529.641098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , r, (){return e.apply(t||this,n.concat(le.call(arguments)))}
[1:1:0712/230529.641328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230530.615229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230530.615399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 500
[1:1:0712/230530.615572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 848
[1:1:0712/230530.615680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 848 0x7f715fd59070 0x1b360967e1e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 693 0x7f715fd59070 0x1b360a18d460 
[1:1:0712/230531.512967:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 764 0x7f7161c812e0 0x1b360f078260 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.513759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896216({})
[1:1:0712/230531.513943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[15304:15304:0712/230531.519175:INFO:CONSOLE(1)] "Uncaught TypeError: jQuery191007277382254981091_1562997896216 is not a function", source: https://wsdetail.b2b.hc360.com/checkVerified?callback=jQuery191007277382254981091_1562997896216&providerid=100001927568&is3y=0&_=1562997896217 (1)
[1:1:0712/230531.546463:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 765 0x7f7161c812e0 0x1b360902fde0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.547402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , webpackJsonp([34],{148:function(e,a){var i={pageType:"supplydetailself",id:""},t={init:function(e){f
[1:1:0712/230531.547519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230531.609876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 768 0x7f7161c812e0 0x1b360a1dc660 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.610707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /**
 * Created by HC360 on 2016/2/25.
 */
HC.W.topnavUrls = [
    {
        css: '//style.org.h
[1:1:0712/230531.610872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230531.611351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.651293:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 769 0x7f7161c812e0 0x1b360934bc60 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.652116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (function(e){e.fn.btntimer=function(t){var n=e.extend({time:"60",className:"",prefix:"",suffix:"reSe
[1:1:0712/230531.652253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230531.652665:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.746921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 772 0x7f7161c812e0 0x1b360bc388e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.747729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/230531.747840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230531.749535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.787115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 773 0x7f7161c812e0 0x1b3609419160 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.787733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896209({"appPhone":"","companyName":"北京昆仑海岸传感技�
[1:1:0712/230531.787843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230531.788364:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.857997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 776 0x7f7161c812e0 0x1b360a1cc860 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230531.860595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(t){function e(r){if(n[r])return n[r].exports;var i=n[r]={exports:{},id:r,loaded:!1};return
[1:1:0712/230531.860720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230532.100688:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230532.545663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x6d6c4b629c8, 0x1b3608ccd490
[1:1:0712/230532.545943:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 1000
[1:1:0712/230532.546357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 892
[1:1:0712/230532.546611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f715fd59070 0x1b360f2ad060 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 776 0x7f7161c812e0 0x1b360a1cc860 
[1:1:0712/230533.139422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 781, 7f716269e881
[1:1:0712/230533.177849:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"635 0x7f7161c812e0 0x1b360939a8e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230533.178171:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"635 0x7f7161c812e0 0x1b360939a8e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230533.178537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230533.179135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230533.179310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230533.180083:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230533.180239:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230533.180564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 900
[1:1:0712/230533.180750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7f715fd59070 0x1b360f2984e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 781 0x7f715fd59070 0x1b360bcda6e0 
[1:1:0712/230533.425481:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230533.426222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/230533.426448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230533.723305:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230533.724090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/230533.724269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230534.227722:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 828, 7f716269e881
[1:1:0712/230534.247220:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"667 0x7f715fd59070 0x1b360939e9e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230534.247437:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"667 0x7f715fd59070 0x1b360939e9e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230534.247674:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230534.247970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){s.isCss3Finish=!0}
[1:1:0712/230534.248072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230534.262672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , document.readyState
[1:1:0712/230534.262843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230534.997879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 844, 7f716269e881
[1:1:0712/230535.037707:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"701 0x7f715fd59070 0x1b36091d2be0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230535.038038:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"701 0x7f715fd59070 0x1b36091d2be0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230535.038419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230535.038995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230535.039199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230535.039993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230535.040194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230535.040639:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 922
[1:1:0712/230535.040884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f715fd59070 0x1b360964b460 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 844 0x7f715fd59070 0x1b36091e3d60 
[1:1:0712/230535.092893:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 829, 7f716269e8db
[1:1:0712/230535.132645:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"667 0x7f715fd59070 0x1b360939e9e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230535.132956:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"667 0x7f715fd59070 0x1b360939e9e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230535.133409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 932
[1:1:0712/230535.133669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7f715fd59070 0x1b360f082e60 , 5:3_https://bjklha.b2b.hc360.com/, 0, , 829 0x7f715fd59070 0x1b36090a1260 
[1:1:0712/230535.133952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230535.134473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){t.next(!0)}
[1:1:0712/230535.134703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230535.147404:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230535.147641:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 800
[1:1:0712/230535.147998:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 933
[1:1:0712/230535.148193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7f715fd59070 0x1b360f300ae0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 829 0x7f715fd59070 0x1b36090a1260 
[1:1:0712/230535.201255:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230535.201787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 935
[1:1:0712/230535.202030:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7f715fd59070 0x1b360f77a560 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 829 0x7f715fd59070 0x1b36090a1260 
[1:1:0712/230535.337351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230535.338123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/230535.338305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230535.528504:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 848, 7f716269e881
[1:1:0712/230535.561479:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"693 0x7f715fd59070 0x1b360a18d460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230535.561892:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"693 0x7f715fd59070 0x1b360a18d460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230535.562357:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230535.563131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){s.disableTransition(),t.call()}
[1:1:0712/230535.563377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230535.740232:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 2000
[1:1:0712/230535.740759:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 966
[1:1:0712/230535.741005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7f715fd59070 0x1b36097b89e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 848 0x7f715fd59070 0x1b360967e1e0 
[1:1:0712/230536.926382:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230536.926798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/230536.926919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230536.930376:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 900, 7f716269e881
[1:1:0712/230536.945246:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"781 0x7f715fd59070 0x1b360bcda6e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230536.945435:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"781 0x7f715fd59070 0x1b360bcda6e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230536.945634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230536.945944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230536.946055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230536.946410:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230536.946507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230536.946681:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 997
[1:1:0712/230536.946786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 997 0x7f715fd59070 0x1b360fc337e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 900 0x7f715fd59070 0x1b360f2984e0 
[1:1:0712/230537.103233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 892, 7f716269e881
[1:1:0712/230537.154858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"776 0x7f7161c812e0 0x1b360a1cc860 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230537.155187:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"776 0x7f7161c812e0 0x1b360a1cc860 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230537.155540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230537.156050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){t.registerDOMObserver()}
[1:1:0712/230537.156263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230537.800003:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230537.800489:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230540.051802:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230540.052087:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230540.052516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1006
[1:1:0712/230540.052771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1006 0x7f715fd59070 0x1b36109a1460 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 892 0x7f715fd59070 0x1b360f2ad060 
[1:1:0712/230540.126185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , document.readyState
[1:1:0712/230540.126413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230540.359128:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230540.359813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , e.onreadystatechange, (){4===e.readyState&&(200===e.status?t(e):r(e))}
[1:1:0712/230540.359990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230540.360694:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230540.933484:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230540.934168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , y.handle, (e){return typeof pe===Z||e&&pe.event.triggered===e.type?a:pe.event.dispatch.apply(d.elem,arguments)
[1:1:0712/230540.934365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230541.262912:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x6d6c4b629c8, 0x1b3608ccd220
[1:1:0712/230541.263078:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 50
[1:1:0712/230541.263255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1022
[1:1:0712/230541.263361:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7f715fd59070 0x1b36109a6ce0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 920 0x7f716f06a960 0x1b360f350740 0x1b360f350750 
[1:1:0712/230541.263660:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230541.264160:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x6d6c4b629c8, 0x1b3608ccd1f0
[1:1:0712/230541.264257:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 500
[1:1:0712/230541.264407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1023
[1:1:0712/230541.264534:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f715fd59070 0x1b36107914e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 920 0x7f716f06a960 0x1b360f350740 0x1b360f350750 
[1:1:0712/230541.854704:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 922, 7f716269e881
[1:1:0712/230541.881376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"844 0x7f715fd59070 0x1b36091e3d60 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230541.881717:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"844 0x7f715fd59070 0x1b36091e3d60 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230541.882105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230541.882715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230541.882892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230541.883558:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230541.883745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230541.884083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1031
[1:1:0712/230541.884271:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1031 0x7f715fd59070 0x1b3610859ee0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 922 0x7f715fd59070 0x1b360964b460 
[1:1:0712/230543.271593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 933, 7f716269e881
[1:1:0712/230543.315469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"829 0x7f715fd59070 0x1b36090a1260 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230543.315772:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"829 0x7f715fd59070 0x1b36090a1260 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230543.316134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230543.316648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){s.isCss3Finish=!0}
[1:1:0712/230543.316820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230543.422649:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 976 0x7f7161c812e0 0x1b360fc2a5e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230543.423239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896216({"code":-1,"openId":"","nickname":"","headImgUrl":""})
[1:1:0712/230543.423349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230543.423688:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
		remove user.12_51b930d2 -> 0
		remove user.13_4d4faa02 -> 0
		remove user.14_a4c58ebe -> 0
[1:1:0712/230543.784492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd4b0
[1:1:0712/230543.784653:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230543.784824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1047
[1:1:0712/230543.784933:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7f715fd59070 0x1b360f2edbe0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 976 0x7f7161c812e0 0x1b360fc2a5e0 
[1:1:0712/230543.809150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 977 0x7f7161c812e0 0x1b360f33d260 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230543.809703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , function checkMpRegUser(d,c){var a=/^0?1(3|5|8)\d{9}$/,b=jQuery("#ajaxLock");"0"!=b.val()&&"undefine
[1:1:0712/230543.809811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230543.810104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230543.936711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230543.937453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/230543.937706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.036382:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 981 0x7f7161c812e0 0x1b360f78b3e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.037279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896209({"code":-1,"openId":"","nickname":"","headImgUrl":""})
[1:1:0712/230544.037503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.038196:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.137854:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd330
[1:1:0712/230544.138013:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230544.138185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1065
[1:1:0712/230544.138301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7f715fd59070 0x1b360964ba60 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 981 0x7f7161c812e0 0x1b360f78b3e0 
[1:1:0712/230544.154972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 982 0x7f7161c812e0 0x1b3610218860 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.155943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*!
 * jQuery Cookie Plugin v1.4.1
 * //github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus
[1:1:0712/230544.156055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.156922:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.420497:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 984 0x7f7161c812e0 0x1b360fc497e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.421823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (function(e){"function"!=typeof e.cookie&&e.getScript("//style.org.hc360.cn/js/build/source/widgets/
[1:1:0712/230544.422008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.424172:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.611635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f7161c812e0 0x1b36093ae4e0 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.613467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/230544.613664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.617975:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.730312:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 988 0x7f7161c812e0 0x1b360fc49560 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.730954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/230544.731074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.732294:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.969733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 997, 7f716269e881
[1:1:0712/230544.982470:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"900 0x7f715fd59070 0x1b360f2984e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230544.982627:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"900 0x7f715fd59070 0x1b360f2984e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230544.982805:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230544.983112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230544.983215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230544.983587:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230544.983702:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230544.983861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1083
[1:1:0712/230544.983963:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7f715fd59070 0x1b36097b8e60 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 997 0x7f715fd59070 0x1b360fc337e0 
[1:1:0712/230544.999531:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 966, 7f716269e8db
[1:1:0712/230545.021963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"848 0x7f715fd59070 0x1b360967e1e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.022207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"848 0x7f715fd59070 0x1b360967e1e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.022529:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 1084
[1:1:0712/230545.022710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f715fd59070 0x1b360f33d060 , 5:3_https://bjklha.b2b.hc360.com/, 0, , 966 0x7f715fd59070 0x1b36097b89e0 
[1:1:0712/230545.022969:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230545.023385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , r, (){return e.apply(t||this,n.concat(le.call(arguments)))}
[1:1:0712/230545.023532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230545.156899:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230545.157054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 500
[1:1:0712/230545.157223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1086
[1:1:0712/230545.157332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7f715fd59070 0x1b3609347fe0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 966 0x7f715fd59070 0x1b36097b89e0 
[1:1:0712/230545.174082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , document.readyState
[1:1:0712/230545.174235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230545.190851:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 935, 7f716269e8db
[1:1:0712/230545.205927:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"829 0x7f715fd59070 0x1b36090a1260 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.206107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"829 0x7f715fd59070 0x1b36090a1260 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.206344:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 1090
[1:1:0712/230545.206458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1090 0x7f715fd59070 0x1b360fc2a5e0 , 5:3_https://bjklha.b2b.hc360.com/, 0, , 935 0x7f715fd59070 0x1b360f77a560 
[1:1:0712/230545.206636:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230545.206942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){t.next(!0)}
[1:1:0712/230545.207045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230545.211321:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230545.211431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 800
[1:1:0712/230545.211592:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1091
[1:1:0712/230545.211714:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1091 0x7f715fd59070 0x1b36093a9760 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 935 0x7f715fd59070 0x1b360f77a560 
[1:1:0712/230545.230117:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 3000
[1:1:0712/230545.230337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 1092
[1:1:0712/230545.230456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1092 0x7f715fd59070 0x1b3609388a60 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 935 0x7f715fd59070 0x1b360f77a560 
[1:1:0712/230545.231001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1006, 7f716269e881
[1:1:0712/230545.247169:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"892 0x7f715fd59070 0x1b360f2ad060 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.247335:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"892 0x7f715fd59070 0x1b360f2ad060 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.247552:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230545.247862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){i.mirror.initialize(o)}
[1:1:0712/230545.247973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230545.248538:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230545.248638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230545.248854:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1093
[1:1:0712/230545.248962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7f715fd59070 0x1b36093b80e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1006 0x7f715fd59070 0x1b36109a1460 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[15304:15304:0712/230545.730977:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/230545.751001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1022, 7f716269e881
[1:1:0712/230545.768450:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"920 0x7f716f06a960 0x1b360f350740 0x1b360f350750 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.768635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"920 0x7f716f06a960 0x1b360f350740 0x1b360f350750 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230545.768871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230545.769181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){e.windowWidth=i(window).width(),e.checkResponsive(),e.unslicked||e.setPosition()}
[1:1:0712/230545.769283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230546.099941:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1023, 7f716269e881
[1:1:0712/230546.151281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"920 0x7f716f06a960 0x1b360f350740 0x1b360f350750 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230546.151684:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"920 0x7f716f06a960 0x1b360f350740 0x1b360f350750 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230546.152089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230546.152432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){t.apply(n,i)}
[1:1:0712/230546.152543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230546.153250:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230546.153357:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230546.153535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1120
[1:1:0712/230546.153650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f715fd59070 0x1b360f2d0560 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1023 0x7f715fd59070 0x1b36107914e0 
[1:1:0712/230546.155272:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1031, 7f716269e881
[1:1:0712/230546.205939:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"922 0x7f715fd59070 0x1b360964b460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230546.206275:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"922 0x7f715fd59070 0x1b360964b460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230546.206658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230546.207239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230546.207436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230546.208306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230546.208468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230546.208804:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1124
[1:1:0712/230546.209036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7f715fd59070 0x1b360a1d4ce0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1031 0x7f715fd59070 0x1b3610859ee0 
[1:1:0712/230546.855981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1047, 7f716269e881
[1:1:0712/230546.892243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"976 0x7f7161c812e0 0x1b360fc2a5e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230546.892566:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"976 0x7f7161c812e0 0x1b360fc2a5e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230546.892914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230546.893474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){e.mirror.applyChanged(i,o,a,s)}
[1:1:0712/230546.893652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230546.894848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230546.895005:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230546.895357:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1163
[1:1:0712/230546.895555:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1163 0x7f715fd59070 0x1b360f7be960 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1047 0x7f715fd59070 0x1b360f2edbe0 
[1:1:0712/230547.805511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1064 0x7f7161c812e0 0x1b360f77a360 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230547.806715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , jQuery191007277382254981091_1562997896216({"isQiDian":false,"pageJs":"","qqUrl":"","webImUrl":""})
[1:1:0712/230547.806980:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230547.807875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230547.925389:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1065, 7f716269e881
[1:1:0712/230547.942588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"981 0x7f7161c812e0 0x1b360f78b3e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230547.942758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"981 0x7f7161c812e0 0x1b360f78b3e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230547.942975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230547.943331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){e.mirror.applyChanged(i,o,a,s)}
[1:1:0712/230547.943444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230547.943814:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230547.943912:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230547.944082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1224
[1:1:0712/230547.944194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1224 0x7f715fd59070 0x1b36110ec460 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1065 0x7f715fd59070 0x1b360964ba60 
[1:1:0712/230548.337454:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230548.338183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , t, (n,o){var s,u,c,d;try{if(t&&(o||4===l.readyState))if(t=a,i&&(l.onreadystatechange=pe.noop,nn&&delete
[1:1:0712/230548.338394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230548.339565:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230548.342080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230548.342745:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xc2eb898d6f8
[1:1:0712/230548.870952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1083, 7f716269e881
[1:1:0712/230548.899616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"997 0x7f715fd59070 0x1b360fc337e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230548.899810:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"997 0x7f715fd59070 0x1b360fc337e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230548.900058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230548.900394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230548.900525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230548.900867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230548.900968:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230548.901131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1285
[1:1:0712/230548.901239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1285 0x7f715fd59070 0x1b36108452e0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1083 0x7f715fd59070 0x1b36097b8e60 
[1:1:0712/230548.920663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , document.readyState
[1:1:0712/230548.920812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230548.922106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1093, 7f716269e881
[1:1:0712/230548.942221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"1006 0x7f715fd59070 0x1b36109a1460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230548.942409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"1006 0x7f715fd59070 0x1b36109a1460 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230548.942627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230548.943058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){n(t)}
[1:1:0712/230548.943298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/230549.366015:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1086, 7f716269e881
[1:1:0712/230549.385706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"966 0x7f715fd59070 0x1b36097b89e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230549.385889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"966 0x7f715fd59070 0x1b36097b89e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230549.386158:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230549.386608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){s.disableTransition(),t.call()}
[1:1:0712/230549.386737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230549.447072:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 2000
[1:1:0712/230549.447315:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://bjklha.b2b.hc360.com/, 1310
[1:1:0712/230549.447425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1310 0x7f715fd59070 0x1b3608bc2f60 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1086 0x7f715fd59070 0x1b3609347fe0 
[1:1:0712/230550.190324:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1091, 7f716269e881
[1:1:0712/230550.264640:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"935 0x7f715fd59070 0x1b360f77a560 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230550.264951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"935 0x7f715fd59070 0x1b360f77a560 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230550.265350:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230550.265882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){s.isCss3Finish=!0}
[1:1:0712/230550.266087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230550.372986:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1120, 7f716269e881
[1:1:0712/230550.407925:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"1023 0x7f715fd59070 0x1b36107914e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230550.408225:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"1023 0x7f715fd59070 0x1b36107914e0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230550.408649:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230550.409161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , (){n()}
[1:1:0712/230550.409387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230550.655819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1124, 7f716269e881
[1:1:0712/230550.714205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2ef4c78e2860","ptid":"1031 0x7f715fd59070 0x1b3610859ee0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230550.714544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://bjklha.b2b.hc360.com/","ptid":"1031 0x7f715fd59070 0x1b3610859ee0 ","rf":"5:3_https://bjklha.b2b.hc360.com/"}
[1:1:0712/230550.714934:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bjklha.b2b.hc360.com/"
[1:1:0712/230550.715571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/230550.715771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230550.716460:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x6d6c4b629c8, 0x1b3608ccd150
[1:1:0712/230550.716618:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 100
[1:1:0712/230550.716948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1359
[1:1:0712/230550.717136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1359 0x7f715fd59070 0x1b3611658960 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1124 0x7f715fd59070 0x1b360a1d4ce0 
[1:1:0712/230551.906573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1159 0x7f7161c812e0 0x1b360f2d0160 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230551.908658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*! 2019-04-10 03:04:34 */

function clearAllCookie(){try{var a=document.cookie.match(/[^ =;]+(?=\=)
[1:1:0712/230551.908834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230552.716798:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x6d6c4b629c8, 0x1b3608ccd368
[1:1:0712/230552.716983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bjklha.b2b.hc360.com/", 0
[1:1:0712/230552.717211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://bjklha.b2b.hc360.com/, 1453
[1:1:0712/230552.717322:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7f715fd59070 0x1b36109eafe0 , 5:3_https://bjklha.b2b.hc360.com/, 1, -5:3_https://bjklha.b2b.hc360.com/, 1159 0x7f7161c812e0 0x1b360f2d0160 
[1:1:0712/230552.718452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230552.753605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1160 0x7f7161c812e0 0x1b360f2caa60 , "https://bjklha.b2b.hc360.com/"
[1:1:0712/230552.755355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://bjklha.b2b.hc360.com/, 2ef4c78e2860, , , /*! 2019-04-17 05:04:31 */

!function(a,b,c){if(void 0!==c){var d={Cookie:{get:function(a,b){for(var
[1:1:0712/230552.755484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bjklha.b2b.hc360.com/", "bjklha.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/230552.756876:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bjklha.b2b.hc360.com/"
[1:1:0712/230553.461647:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230553.465493:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/230553.465883:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
