[0712/225824.548405:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/225824.548823:INFO:switcher_clone.cc(787)] backtrace rip is 7fcea3772891
[0712/225825.447750:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/225825.448176:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f33b03891
[1:1:0712/225825.452380:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/225825.452545:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/225825.457123:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[14640:14640:0712/225826.334613:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/878b1dfd-9f6f-4d38-9ec4-63791fc9db6f
[14640:14640:0712/225826.740176:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[14640:14671:0712/225826.740918:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/225826.741154:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/225826.741431:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/225826.742140:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/225826.742336:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/225826.745738:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1b859df7, 1
[1:1:0712/225826.745946:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xa02f8e5, 0
[1:1:0712/225826.746036:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3281114d, 3
[1:1:0712/225826.746124:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x338acdf7, 2
[1:1:0712/225826.746229:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe5fffffff8020a fffffff7ffffff9dffffff851b fffffff7ffffffcdffffff8a33 4d11ffffff8132 , 10104, 4
[1:1:0712/225826.746927:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14640:14671:0712/225826.747056:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��
����͊3M�2��3
[14640:14671:0712/225826.747107:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��
����͊3M�28���3
[14640:14671:0712/225826.747314:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[14640:14671:0712/225826.747380:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14685, 4, e5f8020a f79d851b f7cd8a33 4d118132 
[1:1:0712/225826.747694:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f31d3e0a0, 3
[1:1:0712/225826.747804:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f31ec9080, 2
[1:1:0712/225826.747885:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f1bb8cd20, -2
[1:1:0712/225826.759954:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/225826.760811:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 338acdf7
[1:1:0712/225826.761726:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 338acdf7
[1:1:0712/225826.763188:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 338acdf7
[1:1:0712/225826.764627:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.764802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.764974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.765147:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.765766:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 338acdf7
[1:1:0712/225826.766071:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f33b037ba
[1:1:0712/225826.766196:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f33afadef, 7f7f33b0377a, 7f7f33b050cf
[1:1:0712/225826.771497:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 338acdf7
[1:1:0712/225826.771848:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 338acdf7
[1:1:0712/225826.772521:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 338acdf7
[1:1:0712/225826.774588:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.774832:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.775036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.775216:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 338acdf7
[1:1:0712/225826.776450:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 338acdf7
[1:1:0712/225826.776849:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f33b037ba
[1:1:0712/225826.776989:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f33afadef, 7f7f33b0377a, 7f7f33b050cf
[1:1:0712/225826.784843:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/225826.785381:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/225826.785532:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff10f09458, 0x7fff10f093d8)
[0712/225826.789124:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/225826.789408:INFO:switcher_clone.cc(787)] backtrace rip is 7fac97989891
[1:1:0712/225826.802050:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/225826.808151:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[14675:14675:0712/225827.006925:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14675
[14699:14699:0712/225827.007262:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14699
[14640:14640:0712/225827.300144:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14640:14640:0712/225827.302880:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14640:14651:0712/225827.322706:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[14640:14651:0712/225827.322811:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[14640:14640:0712/225827.323003:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[14640:14640:0712/225827.323101:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[14640:14640:0712/225827.323311:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,14685, 4
[1:7:0712/225827.327669:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[14640:14662:0712/225827.396563:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/225827.403356:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2c41bead8220
[1:1:0712/225827.403650:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/225827.720749:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/225829.180283:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225829.183411:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[14640:14640:0712/225829.363892:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[14640:14640:0712/225829.363999:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/225830.290655:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/225830.396210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/225830.396464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/225830.413373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/225830.413655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/225830.603424:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/225830.603684:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225830.868917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225830.876927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/225830.877167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/225830.913536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225830.923971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/225830.924207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/225830.929508:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/225830.932844:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c41bead6e20
[1:1:0712/225830.933053:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[14640:14640:0712/225830.942156:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[14640:14640:0712/225830.963067:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[14640:14640:0712/225831.010271:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[14640:14640:0712/225831.010495:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[14640:14640:0712/225831.031397:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/225831.045310:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225831.879421:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f7f1d7672e0 0x2c41be9cd160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225831.880765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/225831.880982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/225831.882553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[14640:14640:0712/225831.930427:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/225831.931458:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2c41bead7820
[1:1:0712/225831.931726:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[14640:14640:0712/225831.944777:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/225831.950400:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/225831.952847:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[14640:14640:0712/225831.960953:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[14640:14640:0712/225831.971388:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14640:14640:0712/225831.972383:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14640:14651:0712/225831.979000:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[14640:14651:0712/225831.979081:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[14640:14640:0712/225831.979346:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[14640:14640:0712/225831.979442:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[14640:14640:0712/225831.979612:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,14685, 4
[1:7:0712/225831.981668:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/225832.447588:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/225832.802293:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f7f1d7672e0 0x2c41bec999e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225832.802868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/225832.802977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/225832.803326:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225832.851286:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[14640:14640:0712/225832.872564:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[14640:14640:0712/225832.872697:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/225833.095184:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/225833.822928:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/225833.823148:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225834.222815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225834.224422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/225834.224576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225834.226812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225834.302461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/225834.302878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 173193e01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/225834.302987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[14640:14640:0712/225834.412955:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[14640:14671:0712/225834.413733:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/225834.414110:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/225834.414502:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/225834.415083:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/225834.415257:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/225834.419196:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e0bc043, 1
[1:1:0712/225834.420438:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3ad73678, 0
[1:1:0712/225834.420938:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2db8d13, 3
[1:1:0712/225834.421324:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x20dc69c2, 2
[1:1:0712/225834.421739:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7836ffffffd73a 43ffffffc00b1e ffffffc269ffffffdc20 13ffffff8dffffffdb02 , 10104, 5
[1:1:0712/225834.424074:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14640:14671:0712/225834.424613:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGx6�:C��i� ����3
[14640:14671:0712/225834.424843:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is x6�:C��i� �����3
[1:1:0712/225834.425083:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f31d3e0a0, 3
[14640:14671:0712/225834.425388:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14736, 5, 7836d73a 43c00b1e c269dc20 138ddb02 
[1:1:0712/225834.425489:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f31ec9080, 2
[1:1:0712/225834.425887:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7f1bb8cd20, -2
[1:1:0712/225834.439000:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225834.441895:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/225834.442268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/225834.442571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225834.528705:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/225834.529108:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20dc69c2
[1:1:0712/225834.529425:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20dc69c2
[1:1:0712/225834.530084:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20dc69c2
[1:1:0712/225834.531614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.531840:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.532036:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.532218:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.532929:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20dc69c2
[1:1:0712/225834.533226:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f33b037ba
[1:1:0712/225834.533362:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f33afadef, 7f7f33b0377a, 7f7f33b050cf
[1:1:0712/225834.540142:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20dc69c2
[1:1:0712/225834.540533:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20dc69c2
[1:1:0712/225834.541337:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20dc69c2
[1:1:0712/225834.543462:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.543690:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.543912:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.544111:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20dc69c2
[1:1:0712/225834.545414:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20dc69c2
[1:1:0712/225834.545815:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7f33b037ba
[1:1:0712/225834.545957:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7f33afadef, 7f7f33b0377a, 7f7f33b050cf
[1:1:0712/225834.554496:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/225834.555057:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/225834.555217:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff10f09458, 0x7fff10f093d8)
[1:1:0712/225834.565586:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/225834.569239:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225834.570067:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/225834.570132:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/225834.570346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/225834.570617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225834.771898:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2c41beaa7220
[1:1:0712/225834.772161:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/225835.212532:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/225835.385940:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[14640:14640:0712/225835.507868:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14640:14640:0712/225835.514232:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/225835.546206:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://qq.com/"
[14640:14651:0712/225835.554642:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[14640:14651:0712/225835.554758:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[14640:14640:0712/225835.557839:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://zjndgl.b2b.hc360.com/
[14640:14640:0712/225835.557921:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://zjndgl.b2b.hc360.com/, https://zjndgl.b2b.hc360.com/, 1
[14640:14640:0712/225835.558055:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://zjndgl.b2b.hc360.com/, HTTP/1.1 200 Date: Sat, 13 Jul 2019 05:58:35 GMT Server: nginx Content-Type: text/html;charset=UTF-8 Vary: Accept-Encoding X-Application-Context: msdhomes:80 Content-Language: zh-CN,en-us Content-Encoding: gzip Keep-Alive: timeout=15, max=10000 Connection: Keep-Alive Transfer-Encoding: chunked  ,14736, 5
[1:7:0712/225835.563827:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/225835.581987:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://zjndgl.b2b.hc360.com/
[1:1:0712/225835.631965:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://ikea.com/"
[14640:14640:0712/225835.682265:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://zjndgl.b2b.hc360.com/, https://zjndgl.b2b.hc360.com/, 1
[14640:14640:0712/225835.682399:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://zjndgl.b2b.hc360.com/, https://zjndgl.b2b.hc360.com
[1:1:0712/225835.687515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/225835.733836:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/225835.784203:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/225835.842260:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/225835.862169:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/225835.862445:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225835.877544:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.1688.com/"
[1:1:0712/225836.000256:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.aliexpress.com/"
[1:1:0712/225836.034513:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/225836.076997:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.alibaba.com/"
[1:1:0712/225836.178614:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225836.179578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/225836.179867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225836.327929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225836.328857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/225836.329158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225836.445798:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225836.446710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/225836.446975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225836.515046:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225836.515981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/225836.516249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225836.580841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225836.581758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/225836.582028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225836.611451:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f7f1b83f070 0x2c41becaaf60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225836.619731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(e){function t(o){if(n[o])return n[o].exports;var i=n[o]={exports:{},id:o,loaded:!1};return
[1:1:0712/225836.619977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225836.628354:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225836.718523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f7f1b83f070 0x2c41becaaf60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225836.772067:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225836.772971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/225836.773252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225837.043559:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.32609, 2039, 1
[1:1:0712/225837.043827:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/225837.090716:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225837.091602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/225837.091870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/225837.180229:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/225837.181178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 173193f2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/225837.181450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/225837.709138:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/225837.709379:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225837.949198:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225838.266559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f7f1bba7bd0 0x2c41bedd2a58 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225838.280066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(e){function t(n){if(r[n])return r[n].exports;var i=r[n]={exports:{},id:n,loaded:!1};return
[1:1:0712/225838.280328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225838.290196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 298 0x7f7f1bba7bd0 0x2c41bedd2a58 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225841.395703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x88cdf9629c8, 0x2c41be9019b0
[1:1:0712/225841.395956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 300
[1:1:0712/225841.396394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 441
[1:1:0712/225841.396658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 441 0x7f7f1b83f070 0x2c41befd2fe0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 298 0x7f7f1bba7bd0 0x2c41bedd2a58 
[1:1:0712/225842.482720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x88cdf9629c8, 0x2c41be9019b0
[1:1:0712/225842.482937:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225842.483137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 471
[1:1:0712/225842.483244:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f7f1b83f070 0x2c41be7d1860 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 298 0x7f7f1bba7bd0 0x2c41bedd2a58 
[1:1:0712/225842.486152:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 4.20303, 0, 0
[1:1:0712/225842.486264:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/225845.060013:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225845.060465:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225845.060840:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225845.061272:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225845.061672:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225846.381123:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/225846.381392:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225846.384677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7f7f1b83f070 0x2c41befd2660 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225846.386314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(e){function o(n){if(t[n])return t[n].exports;var r=t[n]={exports:{},id:n,loaded:!1};return
[1:1:0712/225846.386535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225846.627512:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 441, 7f7f1e184881
[1:1:0712/225846.645682:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"298 0x7f7f1bba7bd0 0x2c41bedd2a58 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225846.646003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"298 0x7f7f1bba7bd0 0x2c41bedd2a58 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225846.646376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225846.646943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){C()}
[1:1:0712/225846.647159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225849.301861:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225849.303882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/225849.304105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.450177:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 630 0x7f7f1d7672e0 0x2c41bedc3860 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.451268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /**
 * Created by ������ on 2016/8/9.
 */
HC.W.searchModuleUrls = [
    {
        c
[1:1:0712/225850.451484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.452294:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.478987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 631 0x7f7f1d7672e0 0x2c41befc72e0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.480811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , webpackJsonp([11],{96:function(e,o){e.exports=function(){var e="ignoreIELowVersionPrompt",o=HC.util.
[1:1:0712/225850.481067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.497566:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 471, 7f7f1e184881
[1:1:0712/225850.528602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"298 0x7f7f1bba7bd0 0x2c41bedd2a58 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225850.528974:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"298 0x7f7f1bba7bd0 0x2c41bedd2a58 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225850.529406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.529924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){T.abort("timeout")}
[1:1:0712/225850.530140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.565398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 634 0x7f7f1d7672e0 0x2c41befc9ae0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.566548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /*! 姜艳云 2018-03-21 */

HC.HUB.addCss("//style.org.hc360.com/css/my/style/regist/loginAlert2018
[1:1:0712/225850.566780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.578907:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.629499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 635 0x7f7f1d7672e0 0x2c41bed76060 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.632692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /*! 2019-04-23 05:04:49 */

var hcflowconfig={dsp:100,exp:100,performance:30},sideToolConfig={_defau
[1:1:0712/225850.632988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.637804:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.755483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 639 0x7f7f1d7672e0 0x2c41bf1c3d60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.759902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /*! 2019-04-12 02:04:42 */

!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):
[1:1:0712/225850.760138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225850.766455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.817292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 640 0x7f7f1d7672e0 0x2c41bef65660 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225850.822028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , webpackJsonp([6],{59:function(t,e,o){(function(e){t.exports=e.OwlCarousel=o(60)}).call(e,function(){
[1:1:0712/225850.822303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225851.306902:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225851.533433:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225851.533983:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 780
[1:1:0712/225851.534245:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 780 0x7f7f1b83f070 0x2c41bed61de0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 640 0x7f7f1d7672e0 0x2c41bef65660 
[1:1:0712/225851.710334:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 643 0x7f7f1d7672e0 0x2c41bef30fe0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225851.714604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , webpackJsonp([33],{136:function(i,e,t){var o,s,n;!function(r){"use strict";s=[t(4)],o=r,n="function"
[1:1:0712/225851.714875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225852.074210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 644 0x7f7f1d7672e0 0x2c41bed76360 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225852.084339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (function(q){function w(a){this.mode=r.MODE_8BIT_BYTE;this.data=a}function t(a,d){this.typeNumber=a;
[1:1:0712/225852.084581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225852.093398:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
		remove user.10_529d7aca -> 0
		remove user.11_d089dd85 -> 0
		remove user.14_6cb4186 -> 0
		remove user.12_a233bec8 -> 0
		remove user.13_7fdf43bb -> 0
		remove user.11_b6891146 -> 0
[1:1:0712/225902.799828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649 0x7f7f1d7672e0 0x2c41bedc3ee0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225902.800737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520584({"code":200,"openId":"","nickname":"","headImgUrl":""})
[1:1:0712/225902.800969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225902.801884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225902.870377:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 650 0x7f7f1d7672e0 0x2c41befce960 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225902.873089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , webpackJsonp([1],{45:function(i,t){var e=e||{VER:"0.9.944"};e.bgs_Available=!1,e.bgs_CheckRunned=!1,
[1:1:0712/225902.873274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225903.132162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 652 0x7f7f1d7672e0 0x2c41c0197d60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.133251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(a){a.fn.moveXY=function(b){var c=a.extend({},a.fn.moveXY.defaults,b);return this.each(func
[1:1:0712/225903.133371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225903.134104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.146481:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f7f1d7672e0 0x2c41bedca160 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.146889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520586({"isQiDian":true,"pageJs":"<!-- WPA start --><script src=\"
[1:1:0712/225903.147026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225903.147353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.293195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 656 0x7f7f1d7672e0 0x2c41befc75e0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.294008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520588(true)
[1:1:0712/225903.294218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225903.330333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 657 0x7f7f1d7672e0 0x2c41bef2c660 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.331428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520579({"data":"<style>\n.customAdvBox .blank10{clear:both;height:
[1:1:0712/225903.331605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225903.332500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.485566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 659 0x7f7f1d7672e0 0x2c41bef07260 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225903.487353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520581({"data":"<style>\n.customAdvBox .proList6New{width:990px;ma
[1:1:0712/225903.487562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225903.488497:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225904.061067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670, "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225904.072597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /*! 2018-12-06 06:12:29 */

var _hcuba_=_hcuba_||[];!function(){_hcuba_.push(["setAccountId","B00558
[1:1:0712/225904.072829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225904.208663:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/225904.220793:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2c41bf3e2020
[1:1:0712/225904.220972:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/225904.496756:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670, "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225904.575600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x88cdf9629c8, 0x2c41be9019c0
[1:1:0712/225904.575798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 1000
[1:1:0712/225904.576233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 871
[1:1:0712/225904.576419:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7f7f1b83f070 0x2c41c18176e0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 670
[1:1:0712/225904.623189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670, "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225904.630203:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 670, "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225904.649089:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225904.713018:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225905.660426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x88cdf9629c8, 0x2c41be9019e0
[1:1:0712/225905.660620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225905.660945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 881
[1:1:0712/225905.661196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 881 0x7f7f1b83f070 0x2c41c4ba21e0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 670
[1:1:0712/225905.751133:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x88cdf9629c8, 0x2c41be9019e0
[1:1:0712/225905.751274:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225905.751454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 884
[1:1:0712/225905.751559:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f7f1b83f070 0x2c41c4b94e60 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 670
[1:1:0712/225905.763945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225907.570496:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 729 0x7f7f1d7672e0 0x2c41bf005ee0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225907.573630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (function(){var h={},mt={},c={id:"e1e386be074a459371b2832363c0d7e7",dm:["hc360.com"],js:"tongji.baid
[1:1:0712/225907.573817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225907.601944:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x88cdf9629c8, 0x2c41be901948
[1:1:0712/225907.602116:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 100
[1:1:0712/225907.602302:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 918
[1:1:0712/225907.602414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 918 0x7f7f1b83f070 0x2c41c17db8e0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 729 0x7f7f1d7672e0 0x2c41bf005ee0 
[14640:14640:0712/225907.906606:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://style.org.hc360.cn/js/module/common/logrecordservice.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://style.org.hc360.cn/js/module/shop3.0/dist/common/page.bottom.js (1)
[14640:14640:0712/225907.910439:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://style.org.hc360.cn/js/module/common/logrecordservice.min.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://style.org.hc360.cn/js/module/shop3.0/dist/common/page.bottom.js (1)
[14640:14640:0712/225908.005786:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[14640:14640:0712/225908.037076:INFO:CONSOLE(1)] "Uncaught TypeError: jQuery19108390608243175388_1562997520588 is not a function", source: https://order.b2b.hc360.com/brandneworder/checkbuslinks.html?jsoncallback=jQuery19108390608243175388_1562997520588&providerid=100015315725&_=1562997520589 (1)
[14640:14640:0712/225908.059602:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260900103877.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.068799:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260901521319.png'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.077501:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260859599450.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.086624:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260901521319.png'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.089847:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260859453168.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.091231:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260901521319.png'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.093016:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260907266294.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.094375:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260908222914.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.097571:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260909393601.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.106521:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260910183482.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.115373:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260910556562.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.124289:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://zjndgl.b2b.hc360.com/' was loaded over HTTPS, but requested an insecure image 'http://img00.hc360.com/service/201709/201709260911218502.jpg'. This content should also be served over HTTPS.", source: https://zjndgl.b2b.hc360.com/ (0)
[14640:14640:0712/225908.135846:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[14640:14640:0712/225908.143948:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: UBA_iframe, 4, 4, 
[14640:14640:0712/225908.169418:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://zjndgl.b2b.hc360.com/, https://zjndgl.b2b.hc360.com/, 4
[14640:14640:0712/225908.169584:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://zjndgl.b2b.hc360.com/, https://zjndgl.b2b.hc360.com
[3:3:0712/225908.311614:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[14640:14640:0712/225908.424441:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/225909.845200:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 780, 7f7f1e1848db
[14640:14651:0712/225909.856011:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/225909.880850:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"640 0x7f7f1d7672e0 0x2c41bef65660 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225909.881039:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"640 0x7f7f1d7672e0 0x2c41bef65660 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225909.881256:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 994
[1:1:0712/225909.881367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7f7f1b83f070 0x2c41bed976e0 , 5:3_https://zjndgl.b2b.hc360.com/, 0, , 780 0x7f7f1b83f070 0x2c41bed61de0 
[1:1:0712/225909.881522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225909.881837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){t.next(!0)}
[1:1:0712/225909.881941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225909.888429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225909.888546:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 800
[1:1:0712/225909.888753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 995
[1:1:0712/225909.888874:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 995 0x7f7f1b83f070 0x2c41beb27be0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 780 0x7f7f1b83f070 0x2c41bed61de0 
[1:1:0712/225909.916441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225909.916753:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 996
[1:1:0712/225909.916955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 996 0x7f7f1b83f070 0x2c41bed6f460 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 780 0x7f7f1b83f070 0x2c41bed61de0 
[1:1:0712/225912.861479:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 871, 7f7f1e184881
[1:1:0712/225912.904633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"670","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225912.904950:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"670","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225912.905289:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225912.905804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){v.referrer=l}
[1:1:0712/225912.905986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225913.224182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/225913.224419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225913.324476:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 905 0x7f7f1d7672e0 0x2c41c4b74be0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225913.328424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , webpackJsonp([34],{148:function(e,a){var i={pageType:"supplydetailself",id:""},t={init:function(e){f
[1:1:0712/225913.328618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225913.393679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 906 0x7f7f1d7672e0 0x2c41c4b74ae0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225913.394270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /**
 * Created by HC360 on 2016/2/25.
 */
HC.W.topnavUrls = [
    {
        css: '//style.org.h
[1:1:0712/225913.394383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225913.394703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[14640:14651:0712/225913.868355:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/225914.779430:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 918, 7f7f1e184881
[1:1:0712/225914.792662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"729 0x7f7f1d7672e0 0x2c41bf005ee0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225914.792823:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"729 0x7f7f1d7672e0 0x2c41bf005ee0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225914.793050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225914.793521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/225914.793716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225914.794129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225914.794231:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 100
[1:1:0712/225914.794394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1060
[1:1:0712/225914.794499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f7f1b83f070 0x2c41be7d15e0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 918 0x7f7f1b83f070 0x2c41c17db8e0 
[1:1:0712/225915.646816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 881, 7f7f1e184881
[1:1:0712/225915.661415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"670","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225915.661576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"670","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225915.661779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.662076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){T.abort("timeout")}
[1:1:0712/225915.662198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225915.680559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 971 0x7f7f1d7672e0 0x2c41bef2c0e0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.681789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (function(e){e.fn.btntimer=function(t){var n=e.extend({time:"60",className:"",prefix:"",suffix:"reSe
[1:1:0712/225915.681988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225915.682693:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.716888:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 972 0x7f7f1d7672e0 0x2c41c019ab60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.719199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/225915.719401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225915.721817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.749160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 884, 7f7f1e184881
[1:1:0712/225915.764428:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"670","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225915.764586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"670","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225915.764789:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.765059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){T.abort("timeout")}
[1:1:0712/225915.765161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225915.936857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225915.937678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/225915.937884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225916.094135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225916.094811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/225916.094987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225916.189649:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 985 0x7f7f1d7672e0 0x2c41c16bdee0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225916.190574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520586({"code":200,"openId":"","nickname":"","headImgUrl":""})
[1:1:0712/225916.190755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225916.191433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225916.273803:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 986 0x7f7f1d7672e0 0x2c41bebe8de0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225916.297170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (function(){var h={},mt={},c={id:"c1bfff064e4a03c5b6f2b589e099da36",dm:["b2b.hc360.com"],js:"tongji.
[1:1:0712/225916.297404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225916.326861:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x88cdf9629c8, 0x2c41be901988
[1:1:0712/225916.327077:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 100
[1:1:0712/225916.327416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1087
[1:1:0712/225916.327728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7f7f1b83f070 0x2c41c4b94e60 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 986 0x7f7f1d7672e0 0x2c41bebe8de0 
[1:1:0712/225917.885580:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 988 0x7f7f1d7672e0 0x2c41bebe3960 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225917.886084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , 
[1:1:0712/225917.886226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225917.886461:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225917.907078:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 989 0x7f7f1d7672e0 0x2c41bebb96e0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225917.946129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , parseIsbuysupershop({"result":"0","info":"1"})
[1:1:0712/225917.964724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[14640:14640:0712/225918.044937:INFO:CONSOLE(1)] "Uncaught TypeError: parseIsbuysupershop is not a function", source: https://p4papi.hc360.com/p4pinterface/p4ptoshops/isbuysupershop.html?callback=parseIsbuysupershop&providerid=100015315725&_=1562997520592 (1)
[1:1:0712/225918.294714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 999 0x7f7f1d7672e0 0x2c41c4b8a160 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225918.295660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520579({})
[1:1:0712/225918.295885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[14640:14640:0712/225918.301870:INFO:CONSOLE(1)] "Uncaught TypeError: jQuery19108390608243175388_1562997520579 is not a function", source: https://wsdetail.b2b.hc360.com/checkVerified?callback=jQuery19108390608243175388_1562997520579&providerid=100015315725&is3y=0&_=1562997520593 (1)
[1:1:0712/225918.398871:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1000 0x7f7f1d7672e0 0x2c41bf0159e0 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225918.400683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/225918.400865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225918.406949:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225918.850969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 995, 7f7f1e184881
[1:1:0712/225918.866092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"780 0x7f7f1b83f070 0x2c41bed61de0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225918.866265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"780 0x7f7f1b83f070 0x2c41bed61de0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225918.866444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225918.866746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){s.isCss3Finish=!0}
[1:1:0712/225918.866853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225919.712747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1031 0x7f7f1d7672e0 0x2c41bfd8a860 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225919.723424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(t){function e(r){if(n[r])return n[r].exports;var i=n[r]={exports:{},id:r,loaded:!1};return
[1:1:0712/225919.723662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225920.749847:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x88cdf9629c8, 0x2c41be901b90
[1:1:0712/225920.750060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 1000
[1:1:0712/225920.750415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1174
[1:1:0712/225920.750606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f7f1b83f070 0x2c41c1e6a160 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1031 0x7f7f1d7672e0 0x2c41bfd8a860 
[1:1:0712/225921.401574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 996, 7f7f1e1848db
[1:1:0712/225921.417907:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"780 0x7f7f1b83f070 0x2c41bed61de0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225921.418099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"780 0x7f7f1b83f070 0x2c41bed61de0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225921.418305:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 1194
[1:1:0712/225921.418414:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1194 0x7f7f1b83f070 0x2c41c5268fe0 , 5:3_https://zjndgl.b2b.hc360.com/, 0, , 996 0x7f7f1b83f070 0x2c41bed6f460 
[1:1:0712/225921.418739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225921.419121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){t.next(!0)}
[1:1:0712/225921.419227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225921.424070:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225921.424182:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 800
[1:1:0712/225921.424346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1195
[1:1:0712/225921.424450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7f7f1b83f070 0x2c41bed34960 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 996 0x7f7f1b83f070 0x2c41bed6f460 
[1:1:0712/225921.461667:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225921.462064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 1196
[1:1:0712/225921.462255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1196 0x7f7f1b83f070 0x2c41c0195560 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 996 0x7f7f1b83f070 0x2c41bed6f460 
[1:1:0712/225921.497897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , document.readyState
[1:1:0712/225921.498106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225923.021194:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_RESET","https://logrecords.hc360.com/logrecordservice/logrecordtime?callback=jQuery19108390608243175388_1562997520584&pid=C884F2F013A00001D18ABFF012806100&pft%5Bnavigation%5D%5BtoJSON%5D=&pft%5Bnavigation%5D%5BTYPE_NAVIGATE%5D=0&pft%5Bnavigation%5D%5BTYPE_RELOAD%5D=1&pft%5Bnavigation%5D%5BTYPE_BACK_FORWARD%5D=2&pft%5Bnavigation%5D%5BTYPE_RESERVED%5D=255&pft%5Bnavigation%5D%5Btype%5D=0&pft%5Bnavigation%5D%5BredirectCount%5D=0&pft%5Btiming%5D%5BnavigationStart%5D=1562997514786&pft%5Btiming%5D%5BunloadEventStart%5D=0&pft%5Btiming%5D%5BunloadEventEnd%5D=0&pft%5Btiming%5D%5BredirectStart%5D=0&pft%5Btiming%5D%5BredirectEnd%5D=0&pft%5Btiming%5D%5BfetchStart%5D=1562997514815&pft%5Btiming%5D%5BdomainLookupStart%5D=1562997514825&pft%5Btiming%5D%5BdomainLookupEnd%5D=1562997514963&pft%5Btiming%5D%5BconnectStart%5D=1562997514963&pft%5Btiming%5D%5BconnectEnd%5D=1562997515194&pft%5Btiming%5D%5BsecureConnectionStart%5D=1562997514970&pft%5Btiming%5D%5BrequestStart%5D=1562997515220&pft%5Btiming%5D%5BresponseStart%5D=1562997515502&pft%5Btiming%5D%5BresponseEnd%5D=1562997515595&pft%5Btiming%5D%5BdomLoading%5D=1562997515624&pft%5Btiming%5D%5BdomInteractive%5D=1562997544645&pft%5Btiming%5D%5BdomContentLoadedEventStart%5D=1562997544647&pft%5Btiming%5D%5BdomContentLoadedEventEnd%5D=0&pft%5Btiming%5D%5BdomComplete%5D=0&pft%5Btiming%5D%5BloadEventStart%5D=0&pft%5Btiming%5D%5BloadEventEnd%5D=0&_=1562997520594"
[1:1:0712/225923.371589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225923.391554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/225923.416744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225923.645393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1060, 7f7f1e184881
[1:1:0712/225923.715309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"918 0x7f7f1b83f070 0x2c41c17db8e0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225923.715653:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"918 0x7f7f1b83f070 0x2c41c17db8e0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225923.734872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225923.753768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/225923.780989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225923.781786:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225923.781950:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 100
[1:1:0712/225923.782299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1234
[1:1:0712/225923.782510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1234 0x7f7f1b83f070 0x2c41bef327e0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1060 0x7f7f1b83f070 0x2c41be7d15e0 
[14640:14651:0712/225924.756561:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/225925.271752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1085 0x7f7f1d7672e0 0x2c41be6dad60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225925.272994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , jQuery19108390608243175388_1562997520588({"code":200,"openId":"","nickname":"","headImgUrl":""})
[1:1:0712/225925.273339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225925.274131:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225925.778866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x88cdf9629c8, 0x2c41be901a10
[1:1:0712/225925.779138:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 5000
[1:1:0712/225925.779517:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1275
[1:1:0712/225925.779713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1275 0x7f7f1b83f070 0x2c41bef8a560 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1085 0x7f7f1d7672e0 0x2c41be6dad60 
[1:1:0712/225926.927159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1087, 7f7f1e184881
[1:1:0712/225926.965862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"986 0x7f7f1d7672e0 0x2c41bebe8de0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225926.966207:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"986 0x7f7f1d7672e0 0x2c41bebe8de0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225926.966653:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225926.967226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/225926.967433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225926.968240:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225926.968431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 100
[1:1:0712/225926.968851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1324
[1:1:0712/225926.969099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1324 0x7f7f1b83f070 0x2c41c52e9e60 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1087 0x7f7f1b83f070 0x2c41c4b94e60 
[1:1:0712/225928.506006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1159 0x7f7f1d7672e0 0x2c41c4b8ac60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225928.507788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , function checkMpRegUser(d,c){var a=/^0?1(3|5|8)\d{9}$/,b=jQuery("#ajaxLock");"0"!=b.val()&&"undefine
[1:1:0712/225928.508015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225928.508948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[14640:14651:0712/225928.768459:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/225929.328447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , document.readyState
[1:1:0712/225929.328705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225929.691525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1201 0x7f7f1d7672e0 0x2c41bef31660 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225929.692460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /*!
 * jQuery Cookie Plugin v1.4.1
 * //github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus
[1:1:0712/225929.692573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225929.694191:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225929.879815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1202 0x7f7f1d7672e0 0x2c41c527bd60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225929.883484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (function(e){"function"!=typeof e.cookie&&e.getScript("//style.org.hc360.cn/js/build/source/widgets/
[1:1:0712/225929.883702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225929.885046:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225929.886826:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[14640:14640:0712/225929.985016:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/225930.034671:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225930.035136:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/225930.225687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225930.226131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , o.readyState.o.onload, (){n&&n()}
[1:1:0712/225930.226319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225931.061529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225931.062240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , y.handle, (e){return typeof pe===Z||e&&pe.event.triggered===e.type?a:pe.event.dispatch.apply(d.elem,arguments)
[1:1:0712/225931.062415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225931.423056:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1174, 7f7f1e184881
[1:1:0712/225931.468243:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"1031 0x7f7f1d7672e0 0x2c41bfd8a860 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225931.468628:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"1031 0x7f7f1d7672e0 0x2c41bfd8a860 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225931.469071:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225931.469689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){t.registerDOMObserver()}
[1:1:0712/225931.469892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
		remove user.12_27d63f27 -> 0
		remove user.13_5e6fdaf9 -> 0
		remove user.14_7e31ffa -> 0
[1:1:0712/225935.323793:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225935.324030:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 0
[1:1:0712/225935.324405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1432
[1:1:0712/225935.324641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1432 0x7f7f1b83f070 0x2c41ccaaf0e0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1174 0x7f7f1b83f070 0x2c41c1e6a160 
[1:1:0712/225935.348132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1195, 7f7f1e184881
[1:1:0712/225935.379654:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"996 0x7f7f1b83f070 0x2c41bed6f460 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225935.379993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"996 0x7f7f1b83f070 0x2c41bed6f460 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225935.380370:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225935.380920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){s.isCss3Finish=!0}
[1:1:0712/225935.381121:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225935.471342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1222 0x7f7f1d7672e0 0x2c41bf2c2160 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225935.472010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , !function(e){function t(i){if(n[i])return n[i].exports;var o=n[i]={exports:{},id:i,loaded:!1};return
[1:1:0712/225935.472125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225935.473352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225935.564683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1223 0x7f7f1d7672e0 0x2c41bef8ef60 , "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225935.565679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , /*!
 * jQuery Cookie Plugin v1.4.1
 * //github.com/carhartl/jquery-cookie
 *
 * Copyright 2013 Klaus
[1:1:0712/225935.565797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225935.566535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225936.002918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1234, 7f7f1e184881
[1:1:0712/225936.053493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"1060 0x7f7f1b83f070 0x2c41be7d15e0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225936.053698:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"1060 0x7f7f1b83f070 0x2c41be7d15e0 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225936.053939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225936.054310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/225936.054443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225936.054851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225936.054951:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 100
[1:1:0712/225936.055159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1479
[1:1:0712/225936.055287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1479 0x7f7f1b83f070 0x2c41bf2c2ee0 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1234 0x7f7f1b83f070 0x2c41bef327e0 
[1:1:0712/225936.517304:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 1196, 7f7f1e1848db
[1:1:0712/225936.577899:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"18daf1e02860","ptid":"996 0x7f7f1b83f070 0x2c41bed6f460 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225936.578102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zjndgl.b2b.hc360.com/","ptid":"996 0x7f7f1b83f070 0x2c41bed6f460 ","rf":"5:3_https://zjndgl.b2b.hc360.com/"}
[1:1:0712/225936.578394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 1506
[1:1:0712/225936.578512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1506 0x7f7f1b83f070 0x2c41c59321e0 , 5:3_https://zjndgl.b2b.hc360.com/, 0, , 1196 0x7f7f1b83f070 0x2c41c0195560 
[1:1:0712/225936.578708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zjndgl.b2b.hc360.com/"
[1:1:0712/225936.579031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zjndgl.b2b.hc360.com/, 18daf1e02860, , , (){t.next(!0)}
[1:1:0712/225936.579158:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zjndgl.b2b.hc360.com/", "zjndgl.b2b.hc360.com", 3, 1, , , 0
[1:1:0712/225936.583819:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x88cdf9629c8, 0x2c41be901950
[1:1:0712/225936.583936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 800
[1:1:0712/225936.584123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zjndgl.b2b.hc360.com/, 1507
[1:1:0712/225936.584233:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1507 0x7f7f1b83f070 0x2c41cc7f3760 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1196 0x7f7f1b83f070 0x2c41c0195560 
[1:1:0712/225936.618770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zjndgl.b2b.hc360.com/", 3000
[1:1:0712/225936.619020:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://zjndgl.b2b.hc360.com/, 1509
[1:1:0712/225936.619138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1509 0x7f7f1b83f070 0x2c41cca69160 , 5:3_https://zjndgl.b2b.hc360.com/, 1, -5:3_https://zjndgl.b2b.hc360.com/, 1196 0x7f7f1b83f070 0x2c41c0195560 
