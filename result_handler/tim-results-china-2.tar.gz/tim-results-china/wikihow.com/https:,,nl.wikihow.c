[0711/230423.449371:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/230423.449791:INFO:switcher_clone.cc(787)] backtrace rip is 7f92de7ec891
[0711/230424.393849:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/230424.394258:INFO:switcher_clone.cc(787)] backtrace rip is 7f111827c891
[1:1:0711/230424.405938:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/230424.406258:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/230424.411477:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0711/230425.880390:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/230425.880656:INFO:switcher_clone.cc(787)] backtrace rip is 7f7a4b73b891
[30197:30197:0711/230425.913293:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/5c2993b1-e204-4e12-8137-daeb8e6a0259
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[30230:30230:0711/230426.136050:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30230
[30242:30242:0711/230426.136459:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30242
[30197:30197:0711/230426.255052:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[30197:30228:0711/230426.255772:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/230426.256017:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/230426.256233:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/230426.256845:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/230426.257019:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/230426.259383:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d0bd848, 1
[1:1:0711/230426.259739:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x37274d36, 0
[1:1:0711/230426.259933:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d578b9c, 3
[1:1:0711/230426.260143:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2c892d01, 2
[1:1:0711/230426.260365:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 364d2737 48ffffffd80b2d 012dffffff892c ffffff9cffffff8b572d , 10104, 4
[1:1:0711/230426.261361:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30197:30228:0711/230426.261642:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING6M'7H�--�,��W->8["
[30197:30228:0711/230426.261716:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 6M'7H�--�,��W-�c>8["
[1:1:0711/230426.261630:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f11164b70a0, 3
[30197:30228:0711/230426.262013:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0711/230426.261877:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1116642080, 2
[30197:30228:0711/230426.262113:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30250, 4, 364d2737 48d80b2d 012d892c 9c8b572d 
[1:1:0711/230426.262166:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1100305d20, -2
[1:1:0711/230426.280918:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/230426.281762:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2c892d01
[1:1:0711/230426.282670:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2c892d01
[1:1:0711/230426.284252:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2c892d01
[1:1:0711/230426.285750:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.285976:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.286196:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.286426:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.287095:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2c892d01
[1:1:0711/230426.287466:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f111827c7ba
[1:1:0711/230426.287670:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1118273def, 7f111827c77a, 7f111827e0cf
[1:1:0711/230426.293356:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2c892d01
[1:1:0711/230426.293794:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2c892d01
[1:1:0711/230426.294564:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2c892d01
[1:1:0711/230426.296620:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.296853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.297077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.297296:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2c892d01
[1:1:0711/230426.298596:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2c892d01
[1:1:0711/230426.298986:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f111827c7ba
[1:1:0711/230426.299156:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1118273def, 7f111827c77a, 7f111827e0cf
[1:1:0711/230426.306875:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/230426.307320:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/230426.307515:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc988da848, 0x7ffc988da7c8)
[1:1:0711/230426.322649:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/230426.328276:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[30197:30197:0711/230426.854494:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30197:30197:0711/230426.855858:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30197:30209:0711/230426.879801:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[30197:30197:0711/230426.879855:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[30197:30197:0711/230426.879909:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[30197:30209:0711/230426.879925:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[30197:30197:0711/230426.879984:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,30250, 4
[1:7:0711/230426.882348:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[30197:30220:0711/230426.897594:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/230426.914452:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x126521716220
[1:1:0711/230426.914700:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0711/230427.171521:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[30197:30197:0711/230428.621462:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[30197:30197:0711/230428.621531:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/230428.692094:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230428.696303:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/230429.319399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/230429.319728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230429.335705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/230429.336039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230429.372932:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230429.735199:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230429.735474:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230430.089070:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230430.093876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/230430.094101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230430.144939:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230430.150394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/230430.150638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230430.162227:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0711/230430.165565:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x126521714e20
[1:1:0711/230430.165916:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[30197:30197:0711/230430.166235:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[30197:30197:0711/230430.180041:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[30197:30197:0711/230430.220023:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[30197:30197:0711/230430.220175:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/230430.257346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230430.905342:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f1101ee02e0 0x126521998560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230430.906669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0711/230430.906869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230430.908343:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30197:30197:0711/230430.975402:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/230430.976208:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x126521715820
[1:1:0711/230430.976401:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[30197:30197:0711/230430.985891:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/230430.995327:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/230430.995556:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[30197:30197:0711/230431.003171:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[30197:30197:0711/230431.014729:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30197:30197:0711/230431.016015:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30197:30209:0711/230431.023489:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[30197:30209:0711/230431.023575:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[30197:30197:0711/230431.023865:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[30197:30197:0711/230431.023963:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[30197:30197:0711/230431.024149:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,30250, 4
[1:7:0711/230431.026601:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/230431.457986:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/230431.981798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 477 0x7f1101ee02e0 0x126521acd5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230431.982915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/230431.984120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230431.984840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30197:30197:0711/230432.056708:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[30197:30197:0711/230432.056823:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/230432.089189:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/230432.317974:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230432.698889:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230432.699078:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230432.961614:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 541, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230432.967265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/230432.967568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230432.977234:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[30197:30197:0711/230433.116695:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[30197:30228:0711/230433.117090:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/230433.117303:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/230433.117504:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/230433.117859:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/230433.117995:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/230433.121060:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x5ff5e87, 1
[1:1:0711/230433.121528:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x37d9a432, 0
[1:1:0711/230433.121713:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2b2cb8a2, 3
[1:1:0711/230433.121890:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2b836b57, 2
[1:1:0711/230433.122067:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 32ffffffa4ffffffd937 ffffff875effffffff05 576bffffff832b ffffffa2ffffffb82c2b , 10104, 5
[1:1:0711/230433.123393:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30197:30228:0711/230433.123704:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING2��7�^�Wk�+��,+�8["
[30197:30228:0711/230433.123793:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 2��7�^�Wk�+��,+�5�8["
[1:1:0711/230433.123694:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f11164b70a0, 3
[30197:30228:0711/230433.124122:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30297, 5, 32a4d937 875eff05 576b832b a2b82c2b 
[1:1:0711/230433.124043:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1116642080, 2
[1:1:0711/230433.124737:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1100305d20, -2
[1:1:0711/230433.137489:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230433.138241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/230433.138457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/230433.146948:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/230433.147344:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b836b57
[1:1:0711/230433.147695:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b836b57
[1:1:0711/230433.148391:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b836b57
[1:1:0711/230433.149806:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.150020:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.150273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.150511:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.151227:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b836b57
[1:1:0711/230433.151550:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f111827c7ba
[1:1:0711/230433.151754:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1118273def, 7f111827c77a, 7f111827e0cf
[1:1:0711/230433.157982:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b836b57
[1:1:0711/230433.158505:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b836b57
[1:1:0711/230433.159319:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b836b57
[1:1:0711/230433.161460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.161716:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.161957:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.162221:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b836b57
[1:1:0711/230433.163507:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b836b57
[1:1:0711/230433.163933:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f111827c7ba
[1:1:0711/230433.164116:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1118273def, 7f111827c77a, 7f111827e0cf
[1:1:0711/230433.171885:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/230433.172472:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/230433.172670:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc988da848, 0x7ffc988da7c8)
[1:1:0711/230433.186553:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/230433.192124:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/230433.361544:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230433.363621:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/230433.363934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/230433.364224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230433.381275:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1265216cf220
[1:1:0711/230433.381590:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/230433.505439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230433.506355:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/230433.506626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/230433.506899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230434.335951:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0711/230434.381644:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0711/230434.435219:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0711/230434.512157:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0711/230434.564623:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://gome.com.cn/"
[1:1:0711/230434.750094:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://wiley.com/"
[1:1:0711/230434.816607:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0711/230434.897806:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0711/230434.958471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230434.959422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230434.959819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.083368:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.084381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230435.084674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.204707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.205618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230435.205924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.255287:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.256256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230435.256537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.321591:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.322501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230435.322797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.428203:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.429256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230435.429541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.522491:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.523412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230435.523718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.590324:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.591286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230435.591556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.681458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.682378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230435.682644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.743224:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.744182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230435.744456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.834191:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.835175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230435.835484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230435.948408:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230435.949357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230435.949630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230436.017638:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230436.018584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230436.018852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230436.108529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230436.109426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230436.109685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230436.169672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230436.170607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/230436.170920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230436.225986:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/230436.226914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0af07132e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/230436.227237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/230436.439522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/230436.440840:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:1_chrome-search://local-ntp/, 4:4_chrome-search://most-visited/
[1:1:0711/230436.441059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0af071201f78, , handlePostMessage, (event) {
  var cmd = event.data.cmd;
  var args = event.data;
  if (cmd === 'loaded') {
    tilesAr
[1:1:0711/230436.441268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[30197:30197:0711/230436.746195:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30197:30197:0711/230436.756326:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30197:30209:0711/230436.786335:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[30197:30209:0711/230436.786433:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[30197:30197:0711/230436.787162:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://nl.wikihow.com/
[30197:30197:0711/230436.787240:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://nl.wikihow.com/, https://nl.wikihow.com/Hoofdpagina, 1
[30197:30197:0711/230436.787370:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://nl.wikihow.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=UTF-8 content-language:nl x-frame-options:SAMEORIGIN cache-control:s-maxage=3600, must-revalidate, max-age=0 content-encoding:gzip accept-ranges:bytes date:Fri, 12 Jul 2019 06:04:36 GMT age:0 x-timer:S1562911476.079304,VS0,VE520 x-c:cache-hnd18734-HND,M cache-iad2137-IAD,m x-content-type-options:nosniff x-xss-protection:1; mode=block strict-transport-security:max-age=31536000; includeSubDomains; preload vary:X-Layout, Cookie, Accept-Encoding, User-Agent content-length:18155  ,30297, 5
[1:7:0711/230436.792815:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/230436.842243:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://nl.wikihow.com/
[1:1:0711/230436.977788:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30197:30197:0711/230436.985290:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://nl.wikihow.com/, https://nl.wikihow.com/, 1
[30197:30197:0711/230436.985395:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://nl.wikihow.com/, https://nl.wikihow.com
[1:1:0711/230437.013978:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230437.086347:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/230437.140755:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230437.140998:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230437.156971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 136 0x7f10fffb8070 0x126521939360 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230437.158052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , window.WH=window.WH||{timeStart:+(new Date()),lang:{}};
[1:1:0711/230437.158307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230437.590570:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230437.679367:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 178 0x7f1100320bd0 0x12652193c158 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230437.680311:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , var mediaWikiLoadStart=(new Date()).getTime();function isCompatible(ua){if(ua===undefined){ua=naviga
[1:1:0711/230437.680423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230437.681529:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230444.451710:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230444.452211:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230444.452619:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230444.453165:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230444.453630:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230448.685962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/230448.686301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230448.862597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f1100320bd0 0x126521942ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230448.873927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (function(window,undefined){var rootjQuery,readyList,document=window.document,location=window.locati
[1:1:0711/230448.874117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
		remove user.f_4468535f -> 0
[30197:30197:0711/230448.978961:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0711/230448.991809:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/230449.414902:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f1100320bd0 0x126521942ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230449.424830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f1100320bd0 0x126521942ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230449.447350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f1100320bd0 0x126521942ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230449.722825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230449.723094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230449.901679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230449.901843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230449.920685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230449.920848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230449.953793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230449.954032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230449.979766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230449.979954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.015260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.015517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.050562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.050851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.067051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.067229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.094652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.094872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.126988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.127221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.144934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.145106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.175555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.175781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.205721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.205909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.226042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.226286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.242219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.242420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.276281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.276509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.305507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.305825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.330431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.330692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.356063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.356381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.375589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.375761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.411609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.411953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.437876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.438182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.476482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.476721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.519791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.520142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.557143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.557379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.591589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.591931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.619664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.620011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.636658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.636949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.662943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.663216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.690075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.690369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.731363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.731796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.769085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.769367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.789751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.790055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.829909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.830166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.847907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.848084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.864721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.864889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.893134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.893313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.935170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.935477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230450.973763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230450.974049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.012178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.012350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.056635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.056883:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.095363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.095722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.164480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.164798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.211915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.212160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.275468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.275808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.311707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.311899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.350342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.350587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.392714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.393002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.436535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.436862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.483470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.483831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.524967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.525248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.566158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.566427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.629343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.629648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.673774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.674054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.696057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.696351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.714580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.714861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.730133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.730428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.775709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.776065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.814044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.814293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.858971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.859312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.900123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.900361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.944032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.944366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.971716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.971932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230451.989424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230451.989598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.018554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.018794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.047489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.047690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.065308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.065470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.106628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.106894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.127414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.127654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.145474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.145763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.192343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.192643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.233335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.233612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[30197:30197:0711/230452.241161:WARNING:one_google_bar_fetcher_impl.cc(315)] Request failed with error: -102: net::ERR_CONNECTION_REFUSED
[1:1:0711/230452.285251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.285557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.338659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.339015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.382187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.382506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.406344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.406567:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.439365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.439536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.490363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.490662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.536494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.536731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.586956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.587292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.614645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.614819:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.663635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.663947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.707575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.707812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.762224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.762517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.815487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.815791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.859953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.860243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.890890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.891077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.914814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.914983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.942919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.943120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230452.989779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230452.990102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.036883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.037056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.062301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.062468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.107251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.107511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.127173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.127337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.144278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.144444:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.187340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.187574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.215033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.215224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.235168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.235349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.251222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.251387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.292441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.292698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.316384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.316554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.368865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.369183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.417827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.418065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.453777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.454018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.476526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.476691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.502578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.502747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.528521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.528752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.563845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.564141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.611258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.611498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.659679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.659920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.707172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.707434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.734704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.734877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.781855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.782092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.829462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.829699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.882745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.882986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.903108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.903277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.931975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.932274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230453.981957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230453.982252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.041315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.041637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.062987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.063163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.108655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.108916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.139331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.139518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.193298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.193570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.245229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.245490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.302343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.302660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.344941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.345186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.382293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.382483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.437264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.437575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.456999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.457179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.504293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.504548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.564396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.564755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.584521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.584682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.604659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.604822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.646220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.646389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.661746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.661914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.707139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.707376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.738331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.738616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.777558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.777730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.826443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.826714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.857379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.857571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.909128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.909368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230454.962315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230454.962551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.014523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.014770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.038934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.039163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.094402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.094662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.146686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.146914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.201979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.202210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.258557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.258758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.321157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.321440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.368204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.368372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.423289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.423521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.464711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.464941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.523503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.523876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.581292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.581531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.663592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.663870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.745807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.746039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.805291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.805515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.844832:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.845005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.909444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.909680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.952227:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.952390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.980146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.980312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230455.998405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230455.998568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.019983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.020141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.074095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.074338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.114955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.115120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.151037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.151511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.187450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.187615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.243194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.243428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.305278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.305574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.360391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.360674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.418621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.419021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.504198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.504496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.561531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.561816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.621014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.621312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.663292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.663574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.686317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.686593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.709620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.709882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.777695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.777974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.888968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.889277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230456.953781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230456.954099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.002579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.002853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.044022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.044327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.081057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.082555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.116902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.117064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.138970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.139156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.201693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.201990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.304800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.305041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.405672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.405839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.463314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.463604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.523828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.524113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.583807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.584052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.646554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.646791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.707642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.707876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.769613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.769843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.858941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.859173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230457.946334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230457.946564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.068921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.069161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.134309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.134574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.212284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.212555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.280644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.280833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.324885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.325125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.374260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.374456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.419714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.419954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.486010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.486244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.549732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.549968:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.600424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.600712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.658829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.659162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.731137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.731305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.803158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.803410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.831086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.831258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.866102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.866275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.912518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.912828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.972546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.972737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230458.996206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230458.996430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.026527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.026841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.066918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.067091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.102113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.102288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.173081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.173322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.284000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.284178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.319320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.319492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.386705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.386940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.483650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.483906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.597464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.597730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.631430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.631606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.697229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.697475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.761742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.762030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.886614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.886877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230459.957588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230459.957841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230500.042371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230500.042669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230500.110710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230500.110899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230500.245682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230500.245940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230500.354022:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f1100320bd0 0x126521f38ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230500.366021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , mw.loader.implement("ext.wikihow.ataglance",function(){(function(mw,$){window.WH=window.WH||{};WH.at
[1:1:0711/230500.366242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230500.374828:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2459a67829c8, 0x126521558160
[1:1:0711/230500.374983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 0
[1:1:0711/230500.375176:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 601
[1:1:0711/230500.375323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7f10fffb8070 0x126521d24060 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 597 0x7f1100320bd0 0x126521f38ed8 
[1:1:0711/230500.384305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2459a67829c8, 0x126521558160
[1:1:0711/230500.384442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 0
[1:1:0711/230500.384620:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 602
[1:1:0711/230500.384726:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f10fffb8070 0x126521ef05e0 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 597 0x7f1100320bd0 0x126521f38ed8 
[1:1:0711/230500.630628:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2459a67829c8, 0x126521558160
[1:1:0711/230500.630857:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 0
[1:1:0711/230500.631260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 607
[1:1:0711/230500.631452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 607 0x7f10fffb8070 0x126521f2c9e0 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 597 0x7f1100320bd0 0x126521f38ed8 
[1:1:0711/230500.642625:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2459a67829c8, 0x126521558160
[1:1:0711/230500.642849:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 0
[1:1:0711/230500.643233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 608
[1:1:0711/230500.643425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f10fffb8070 0x12652213ece0 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 597 0x7f1100320bd0 0x126521f38ed8 
[1:1:0711/230500.729258:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f1100320bd0 0x126521f38ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230500.730654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f1100320bd0 0x126521f38ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230500.732327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f1100320bd0 0x126521f38ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230500.733468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 597 0x7f1100320bd0 0x126521f38ed8 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230500.764634:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0395219, 281, 1
[1:1:0711/230500.764783:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230500.776332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230500.776487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230502.902101:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230502.902399:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230502.903221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230502.904090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , 
		WH.translationData = {};
		
[1:1:0711/230502.904322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230502.907272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230502.937927:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230502.945695:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230502.952137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230502.996176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230503.064226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 653 0x7f10fffb8070 0x1265221c8460 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230503.096453:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.193936, 59, 1
[1:1:0711/230503.096719:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230503.135735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 601, 7f11028fd881
[1:1:0711/230503.152169:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.152519:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.152885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230503.153541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (){addEmbeddedCSS();}
[1:1:0711/230503.153769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230503.272536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 602, 7f11028fd881
[1:1:0711/230503.312001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.312348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.312711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230503.313391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (){addEmbeddedCSS();}
[1:1:0711/230503.313663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230503.315853:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 607, 7f11028fd881
[1:1:0711/230503.334198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.334559:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.334987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230503.335584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (){addEmbeddedCSS();}
[1:1:0711/230503.335843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230503.379001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230503.379299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230503.409096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 608, 7f11028fd881
[1:1:0711/230503.434546:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.434985:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"597 0x7f1100320bd0 0x126521f38ed8 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230503.435501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230503.436252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (){addEmbeddedCSS();}
[1:1:0711/230503.436487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230504.863023:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230504.865056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , window.onresize, (){n.forEach&&n.forEach(function(a){a()})}
[1:1:0711/230504.865308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230506.229211:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230506.229508:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230506.230312:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7f10fffb8070 0x1265224792e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230506.231217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3b97b5')
[1:1:0711/230506.231491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230506.268841:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7f10fffb8070 0x1265224792e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230506.311699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7f10fffb8070 0x1265224792e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230506.363366:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7f10fffb8070 0x1265224792e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230506.404600:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.174964, 64, 1
[1:1:0711/230506.404863:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230506.550106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230506.550486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230507.548816:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230507.667034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "play", "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230507.668865:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "waiting", "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230507.669566:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230508.286242:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230508.286458:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230508.287238:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 782 0x7f10fffb8070 0x12652232e260 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230508.288123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3bd75d')
[1:1:0711/230508.288313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230508.336327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 782 0x7f10fffb8070 0x12652232e260 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230508.361980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 782 0x7f10fffb8070 0x12652232e260 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230508.433879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 782 0x7f10fffb8070 0x12652232e260 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230508.477475:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.190934, 62, 1
[1:1:0711/230508.477734:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230508.531493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230508.531782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230510.007828:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230510.008084:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230510.008925:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 824 0x7f10fffb8070 0x12652401de60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230510.009823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3bdf0c')
[1:1:0711/230510.010058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230510.081365:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 824 0x7f10fffb8070 0x12652401de60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230510.117819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 824 0x7f10fffb8070 0x12652401de60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230510.144966:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.136752, 51, 1
[1:1:0711/230510.145229:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230510.231475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230510.231759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[30197:30197:0711/230510.853128:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/230511.293436:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230511.293704:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230511.294572:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 860 0x7f10fffb8070 0x12652401e360 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230511.295458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3c34ac')
[1:1:0711/230511.295740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230511.365458:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 860 0x7f10fffb8070 0x12652401e360 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230511.409279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 860 0x7f10fffb8070 0x12652401e360 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230511.455265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 860 0x7f10fffb8070 0x12652401e360 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230511.498379:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.204526, 64, 1
[1:1:0711/230511.498631:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230511.546839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230511.547233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230512.549864:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230512.550148:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230512.551001:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7f10fffb8070 0x1265242fc160 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230512.551928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3c6896')
[1:1:0711/230512.552144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230512.635103:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7f10fffb8070 0x1265242fc160 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230512.692050:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7f10fffb8070 0x1265242fc160 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230512.737720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7f10fffb8070 0x1265242fc160 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230512.785191:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.234888, 66, 1
[1:1:0711/230512.785409:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230512.835237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230512.835472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230514.145530:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230514.145841:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230514.146897:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f10fffb8070 0x1265243e23e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230514.148002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3cbc1c')
[1:1:0711/230514.148238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230514.273716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f10fffb8070 0x1265243e23e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230514.306100:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f10fffb8070 0x1265243e23e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230514.349903:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 912 0x7f10fffb8070 0x1265243e23e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230514.387026:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.24099, 63, 1
[1:1:0711/230514.387245:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230514.594337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230514.594678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230516.189060:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230516.189217:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230516.189655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 954 0x7f10fffb8070 0x12652467cae0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230516.190168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3cc6a2')
[1:1:0711/230516.190280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230516.250368:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 954 0x7f10fffb8070 0x12652467cae0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230516.298781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 954 0x7f10fffb8070 0x12652467cae0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230516.344782:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.155654, 51, 1
[1:1:0711/230516.345081:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230516.370394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230516.370572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230517.797526:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230517.797739:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230517.798606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f10fffb8070 0x1265211fcce0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230517.799458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3d1014')
[1:1:0711/230517.799640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230517.884627:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f10fffb8070 0x1265211fcce0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230517.931604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f10fffb8070 0x1265211fcce0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230517.936668:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f10fffb8070 0x1265211fcce0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230517.981678:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 991 0x7f10fffb8070 0x1265211fcce0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230518.023619:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.225775, 64, 1
[1:1:0711/230518.023860:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230518.239728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230518.239970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230519.471003:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230519.471158:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230519.471677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1025 0x7f10fffb8070 0x1265243e2760 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230519.472163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3d7d8a')
[1:1:0711/230519.472272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230519.511563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1025 0x7f10fffb8070 0x1265243e2760 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230519.528570:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1025 0x7f10fffb8070 0x1265243e2760 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230519.560525:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1025 0x7f10fffb8070 0x1265243e2760 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230519.604417:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.133249, 62, 1
[1:1:0711/230519.604582:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230519.624544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230519.624728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230521.032816:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230521.032981:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230521.033491:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1067 0x7f10fffb8070 0x126524683f60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230521.033988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3d8554')
[1:1:0711/230521.034118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230521.068175:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1067 0x7f10fffb8070 0x126524683f60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230521.088655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1067 0x7f10fffb8070 0x126524683f60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230521.142241:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1067 0x7f10fffb8070 0x126524683f60 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230521.190613:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.157642, 66, 1
[1:1:0711/230521.190837:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230521.243803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230521.243978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230522.651228:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230522.651390:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230522.651940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1110 0x7f10fffb8070 0x1265243fe8e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230522.652466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , WH.shared.addScrollLoadItem('5d2822f3dd480')
[1:1:0711/230522.652688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230522.751020:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1110 0x7f10fffb8070 0x1265243fe8e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230522.752620:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1110 0x7f10fffb8070 0x1265243fe8e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230522.795550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1110 0x7f10fffb8070 0x1265243fe8e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230522.833509:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.182114, 269, 1
[1:1:0711/230522.833744:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230522.933175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230522.933353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230525.118554:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230525.118756:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230525.119307:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1151 0x7f10fffb8070 0x1265246817e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230525.119853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , 
		WH.RCWidget.setParams({
			'rc_URL': '/Special:RCWidget',
			'rc_ReloadInterval': 60000,
			'rc_n
[1:1:0711/230525.119964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230525.131119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1151 0x7f10fffb8070 0x1265246817e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230525.134024:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1151 0x7f10fffb8070 0x1265246817e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230525.158938:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1151 0x7f10fffb8070 0x1265246817e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230525.501646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2459a67829c8, 0x126521558198
[1:1:0711/230525.504380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 500
[1:1:0711/230525.504797:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1206
[1:1:0711/230525.505030:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1206 0x7f10fffb8070 0x126524b7b7e0 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 1151 0x7f10fffb8070 0x1265246817e0 
[1:1:0711/230525.972640:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 150
[1:1:0711/230525.973163:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1211
[1:1:0711/230525.973418:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1211 0x7f10fffb8070 0x126524ee93e0 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 1151 0x7f10fffb8070 0x1265246817e0 
[1:1:0711/230525.986896:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230526.050155:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.931612, 0, 1
[1:1:0711/230526.050568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/230526.098557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230526.098738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230528.617033:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/230528.617306:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230528.618222:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1212 0x7f10fffb8070 0x126524294ae0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230528.619202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , if(window.mw){
mw.loader.state({"site":"ready","user":"ready","user.groups":"ready"});
}
[1:1:0711/230528.619418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230528.627965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1212 0x7f10fffb8070 0x126524294ae0 , "https://nl.wikihow.com/Hoofdpagina"
		remove user.11_74d6b255 -> 0
		remove user.12_a7051a7b -> 0
[1:1:0711/230528.822578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230528.824035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230529.035160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1206, 7f11028fd881
[1:1:0711/230529.093949:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"1151 0x7f10fffb8070 0x1265246817e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230529.094266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"1151 0x7f10fffb8070 0x1265246817e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230529.094601:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230529.095162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (){checkHeaderToggle();loadSubmethods();checkMakeHeadingsSticky();}
[1:1:0711/230529.095338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230529.256141:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/230529.280834:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2459a67829c8, 0x126521558150
[1:1:0711/230529.281052:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 0
[1:1:0711/230529.281434:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1305
[1:1:0711/230529.281622:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1305 0x7f10fffb8070 0x12652228c9e0 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 1206 0x7f10fffb8070 0x126524b7b7e0 
[1:1:0711/230529.330954:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://nl.wikihow.com/Hoofdpagina", 13
[1:1:0711/230529.331421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1306
[1:1:0711/230529.331616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7f10fffb8070 0x12652492dd60 , 0:0_switcher://chrome, 1, -5:3_https://nl.wikihow.com/, 1206 0x7f10fffb8070 0x126524b7b7e0 
[1:1:0711/230530.044598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230530.044912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230530.050419:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1211, 7f11028fd8db
[1:1:0711/230530.130535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"1151 0x7f10fffb8070 0x1265246817e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230530.130927:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"1151 0x7f10fffb8070 0x1265246817e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230530.131407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1348
[1:1:0711/230530.131728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1348 0x7f10fffb8070 0x126524b77260 , 0:0_switcher://chrome, 0, , 1211 0x7f10fffb8070 0x126524ee93e0 
[1:1:0711/230530.132240:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230530.132950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , typeText, (){var currentString=$("#hp_container .hp_title").html();var currentLength=currentString.length;var 
[1:1:0711/230530.133194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0711/230532.154093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1287 0x7f1101ee02e0 0x126523f8c7e0 , "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230532.163442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0711/230532.163792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
		remove user.13_ef1dd3bf -> 0
[1:1:0711/230533.364090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1305, 7f11028fd881
[1:1:0711/230533.433024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"1206 0x7f10fffb8070 0x126524b7b7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230533.433366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"1206 0x7f10fffb8070 0x126524b7b7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230533.433714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230533.434275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , (){fxNow=undefined;}
[1:1:0711/230533.434454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230533.436887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1306, 7f11028fd8db
[1:1:0711/230533.508425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1b1ac7442860","ptid":"1206 0x7f10fffb8070 0x126524b7b7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230533.508813:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://nl.wikihow.com/","ptid":"1206 0x7f10fffb8070 0x126524b7b7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230533.509275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1498
[1:1:0711/230533.509474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1498 0x7f10fffb8070 0x1265222808e0 , 0:0_switcher://chrome, 0, , 1306 0x7f10fffb8070 0x12652492dd60 
[1:1:0711/230533.509790:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230533.510402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , jQuery.fx.tick, (){var timer,timers=jQuery.timers,i=0;fxNow=jQuery.now();for(;i<timers.length;i++){timer=timers[i];i
[1:1:0711/230533.510600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[30197:30223:0711/230533.577607:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[30197:30197:0711/230534.726156:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0711/230535.413220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , , document.readyState
[1:1:0711/230535.413464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
[1:1:0711/230535.496538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1348, 7f11028fd8db
[1:1:0711/230535.565105:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1211 0x7f10fffb8070 0x126524ee93e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230535.565373:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1211 0x7f10fffb8070 0x126524ee93e0 ","rf":"0:0_switcher://chrome"}
[1:1:0711/230535.565733:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1534
[1:1:0711/230535.565929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1534 0x7f10fffb8070 0x126521a4e860 , 0:0_switcher://chrome, 0, , 1348 0x7f10fffb8070 0x126524b77260 
[1:1:0711/230535.566273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://nl.wikihow.com/Hoofdpagina"
[1:1:0711/230535.566835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://nl.wikihow.com/, 1b1ac7442860, , typeText, (){var currentString=$("#hp_container .hp_title").html();var currentLength=currentString.length;var 
[1:1:0711/230535.567013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://nl.wikihow.com/Hoofdpagina", "nl.wikihow.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
