[0712/141048.843055:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141048.843597:INFO:switcher_clone.cc(787)] backtrace rip is 7f1bd5b38891
[0712/141049.813005:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141049.813404:INFO:switcher_clone.cc(787)] backtrace rip is 7fb5e7daf891
[1:1:0712/141049.824772:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/141049.825050:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/141049.829348:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/141051.160381:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141051.160798:INFO:switcher_clone.cc(787)] backtrace rip is 7efd4fdc8891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[21767:21767:0712/141051.398019:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=21767
[21777:21777:0712/141051.398938:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=21777
[21736:21736:0712/141051.497020:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/61423822-cf4e-47fd-a267-7b0219c7884e
[21736:21736:0712/141051.955488:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[21736:21765:0712/141051.956221:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/141051.956464:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/141051.956694:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/141051.957288:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/141051.957461:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/141051.960551:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2fbba7cc, 1
[1:1:0712/141051.960932:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1b15c75a, 0
[1:1:0712/141051.961124:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x247826a4, 3
[1:1:0712/141051.961336:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3837aaf0, 2
[1:1:0712/141051.961571:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 5affffffc7151b ffffffccffffffa7ffffffbb2f fffffff0ffffffaa3738 ffffffa4267824 , 10104, 4
[1:1:0712/141051.962728:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[21736:21765:0712/141051.962964:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGZ�̧�/�78�&x$�6$
[21736:21765:0712/141051.963059:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Z�̧�/�78�&x$�6$
[21736:21765:0712/141051.963368:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[21736:21765:0712/141051.963444:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21787, 4, 5ac7151b cca7bb2f f0aa3738 a4267824 
[1:1:0712/141051.963182:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5e5fea0a0, 3
[1:1:0712/141051.964063:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5e6175080, 2
[1:1:0712/141051.964247:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5cfe38d20, -2
[1:1:0712/141052.064189:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/141052.065156:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3837aaf0
[1:1:0712/141052.066257:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3837aaf0
[1:1:0712/141052.067938:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3837aaf0
[1:1:0712/141052.069429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.069612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.069783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.069965:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.070572:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3837aaf0
[1:1:0712/141052.070926:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5e7daf7ba
[1:1:0712/141052.071062:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb5e7da6def, 7fb5e7daf77a, 7fb5e7db10cf
[1:1:0712/141052.076537:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3837aaf0
[1:1:0712/141052.076868:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3837aaf0
[1:1:0712/141052.077573:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3837aaf0
[1:1:0712/141052.079471:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.079658:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.079840:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.080025:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3837aaf0
[1:1:0712/141052.081201:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3837aaf0
[1:1:0712/141052.081569:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5e7daf7ba
[1:1:0712/141052.081760:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb5e7da6def, 7fb5e7daf77a, 7fb5e7db10cf
[1:1:0712/141052.089778:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/141052.090405:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/141052.090604:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffea1065378, 0x7ffea10652f8)
[1:1:0712/141052.106305:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/141052.112436:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[21736:21736:0712/141052.539850:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21736:21736:0712/141052.541247:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21736:21746:0712/141052.561117:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[21736:21746:0712/141052.561239:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[21736:21736:0712/141052.561469:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[21736:21736:0712/141052.561548:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[21736:21736:0712/141052.561686:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,21787, 4
[1:7:0712/141052.563306:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[21736:21757:0712/141052.608234:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/141052.647576:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x390f48dd8220
[1:1:0712/141052.647881:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/141053.140536:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[21736:21736:0712/141054.911964:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[21736:21736:0712/141054.912129:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/141054.937262:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141054.941478:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141055.969481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/141055.969827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141055.986774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/141055.987081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141056.013033:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141056.291478:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141056.291765:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141056.555386:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141056.563758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/141056.564064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141056.599835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141056.610528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/141056.610828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141056.622784:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[21736:21736:0712/141056.625957:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/141056.626305:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x390f48dd6e20
[1:1:0712/141056.626525:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[21736:21736:0712/141056.633598:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[21736:21736:0712/141056.658049:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[21736:21736:0712/141056.658168:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/141056.675644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141057.401362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7fb5d1a132e0 0x390f48f5f960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141057.403882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/141057.404418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141057.407489:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[21736:21736:0712/141057.488080:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/141057.491740:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x390f48dd7820
[1:1:0712/141057.492223:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[21736:21736:0712/141057.502879:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/141057.508019:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/141057.508552:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[21736:21736:0712/141057.516716:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[21736:21736:0712/141057.526231:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21736:21736:0712/141057.526682:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21736:21746:0712/141057.528338:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[21736:21736:0712/141057.528424:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[21736:21746:0712/141057.528425:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[21736:21736:0712/141057.528463:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[21736:21736:0712/141057.528524:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,21787, 4
[1:7:0712/141057.535642:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/141058.268843:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/141058.862490:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 488 0x7fb5d1a132e0 0x390f4908a260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141058.864189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/141058.864430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141058.865208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[21736:21736:0712/141059.119143:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[21736:21736:0712/141059.119293:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/141059.130154:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[21736:21736:0712/141059.381637:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[21736:21765:0712/141059.382056:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/141059.382237:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/141059.382562:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/141059.383112:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/141059.383310:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/141059.387214:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3bbdb109, 1
[1:1:0712/141059.387930:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x7c5e254, 0
[1:1:0712/141059.388193:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3a259ce2, 3
[1:1:0712/141059.388415:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb43e316, 2
[1:1:0712/141059.388647:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 54ffffffe2ffffffc507 09ffffffb1ffffffbd3b 16ffffffe3430b ffffffe2ffffff9c253a , 10104, 5
[1:1:0712/141059.389847:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[21736:21765:0712/141059.390303:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGT��	��;�C�%:F9$
[21736:21765:0712/141059.390378:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is T��	��;�C�%:x�F9$
[1:1:0712/141059.390286:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5e5fea0a0, 3
[21736:21765:0712/141059.390732:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21833, 5, 54e2c507 09b1bd3b 16e3430b e29c253a 
[1:1:0712/141059.390544:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5e6175080, 2
[1:1:0712/141059.390824:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb5cfe38d20, -2
[1:1:0712/141059.414547:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/141059.414963:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b43e316
[1:1:0712/141059.415407:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b43e316
[1:1:0712/141059.416304:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b43e316
[1:1:0712/141059.418125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.418389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.418639:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.418879:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.419796:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b43e316
[1:1:0712/141059.420112:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5e7daf7ba
[1:1:0712/141059.420273:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb5e7da6def, 7fb5e7daf77a, 7fb5e7db10cf
[1:1:0712/141059.425182:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b43e316
[1:1:0712/141059.425434:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b43e316
[1:1:0712/141059.425775:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b43e316
[1:1:0712/141059.426534:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.426680:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.426806:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.426914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b43e316
[1:1:0712/141059.427399:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b43e316
[1:1:0712/141059.427575:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb5e7daf7ba
[1:1:0712/141059.427773:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb5e7da6def, 7fb5e7daf77a, 7fb5e7db10cf
[1:1:0712/141059.431064:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/141059.431559:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/141059.431733:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffea1065378, 0x7ffea10652f8)
[1:1:0712/141059.442972:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/141059.447804:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/141059.457143:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141059.660755:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x390f48da7220
[1:1:0712/141059.661048:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/141100.328408:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141100.328716:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141100.677999:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141100.682553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 119ff2d6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/141100.682860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/141100.692537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[21736:21736:0712/141100.806483:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21736:21736:0712/141100.815255:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/141100.818369:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141100.819186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119ff2c41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/141100.819928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[21736:21746:0712/141100.837384:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[21736:21746:0712/141100.837487:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[21736:21736:0712/141100.838246:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.healthr.com/
[21736:21736:0712/141100.838341:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.healthr.com/, http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html, 1
[21736:21736:0712/141100.838477:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.healthr.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 21:10:47 GMT Server: Apache Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Cluster_id: IDC_WEB_232 Vary: User-Agent,Accept-Encoding Content-Encoding: gzip Content-Length: 37629 Keep-Alive: timeout=5, max=100 Connection: Keep-Alive Content-Type: text/html Content-Language: zh-CN  ,21833, 5
[1:7:0712/141100.841909:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/141100.857894:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.healthr.com/
[21736:21736:0712/141100.946339:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.healthr.com/, http://www.healthr.com/, 1
[21736:21736:0712/141100.946399:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.healthr.com/, http://www.healthr.com
[1:1:0712/141100.983085:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141101.000439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141101.002325:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/141101.002559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 119ff2d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/141101.002846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/141101.071011:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141101.086092:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141101.094773:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141101.094990:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141101.131968:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141101.132866:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/141101.133087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 119ff2d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/141101.133368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/141101.234305:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/141102.666084:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fb5e6175080 0x390f48cbc9c0 1 0 0x390f48cbc9d8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141102.669302:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141102.677711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , /*! jQuery v1.10.2 | (c) 2005, 2013 jQuery Foundation, Inc. | jquery.org/license
// # sourceMappingU
[1:1:0712/141102.678082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141102.937327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fb5e6175080 0x390f48cbc9c0 1 0 0x390f48cbc9d8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.029269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7fb5e6175080 0x390f48cbc9c0 1 0 0x390f48cbc9d8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.114194:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141103.126423:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.133479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , /* 
 * File : c_funtype_json.js 
 * CreateTime : 2019-02-21 13:35:50 
 * 
 */
 
 /* webcode : 
[1:1:0712/141103.133730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141103.136887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.146977:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.158308:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.169745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.178721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.186713:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7fb5e6175080 0x390f48d6fce0 1 0 0x390f48d6fcf8 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.261791:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.126992, 113, 1
[1:1:0712/141103.262079:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141103.756806:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141103.757072:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.757964:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7fb5cfaeb070 0x390f49123ee0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.759004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , 
$(function(){	
	$.getScript("http://my.healthr.com/loginstate/pagetopbar");
});

[1:1:0712/141103.759240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141103.767784:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7fb5cfaeb070 0x390f49123ee0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141103.779688:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0224428, 55, 1
[1:1:0712/141103.779979:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.021871:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.022137:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.023081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7fb5cfaeb070 0x390f48fa64e0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.024680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , 
var _tipTimer=0
function showtip(tiptxt,second,top,style,url){
	if(_tipTimer){ 	window.clearTimeout
[1:1:0712/141104.024898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141104.079943:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0576909, 294, 1
[1:1:0712/141104.080289:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.170010:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.170334:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.174397:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 295 0x7fb5cfaeb070 0x390f490f0060 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.176125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , // JavaScript Document
// var currHy = '';
/*关键词的搜索方式*/
function showkeywordholde
[1:1:0712/141104.176449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141104.188715:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 295 0x7fb5cfaeb070 0x390f490f0060 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.345082:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.174541, 2265, 1
[1:1:0712/141104.345385:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.562084:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.562360:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.564189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 312 0x7fb5cfaeb070 0x390f4917bde0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.571125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , 
var aryhy={11:"建筑行业",14:"医药行业",29:"化工行业",12:"金融行业",22:"制造行业
[1:1:0712/141104.571368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141104.592600:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0300159, 88, 1
[1:1:0712/141104.592847:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.683445:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.683751:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.684678:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 321 0x7fb5cfaeb070 0x390f490c7860 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.685715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , 

[1:1:0712/141104.685938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141104.705595:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0216579, 117, 1
[1:1:0712/141104.705853:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.809629:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141104.809916:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.810855:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.811910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , 
function updateAppStateText(jid){
	$('#appbtn_'+jid).attr('appstate','1').attr('title','已应聘�
[1:1:0712/141104.812136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141104.814489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.826056:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.845639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.852577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141104.867422:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141109.144996:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.145655:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.236208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x17b157b429c8, 0x390f4875c440
[1:1:0712/141109.236548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", 0
[1:1:0712/141109.236980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.healthr.com/, 413
[1:1:0712/141109.237164:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 413 0x7fb5cfaeb070 0x390f49d65860 , 5:3_http://www.healthr.com/, 1, -5:3_http://www.healthr.com/, 328 0x7fb5cfaeb070 0x390f4906bae0 
[1:1:0712/141109.288161:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", 13
[1:1:0712/141109.288720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.healthr.com/, 414
[1:1:0712/141109.288911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7fb5cfaeb070 0x390f49d90c60 , 5:3_http://www.healthr.com/, 1, -5:3_http://www.healthr.com/, 328 0x7fb5cfaeb070 0x390f4906bae0 
[1:1:0712/141109.588922:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.589502:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.589925:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.590361:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.590889:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141109.735936:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141109.740522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141109.745155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141109.754870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141109.761850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fb5cfaeb070 0x390f4906bae0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141111.260785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141111.261676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , r, (e,i){var s,u,c,p;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=x.noop,$n&&delete 
[1:1:0712/141111.261933:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141111.263166:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141111.264079:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x26436130d4c0
[1:1:0712/141111.707185:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141111.708129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , r, (e,i){var s,u,c,p;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=x.noop,$n&&delete 
[1:1:0712/141111.708364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141111.709051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141111.712080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141111.712903:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x26436130d4c0
[1:1:0712/141112.150382:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.healthr.com/, 413, 7fb5d2430881
[1:1:0712/141112.170422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"357e15682860","ptid":"328 0x7fb5cfaeb070 0x390f4906bae0 ","rf":"5:3_http://www.healthr.com/"}
[1:1:0712/141112.170776:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.healthr.com/","ptid":"328 0x7fb5cfaeb070 0x390f4906bae0 ","rf":"5:3_http://www.healthr.com/"}
[1:1:0712/141112.171109:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141112.171731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , (){Xn=t}
[1:1:0712/141112.172006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141112.194493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.healthr.com/, 414, 7fb5d24308db
[1:1:0712/141112.214187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"357e15682860","ptid":"328 0x7fb5cfaeb070 0x390f4906bae0 ","rf":"5:3_http://www.healthr.com/"}
[1:1:0712/141112.214496:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.healthr.com/","ptid":"328 0x7fb5cfaeb070 0x390f4906bae0 ","rf":"5:3_http://www.healthr.com/"}
[1:1:0712/141112.214833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.healthr.com/, 490
[1:1:0712/141112.215066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7fb5cfaeb070 0x390f49245760 , 5:3_http://www.healthr.com/, 0, , 414 0x7fb5cfaeb070 0x390f49d90c60 
[1:1:0712/141112.215375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141112.216022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , x.fx.tick, (){var e,n=x.timers,r=0;for(Xn=x.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/141112.216238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141113.114538:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fb5d1a132e0 0x390f491daee0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141113.115501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , var userstatestr ='';

[1:1:0712/141113.115795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141113.116525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141113.155975:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7fb5d1a132e0 0x390f49245be0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141113.157224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , var userstatestr ='';
userstatestr = userstatestr +'<div class="head_btn">';
userstatestr = userstat
[1:1:0712/141113.157462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141113.162794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141113.202776:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7fb5d1a132e0 0x390f4a034ce0 , "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141113.203799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , 
[1:1:0712/141113.204049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141113.325342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141113.326177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , v.handle, (e){return typeof x===i||e&&x.event.triggered===e.type?t:x.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/141113.326404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[1:1:0712/141113.349315:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html"
[1:1:0712/141132.163511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.healthr.com/, 357e15682860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/141132.163882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html", "www.healthr.com", 3, 1, , , 0
[21736:21736:0712/141132.584160:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: http://www.healthr.com/so/kj%E8%80%B3%E9%BC%BB%E5%96%89-14.html (0)
[21736:21736:0712/141132.790489:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/141132.802126:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
