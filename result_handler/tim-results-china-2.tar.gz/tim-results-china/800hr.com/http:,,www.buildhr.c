[0712/141444.361890:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141444.363656:INFO:switcher_clone.cc(787)] backtrace rip is 7f6d3ba2d891
[0712/141445.330589:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141445.330939:INFO:switcher_clone.cc(787)] backtrace rip is 7f475d69b891
[1:1:0712/141445.342632:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/141445.342889:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/141445.348163:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[22376:22376:0712/141446.741380:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/29e7b912-6337-41ab-9347-276db4b012dc
[0712/141446.934009:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/141446.934534:INFO:switcher_clone.cc(787)] backtrace rip is 7fb61df4a891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[22408:22408:0712/141447.139363:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=22408
[22420:22420:0712/141447.139892:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=22420
[22376:22376:0712/141447.200549:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[22376:22406:0712/141447.201268:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/141447.201491:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/141447.201818:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/141447.202590:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/141447.202841:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/141447.206460:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x15ca2a03, 1
[1:1:0712/141447.206878:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x34946c24, 0
[1:1:0712/141447.207084:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2d6457bc, 3
[1:1:0712/141447.207290:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2e16b964, 2
[1:1:0712/141447.207539:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 246cffffff9434 032affffffca15 64ffffffb9162e ffffffbc57642d , 10104, 4
[1:1:0712/141447.208804:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[22376:22406:0712/141447.209090:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING$l�4*�d�.�Wd-��?
[22376:22406:0712/141447.209160:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is $l�4*�d�.�Wd-8w��?
[1:1:0712/141447.209082:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f475b8d60a0, 3
[22376:22406:0712/141447.209497:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[22376:22406:0712/141447.209624:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 22428, 4, 246c9434 032aca15 64b9162e bc57642d 
[1:1:0712/141447.209613:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f475ba61080, 2
[1:1:0712/141447.209818:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4745724d20, -2
[1:1:0712/141447.234044:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/141447.235155:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e16b964
[1:1:0712/141447.236386:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e16b964
[1:1:0712/141447.238406:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e16b964
[1:1:0712/141447.240341:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.240596:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.240842:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.241081:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.241886:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e16b964
[1:1:0712/141447.242298:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f475d69b7ba
[1:1:0712/141447.242469:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f475d692def, 7f475d69b77a, 7f475d69d0cf
[1:1:0712/141447.249615:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2e16b964
[1:1:0712/141447.250061:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2e16b964
[1:1:0712/141447.250991:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2e16b964
[1:1:0712/141447.253692:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.253973:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.254207:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.254445:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2e16b964
[1:1:0712/141447.256068:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2e16b964
[1:1:0712/141447.256524:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f475d69b7ba
[1:1:0712/141447.256723:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f475d692def, 7f475d69b77a, 7f475d69d0cf
[1:1:0712/141447.266466:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/141447.267005:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/141447.267191:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd668b5be8, 0x7ffd668b5b68)
[1:1:0712/141447.284249:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/141447.289996:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[22376:22376:0712/141447.847201:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22376:22376:0712/141447.848459:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22376:22387:0712/141447.867863:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[22376:22376:0712/141447.868046:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[22376:22376:0712/141447.868128:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[22376:22387:0712/141447.867969:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[22376:22376:0712/141447.868326:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,22428, 4
[1:7:0712/141447.873135:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[22376:22400:0712/141447.928302:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/141447.936346:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x124c68da0220
[1:1:0712/141447.937017:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/141448.127843:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/141449.389838:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141449.393621:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[22376:22376:0712/141450.191323:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[22376:22376:0712/141450.191467:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/141450.365525:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141450.818549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 161db67c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/141450.818842:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141450.828914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 161db67c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/141450.829154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141450.908635:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141450.908914:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141451.297428:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141451.302454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 161db67c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/141451.302965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141451.351610:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141451.361730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 161db67c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/141451.361973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141451.374729:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[22376:22376:0712/141451.378929:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/141451.380187:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x124c68d9ee20
[1:1:0712/141451.380715:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[22376:22376:0712/141451.393423:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[22376:22376:0712/141451.424665:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[22376:22376:0712/141451.424761:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/141451.430572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141452.301156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f47472ff2e0 0x124c68ffd960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141452.302849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 161db67c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/141452.303056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141452.303972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[22376:22376:0712/141452.354546:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/141452.356273:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x124c68d9f820
[1:1:0712/141452.356437:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/141452.363093:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/141452.363274:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[22376:22376:0712/141452.367185:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[22376:22376:0712/141452.385685:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[22376:22376:0712/141452.398193:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22376:22376:0712/141452.399182:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22376:22387:0712/141452.405150:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[22376:22387:0712/141452.405239:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[22376:22376:0712/141452.405383:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[22376:22376:0712/141452.405456:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[22376:22376:0712/141452.405610:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,22428, 4
[1:7:0712/141452.415731:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/141452.907170:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/141453.320443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f47472ff2e0 0x124c6915fce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/141453.321447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 161db67c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/141453.321884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/141453.322615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[22376:22376:0712/141453.403875:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[22376:22376:0712/141453.404002:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/141453.429069:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141453.823293:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141454.193337:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141454.193512:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[22376:22376:0712/141454.250278:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[22376:22406:0712/141454.250744:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/141454.250982:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/141454.251214:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/141454.251618:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/141454.251778:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/141454.255019:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1692b390, 1
[1:1:0712/141454.255383:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xcf1b0b5, 0
[1:1:0712/141454.255550:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x306cac97, 3
[1:1:0712/141454.255692:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x25d4d8c3, 2
[1:1:0712/141454.255837:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb5ffffffb0fffffff10c ffffff90ffffffb3ffffff9216 ffffffc3ffffffd8ffffffd425 ffffff97ffffffac6c30 , 10104, 5
[1:1:0712/141454.256869:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[22376:22406:0712/141454.257112:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���������%��l0�?
[22376:22406:0712/141454.257176:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���������%��l0X-�?
[1:1:0712/141454.257283:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f475b8d60a0, 3
[22376:22406:0712/141454.257444:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 22473, 5, b5b0f10c 90b39216 c3d8d425 97ac6c30 
[1:1:0712/141454.257481:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f475ba61080, 2
[1:1:0712/141454.257664:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4745724d20, -2
[1:1:0712/141454.283687:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/141454.284167:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 25d4d8c3
[1:1:0712/141454.284562:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 25d4d8c3
[1:1:0712/141454.285331:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 25d4d8c3
[1:1:0712/141454.287069:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.287308:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.287528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.287745:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.288569:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 25d4d8c3
[1:1:0712/141454.288919:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f475d69b7ba
[1:1:0712/141454.289104:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f475d692def, 7f475d69b77a, 7f475d69d0cf
[1:1:0712/141454.296044:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 25d4d8c3
[1:1:0712/141454.296492:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 25d4d8c3
[1:1:0712/141454.297392:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 25d4d8c3
[1:1:0712/141454.299881:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.300172:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.300401:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.300637:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 25d4d8c3
[1:1:0712/141454.302176:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 25d4d8c3
[1:1:0712/141454.302621:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f475d69b7ba
[1:1:0712/141454.302783:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f475d692def, 7f475d69b77a, 7f475d69d0cf
[1:1:0712/141454.312243:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/141454.312818:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/141454.313023:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd668b5be8, 0x7ffd668b5b68)
[1:1:0712/141454.329100:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/141454.333630:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/141454.487885:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141454.492453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 161db68ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/141454.492737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/141454.500488:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/141454.588614:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x124c68d64220
[1:1:0712/141454.588877:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[22376:22376:0712/141455.311807:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[22376:22376:0712/141455.317738:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[22376:22387:0712/141455.336768:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[22376:22387:0712/141455.336866:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[22376:22376:0712/141455.337253:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.buildhr.com/
[22376:22376:0712/141455.337331:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.buildhr.com/, http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html, 1
[22376:22376:0712/141455.337463:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.buildhr.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 21:14:41 GMT Server: Apache Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Cluster_id: IDC_WEB_233 Vary: User-Agent,Accept-Encoding Content-Encoding: gzip Content-Length: 39588 Keep-Alive: timeout=5, max=100 Connection: Keep-Alive Content-Type: text/html Content-Language: zh-CN  ,22473, 5
[1:7:0712/141455.341682:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/141455.373164:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.buildhr.com/
[22376:22376:0712/141455.463243:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.buildhr.com/, http://www.buildhr.com/, 1
[22376:22376:0712/141455.463346:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.buildhr.com/, http://www.buildhr.com
[1:1:0712/141455.464201:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141455.565907:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141455.605237:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/141455.622170:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141455.622417:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141455.829970:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/141456.548718:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141456.549757:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141456.550323:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141456.551723:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141456.552207:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141456.886354:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f475ba61080 0x124c68c81740 1 0 0x124c68c81758 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141456.889096:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141456.897301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , /*! jQuery v1.10.2 | (c) 2005, 2013 jQuery Foundation, Inc. | jquery.org/license
// # sourceMappingU
[1:1:0712/141456.897595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
		remove user.10_f8d653d -> 0
		remove user.11_878b03fd -> 0
		remove user.12_9e71a842 -> 0
		remove user.13_c9af221e -> 0
		remove user.14_fc40234c -> 0
[1:1:0712/141457.142444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f475ba61080 0x124c68c81740 1 0 0x124c68c81758 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.190990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f475ba61080 0x124c68c81740 1 0 0x124c68c81758 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.250736:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141457.266610:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.274594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , /* 
 * File : c_funtype_json.js 
 * CreateTime : 2019-02-21 13:35:50 
 * 
 */
 
 /* webcode : 
[1:1:0712/141457.274993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141457.281967:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.291189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.311503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.324129:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.336097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.352410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 198 0x7f475ba61080 0x124c68f00920 1 0 0x124c68f00938 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141457.420255:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.142344, 113, 1
[1:1:0712/141457.420584:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.071873:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.072149:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.073080:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f47453d7070 0x124c68e98c60 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.074082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , 
$(function(){	
	$.getScript("http://my.buildhr.com/loginstate/pagetopbar");
});

[1:1:0712/141458.074300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141458.082489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 250 0x7f47453d7070 0x124c68e98c60 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.093377:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0210099, 51, 1
[1:1:0712/141458.093632:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.320203:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.320548:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.321955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 270 0x7f47453d7070 0x124c68e96e60 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.323517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , 
var _tipTimer=0
function showtip(tiptxt,second,top,style,url){
	if(_tipTimer){ 	window.clearTimeout
[1:1:0712/141458.323789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141458.374712:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0535932, 283, 1
[1:1:0712/141458.375023:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.561309:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.561596:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.565386:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 283 0x7f47453d7070 0x124c68e4afe0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.567032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , // JavaScript Document
// var currHy = '';
/*关键词的搜索方式*/
function showkeywordholde
[1:1:0712/141458.567257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141458.579934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 283 0x7f47453d7070 0x124c68e4afe0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.790675:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.228911, 2308, 1
[1:1:0712/141458.791030:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.920590:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141458.920900:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.922779:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 299 0x7f47453d7070 0x124c68e8e860 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141458.929961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , 
var aryhy={11:"建筑行业",14:"医药行业",29:"化工行业",12:"金融行业",22:"制造行业
[1:1:0712/141458.930206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141458.956091:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0349979, 90, 1
[1:1:0712/141458.956406:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141459.040244:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141459.040536:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.041526:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 307 0x7f47453d7070 0x124c68fca7e0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.042630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , 

[1:1:0712/141459.042879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141459.070246:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0294938, 117, 1
[1:1:0712/141459.070551:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/141459.191263:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/141459.191552:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.192577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.193677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , 
function updateAppStateText(jid){
	$('#appbtn_'+jid).attr('appstate','1').attr('title','已应聘�
[1:1:0712/141459.193983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141459.196560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.208156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.220963:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.228332:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141459.243013:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141504.058265:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/141504.117534:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x36a1de4029c8, 0x124c68be1440
[1:1:0712/141504.117830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", 0
[1:1:0712/141504.118377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.buildhr.com/, 404
[1:1:0712/141504.118619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 404 0x7f47453d7070 0x124c691edd60 , 5:3_http://www.buildhr.com/, 1, -5:3_http://www.buildhr.com/, 314 0x7f47453d7070 0x124c68ea5ce0 
[1:1:0712/141504.164127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", 13
[1:1:0712/141504.164749:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.buildhr.com/, 405
[1:1:0712/141504.165069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 405 0x7f47453d7070 0x124c69993160 , 5:3_http://www.buildhr.com/, 1, -5:3_http://www.buildhr.com/, 314 0x7f47453d7070 0x124c68ea5ce0 
[1:1:0712/141504.604948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141504.617961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141504.622106:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141504.634702:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141504.648798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 314 0x7f47453d7070 0x124c68ea5ce0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141506.265230:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141506.266169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , r, (e,i){var s,u,c,p;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=x.noop,$n&&delete 
[1:1:0712/141506.266417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141506.267675:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141506.268631:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1f36cb32e210
[1:1:0712/141506.695913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.buildhr.com/, 404, 7f4747d1c881
[1:1:0712/141506.716744:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24f922182860","ptid":"314 0x7f47453d7070 0x124c68ea5ce0 ","rf":"5:3_http://www.buildhr.com/"}
[1:1:0712/141506.717143:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.buildhr.com/","ptid":"314 0x7f47453d7070 0x124c68ea5ce0 ","rf":"5:3_http://www.buildhr.com/"}
[1:1:0712/141506.717574:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141506.718237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , (){Xn=t}
[1:1:0712/141506.718474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141506.735826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.buildhr.com/, 405, 7f4747d1c8db
[1:1:0712/141506.748415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"24f922182860","ptid":"314 0x7f47453d7070 0x124c68ea5ce0 ","rf":"5:3_http://www.buildhr.com/"}
[1:1:0712/141506.748788:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.buildhr.com/","ptid":"314 0x7f47453d7070 0x124c68ea5ce0 ","rf":"5:3_http://www.buildhr.com/"}
[1:1:0712/141506.749229:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.buildhr.com/, 479
[1:1:0712/141506.749488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 479 0x7f47453d7070 0x124c68fc4160 , 5:3_http://www.buildhr.com/, 0, , 405 0x7f47453d7070 0x124c69993160 
[1:1:0712/141506.749829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141506.750542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , x.fx.tick, (){var e,n=x.timers,r=0;for(Xn=x.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/141506.750789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141507.511716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 463 0x7f47472ff2e0 0x124c68fc59e0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.512813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , var userstatestr ='';

[1:1:0712/141507.513039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141507.513791:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.550358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f47472ff2e0 0x124c68e75ee0 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.551739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , var userstatestr ='';
userstatestr = userstatestr +'<div class="head_btn">';
userstatestr = userstat
[1:1:0712/141507.551992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141507.557837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.620243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 466 0x7f47472ff2e0 0x124c691eda60 , "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.621295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , 
[1:1:0712/141507.621542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141507.698439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.699383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , r, (e,i){var s,u,c,p;try{if(r&&(i||4===l.readyState))if(r=t,a&&(l.onreadystatechange=x.noop,$n&&delete 
[1:1:0712/141507.699696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141507.700371:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.703599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141507.704460:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x1f36cb32e210
[1:1:0712/141508.310288:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141508.311188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , v.handle, (e){return typeof x===i||e&&x.event.triggered===e.type?t:x.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/141508.311422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[1:1:0712/141508.336805:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html"
[1:1:0712/141521.422109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.buildhr.com/, 24f922182860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/141521.422459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html", "www.buildhr.com", 3, 1, , , 0
[22376:22376:0712/141521.995997:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: http://www.buildhr.com/so/kw%E7%BB%93%E6%9E%84%E8%AE%BE%E8%AE%A1-11-sm1.html (0)
[22376:22376:0712/141522.276739:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/141522.287339:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
