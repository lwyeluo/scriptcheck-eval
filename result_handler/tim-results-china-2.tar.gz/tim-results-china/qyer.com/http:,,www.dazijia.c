[0713/012934.493425:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/012934.493714:INFO:switcher_clone.cc(787)] backtrace rip is 7fbda4e9d891
[0713/012935.607507:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/012935.607858:INFO:switcher_clone.cc(787)] backtrace rip is 7f5959157891
[1:1:0713/012935.619633:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/012935.619884:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/012935.629835:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/012937.124515:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/012937.124937:INFO:switcher_clone.cc(787)] backtrace rip is 7fe891235891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[33110:33110:0713/012937.300834:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[33141:33141:0713/012937.368295:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33141
[33151:33151:0713/012937.368857:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33151

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c2a20b3a-b2be-4a7a-a62e-8b9688b619ed
[33110:33110:0713/012937.872441:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[33110:33139:0713/012937.873605:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/012937.874060:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/012937.874437:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/012937.875626:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/012937.875951:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/012937.879372:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x366e0d31, 1
[1:1:0713/012937.879763:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1d2b9d11, 0
[1:1:0713/012937.880012:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xc7b6594, 3
[1:1:0713/012937.880222:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x33ae8902, 2
[1:1:0713/012937.880443:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 11ffffff9d2b1d 310d6e36 02ffffff89ffffffae33 ffffff94657b0c , 10104, 4
[1:1:0713/012937.881564:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33110:33139:0713/012937.881817:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�+1n6��3�e{���
[33110:33139:0713/012937.881908:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �+1n6��3�e{���
[1:1:0713/012937.881818:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59573920a0, 3
[33110:33139:0713/012937.882263:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[33110:33139:0713/012937.882332:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33161, 4, 119d2b1d 310d6e36 0289ae33 94657b0c 
[1:1:0713/012937.882336:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f595751d080, 2
[1:1:0713/012937.882489:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59411e0d20, -2
[1:1:0713/012937.898779:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/012937.899618:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33ae8902
[1:1:0713/012937.900482:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33ae8902
[1:1:0713/012937.902307:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33ae8902
[1:1:0713/012937.904398:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.904670:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.904961:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.905210:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.906168:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33ae8902
[1:1:0713/012937.906573:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f59591577ba
[1:1:0713/012937.906753:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f595914edef, 7f595915777a, 7f59591590cf
[1:1:0713/012937.913357:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33ae8902
[1:1:0713/012937.913714:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33ae8902
[1:1:0713/012937.914463:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33ae8902
[1:1:0713/012937.916467:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.916656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.916864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.917059:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33ae8902
[1:1:0713/012937.918283:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33ae8902
[1:1:0713/012937.918634:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f59591577ba
[1:1:0713/012937.918783:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f595914edef, 7f595915777a, 7f59591590cf
[1:1:0713/012937.926485:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/012937.926915:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/012937.927092:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce3fc5d38, 0x7ffce3fc5cb8)
[1:1:0713/012937.942134:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/012937.947884:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[33110:33110:0713/012938.569765:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33110:33110:0713/012938.570236:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33110:33120:0713/012938.586120:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[33110:33120:0713/012938.586251:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[33110:33110:0713/012938.586446:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[33110:33110:0713/012938.586542:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[33110:33110:0713/012938.586719:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,33161, 4
[1:7:0713/012938.588740:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[33110:33133:0713/012938.682708:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/012938.699874:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3295b122a220
[1:1:0713/012938.700154:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0713/012939.043304:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/012940.507930:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012940.511306:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33110:33110:0713/012940.770279:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[33110:33110:0713/012940.770411:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/012941.688816:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/012941.931748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d1fddce1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/012941.932018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012941.948197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d1fddce1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/012941.948409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012942.056574:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012942.056875:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012942.561849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012942.570007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d1fddce1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/012942.570193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012942.603739:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012942.613953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d1fddce1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/012942.614141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012942.625619:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0713/012942.630328:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3295b1228e20
[1:1:0713/012942.630493:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[33110:33110:0713/012942.633730:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[33110:33110:0713/012942.640481:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[33110:33110:0713/012942.668255:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[33110:33110:0713/012942.668345:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/012942.725471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012943.801112:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f5942dbb2e0 0x3295b1479fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012943.802427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d1fddce1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0713/012943.802619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012943.804076:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33110:33110:0713/012943.873588:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/012943.878809:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3295b1229820
[1:1:0713/012943.879060:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[33110:33110:0713/012943.881354:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/012943.898533:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/012943.898726:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[33110:33110:0713/012943.907305:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[33110:33110:0713/012943.922471:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33110:33110:0713/012943.925441:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33110:33110:0713/012943.933829:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[33110:33110:0713/012943.933930:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[33110:33110:0713/012943.934219:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,33161, 4
[33110:33120:0713/012943.934679:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[33110:33120:0713/012943.934761:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/012943.936662:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/012944.420049:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/012945.109322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7f5942dbb2e0 0x3295b14e6c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/012945.110316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d1fddce1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/012945.110566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/012945.111314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33110:33110:0713/012945.210102:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[33110:33139:0713/012945.210520:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/012945.210729:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/012945.210991:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/012945.211395:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/012945.211560:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/012945.214735:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1f6fc693, 1
[1:1:0713/012945.215110:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2b5fcd9f, 0
[1:1:0713/012945.215294:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x32c5d14, 3
[1:1:0713/012945.215475:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1ff3d1e1, 2
[1:1:0713/012945.215682:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9fffffffcd5f2b ffffff93ffffffc66f1f ffffffe1ffffffd1fffffff31f 145d2c03 , 10104, 5
[1:1:0713/012945.216680:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33110:33139:0713/012945.216950:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��_+��o���],���
[33110:33139:0713/012945.217019:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��_+��o���],�ꖇ�
[1:1:0713/012945.216938:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59573920a0, 3
[1:1:0713/012945.217153:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f595751d080, 2
[33110:33139:0713/012945.217305:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33205, 5, 9fcd5f2b 93c66f1f e1d1f31f 145d2c03 
[1:1:0713/012945.217408:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59411e0d20, -2
[1:1:0713/012945.236420:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/012945.241663:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/012945.242028:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ff3d1e1
[1:1:0713/012945.242385:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ff3d1e1
[1:1:0713/012945.243075:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ff3d1e1
[1:1:0713/012945.244516:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.244781:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.245000:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.245217:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.245926:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ff3d1e1
[1:1:0713/012945.246249:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f59591577ba
[1:1:0713/012945.246421:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f595914edef, 7f595915777a, 7f59591590cf
[1:1:0713/012945.252489:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1ff3d1e1
[1:1:0713/012945.252944:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1ff3d1e1
[1:1:0713/012945.253752:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1ff3d1e1
[1:1:0713/012945.255923:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.256194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.256681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.256882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1ff3d1e1
[1:1:0713/012945.258128:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1ff3d1e1
[1:1:0713/012945.258493:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f59591577ba
[1:1:0713/012945.258678:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f595914edef, 7f595915777a, 7f59591590cf
[33110:33110:0713/012945.262508:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[33110:33110:0713/012945.262628:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/012945.266345:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/012945.266846:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/012945.266999:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffce3fc5d38, 0x7ffce3fc5cb8)
[1:1:0713/012945.281362:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/012945.286068:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/012945.496646:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3295b11fb220
[1:1:0713/012945.496801:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/012945.832154:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[33110:33110:0713/012946.442291:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33110:33110:0713/012946.445214:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/012946.474304:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012946.474547:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[33110:33110:0713/012946.487644:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.dazijia.com/
[33110:33110:0713/012946.487741:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.dazijia.com/, http://www.dazijia.com/, 1
[33110:33110:0713/012946.488594:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.dazijia.com/, HTTP/1.1 200 OK Server: nginx Date: Sat, 13 Jul 2019 08:24:48 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=ialtp2p1ofgf26mmttdl5vt4k5; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Pragma: no-cache Set-Cookie: guid=e536cf14c184a685eef8d7b153907e4b2154fdea; path=/ Set-Cookie: think_template=pcwap; expires=Tue, 23-Jul-2019 08:24:47 GMT; path=/ Cache-control: private X-Powered-By: PCWAP Content-Encoding: gzip  ,33205, 5
[33110:33120:0713/012946.488785:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[33110:33120:0713/012946.488937:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/012946.491725:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/012946.524943:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.dazijia.com/
[33110:33110:0713/012946.606238:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.dazijia.com/, http://www.dazijia.com/, 1
[33110:33110:0713/012946.606340:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.dazijia.com/, http://www.dazijia.com
[1:1:0713/012946.628006:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/012946.674369:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/012946.691801:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/012946.691980:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dazijia.com/"
[1:1:0713/012946.762828:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/012946.982552:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/012946.987061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d1fdde0e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/012946.987335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/012946.995017:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/012947.615124:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012947.615923:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012947.616301:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012947.616722:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012947.617343:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/012948.710020:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/013001.222145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f59411fbbd0 0x3295b1381858 , "http://www.dazijia.com/"
[1:1:0713/013001.232650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , /*! jQuery v1.11.0 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0713/013001.232960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013001.262683:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/013001.583073:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f59411fbbd0 0x3295b1381858 , "http://www.dazijia.com/"
[1:1:0713/013001.596416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f59411fbbd0 0x3295b1381858 , "http://www.dazijia.com/"
[1:1:0713/013001.619649:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f59411fbbd0 0x3295b1381858 , "http://www.dazijia.com/"
[1:1:0713/013001.626248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f59411fbbd0 0x3295b1381858 , "http://www.dazijia.com/"
[1:1:0713/013001.630074:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7f59411fbbd0 0x3295b1381858 , "http://www.dazijia.com/"
[1:1:0713/013001.738085:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.15859, 581, 1
[1:1:0713/013001.738354:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/013002.199333:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/013002.199605:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dazijia.com/"
[1:1:0713/013002.200358:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 338 0x7f5940e93070 0x3295b1733560 , "http://www.dazijia.com/"
[1:1:0713/013002.201345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , 
		$(function(){
			$('#carousel1').carousel({
				el : {
					imgsContainer	: '.carousel', // 图�
[1:1:0713/013002.201634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013002.370761:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.171087, 1471, 1
[1:1:0713/013002.371060:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/013002.424095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 343 0x7f5942dbb2e0 0x3295b14d50e0 , "http://www.dazijia.com/"
[1:1:0713/013002.424773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0713/013002.424885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013002.635822:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/013002.636074:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dazijia.com/"
[1:1:0713/013002.636908:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365 0x7f5940e93070 0x3295b150fe60 , "http://www.dazijia.com/"
[1:1:0713/013002.637739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , 
	$('#navs1').rpMaticNav();

[1:1:0713/013002.637954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013004.349384:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.71325, 0, 0
[1:1:0713/013004.349664:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/013004.496806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 374 0x7f5942dbb2e0 0x3295b12ca460 , "http://www.dazijia.com/"
[1:1:0713/013004.507294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (function(){var h={},mt={},c={id:"0d9d5986681ab9680112d32d7502d5c6",dm:["dazijia.com"],js:"tongji.ba
[1:1:0713/013004.507553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013004.537001:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089948
[1:1:0713/013004.537273:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013004.537644:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 391
[1:1:0713/013004.537879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 391 0x7f5940e93070 0x3295b16ac4e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 374 0x7f5942dbb2e0 0x3295b12ca460 
[33110:33110:0713/013022.768351:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0713/013022.817720:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/013022.944087:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 600000
[1:1:0713/013022.944589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 433
[1:1:0713/013022.944868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 433 0x7f5940e93070 0x3295b13939e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 374 0x7f5942dbb2e0 0x3295b12ca460 
[1:1:0713/013022.945784:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 5000
[1:1:0713/013022.946236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 434
[1:1:0713/013022.946521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 434 0x7f5940e93070 0x3295b12c76e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 374 0x7f5942dbb2e0 0x3295b12ca460 
[1:1:0713/013023.194911:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/013023.195180:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.dazijia.com/"
[1:1:0713/013023.207433:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.dazijia.com/"
[1:1:0713/013023.209619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , K, (){(z.addEventListener||"load"===event.type||"complete"===z.readyState)&&(J(),n.ready())}
[1:1:0713/013023.209919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013023.611101:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089c40
[1:1:0713/013023.611364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013023.611758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 464
[1:1:0713/013023.612005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 464 0x7f5940e93070 0x3295b16b3ee0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 384 0x7f5940e93070 0x3295b1731d60 
[1:1:0713/013023.697392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013023.697868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 465
[1:1:0713/013023.698146:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 465 0x7f5940e93070 0x3295b131c160 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 384 0x7f5940e93070 0x3295b1731d60 
[1:1:0713/013023.741977:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 3000
[1:1:0713/013023.742572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 466
[1:1:0713/013023.742818:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7f5940e93070 0x3295b1d20b60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 384 0x7f5940e93070 0x3295b1731d60 
[1:1:0713/013024.420573:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.dazijia.com/"
[1:1:0713/013024.613040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/013024.613401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013025.473570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 391, 7f59437d8881
[1:1:0713/013025.491298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"374 0x7f5942dbb2e0 0x3295b12ca460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013025.491679:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"374 0x7f5942dbb2e0 0x3295b12ca460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013025.492041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013025.492630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013025.492896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013025.493708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013025.493949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013025.494350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 501
[1:1:0713/013025.494605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 501 0x7f5940e93070 0x3295b20199e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 391 0x7f5940e93070 0x3295b16ac4e0 
[1:1:0713/013025.916266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 464, 7f59437d8881
[1:1:0713/013025.930728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"384 0x7f5940e93070 0x3295b1731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013025.931088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"384 0x7f5940e93070 0x3295b1731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013025.931395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013025.931932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013025.932189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013025.933877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 465, 7f59437d88db
[1:1:0713/013025.958025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"384 0x7f5940e93070 0x3295b1731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013025.958368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"384 0x7f5940e93070 0x3295b1731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013025.958747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 518
[1:1:0713/013025.958974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f5940e93070 0x3295b1d8b9e0 , 0:0_switcher://chrome, 0, , 465 0x7f5940e93070 0x3295b131c160 
[1:1:0713/013025.959293:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013025.959849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013025.960086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013026.021225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013026.021529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013026.869169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 501, 7f59437d8881
[1:1:0713/013026.895049:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"391 0x7f5940e93070 0x3295b16ac4e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013026.895404:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"391 0x7f5940e93070 0x3295b16ac4e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013026.895757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013026.896332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013026.896581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013026.897289:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013026.897516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013026.897911:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 558
[1:1:0713/013026.898169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 558 0x7f5940e93070 0x3295b141e660 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 501 0x7f5940e93070 0x3295b20199e0 
[1:1:0713/013026.967193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dazijia.com/"
[1:1:0713/013026.967935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , r.handle, (a){return typeof n===L||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,argument
[1:1:0713/013026.968332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013027.023843:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089a10
[1:1:0713/013027.024120:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013027.024512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 561
[1:1:0713/013027.024835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f5940e93070 0x3295b15118e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 510 0x7f5940e93070 0x3295b1d94960 
[1:1:0713/013027.068064:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013027.068558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 562
[1:1:0713/013027.068841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 562 0x7f5940e93070 0x3295b1ff4160 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 510 0x7f5940e93070 0x3295b1d94960 
[1:1:0713/013027.142700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dazijia.com/"
[1:1:0713/013027.143463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , r.handle, (a){return typeof n===L||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,argument
[1:1:0713/013027.143686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013027.312720:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dazijia.com/"
[1:1:0713/013027.313486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , r.handle, (a){return typeof n===L||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,argument
[1:1:0713/013027.313744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013027.417001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013027.417361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013028.373529:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 466, 7f59437d88db
[1:1:0713/013028.400140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"384 0x7f5940e93070 0x3295b1731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013028.400543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"384 0x7f5940e93070 0x3295b1731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013028.400882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 584
[1:1:0713/013028.401119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7f5940e93070 0x3295b272a560 , 0:0_switcher://chrome, 0, , 466 0x7f5940e93070 0x3295b1d20b60 
[1:1:0713/013028.401454:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013028.402117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013028.402366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013028.843929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.dazijia.com/"
[1:1:0713/013028.844686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , k.onload, (){k.onload=w;k=window[d]=w;a&&a(b)}
[1:1:0713/013028.844958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013028.864502:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.dazijia.com/"
[1:1:0713/013028.865293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , r.handle, (a){return typeof n===L||a&&n.event.triggered===a.type?void 0:n.event.dispatch.apply(k.elem,argument
[1:1:0713/013028.865560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013029.316494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 558, 7f59437d8881
[1:1:0713/013029.334530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"501 0x7f5940e93070 0x3295b20199e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.334925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"501 0x7f5940e93070 0x3295b20199e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.335286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013029.335882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013029.336099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013029.336881:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013029.337399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013029.337809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 600
[1:1:0713/013029.338044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 600 0x7f5940e93070 0x3295b2731d60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 558 0x7f5940e93070 0x3295b141e660 
[1:1:0713/013029.340008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 561, 7f59437d8881
[1:1:0713/013029.370708:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"510 0x7f5940e93070 0x3295b1d94960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.371082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"510 0x7f5940e93070 0x3295b1d94960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.371413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013029.372108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013029.372375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013029.373125:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 562, 7f59437d88db
[1:1:0713/013029.384852:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"510 0x7f5940e93070 0x3295b1d94960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.385245:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"510 0x7f5940e93070 0x3295b1d94960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.385618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 601
[1:1:0713/013029.385882:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 601 0x7f5940e93070 0x3295b268ace0 , 0:0_switcher://chrome, 0, , 562 0x7f5940e93070 0x3295b1ff4160 
[1:1:0713/013029.386229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013029.386879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013029.387125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013029.483303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013029.483643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013029.624502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 434, 7f59437d88db
[1:1:0713/013029.649968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"374 0x7f5942dbb2e0 0x3295b12ca460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.650331:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"374 0x7f5942dbb2e0 0x3295b12ca460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013029.650716:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 608
[1:1:0713/013029.650961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f5940e93070 0x3295b272a160 , 0:0_switcher://chrome, 0, , 434 0x7f5940e93070 0x3295b12c76e0 
[1:1:0713/013029.651261:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013029.651812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/013029.652035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013030.043877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 600, 7f59437d8881
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0713/013030.058305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"558 0x7f5940e93070 0x3295b141e660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013030.058721:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"558 0x7f5940e93070 0x3295b141e660 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013030.059144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013030.059908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013030.060231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013030.061108:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013030.061381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013030.061883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 613
[1:1:0713/013030.062287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7f5940e93070 0x3295b2019760 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 600 0x7f5940e93070 0x3295b2731d60 
[1:1:0713/013030.116284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013030.117676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013030.122422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 584, 7f59437d88db
[1:1:0713/013030.141223:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"466 0x7f5940e93070 0x3295b1d20b60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013030.141503:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"466 0x7f5940e93070 0x3295b1d20b60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013030.141878:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 622
[1:1:0713/013030.142065:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f5940e93070 0x3295b2a399e0 , 0:0_switcher://chrome, 0, , 584 0x7f5940e93070 0x3295b272a560 
[1:1:0713/013030.142303:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013030.142857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013030.143054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013030.246827:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013030.247104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013030.247506:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 626
[1:1:0713/013030.247768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f5940e93070 0x3295b2738fe0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 584 0x7f5940e93070 0x3295b272a560 
[1:1:0713/013030.302818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013030.303737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 627
[1:1:0713/013030.304230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f5940e93070 0x3295b1ffb260 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 584 0x7f5940e93070 0x3295b272a560 
[1:1:0713/013030.764043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013030.764340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.006467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 613, 7f59437d8881
[1:1:0713/013031.034810:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"600 0x7f5940e93070 0x3295b2731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.035228:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"600 0x7f5940e93070 0x3295b2731d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.035648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013031.036466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013031.036802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.037487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013031.037680:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013031.038131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 648
[1:1:0713/013031.038369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7f5940e93070 0x3295b2dd5f60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 613 0x7f5940e93070 0x3295b2019760 
[1:1:0713/013031.067287:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 626, 7f59437d8881
[1:1:0713/013031.082822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"584 0x7f5940e93070 0x3295b272a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.083226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"584 0x7f5940e93070 0x3295b272a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.083723:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013031.084282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013031.084493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.085964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 627, 7f59437d88db
[1:1:0713/013031.115004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"584 0x7f5940e93070 0x3295b272a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.115349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"584 0x7f5940e93070 0x3295b272a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.115695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 649
[1:1:0713/013031.115946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f5940e93070 0x3295b2adc060 , 0:0_switcher://chrome, 0, , 627 0x7f5940e93070 0x3295b1ffb260 
[1:1:0713/013031.116277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013031.116867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013031.117081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.154932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013031.155210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.502920:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 649, 7f59437d88db
[1:1:0713/013031.526583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7f5940e93070 0x3295b1ffb260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.526944:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7f5940e93070 0x3295b1ffb260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.528200:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 659
[1:1:0713/013031.528550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7f5940e93070 0x3295b264fc60 , 0:0_switcher://chrome, 0, , 649 0x7f5940e93070 0x3295b2adc060 
[1:1:0713/013031.529018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013031.529671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013031.529996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.590081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 648, 7f59437d8881
[1:1:0713/013031.616362:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"613 0x7f5940e93070 0x3295b2019760 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.616918:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"613 0x7f5940e93070 0x3295b2019760 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013031.617356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013031.618037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013031.618488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013031.619324:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013031.619607:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013031.620064:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 664
[1:1:0713/013031.620299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f5940e93070 0x3295b1d941e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 648 0x7f5940e93070 0x3295b2dd5f60 
[1:1:0713/013031.660002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013031.660326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.092390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013032.092750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.121791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 664, 7f59437d8881
[1:1:0713/013032.150851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"648 0x7f5940e93070 0x3295b2dd5f60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.151081:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"648 0x7f5940e93070 0x3295b2dd5f60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.151255:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013032.151561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013032.151666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.151966:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013032.152165:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013032.152460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 680
[1:1:0713/013032.152646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f5940e93070 0x3295b10188e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 664 0x7f5940e93070 0x3295b1d941e0 
[1:1:0713/013032.449799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013032.449974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.461824:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 680, 7f59437d8881
[1:1:0713/013032.496263:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"664 0x7f5940e93070 0x3295b1d941e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.496666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"664 0x7f5940e93070 0x3295b1d941e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.496991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013032.497658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013032.497880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.498702:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013032.498903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013032.499328:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 690
[1:1:0713/013032.499571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 690 0x7f5940e93070 0x3295b2738560 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 680 0x7f5940e93070 0x3295b10188e0 
[1:1:0713/013032.594588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013032.594843:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.721740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013032.721987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.725078:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 690, 7f59437d8881
[1:1:0713/013032.751357:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"680 0x7f5940e93070 0x3295b10188e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.751674:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"680 0x7f5940e93070 0x3295b10188e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.751935:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013032.752478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013032.752655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.753357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013032.753519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013032.753859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 699
[1:1:0713/013032.754049:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f5940e93070 0x3295b13223e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 690 0x7f5940e93070 0x3295b2738560 
[1:1:0713/013032.788907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013032.789085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.822196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 622, 7f59437d88db
[1:1:0713/013032.837027:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"584 0x7f5940e93070 0x3295b272a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.837269:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"584 0x7f5940e93070 0x3295b272a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013032.837460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 705
[1:1:0713/013032.837569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f5940e93070 0x3295b2adc260 , 0:0_switcher://chrome, 0, , 622 0x7f5940e93070 0x3295b2a399e0 
[1:1:0713/013032.837710:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013032.837998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013032.838103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013032.900311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013032.900546:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013032.900880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 706
[1:1:0713/013032.901068:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7f5940e93070 0x3295b2734ae0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 622 0x7f5940e93070 0x3295b2a399e0 
[1:1:0713/013033.022991:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013033.023277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 707
[1:1:0713/013033.023521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f5940e93070 0x3295b1d8c960 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 622 0x7f5940e93070 0x3295b2a399e0 
[1:1:0713/013033.229032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013033.229216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.427844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 699, 7f59437d8881
[1:1:0713/013033.463138:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"690 0x7f5940e93070 0x3295b2738560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.463649:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"690 0x7f5940e93070 0x3295b2738560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.464050:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013033.465400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013033.465789:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.468515:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013033.468728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013033.469129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 725
[1:1:0713/013033.469391:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f5940e93070 0x3295b1fda9e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 699 0x7f5940e93070 0x3295b13223e0 
[1:1:0713/013033.471247:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 706, 7f59437d8881
[1:1:0713/013033.497988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"622 0x7f5940e93070 0x3295b2a399e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.498212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"622 0x7f5940e93070 0x3295b2a399e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.498437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013033.498938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013033.499120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.500068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 608, 7f59437d88db
[1:1:0713/013033.516908:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"434 0x7f5940e93070 0x3295b12c76e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.517257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"434 0x7f5940e93070 0x3295b12c76e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.517677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 727
[1:1:0713/013033.517931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f5940e93070 0x3295b27311e0 , 0:0_switcher://chrome, 0, , 608 0x7f5940e93070 0x3295b272a160 
[1:1:0713/013033.518276:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013033.518807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/013033.518917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.559907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013033.560110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.561525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 707, 7f59437d88db
[1:1:0713/013033.581643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"622 0x7f5940e93070 0x3295b2a399e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.581947:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"622 0x7f5940e93070 0x3295b2a399e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.582295:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 729
[1:1:0713/013033.582586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f5940e93070 0x3295b26fdd60 , 0:0_switcher://chrome, 0, , 707 0x7f5940e93070 0x3295b1d8c960 
[1:1:0713/013033.582933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013033.583473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013033.583652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.820442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013033.820725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.942197:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 725, 7f59437d8881
[1:1:0713/013033.974463:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"699 0x7f5940e93070 0x3295b13223e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.974759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"699 0x7f5940e93070 0x3295b13223e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.975031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013033.975588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013033.975798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013033.976474:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013033.976704:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013033.977147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 740
[1:1:0713/013033.977453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7f5940e93070 0x3295b16f39e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 725 0x7f5940e93070 0x3295b1fda9e0 
[1:1:0713/013033.977939:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 729, 7f59437d88db
[1:1:0713/013033.988491:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7f5940e93070 0x3295b1d8c960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.988700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7f5940e93070 0x3295b1d8c960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013033.989023:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 742
[1:1:0713/013033.989142:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 742 0x7f5940e93070 0x3295b1316be0 , 0:0_switcher://chrome, 0, , 729 0x7f5940e93070 0x3295b26fdd60 
[1:1:0713/013033.989295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013033.989662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013033.989793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.058711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.059061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.280078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.280330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.311231:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 740, 7f59437d8881
[1:1:0713/013034.320861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"725 0x7f5940e93070 0x3295b1fda9e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.321026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"725 0x7f5940e93070 0x3295b1fda9e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.321185:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013034.321479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013034.321640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.321942:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013034.322047:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013034.322214:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 756
[1:1:0713/013034.322321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f5940e93070 0x3295b2734460 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 740 0x7f5940e93070 0x3295b16f39e0 
[1:1:0713/013034.460228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.460409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.480184:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 756, 7f59437d8881
[1:1:0713/013034.505071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"740 0x7f5940e93070 0x3295b16f39e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.505270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"740 0x7f5940e93070 0x3295b16f39e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.505437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013034.505967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013034.506187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.506994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013034.507198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013034.507624:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 760
[1:1:0713/013034.507884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 760 0x7f5940e93070 0x3295b27ce7e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 756 0x7f5940e93070 0x3295b2734460 
[1:1:0713/013034.535026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.535316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.637836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.638020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.641286:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 760, 7f59437d8881
[1:1:0713/013034.654287:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"756 0x7f5940e93070 0x3295b2734460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.654462:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"756 0x7f5940e93070 0x3295b2734460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.654645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013034.654938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013034.655040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.655332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013034.655431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013034.655633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 769
[1:1:0713/013034.655759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7f5940e93070 0x3295b2734fe0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 760 0x7f5940e93070 0x3295b27ce7e0 
[1:1:0713/013034.668115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.668277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.714415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.714588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.759106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.759344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.763062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 769, 7f59437d8881
[1:1:0713/013034.794400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"760 0x7f5940e93070 0x3295b27ce7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.794740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"760 0x7f5940e93070 0x3295b27ce7e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.795083:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013034.795644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013034.795823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.796465:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013034.796666:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013034.797117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 778
[1:1:0713/013034.797304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7f5940e93070 0x3295b0ed6060 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 769 0x7f5940e93070 0x3295b2734fe0 
[1:1:0713/013034.922593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013034.922792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.924106:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 778, 7f59437d8881
[1:1:0713/013034.933961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"769 0x7f5940e93070 0x3295b2734fe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.934097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"769 0x7f5940e93070 0x3295b2734fe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013034.934268:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013034.934526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013034.934725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013034.935027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013034.935122:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013034.935281:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 785
[1:1:0713/013034.935385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7f5940e93070 0x3295b14d43e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 778 0x7f5940e93070 0x3295b0ed6060 
[1:1:0713/013035.011555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.011856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.141756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.142002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.210191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 785, 7f59437d8881
[1:1:0713/013035.249459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"778 0x7f5940e93070 0x3295b0ed6060 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.249884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"778 0x7f5940e93070 0x3295b0ed6060 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.250278:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013035.250941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013035.251166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.256060:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013035.256244:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013035.256582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 796
[1:1:0713/013035.256836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7f5940e93070 0x3295b26fc8e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 785 0x7f5940e93070 0x3295b14d43e0 
[1:1:0713/013035.293844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.294092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.351456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.351776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.374272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.374458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.396566:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 796, 7f59437d8881
[1:1:0713/013035.407187:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"785 0x7f5940e93070 0x3295b14d43e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.407361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"785 0x7f5940e93070 0x3295b14d43e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.407514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013035.407850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013035.407955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.408248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013035.408348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013035.408512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 808
[1:1:0713/013035.408617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 808 0x7f5940e93070 0x3295b1393a60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 796 0x7f5940e93070 0x3295b26fc8e0 
[1:1:0713/013035.429148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.429388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.477182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.477390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.498454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.498617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.556427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.556599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.576216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 808, 7f59437d8881
[1:1:0713/013035.585038:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"796 0x7f5940e93070 0x3295b26fc8e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.585174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"796 0x7f5940e93070 0x3295b26fc8e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.585309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013035.585563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013035.585661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.585982:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013035.586078:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013035.586230:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 819
[1:1:0713/013035.586329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 819 0x7f5940e93070 0x3295b32d8a60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 808 0x7f5940e93070 0x3295b1393a60 
[1:1:0713/013035.735739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.736015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.739399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 819, 7f59437d8881
[1:1:0713/013035.764627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"808 0x7f5940e93070 0x3295b1393a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.764826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"808 0x7f5940e93070 0x3295b1393a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.765131:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013035.765458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013035.765566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.765906:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013035.766012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013035.766187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 824
[1:1:0713/013035.766297:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 824 0x7f5940e93070 0x3295b297fc60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 819 0x7f5940e93070 0x3295b32d8a60 
[1:1:0713/013035.790023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013035.790199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.791482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 705, 7f59437d88db
[1:1:0713/013035.802063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"622 0x7f5940e93070 0x3295b2a399e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.802222:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"622 0x7f5940e93070 0x3295b2a399e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013035.802426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 827
[1:1:0713/013035.802541:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 827 0x7f5940e93070 0x3295b1d8dd60 , 0:0_switcher://chrome, 0, , 705 0x7f5940e93070 0x3295b2adc260 
[1:1:0713/013035.802673:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013035.802962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013035.803067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013035.843450:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013035.843615:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013035.843803:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 828
[1:1:0713/013035.843939:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7f5940e93070 0x3295b0ed4de0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 705 0x7f5940e93070 0x3295b2adc260 
[1:1:0713/013036.007255:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013036.007665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 833
[1:1:0713/013036.007859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7f5940e93070 0x3295b1ffb4e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 705 0x7f5940e93070 0x3295b2adc260 
[1:1:0713/013036.218238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013036.218541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013036.475110:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 828, 7f59437d8881
[1:1:0713/013036.508762:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"705 0x7f5940e93070 0x3295b2adc260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013036.509133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"705 0x7f5940e93070 0x3295b2adc260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013036.509446:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013036.510147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013036.510368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013036.512156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 824, 7f59437d8881
[1:1:0713/013036.555695:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"819 0x7f5940e93070 0x3295b32d8a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013036.556107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"819 0x7f5940e93070 0x3295b32d8a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013036.556544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013036.557277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013036.557544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013036.558414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013036.558660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013036.559104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 849
[1:1:0713/013036.559364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f5940e93070 0x3295b1799860 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 824 0x7f5940e93070 0x3295b297fc60 
[1:1:0713/013036.561147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 833, 7f59437d88db
[1:1:0713/013036.604814:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"705 0x7f5940e93070 0x3295b2adc260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013036.605233:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"705 0x7f5940e93070 0x3295b2adc260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013036.605633:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 850
[1:1:0713/013036.605890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f5940e93070 0x3295b32d9ee0 , 0:0_switcher://chrome, 0, , 833 0x7f5940e93070 0x3295b1ffb4e0 
[1:1:0713/013036.606275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013036.606936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013036.607195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013036.647286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013036.647525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013037.066900:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 850, 7f59437d88db
[1:1:0713/013037.084323:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"833 0x7f5940e93070 0x3295b1ffb4e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013037.084501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"833 0x7f5940e93070 0x3295b1ffb4e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013037.084697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 862
[1:1:0713/013037.084886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f5940e93070 0x3295b35301e0 , 0:0_switcher://chrome, 0, , 850 0x7f5940e93070 0x3295b32d9ee0 
[1:1:0713/013037.085047:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013037.085362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013037.085471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013037.146534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013037.146901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013037.150579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 849, 7f59437d8881
[1:1:0713/013037.188028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"824 0x7f5940e93070 0x3295b297fc60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013037.188543:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"824 0x7f5940e93070 0x3295b297fc60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013037.188957:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013037.189595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013037.189815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013037.190563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013037.190766:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013037.191155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 867
[1:1:0713/013037.191445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 867 0x7f5940e93070 0x3295b1d8bae0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 849 0x7f5940e93070 0x3295b1799860 
[1:1:0713/013037.642722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013037.642970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013037.685073:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 867, 7f59437d8881
[1:1:0713/013037.701587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"849 0x7f5940e93070 0x3295b1799860 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013037.701817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"849 0x7f5940e93070 0x3295b1799860 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013037.702007:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013037.702327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013037.702431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013037.702716:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013037.702810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013037.702971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 878
[1:1:0713/013037.703075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 878 0x7f5940e93070 0x3295b297fb60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 867 0x7f5940e93070 0x3295b1d8bae0 
[1:1:0713/013037.919677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013037.919925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.031533:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 878, 7f59437d8881
[1:1:0713/013038.066901:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"867 0x7f5940e93070 0x3295b1d8bae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.067214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"867 0x7f5940e93070 0x3295b1d8bae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.067493:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.068023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013038.068199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.068865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013038.069036:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013038.069358:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 888
[1:1:0713/013038.069651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f5940e93070 0x3295b0deb9e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 878 0x7f5940e93070 0x3295b297fb60 
[1:1:0713/013038.107289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.107573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.111188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 727, 7f59437d88db
[1:1:0713/013038.139157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"608 0x7f5940e93070 0x3295b272a160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.139354:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"608 0x7f5940e93070 0x3295b272a160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.139747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 891
[1:1:0713/013038.139951:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7f5940e93070 0x3295b31e61e0 , 0:0_switcher://chrome, 0, , 727 0x7f5940e93070 0x3295b27311e0 
[1:1:0713/013038.140256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.140924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/013038.141136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.216245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.216519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.219996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 888, 7f59437d8881
[1:1:0713/013038.256241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"878 0x7f5940e93070 0x3295b297fb60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.256636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"878 0x7f5940e93070 0x3295b297fb60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.256975:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.257664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013038.257915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.258755:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013038.258963:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013038.259376:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 895
[1:1:0713/013038.259647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7f5940e93070 0x3295b31dec60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 888 0x7f5940e93070 0x3295b0deb9e0 
[1:1:0713/013038.287351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.287558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.303069:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/013038.305386:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/013038.305981:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/013038.395266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.395460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.396873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 895, 7f59437d8881
[1:1:0713/013038.409022:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"888 0x7f5940e93070 0x3295b0deb9e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.409215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"888 0x7f5940e93070 0x3295b0deb9e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.409379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.409721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013038.409838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.410152:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013038.410250:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013038.410421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 901
[1:1:0713/013038.410553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7f5940e93070 0x3295b1d8ad60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 895 0x7f5940e93070 0x3295b31dec60 
[1:1:0713/013038.448998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.449322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.525008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.525246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.529253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 901, 7f59437d8881
[1:1:0713/013038.569273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"895 0x7f5940e93070 0x3295b31dec60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.569722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"895 0x7f5940e93070 0x3295b31dec60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.570118:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.570762:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013038.570945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.571593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013038.571698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013038.571865:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 905
[1:1:0713/013038.571979:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 905 0x7f5940e93070 0x3295b2700360 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 901 0x7f5940e93070 0x3295b1d8ad60 
[1:1:0713/013038.603068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.603388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.680795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.681090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.685272:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 905, 7f59437d8881
[1:1:0713/013038.712886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"901 0x7f5940e93070 0x3295b1d8ad60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.713140:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"901 0x7f5940e93070 0x3295b1d8ad60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.713366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.713803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013038.713949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.714380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013038.714510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013038.714771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 909
[1:1:0713/013038.714923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7f5940e93070 0x3295b34bdce0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 905 0x7f5940e93070 0x3295b2700360 
[1:1:0713/013038.732646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.732902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.818691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013038.819009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.823416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 827, 7f59437d88db
[1:1:0713/013038.846467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"705 0x7f5940e93070 0x3295b2adc260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.846761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"705 0x7f5940e93070 0x3295b2adc260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013038.847069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 914
[1:1:0713/013038.847278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 914 0x7f5940e93070 0x3295b1fdaae0 , 0:0_switcher://chrome, 0, , 827 0x7f5940e93070 0x3295b1d8dd60 
[1:1:0713/013038.847529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013038.848226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013038.848456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013038.951478:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013038.951775:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013038.952115:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 915
[1:1:0713/013038.952313:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f5940e93070 0x3295b3396b60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 827 0x7f5940e93070 0x3295b1d8dd60 
[1:1:0713/013039.213604:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013039.214029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 916
[1:1:0713/013039.214220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f5940e93070 0x3295b3729ce0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 827 0x7f5940e93070 0x3295b1d8dd60 
[1:1:0713/013039.404179:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 909, 7f59437d8881
[1:1:0713/013039.450261:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"905 0x7f5940e93070 0x3295b2700360 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.450647:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"905 0x7f5940e93070 0x3295b2700360 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.450994:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013039.451743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013039.451974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013039.452813:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013039.453022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013039.453429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 922
[1:1:0713/013039.453674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f5940e93070 0x3295b1d8b6e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 909 0x7f5940e93070 0x3295b34bdce0 
[1:1:0713/013039.498672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013039.498991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013039.707953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 915, 7f59437d8881
[1:1:0713/013039.755596:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"827 0x7f5940e93070 0x3295b1d8dd60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.756047:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"827 0x7f5940e93070 0x3295b1d8dd60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.756424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013039.757084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013039.757322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013039.759320:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 916, 7f59437d88db
[1:1:0713/013039.794745:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"827 0x7f5940e93070 0x3295b1d8dd60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.794961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"827 0x7f5940e93070 0x3295b1d8dd60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.795137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 932
[1:1:0713/013039.795261:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7f5940e93070 0x3295b3396560 , 0:0_switcher://chrome, 0, , 916 0x7f5940e93070 0x3295b3729ce0 
[1:1:0713/013039.795410:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013039.795688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013039.795820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013039.884175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013039.884353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013039.885575:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 922, 7f59437d8881
[1:1:0713/013039.924147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"909 0x7f5940e93070 0x3295b34bdce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.924463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"909 0x7f5940e93070 0x3295b34bdce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013039.924736:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013039.925298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013039.925475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013039.926134:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013039.926302:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013039.926623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 937
[1:1:0713/013039.926829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7f5940e93070 0x3295b37292e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 922 0x7f5940e93070 0x3295b1d8b6e0 
[1:1:0713/013040.199309:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 932, 7f59437d88db
[1:1:0713/013040.231705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"916 0x7f5940e93070 0x3295b3729ce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.232074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"916 0x7f5940e93070 0x3295b3729ce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.232493:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 940
[1:1:0713/013040.232744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 940 0x7f5940e93070 0x3295b31ded60 , 0:0_switcher://chrome, 0, , 932 0x7f5940e93070 0x3295b3396560 
[1:1:0713/013040.233144:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013040.233827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013040.234127:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.309723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013040.310016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.333306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 937, 7f59437d8881
[1:1:0713/013040.365148:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"922 0x7f5940e93070 0x3295b1d8b6e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.365635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"922 0x7f5940e93070 0x3295b1d8b6e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.366037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013040.367203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013040.367426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.368181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013040.368429:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013040.369088:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 946
[1:1:0713/013040.369367:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7f5940e93070 0x3295b1973d60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 937 0x7f5940e93070 0x3295b37292e0 
[1:1:0713/013040.570159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013040.570402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.586546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 946, 7f59437d8881
[1:1:0713/013040.627066:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"937 0x7f5940e93070 0x3295b37292e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.627473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"937 0x7f5940e93070 0x3295b37292e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.627799:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013040.628459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013040.628683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.629528:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013040.629735:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013040.630160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 953
[1:1:0713/013040.630405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7f5940e93070 0x3295b1973ce0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 946 0x7f5940e93070 0x3295b1973d60 
[1:1:0713/013040.792370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013040.792643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.795862:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 953, 7f59437d8881
[1:1:0713/013040.829386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"946 0x7f5940e93070 0x3295b1973d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.829586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"946 0x7f5940e93070 0x3295b1973d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.829749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013040.830095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013040.830205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.830505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013040.830603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013040.830770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 956
[1:1:0713/013040.830879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 956 0x7f5940e93070 0x3295b26eca60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 953 0x7f5940e93070 0x3295b1973ce0 
[1:1:0713/013040.851646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013040.851829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.938551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013040.938733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.939981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 956, 7f59437d8881
[1:1:0713/013040.969963:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"953 0x7f5940e93070 0x3295b1973ce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.970301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"953 0x7f5940e93070 0x3295b1973ce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013040.970572:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013040.971106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013040.971296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013040.971922:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013040.972099:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013040.972426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 962
[1:1:0713/013040.972614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7f5940e93070 0x3295b37b40e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 956 0x7f5940e93070 0x3295b26eca60 
[1:1:0713/013041.005566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.005755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.091878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.092155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.095440:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 962, 7f59437d8881
[1:1:0713/013041.140144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"956 0x7f5940e93070 0x3295b26eca60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.140523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"956 0x7f5940e93070 0x3295b26eca60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.140850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013041.141541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013041.141763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.142578:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013041.142781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013041.143203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 966
[1:1:0713/013041.143447:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7f5940e93070 0x3295b2dd8460 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 962 0x7f5940e93070 0x3295b37b40e0 
[1:1:0713/013041.188924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.189208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.278573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.278829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.282101:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 966, 7f59437d8881
[1:1:0713/013041.305001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"962 0x7f5940e93070 0x3295b37b40e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.305379:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"962 0x7f5940e93070 0x3295b37b40e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.305589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013041.305923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013041.306031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.306361:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013041.306464:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013041.306638:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 970
[1:1:0713/013041.306751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 970 0x7f5940e93070 0x3295b144bbe0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 966 0x7f5940e93070 0x3295b2dd8460 
[1:1:0713/013041.343416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.343719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.430365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.430687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.434798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 970, 7f59437d8881
[1:1:0713/013041.449893:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"966 0x7f5940e93070 0x3295b2dd8460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.450080:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"966 0x7f5940e93070 0x3295b2dd8460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.450416:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013041.450787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013041.450894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.451224:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013041.451327:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013041.451495:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 974
[1:1:0713/013041.451611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7f5940e93070 0x3295b390a560 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 970 0x7f5940e93070 0x3295b144bbe0 
[1:1:0713/013041.481023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.481308:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.530391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.530650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.604964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.605217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.608393:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 974, 7f59437d8881
[1:1:0713/013041.650102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"970 0x7f5940e93070 0x3295b144bbe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.650432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"970 0x7f5940e93070 0x3295b144bbe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.650729:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013041.651267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013041.651446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.652073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013041.652249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013041.652585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 979
[1:1:0713/013041.652773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7f5940e93070 0x3295b3396b60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 974 0x7f5940e93070 0x3295b390a560 
[1:1:0713/013041.675201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.675415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.758524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013041.758861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.762592:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 914, 7f59437d88db
[1:1:0713/013041.802171:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"827 0x7f5940e93070 0x3295b1d8dd60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.802494:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"827 0x7f5940e93070 0x3295b1d8dd60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013041.802807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 984
[1:1:0713/013041.803001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7f5940e93070 0x3295b37f7560 , 0:0_switcher://chrome, 0, , 914 0x7f5940e93070 0x3295b1fdaae0 
[1:1:0713/013041.803259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013041.803761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013041.803936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013041.907182:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013041.907434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013041.907771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 985
[1:1:0713/013041.907959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f5940e93070 0x3295b1973fe0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 914 0x7f5940e93070 0x3295b1fdaae0 
[1:1:0713/013042.168104:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013042.168597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 986
[1:1:0713/013042.168859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7f5940e93070 0x3295b39b9ee0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 914 0x7f5940e93070 0x3295b1fdaae0 
[1:1:0713/013042.279242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 979, 7f59437d8881
[1:1:0713/013042.322296:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"974 0x7f5940e93070 0x3295b390a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.322616:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"974 0x7f5940e93070 0x3295b390a560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.322871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013042.323411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013042.323590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013042.324215:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013042.324393:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013042.324715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 992
[1:1:0713/013042.324905:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 992 0x7f5940e93070 0x3295b31df5e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 979 0x7f5940e93070 0x3295b3396b60 
[1:1:0713/013042.364586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013042.364837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013042.593268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 985, 7f59437d8881
[1:1:0713/013042.634272:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"914 0x7f5940e93070 0x3295b1fdaae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.634659:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"914 0x7f5940e93070 0x3295b1fdaae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.635074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013042.635752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013042.635942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013042.637415:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 986, 7f59437d88db
[1:1:0713/013042.675538:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"914 0x7f5940e93070 0x3295b1fdaae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.675848:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"914 0x7f5940e93070 0x3295b1fdaae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.676147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1000
[1:1:0713/013042.676335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7f5940e93070 0x3295b37b0460 , 0:0_switcher://chrome, 0, , 986 0x7f5940e93070 0x3295b39b9ee0 
[1:1:0713/013042.676686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013042.677178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013042.677373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013042.796091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013042.796339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013042.798218:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 992, 7f59437d8881
[1:1:0713/013042.835386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"979 0x7f5940e93070 0x3295b3396b60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.835609:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"979 0x7f5940e93070 0x3295b3396b60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013042.835805:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013042.836137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013042.836272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013042.836604:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013042.836704:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013042.836867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1005
[1:1:0713/013042.836974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7f5940e93070 0x3295b3a15960 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 992 0x7f5940e93070 0x3295b31df5e0 
[1:1:0713/013043.159096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1000, 7f59437d88db
[1:1:0713/013043.203078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"986 0x7f5940e93070 0x3295b39b9ee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.203370:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"986 0x7f5940e93070 0x3295b39b9ee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.203711:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1009
[1:1:0713/013043.204024:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7f5940e93070 0x3295b3a4f5e0 , 0:0_switcher://chrome, 0, , 1000 0x7f5940e93070 0x3295b37b0460 
[1:1:0713/013043.204361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013043.204960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013043.205178:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.279744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013043.280046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.307072:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1005, 7f59437d8881
[1:1:0713/013043.321235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"992 0x7f5940e93070 0x3295b31df5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.321426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"992 0x7f5940e93070 0x3295b31df5e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.321641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013043.321955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013043.322057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.322354:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013043.322450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013043.322630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1016
[1:1:0713/013043.322741:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7f5940e93070 0x3295b3a50260 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1005 0x7f5940e93070 0x3295b3a15960 
[1:1:0713/013043.323209:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 891, 7f59437d88db
[1:1:0713/013043.336104:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"727 0x7f5940e93070 0x3295b27311e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.336263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"727 0x7f5940e93070 0x3295b27311e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.336438:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1017
[1:1:0713/013043.336545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f5940e93070 0x3295b26ec0e0 , 0:0_switcher://chrome, 0, , 891 0x7f5940e93070 0x3295b31e61e0 
[1:1:0713/013043.336782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013043.337082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0713/013043.337251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.488817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013043.488989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.582141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1016, 7f59437d8881
[1:1:0713/013043.596991:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1005 0x7f5940e93070 0x3295b3a15960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.597202:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1005 0x7f5940e93070 0x3295b3a15960 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.597368:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013043.597704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013043.597814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.598113:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013043.598214:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013043.598389:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1026
[1:1:0713/013043.598503:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7f5940e93070 0x3295b39cb3e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1016 0x7f5940e93070 0x3295b3a50260 
[1:1:0713/013043.623470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , document.readyState
[1:1:0713/013043.623752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.765335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1026, 7f59437d8881
[1:1:0713/013043.781300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1016 0x7f5940e93070 0x3295b3a50260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.781601:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1016 0x7f5940e93070 0x3295b3a50260 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.781883:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013043.782403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013043.782577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.783329:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013043.783558:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013043.783931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1029
[1:1:0713/013043.784132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f5940e93070 0x3295b128dfe0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1026 0x7f5940e93070 0x3295b39cb3e0 
[1:1:0713/013043.910669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1029, 7f59437d8881
[1:1:0713/013043.957670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1026 0x7f5940e93070 0x3295b39cb3e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.958013:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1026 0x7f5940e93070 0x3295b39cb3e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013043.958279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013043.958830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013043.959057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013043.959696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013043.959877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013043.960203:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1032
[1:1:0713/013043.960398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1032 0x7f5940e93070 0x3295b183b6e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1029 0x7f5940e93070 0x3295b128dfe0 
[1:1:0713/013044.102307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1032, 7f59437d8881
[1:1:0713/013044.142474:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1029 0x7f5940e93070 0x3295b128dfe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.142806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1029 0x7f5940e93070 0x3295b128dfe0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.143170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013044.143868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013044.144048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013044.144682:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013044.144905:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013044.145381:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1035
[1:1:0713/013044.145647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7f5940e93070 0x3295b124eb60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1032 0x7f5940e93070 0x3295b183b6e0 
[1:1:0713/013044.287778:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1035, 7f59437d8881
[1:1:0713/013044.305713:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1032 0x7f5940e93070 0x3295b183b6e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.306067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1032 0x7f5940e93070 0x3295b183b6e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.306346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013044.306882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013044.306997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013044.307312:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013044.307440:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013044.307619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1037
[1:1:0713/013044.307739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7f5940e93070 0x3295b37f70e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1035 0x7f5940e93070 0x3295b124eb60 
[1:1:0713/013044.441656:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1037, 7f59437d8881
[1:1:0713/013044.454569:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1035 0x7f5940e93070 0x3295b124eb60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.454745:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1035 0x7f5940e93070 0x3295b124eb60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.454947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013044.455252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013044.455365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013044.455661:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013044.455762:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013044.455980:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1039
[1:1:0713/013044.456089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1039 0x7f5940e93070 0x3295b2ad6ce0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1037 0x7f5940e93070 0x3295b37f70e0 
[1:1:0713/013044.585007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1039, 7f59437d8881
[1:1:0713/013044.597811:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1037 0x7f5940e93070 0x3295b37f70e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.598006:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1037 0x7f5940e93070 0x3295b37f70e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.598165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013044.598462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013044.598564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013044.598878:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013044.598993:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013044.599155:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1041
[1:1:0713/013044.599260:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7f5940e93070 0x3295b3396460 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1039 0x7f5940e93070 0x3295b2ad6ce0 
[1:1:0713/013044.740602:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1041, 7f59437d8881
[1:1:0713/013044.781642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1039 0x7f5940e93070 0x3295b2ad6ce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.781958:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1039 0x7f5940e93070 0x3295b2ad6ce0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.782237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013044.782756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013044.782929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013044.783576:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013044.783730:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013044.784074:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1043
[1:1:0713/013044.784273:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1043 0x7f5940e93070 0x3295b3729b60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1041 0x7f5940e93070 0x3295b3396460 
[1:1:0713/013044.785647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 984, 7f59437d88db
[1:1:0713/013044.824450:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"914 0x7f5940e93070 0x3295b1fdaae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.824639:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"914 0x7f5940e93070 0x3295b1fdaae0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013044.824814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1045
[1:1:0713/013044.824918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7f5940e93070 0x3295b39cbee0 , 0:0_switcher://chrome, 0, , 984 0x7f5940e93070 0x3295b37f7560 
[1:1:0713/013044.825224:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013044.825516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013044.825618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013044.918499:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013044.918681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013044.918872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1046
[1:1:0713/013044.919007:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f5940e93070 0x3295b3a17e60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 984 0x7f5940e93070 0x3295b37f7560 
[1:1:0713/013044.929016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013044.929279:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1047
[1:1:0713/013044.929408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7f5940e93070 0x3295b2ad69e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 984 0x7f5940e93070 0x3295b37f7560 
[33110:33110:0713/013045.106244:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0713/013045.402159:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1043, 7f59437d8881
[1:1:0713/013045.426211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1041 0x7f5940e93070 0x3295b3396460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.426531:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1041 0x7f5940e93070 0x3295b3396460 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.426818:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013045.427383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013045.427574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013045.428278:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013045.428446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013045.428779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1060
[1:1:0713/013045.428976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1060 0x7f5940e93070 0x3295b28eb760 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1043 0x7f5940e93070 0x3295b3729b60 
[1:1:0713/013045.430439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1046, 7f59437d8881
[1:1:0713/013045.460521:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"984 0x7f5940e93070 0x3295b37f7560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.460758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"984 0x7f5940e93070 0x3295b37f7560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.460942:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013045.461370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013045.461504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013045.461959:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1047, 7f59437d88db
[1:1:0713/013045.476182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"984 0x7f5940e93070 0x3295b37f7560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.476381:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"984 0x7f5940e93070 0x3295b37f7560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.476566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1061
[1:1:0713/013045.476690:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1061 0x7f5940e93070 0x3295b3395160 , 0:0_switcher://chrome, 0, , 1047 0x7f5940e93070 0x3295b2ad69e0 
[1:1:0713/013045.476878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013045.477271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013045.477459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013045.819980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1061, 7f59437d88db
[1:1:0713/013045.875102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1047 0x7f5940e93070 0x3295b2ad69e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.875473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1047 0x7f5940e93070 0x3295b2ad69e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.875899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1067
[1:1:0713/013045.876145:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1067 0x7f5940e93070 0x3295b3a124e0 , 0:0_switcher://chrome, 0, , 1061 0x7f5940e93070 0x3295b3395160 
[1:1:0713/013045.876605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013045.877286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013045.877537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013045.926316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1060, 7f59437d8881
[1:1:0713/013045.957195:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1043 0x7f5940e93070 0x3295b3729b60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.957606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1043 0x7f5940e93070 0x3295b3729b60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013045.957956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013045.958352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013045.958463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013045.958776:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013045.958877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013045.959059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1073
[1:1:0713/013045.959171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1073 0x7f5940e93070 0x3295b37b4e60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1060 0x7f5940e93070 0x3295b28eb760 
[1:1:0713/013046.112693:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1067, 7f59437d88db
[1:1:0713/013046.131026:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1061 0x7f5940e93070 0x3295b3395160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.131400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1061 0x7f5940e93070 0x3295b3395160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.131793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1077
[1:1:0713/013046.132035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f5940e93070 0x3295b31deb60 , 0:0_switcher://chrome, 0, , 1067 0x7f5940e93070 0x3295b3a124e0 
[1:1:0713/013046.132473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013046.133092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013046.133349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013046.248435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1073, 7f59437d8881
[1:1:0713/013046.290162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1060 0x7f5940e93070 0x3295b28eb760 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.290565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1060 0x7f5940e93070 0x3295b28eb760 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.290930:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013046.291621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013046.291852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013046.292681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013046.292887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013046.293326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1079
[1:1:0713/013046.293575:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7f5940e93070 0x3295b2946360 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1073 0x7f5940e93070 0x3295b37b4e60 
[1:1:0713/013046.474242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1079, 7f59437d8881
[1:1:0713/013046.519033:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1073 0x7f5940e93070 0x3295b37b4e60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.519383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1073 0x7f5940e93070 0x3295b37b4e60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.519694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013046.520226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013046.520441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013046.521086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013046.521503:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013046.521904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1086
[1:1:0713/013046.522141:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1086 0x7f5940e93070 0x3295b3530d60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1079 0x7f5940e93070 0x3295b2946360 
[1:1:0713/013046.651420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1086, 7f59437d8881
[1:1:0713/013046.676301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1079 0x7f5940e93070 0x3295b2946360 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.676648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1079 0x7f5940e93070 0x3295b2946360 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.676909:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013046.677489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013046.677669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013046.678300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013046.678481:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013046.678806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1089
[1:1:0713/013046.678991:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1089 0x7f5940e93070 0x3295b26e9de0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1086 0x7f5940e93070 0x3295b3530d60 
[1:1:0713/013046.829881:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1089, 7f59437d8881
[1:1:0713/013046.867277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1086 0x7f5940e93070 0x3295b3530d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.867501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1086 0x7f5940e93070 0x3295b3530d60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013046.867680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013046.867987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013046.868090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013046.868407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013046.868523:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013046.868691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1091
[1:1:0713/013046.868800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1091 0x7f5940e93070 0x3295b1200160 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1089 0x7f5940e93070 0x3295b26e9de0 
[1:1:0713/013047.005968:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1091, 7f59437d8881
[1:1:0713/013047.034037:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1089 0x7f5940e93070 0x3295b26e9de0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.034301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1089 0x7f5940e93070 0x3295b26e9de0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.034540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013047.034960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013047.035106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013047.035566:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013047.035705:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013047.035945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1093
[1:1:0713/013047.036099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1093 0x7f5940e93070 0x3295b2738a60 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1091 0x7f5940e93070 0x3295b1200160 
[1:1:0713/013047.152877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1093, 7f59437d8881
[1:1:0713/013047.169603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1091 0x7f5940e93070 0x3295b1200160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.169812:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1091 0x7f5940e93070 0x3295b1200160 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.169971:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013047.170273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013047.170381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013047.170709:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013047.170814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013047.170991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1095
[1:1:0713/013047.171099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7f5940e93070 0x3295b10654e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1093 0x7f5940e93070 0x3295b2738a60 
[1:1:0713/013047.313576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1095, 7f59437d8881
[1:1:0713/013047.359470:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1093 0x7f5940e93070 0x3295b2738a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.359693:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1093 0x7f5940e93070 0x3295b2738a60 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.359860:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013047.360165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013047.360268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013047.360633:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013047.360746:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013047.360926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1097
[1:1:0713/013047.361036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7f5940e93070 0x3295b37baee0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1095 0x7f5940e93070 0x3295b10654e0 
[1:1:0713/013047.507972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1097, 7f59437d8881
[1:1:0713/013047.536510:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1095 0x7f5940e93070 0x3295b10654e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.536987:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1095 0x7f5940e93070 0x3295b10654e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.537337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013047.538013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013047.538247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013047.539071:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013047.539271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013047.539712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1100
[1:1:0713/013047.539958:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1100 0x7f5940e93070 0x3295b144c0e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1097 0x7f5940e93070 0x3295b37baee0 
[1:1:0713/013047.683155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1100, 7f59437d8881
[1:1:0713/013047.702354:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1097 0x7f5940e93070 0x3295b37baee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.702536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1097 0x7f5940e93070 0x3295b37baee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.702724:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013047.703037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013047.703139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013047.703439:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013047.703539:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013047.703740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1103
[1:1:0713/013047.703853:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7f5940e93070 0x3295b3da54e0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1100 0x7f5940e93070 0x3295b144c0e0 
[1:1:0713/013047.786045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1045, 7f59437d88db
[1:1:0713/013047.825148:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"984 0x7f5940e93070 0x3295b37f7560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.825339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"984 0x7f5940e93070 0x3295b37f7560 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013047.825518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1105
[1:1:0713/013047.825637:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7f5940e93070 0x3295b3a145e0 , 0:0_switcher://chrome, 0, , 1045 0x7f5940e93070 0x3295b39cbee0 
[1:1:0713/013047.825838:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013047.826130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , window.setInterval, () => {
					if ($conf.direction === 'right') changeImage(getNextElement());
					if ($conf.direct
[1:1:0713/013047.826236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013047.863606:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013047.863789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 0
[1:1:0713/013047.863975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1106
[1:1:0713/013047.864082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f5940e93070 0x3295b37f0560 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1045 0x7f5940e93070 0x3295b39cbee0 
[1:1:0713/013047.892493:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 13
[1:1:0713/013047.892782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1107
[1:1:0713/013047.892907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1107 0x7f5940e93070 0x3295b1bb6be0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1045 0x7f5940e93070 0x3295b39cbee0 
[1:1:0713/013048.355599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1103, 7f59437d8881
[1:1:0713/013048.400047:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1100 0x7f5940e93070 0x3295b144c0e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013048.400469:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1100 0x7f5940e93070 0x3295b144c0e0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013048.400764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013048.401531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?u
[1:1:0713/013048.401832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013048.402471:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xc96792229c8, 0x3295b1089950
[1:1:0713/013048.402627:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.dazijia.com/", 100
[1:1:0713/013048.402965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1119
[1:1:0713/013048.403168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1119 0x7f5940e93070 0x3295b26e0ee0 , 0:0_switcher://chrome, 1, -5:3_http://www.dazijia.com/, 1103 0x7f5940e93070 0x3295b3da54e0 
[1:1:0713/013048.404580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 0:0_switcher://chrome, 1106, 7f59437d8881
[1:1:0713/013048.448326:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1045 0x7f5940e93070 0x3295b39cbee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013048.448648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1045 0x7f5940e93070 0x3295b39cbee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013048.448947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013048.449443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , , (){_b=void 0}
[1:1:0713/013048.449630:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013048.486724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1107, 7f59437d88db
[1:1:0713/013048.501028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"096bc37e2860","ptid":"1045 0x7f5940e93070 0x3295b39cbee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013048.501231:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.dazijia.com/","ptid":"1045 0x7f5940e93070 0x3295b39cbee0 ","rf":"0:0_switcher://chrome"}
[1:1:0713/013048.501408:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1120
[1:1:0713/013048.501515:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f5940e93070 0x3295b3a17f60 , 0:0_switcher://chrome, 0, , 1107 0x7f5940e93070 0x3295b1bb6be0 
[1:1:0713/013048.501684:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0713/013048.501996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , n.fx.tick, (){var a,b=n.timers,c=0;for(_b=n.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0713/013048.502106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
[1:1:0713/013048.504607:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1017, 7f59437d88db
[1:1:0100/000000.529111:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"891 0x7f5940e93070 0x3295b31e61e0 ","rf":"0:0_switcher://chrome"}
[1:1:0100/000000.545235:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"891 0x7f5940e93070 0x3295b31e61e0 ","rf":"0:0_switcher://chrome"}
[1:1:0100/000000.545487:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 0:0_switcher://chrome, 1126
[1:1:0100/000000.545625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1126 0x7f5940e93070 0x3295b37b2f60 , 0:0_switcher://chrome, 0, , 1017 0x7f5940e93070 0x3295b26ec0e0 
[1:1:0100/000000.546017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.dazijia.com/"
[1:1:0100/000000.546917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.dazijia.com/, 096bc37e2860, , Vb, (){var a=d.O()+d.H();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0100/000000.547090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.dazijia.com/", "www.dazijia.com", 3, 1, , , 0
