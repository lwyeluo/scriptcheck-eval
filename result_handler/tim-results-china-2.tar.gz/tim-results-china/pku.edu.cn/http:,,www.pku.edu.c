[0712/155534.892218:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155534.892523:INFO:switcher_clone.cc(787)] backtrace rip is 7fb20d936891
[0712/155535.911708:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155535.912242:INFO:switcher_clone.cc(787)] backtrace rip is 7fcfca808891
[1:1:0712/155535.926674:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/155535.927007:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/155535.932365:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/155537.405973:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155537.406254:INFO:switcher_clone.cc(787)] backtrace rip is 7f67f2615891
[34604:34604:0712/155537.482328:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/93f09010-eb7b-4553-8902-11c7c0d2a727
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[34636:34636:0712/155537.636048:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=34636
[34648:34648:0712/155537.636469:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=34648
[34604:34604:0712/155537.887803:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[34604:34634:0712/155537.888705:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/155537.888969:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155537.889207:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155537.889793:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155537.889928:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/155537.892424:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xc828572, 1
[1:1:0712/155537.892757:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x5f374ef, 0
[1:1:0712/155537.892921:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1ed93bf3, 3
[1:1:0712/155537.893088:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1776d934, 2
[1:1:0712/155537.893301:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffef74fffffff305 72ffffff85ffffff820c 34ffffffd97617 fffffff33bffffffd91e , 10104, 4
[1:1:0712/155537.894259:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34604:34634:0712/155537.894485:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�t�r��4�v�;�o�a>
[34604:34634:0712/155537.894567:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �t�r��4�v�;�ȭo�a>
[1:1:0712/155537.894475:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfc8a430a0, 3
[1:1:0712/155537.894757:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfc8bce080, 2
[34604:34634:0712/155537.894960:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/155537.894922:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfb2891d20, -2
[34604:34634:0712/155537.895078:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 34656, 4, ef74f305 7285820c 34d97617 f33bd91e 
[1:1:0712/155537.914967:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155537.915832:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1776d934
[1:1:0712/155537.916496:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1776d934
[1:1:0712/155537.917523:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1776d934
[1:1:0712/155537.918070:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.918187:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.918282:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.918384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.918611:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1776d934
[1:1:0712/155537.918780:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcfca8087ba
[1:1:0712/155537.918856:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcfca7ffdef, 7fcfca80877a, 7fcfca80a0cf
[1:1:0712/155537.920311:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1776d934
[1:1:0712/155537.920475:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1776d934
[1:1:0712/155537.920769:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1776d934
[1:1:0712/155537.921443:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.921555:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.921693:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.921802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1776d934
[1:1:0712/155537.922248:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1776d934
[1:1:0712/155537.922416:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcfca8087ba
[1:1:0712/155537.922503:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcfca7ffdef, 7fcfca80877a, 7fcfca80a0cf
[1:1:0712/155537.924774:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155537.925056:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155537.925168:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaa2bfcf8, 0x7ffcaa2bfc78)
[1:1:0712/155537.943353:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155537.949859:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[34604:34604:0712/155538.600430:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34604:34604:0712/155538.604938:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[34604:34615:0712/155538.626726:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[34604:34615:0712/155538.626868:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[34604:34604:0712/155538.627115:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[34604:34604:0712/155538.627218:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[34604:34604:0712/155538.627402:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,34656, 4
[1:7:0712/155538.634806:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[34604:34628:0712/155538.671059:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/155538.684586:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2ab62c79f220
[1:1:0712/155538.684874:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/155538.949522:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/155540.197337:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155540.201345:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[34604:34604:0712/155541.002004:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[34604:34604:0712/155541.002112:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155541.281279:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155541.484813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155541.485120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155541.515595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155541.515905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155541.595925:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155541.596190:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155541.794488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155541.802828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155541.803138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155541.837445:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155541.848041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155541.848366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155541.860232:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/155541.865932:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ab62c79de20
[1:1:0712/155541.866146:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[34604:34604:0712/155541.869158:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[34604:34604:0712/155541.885217:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[34604:34604:0712/155541.915677:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[34604:34604:0712/155541.915824:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155541.960384:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155542.874558:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fcfb446c2e0 0x2ab62ca51d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155542.876116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/155542.876346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155542.877832:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[34604:34604:0712/155542.954929:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155542.956982:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ab62c79e820
[1:1:0712/155542.957189:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[34604:34604:0712/155542.970585:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/155542.981633:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/155542.981984:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[34604:34604:0712/155542.986958:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[34604:34604:0712/155542.998134:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34604:34604:0712/155542.999137:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[34604:34615:0712/155543.005271:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[34604:34615:0712/155543.005361:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[34604:34604:0712/155543.005498:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[34604:34604:0712/155543.005575:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[34604:34604:0712/155543.005706:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,34656, 4
[1:7:0712/155543.008747:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155543.448887:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/155543.774850:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7fcfb446c2e0 0x2ab62cb544e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155543.775875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/155543.776187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155543.777053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[34604:34604:0712/155543.902977:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[34604:34604:0712/155543.903160:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/155543.913753:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155544.167121:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155544.697292:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155544.697637:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155545.070364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155545.075145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/155545.075466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155545.083272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[34604:34604:0712/155545.250125:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[34604:34634:0712/155545.250643:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/155545.250962:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155545.251427:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155545.252016:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155545.252274:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/155545.255719:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1ecade67, 1
[1:1:0712/155545.256161:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x12eabdf4, 0
[1:1:0712/155545.256409:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x36199e6e, 3
[1:1:0712/155545.256615:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1cc62fec, 2
[1:1:0712/155545.256800:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff4ffffffbdffffffea12 67ffffffdeffffffca1e ffffffec2fffffffc61c 6effffff9e1936 , 10104, 5
[1:1:0712/155545.257867:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34604:34634:0712/155545.258133:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���g���/�n�6Շa>
[34604:34634:0712/155545.258203:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���g���/�n�6X�Շa>
[1:1:0712/155545.258321:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfc8a430a0, 3
[34604:34634:0712/155545.258476:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 34699, 5, f4bdea12 67deca1e ec2fc61c 6e9e1936 
[1:1:0712/155545.258577:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfc8bce080, 2
[1:1:0712/155545.258797:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfb2891d20, -2
[1:1:0712/155545.280869:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155545.281241:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1cc62fec
[1:1:0712/155545.281647:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1cc62fec
[1:1:0712/155545.282302:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1cc62fec
[1:1:0712/155545.283793:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.284045:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.284266:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.284527:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.285225:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1cc62fec
[1:1:0712/155545.285568:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcfca8087ba
[1:1:0712/155545.285750:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcfca7ffdef, 7fcfca80877a, 7fcfca80a0cf
[1:1:0712/155545.291475:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1cc62fec
[1:1:0712/155545.291884:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1cc62fec
[1:1:0712/155545.292666:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1cc62fec
[1:1:0712/155545.294712:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.294965:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.295205:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.295450:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1cc62fec
[1:1:0712/155545.296763:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1cc62fec
[1:1:0712/155545.297164:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcfca8087ba
[1:1:0712/155545.297381:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcfca7ffdef, 7fcfca80877a, 7fcfca80a0cf
[1:1:0712/155545.305062:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155545.305593:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155545.305779:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaa2bfcf8, 0x7ffcaa2bfc78)
[1:1:0712/155545.319278:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155545.323545:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/155545.343586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155545.344385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3c2ec2221f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/155545.344621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155545.517933:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155545.519656:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/155545.519949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/155545.520231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155545.550931:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ab62c76c220
[1:1:0712/155545.551174:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/155545.641621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155545.642590:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/155545.642837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/155545.643132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[34604:34604:0712/155545.960637:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34604:34604:0712/155546.006249:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[34604:34634:0712/155546.006648:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/155546.006866:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155546.007104:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155546.007591:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155546.007845:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/155546.010728:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x10afdffb, 1
[1:1:0712/155546.011019:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2f56e865, 0
[1:1:0712/155546.011228:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x22e687d8, 3
[1:1:0712/155546.011398:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e8485a7, 2
[1:1:0712/155546.011612:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 65ffffffe8562f fffffffbffffffdfffffffaf10 ffffffa7ffffff85ffffff841e ffffffd8ffffff87ffffffe622 , 10104, 6
[1:1:0712/155546.012573:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34604:34634:0712/155546.012852:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGe�V/�߯���؇�"��a>
[34604:34634:0712/155546.012920:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is e�V/�߯���؇�"\��a>
[1:1:0712/155546.012843:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfc8a430a0, 3
[1:1:0712/155546.013024:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfc8bce080, 2
[34604:34634:0712/155546.013154:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 34716, 6, 65e8562f fbdfaf10 a785841e d887e622 
[1:1:0712/155546.013197:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fcfb2891d20, -2
[1:1:0712/155546.031931:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155546.032155:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e8485a7
[1:1:0712/155546.032300:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e8485a7
[1:1:0712/155546.032574:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e8485a7
[1:1:0712/155546.033045:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.033157:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.033253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.033345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.033616:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e8485a7
[1:1:0712/155546.033757:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcfca8087ba
[1:1:0712/155546.033835:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcfca7ffdef, 7fcfca80877a, 7fcfca80a0cf
[1:1:0712/155546.035332:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e8485a7
[1:1:0712/155546.035559:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e8485a7
[1:1:0712/155546.035848:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e8485a7
[1:1:0712/155546.036564:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.036690:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.036791:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.036888:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8485a7
[1:1:0712/155546.037333:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e8485a7
[1:1:0712/155546.037500:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fcfca8087ba
[1:1:0712/155546.037625:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fcfca7ffdef, 7fcfca80877a, 7fcfca80a0cf
[34604:34604:0712/155546.038261:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/155546.039848:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155546.040166:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155546.040259:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcaa2bfcf8, 0x7ffcaa2bfc78)
[34604:34615:0712/155546.051134:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[34604:34615:0712/155546.051226:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[34604:34604:0712/155546.051468:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.pku.edu.cn/
[34604:34604:0712/155546.051506:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.pku.edu.cn/, https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665, 1
[34604:34604:0712/155546.051628:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.pku.edu.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 22:56:40 GMT Server: Apache/2.2.15 (CentOS) Last-Modified: Wed, 10 Jul 2019 06:16:30 GMT ETag: "21443-76c3-58d4d9e44f32a" Accept-Ranges: bytes Content-Length: 30403 Keep-Alive: timeout=15, max=100 Connection: Keep-Alive Content-Type: text/html; charset=UTF-8  ,0, 6
[1:1:0712/155546.052785:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155546.057166:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/155546.059283:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/155546.137208:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155546.264103:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ab62c7a5220
[1:1:0712/155546.264359:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/155546.323318:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://popcash.net/"
[1:1:0712/155546.355217:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.pku.edu.cn/
[1:1:0712/155546.436029:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/155546.535029:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.alibaba.com/"
[1:1:0712/155546.600464:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/155546.690244:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.1688.com/"
[1:1:0712/155546.697511:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[34604:34604:0712/155546.701698:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.pku.edu.cn/, https://www.pku.edu.cn/, 1
[34604:34604:0712/155546.701789:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.pku.edu.cn/, https://www.pku.edu.cn
[1:1:0712/155546.768854:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.aliexpress.com/"
[1:1:0712/155546.837003:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155546.867962:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://qq.com/"
[1:1:0712/155546.952146:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/155546.995874:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155546.996110:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155547.081807:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155547.082735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/155547.083031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155547.569325:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155547.779014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155547.780007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/155547.780288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155547.849855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155547.850796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/155547.851104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155547.983184:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155547.984155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/155547.984434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155548.118053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155548.118952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/155548.119238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155548.190264:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155548.191211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/155548.191493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155548.286176:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155548.287116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/155548.287400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155548.351568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155548.352568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/155548.352890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155548.446876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fcfb28acbd0 0x2ab62c945158 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155548.452617:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155548.461730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindo
[1:1:0712/155548.461977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155548.498101:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155548.498962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3c2ec234e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/155548.499257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155548.700735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fcfb28acbd0 0x2ab62c945158 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155548.704349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fcfb28acbd0 0x2ab62c945158 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155548.727622:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fcfb28acbd0 0x2ab62c945158 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155548.810875:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.114142, 686, 1
[1:1:0712/155548.811133:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/155549.300184:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155549.300495:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155549.301568:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 296 0x7fcfb2544070 0x2ab62cac94e0 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155549.303177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , 
	var _filename_ = location.pathname.match(/[^\/]+$/);

 	if (_filename_ != null && _filename_.lengt
[1:1:0712/155549.303442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155549.409684:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155549.410517:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155549.410883:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155549.411345:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155549.411767:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155549.472690:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.172049, 200, 1
[1:1:0712/155549.472976:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155549.869887:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155549.870166:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155549.871041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fcfb2544070 0x2ab62cbffb60 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155549.872555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , 
	window._bd_share_config={
		"common":{
			"bdSnsKey":{},
			"bdText":"",
			"bdMini":"2",
			"bdMi
[1:1:0712/155549.872780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155549.907917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 328 0x7fcfb2544070 0x2ab62cbffb60 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155549.916766:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155551.973167:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155551.974076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , d, (a,e){var j,k,l,m,n;try{if(d&&(e||h.readyState===4)){d=b,i&&(h.onreadystatechange=f.noop,ce&&delete 
[1:1:0712/155551.976164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155551.978021:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155551.981068:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155551.981821:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2bcddb3b5d80
[1:1:0712/155552.101456:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 387 0x7fcfb446c2e0 0x2ab62c7f4860 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155552.109683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main?window._bd_share_is_recently_loaded=!0:(window._bd_share_is_recently_loaded=!1
[1:1:0712/155552.109958:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155552.213058:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d1c8
[1:1:0712/155552.213342:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155552.213794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 414
[1:1:0712/155552.214054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7fcfb2544070 0x2ab62d266160 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 387 0x7fcfb446c2e0 0x2ab62c7f4860 
[1:1:0712/155552.226535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d1c8
[1:1:0712/155552.227048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155552.227532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 416
[1:1:0712/155552.227826:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7fcfb2544070 0x2ab62d298de0 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 387 0x7fcfb446c2e0 0x2ab62c7f4860 
[1:1:0712/155552.232363:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x3d058c3629c8, 0x2ab62c62d1c8
[1:1:0712/155552.235737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 3000
[1:1:0712/155552.236225:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 418
[1:1:0712/155552.236485:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 418 0x7fcfb2544070 0x2ab62d29b060 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 387 0x7fcfb446c2e0 0x2ab62c7f4860 
[1:1:0712/155552.732611:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7fcfb446c2e0 0x2ab62c48d0e0 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155552.734129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main.F.module("share/share_api",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/155552.734366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155552.743625:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d190
[1:1:0712/155552.743881:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155552.744356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 438
[1:1:0712/155552.744586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 438 0x7fcfb2544070 0x2ab62d2e40e0 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 429 0x7fcfb446c2e0 0x2ab62c48d0e0 
[1:1:0712/155552.774396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d190
[1:1:0712/155552.774657:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155552.775124:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 441
[1:1:0712/155552.775388:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 441 0x7fcfb2544070 0x2ab62d2fd5e0 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 429 0x7fcfb446c2e0 0x2ab62c48d0e0 
[1:1:0712/155552.780798:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155552.813836:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 430 0x7fcfb446c2e0 0x2ab62d2965e0 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155552.815777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main.F.module("view/share_view",function(e,t,n){var r=e("base/tangram").T,i=e("base
[1:1:0712/155552.816429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155552.846114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d190
[1:1:0712/155552.846636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155552.849752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 445
[1:1:0712/155552.850028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 445 0x7fcfb2544070 0x2ab62d3461e0 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 430 0x7fcfb446c2e0 0x2ab62d2965e0 
[1:1:0712/155552.854598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155553.215118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 454 0x7fcfb446c2e0 0x2ab62d32f3e0 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155553.217119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main.F.module("share/api_base",function(e,t,n){var r=e("base/tangram").T,i=e("base/
[1:1:0712/155553.217369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155553.231914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155553.259772:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 455 0x7fcfb446c2e0 0x2ab62d33ee60 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155553.261693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main.F.module("view/view_base",function(e,t,n){var r=e("base/tangram").T,i=e("conf/
[1:1:0712/155553.261917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155553.281849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155553.354803:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 458 0x7fcfb446c2e0 0x2ab62d264c60 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155553.372909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main.F.module("base/tangram",function(e,t){var n,r=n=function(){var e,t=e=t||functi
[1:1:0712/155553.373190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155553.907753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d148
[1:1:0712/155553.908063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155553.908570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 466
[1:1:0712/155553.908805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7fcfb2544070 0x2ab62d4dac60 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 458 0x7fcfb446c2e0 0x2ab62d264c60 
[1:1:0712/155554.070040:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3d058c3629c8, 0x2ab62c62d148
[1:1:0712/155554.070360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 0
[1:1:0712/155554.071039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 469
[1:1:0712/155554.071334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7fcfb2544070 0x2ab62d51e2e0 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 458 0x7fcfb446c2e0 0x2ab62d264c60 
[1:1:0712/155554.071922:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d148
[1:1:0712/155554.072154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155554.072609:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 470
[1:1:0712/155554.072852:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 470 0x7fcfb2544070 0x2ab62d56a060 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 458 0x7fcfb446c2e0 0x2ab62d264c60 
[1:1:0712/155554.090313:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155554.509839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 482 0x7fcfb446c2e0 0x2ab62d592960 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155554.511605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , window._bd_share_main.F.module("component/partners",function(e,t){t.partners={evernotecn:{name:"\u53
[1:1:0712/155554.511873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155554.560063:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155554.568428:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 469, 7fcfb4e89881
[1:1:0712/155554.589823:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c9c68342860","ptid":"458 0x7fcfb446c2e0 0x2ab62d264c60 ","rf":"6:3_https://www.pku.edu.cn/"}
[1:1:0712/155554.590212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.pku.edu.cn/","ptid":"458 0x7fcfb446c2e0 0x2ab62d264c60 ","rf":"6:3_https://www.pku.edu.cn/"}
[1:1:0712/155554.590560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155554.591218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , (){c(e,t)}
[1:1:0712/155554.591434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155554.594477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3d058c3629c8, 0x2ab62c62d150
[1:1:0712/155554.594743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 1
[1:1:0712/155554.595205:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 490
[1:1:0712/155554.595438:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 490 0x7fcfb2544070 0x2ab62d511d60 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 469 0x7fcfb2544070 0x2ab62d51e2e0 
[1:1:0712/155554.643831:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155554.644686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , ready, (a){if(a===!0&&!--e.readyWait||a!==!0&&!e.isReady){if(!c.body)return setTimeout(e.ready,1);e.isReady
[1:1:0712/155554.644922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155554.645439:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155555.490918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 490, 7fcfb4e89881
[1:1:0712/155555.513230:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c9c68342860","ptid":"469 0x7fcfb2544070 0x2ab62d51e2e0 ","rf":"6:3_https://www.pku.edu.cn/"}
[1:1:0712/155555.515010:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.pku.edu.cn/","ptid":"469 0x7fcfb2544070 0x2ab62d51e2e0 ","rf":"6:3_https://www.pku.edu.cn/"}
[1:1:0712/155555.515419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155555.516170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , (){n?t&&t():c(e,t)}
[1:1:0712/155555.516397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155555.601762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 418, 7fcfb4e89881
[1:1:0712/155555.624810:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2c9c68342860","ptid":"387 0x7fcfb446c2e0 0x2ab62c7f4860 ","rf":"6:3_https://www.pku.edu.cn/"}
[1:1:0712/155555.625241:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.pku.edu.cn/","ptid":"387 0x7fcfb446c2e0 0x2ab62c7f4860 ","rf":"6:3_https://www.pku.edu.cn/"}
[1:1:0712/155555.625578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155555.626275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , (){window._bd_share_main.F.use("trans/logger",function(e){e.nsClick(),e.back(),e.duration()})}
[1:1:0712/155555.626536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155555.633876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x3d058c3629c8, 0x2ab62c62d150
[1:1:0712/155555.634091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", 15000
[1:1:0712/155555.634544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.pku.edu.cn/, 497
[1:1:0712/155555.634833:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7fcfb2544070 0x2ab62d764060 , 6:3_https://www.pku.edu.cn/, 1, -6:3_https://www.pku.edu.cn/, 418 0x7fcfb2544070 0x2ab62d29b060 
[1:1:0712/155555.713698:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7fcfb446c2e0 0x2ab62d731460 , "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155555.714684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , 
[1:1:0712/155555.714934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155555.715508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155616.117649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/155616.117987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[34604:34604:0712/155616.750956:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/155616.764301:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/155617.747010:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665"
[1:1:0712/155617.747930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.pku.edu.cn/, 2c9c68342860, , i, (a){return typeof f!="undefined"&&(!a||f.event.triggered!==a.type)?f.event.dispatch.apply(i.elem,arg
[1:1:0712/155617.748208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.pku.edu.cn/tzgg/tzggxx/index.htm?id=242665", "www.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155618.157803:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155618.158650:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
