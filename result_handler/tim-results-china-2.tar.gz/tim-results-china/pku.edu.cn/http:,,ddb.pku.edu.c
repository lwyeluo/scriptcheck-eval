[0712/160226.741698:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/160226.742308:INFO:switcher_clone.cc(787)] backtrace rip is 7f4bc103c891
[0712/160228.048011:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/160228.048329:INFO:switcher_clone.cc(787)] backtrace rip is 7fa204e4b891
[1:1:0712/160228.059034:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/160228.059335:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/160228.065245:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[35666:35666:0712/160229.761511:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/160229.778595:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/160229.779092:INFO:switcher_clone.cc(787)] backtrace rip is 7feab7f5b891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bd5f50ee-0c2b-45bb-b11f-eb8daad1ee5d
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[35698:35698:0712/160230.168457:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35698
[35711:35711:0712/160230.168898:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35711
[35666:35666:0712/160230.348384:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[35666:35696:0712/160230.349227:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/160230.349571:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/160230.349869:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/160230.350628:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/160230.350791:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/160230.354185:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1e5c2f61, 1
[1:1:0712/160230.354619:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1d1d664e, 0
[1:1:0712/160230.354827:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3269c208, 3
[1:1:0712/160230.354994:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30bad92c, 2
[1:1:0712/160230.355222:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4e661d1d 612f5c1e 2cffffffd9ffffffba30 08ffffffc26932 , 10104, 4
[1:1:0712/160230.356231:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35666:35696:0712/160230.356518:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGNfa/\,ٺ0�i2f<�
[35666:35696:0712/160230.356587:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Nfa/\,ٺ0�i2�f<�
[1:1:0712/160230.356498:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2030860a0, 3
[1:1:0712/160230.356700:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa203211080, 2
[35666:35696:0712/160230.356917:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/160230.356856:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa1eced4d20, -2
[35666:35696:0712/160230.356992:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35719, 4, 4e661d1d 612f5c1e 2cd9ba30 08c26932 
[1:1:0712/160230.378160:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/160230.379097:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30bad92c
[1:1:0712/160230.380120:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30bad92c
[1:1:0712/160230.382090:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30bad92c
[1:1:0712/160230.384137:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.384485:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.384743:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.385009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.385842:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30bad92c
[1:1:0712/160230.386294:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa204e4b7ba
[1:1:0712/160230.386470:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa204e42def, 7fa204e4b77a, 7fa204e4d0cf
[1:1:0712/160230.393689:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30bad92c
[1:1:0712/160230.394158:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30bad92c
[1:1:0712/160230.395079:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30bad92c
[1:1:0712/160230.397656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.397908:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.398145:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.398395:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30bad92c
[1:1:0712/160230.399989:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30bad92c
[1:1:0712/160230.400473:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa204e4b7ba
[1:1:0712/160230.400648:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa204e42def, 7fa204e4b77a, 7fa204e4d0cf
[1:1:0712/160230.409636:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/160230.410106:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/160230.410268:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdeec46408, 0x7ffdeec46388)
[1:1:0712/160230.429029:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/160230.434948:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[35666:35666:0712/160230.864346:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[35666:35666:0712/160231.059530:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35666:35666:0712/160231.061322:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35666:35678:0712/160231.083813:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[35666:35678:0712/160231.083946:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[35666:35666:0712/160231.084026:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[35666:35666:0712/160231.084106:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[35666:35666:0712/160231.084247:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,35719, 4
[1:7:0712/160231.086704:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160231.153306:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x320c460e0220
[1:1:0712/160231.153630:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[35666:35689:0712/160231.404207:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/160231.544151:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/160233.836407:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160233.841358:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[35666:35666:0712/160234.033057:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[35666:35666:0712/160234.033193:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/160235.022919:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160235.379193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cdebe421f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/160235.379488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160235.399897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cdebe421f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/160235.400259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160235.561966:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160235.562255:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160235.976320:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160235.985116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cdebe421f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/160235.985332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160236.036431:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160236.039666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cdebe421f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/160236.039807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160236.044409:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/160236.047880:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x320c460dee20
[1:1:0712/160236.048130:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[35666:35666:0712/160236.049582:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[35666:35666:0712/160236.056945:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[35666:35666:0712/160236.087790:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[35666:35666:0712/160236.087892:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/160236.150894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[35666:35666:0712/160236.730182:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[35666:35696:0712/160236.730763:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/160236.731013:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/160236.731279:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/160236.731748:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/160236.731915:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/160236.735518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2fd28b54, 1
[1:1:0712/160236.735884:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x320ebca0, 0
[1:1:0712/160236.736040:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x37af7fd9, 3
[1:1:0712/160236.736296:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1255f922, 2
[1:1:0712/160236.736485:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa0ffffffbc0e32 54ffffff8bffffffd22f 22fffffff95512 ffffffd97fffffffaf37 , 10104, 5
[1:1:0712/160236.737718:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[35666:35696:0712/160236.737991:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��2T��/"�U��7??�
[35666:35696:0712/160236.738090:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��2T��/"�U��7��??�
[1:1:0712/160236.738240:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa2030860a0, 3
[35666:35696:0712/160236.738384:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35762, 5, a0bc0e32 548bd22f 22f95512 d97faf37 
[1:1:0712/160236.738457:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa203211080, 2
[1:1:0712/160236.738703:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa1eced4d20, -2
[1:1:0712/160236.756492:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/160236.756847:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1255f922
[1:1:0712/160236.757192:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1255f922
[1:1:0712/160236.757821:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1255f922
[1:1:0712/160236.759280:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.759468:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.759652:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.759848:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.760521:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1255f922
[1:1:0712/160236.760813:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa204e4b7ba
[1:1:0712/160236.760961:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa204e42def, 7fa204e4b77a, 7fa204e4d0cf
[1:1:0712/160236.766636:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1255f922
[1:1:0712/160236.766987:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1255f922
[1:1:0712/160236.767874:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1255f922
[1:1:0712/160236.770409:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.770690:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.770933:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.771193:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1255f922
[1:1:0712/160236.772761:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1255f922
[1:1:0712/160236.773243:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa204e4b7ba
[1:1:0712/160236.773422:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa204e42def, 7fa204e4b77a, 7fa204e4d0cf
[1:1:0712/160236.782482:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/160236.783002:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/160236.783189:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdeec46408, 0x7ffdeec46388)
[1:1:0712/160236.797886:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/160236.802641:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/160237.024366:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x320c460a9220
[1:1:0712/160237.024576:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/160237.211747:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7fa1eeaaf2e0 0x320c46219460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160237.213316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3cdebe421f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/160237.213557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160237.215351:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[35666:35666:0712/160237.297406:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160237.299419:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x320c460df820
[1:1:0712/160237.299679:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[35666:35666:0712/160237.305490:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/160237.322001:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160237.322290:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[35666:35666:0712/160237.328505:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[35666:35666:0712/160237.343434:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35666:35666:0712/160237.344530:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35666:35678:0712/160237.346968:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[35666:35678:0712/160237.347067:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[35666:35666:0712/160237.347333:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[35666:35666:0712/160237.347425:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[35666:35666:0712/160237.347608:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,35719, 4
[1:7:0712/160237.351106:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[35666:35666:0712/160237.540813:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[35666:35666:0712/160237.545740:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[35666:35678:0712/160237.594003:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[35666:35678:0712/160237.594101:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[35666:35666:0712/160237.594650:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://ddb.pku.edu.cn/
[35666:35666:0712/160237.595519:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://ddb.pku.edu.cn/, http://ddb.pku.edu.cn/rexian/, 1
[35666:35666:0712/160237.595734:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://ddb.pku.edu.cn/, HTTP/1.1 200 OK Server: Apache-Coyote/1.1 Accept-Ranges: bytes ETag: W/"5305-1554993845000" Last-Modified: Thu, 11 Apr 2019 14:44:05 GMT Content-Type: text/html Content-Length: 5305 Date: Fri, 12 Jul 2019 23:01:26 GMT  ,35762, 5
[1:7:0712/160237.598468:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160237.627406:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://ddb.pku.edu.cn/
[35666:35666:0712/160237.757057:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://ddb.pku.edu.cn/, http://ddb.pku.edu.cn/, 1
[35666:35666:0712/160237.757122:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://ddb.pku.edu.cn/, http://ddb.pku.edu.cn
[1:1:0712/160237.765869:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160237.862571:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160237.934426:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160237.934755:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://ddb.pku.edu.cn/rexian/"
[1:1:0712/160237.959762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7fa1ecb87070 0x320c460e4660 , "http://ddb.pku.edu.cn/rexian/"
[1:1:0712/160237.963856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://ddb.pku.edu.cn/, 052080c62860, , , 
<!--
function PwdInput(pwd_item){
var pwd=document.getElementById("password");
pwd_item.style.displ
[1:1:0712/160237.964160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://ddb.pku.edu.cn/rexian/", "ddb.pku.edu.cn", 3, 1, , , 0
[1:1:0712/160238.062634:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/160238.359961:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://ddb.pku.edu.cn/rexian/"
[1:1:0712/160238.361998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://ddb.pku.edu.cn/, 052080c62860, , onload, getfocus()
[1:1:0712/160238.362256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://ddb.pku.edu.cn/rexian/", "ddb.pku.edu.cn", 3, 1, , , 0
[1:1:0712/160239.428172:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160239.429072:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160239.429500:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160239.429959:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160239.430350:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160309.028796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://ddb.pku.edu.cn/, 052080c62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/160309.029048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://ddb.pku.edu.cn/rexian/", "ddb.pku.edu.cn", 3, 1, , , 0
[1:1:0712/160309.030155:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[35666:35666:0712/160309.350980:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: http://ddb.pku.edu.cn/rexian/ (0)
[35666:35666:0712/160309.364300:INFO:CONSOLE(96)] "Uncaught TypeError: Cannot read property 'focus' of null", source: http://ddb.pku.edu.cn/rexian/ (96)
[35666:35666:0712/160309.474475:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/160309.546083:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
