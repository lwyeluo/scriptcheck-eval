[0712/154834.380764:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/154834.381183:INFO:switcher_clone.cc(787)] backtrace rip is 7f5cd5930891
[0712/154835.434938:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/154835.435338:INFO:switcher_clone.cc(787)] backtrace rip is 7f2a2e360891
[1:1:0712/154835.447556:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/154835.447910:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/154835.454156:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[33567:33567:0712/154836.537607:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/f03f7899-3425-41cc-9742-14465d28e65b
[0712/154836.953316:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/154836.953718:INFO:switcher_clone.cc(787)] backtrace rip is 7f11890c3891
[33567:33567:0712/154837.036842:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[33567:33599:0712/154837.037636:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/154837.037885:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/154837.038166:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/154837.038822:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/154837.039017:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/154837.042062:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2250a00c, 1
[1:1:0712/154837.042400:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e7fea18, 0
[1:1:0712/154837.042600:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x34be37d3, 3
[1:1:0712/154837.042841:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1faa8db2, 2
[1:1:0712/154837.043092:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 18ffffffea7f2e 0cffffffa05022 ffffffb2ffffff8dffffffaa1f ffffffd337ffffffbe34 , 10104, 4
[1:1:0712/154837.044101:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33567:33599:0712/154837.044367:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�.�P"����7�4���+
[33567:33599:0712/154837.044451:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �.�P"����7�4����+
[1:1:0712/154837.044355:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a2c59b0a0, 3
[33567:33599:0712/154837.044737:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[33567:33599:0712/154837.044827:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33614, 4, 18ea7f2e 0ca05022 b28daa1f d337be34 
[1:1:0712/154837.044824:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a2c726080, 2
[1:1:0712/154837.045022:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a163e9d20, -2
[1:1:0712/154837.069308:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/154837.070226:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1faa8db2
[1:1:0712/154837.071203:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1faa8db2
[1:1:0712/154837.072872:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1faa8db2
[1:1:0712/154837.074369:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.074624:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.074883:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.075118:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.075835:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1faa8db2
[1:1:0712/154837.076203:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a2e3607ba
[1:1:0712/154837.076379:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a2e357def, 7f2a2e36077a, 7f2a2e3620cf
[1:1:0712/154837.082194:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1faa8db2
[1:1:0712/154837.082576:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1faa8db2
[1:1:0712/154837.083366:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1faa8db2
[1:1:0712/154837.085481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.085738:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.086023:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.086258:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1faa8db2
[1:1:0712/154837.087537:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1faa8db2
[1:1:0712/154837.087986:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a2e3607ba
[1:1:0712/154837.088167:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a2e357def, 7f2a2e36077a, 7f2a2e3620cf
[1:1:0712/154837.097285:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/154837.097778:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/154837.097964:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07119638, 0x7ffe071195b8)
[1:1:0712/154837.114746:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/154837.122420:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[33601:33601:0712/154837.228118:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33601
[33628:33628:0712/154837.228550:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=33628
[33567:33567:0712/154837.655702:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33567:33567:0712/154837.657150:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33567:33580:0712/154837.672989:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[33567:33580:0712/154837.673094:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[33567:33567:0712/154837.673331:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[33567:33567:0712/154837.673426:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[33567:33567:0712/154837.673598:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,33614, 4
[1:7:0712/154837.678343:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[33567:33593:0712/154837.718857:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/154837.805057:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x100e0d232220
[1:1:0712/154837.805341:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/154838.201302:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/154839.970560:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154839.974223:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33567:33567:0712/154840.072538:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[33567:33567:0712/154840.072626:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/154841.095753:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/154841.399715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/154841.400091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154841.420786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/154841.421074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154841.478533:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/154841.478708:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154841.950809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154841.953491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/154841.953635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154841.970144:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154841.973240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/154841.973375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154841.977543:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/154841.980691:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x100e0d230e20
[1:1:0712/154841.980859:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[33567:33567:0712/154841.989698:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[33567:33567:0712/154841.997105:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[33567:33567:0712/154842.031843:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[33567:33567:0712/154842.032016:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/154842.063573:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154842.783629:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7f2a17fc42e0 0x100e0d4c98e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154842.784380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/154842.784845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154842.786342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33567:33567:0712/154842.858754:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/154842.859711:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x100e0d231820
[1:1:0712/154842.859917:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[33567:33567:0712/154842.872048:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/154842.878341:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/154842.878534:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[33567:33567:0712/154842.895068:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[33567:33567:0712/154842.912445:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33567:33567:0712/154842.913355:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[33567:33567:0712/154842.915001:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[33567:33567:0712/154842.915039:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[33567:33580:0712/154842.915035:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[33567:33567:0712/154842.915098:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,33614, 4
[33567:33580:0712/154842.915195:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/154842.920978:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/154843.457099:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/154843.833748:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f2a17fc42e0 0x100e0d516b60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154843.834856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/154843.835166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154843.836929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[33567:33567:0712/154844.022268:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[33567:33567:0712/154844.022506:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/154844.034429:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/154844.466799:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[33567:33567:0712/154844.794476:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[33567:33599:0712/154844.794905:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/154844.795106:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/154844.795431:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/154844.796001:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/154844.796189:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/154844.799818:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa95fe38, 1
[1:1:0712/154844.800224:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25185291, 0
[1:1:0712/154844.800389:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e11916b, 3
[1:1:0712/154844.800573:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb4e25c7, 2
[1:1:0712/154844.800738:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff91521825 38fffffffeffffff950a ffffffc7254e0b 6bffffff91112e , 10104, 5
[1:1:0712/154844.801726:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33567:33599:0712/154844.801988:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�R%8��
�%Nk�.���+
[33567:33599:0712/154844.802062:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �R%8��
�%Nk�.xE���+
[1:1:0712/154844.801978:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a2c59b0a0, 3
[1:1:0712/154844.802188:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a2c726080, 2
[33567:33599:0712/154844.802371:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33666, 5, 91521825 38fe950a c7254e0b 6b91112e 
[1:1:0712/154844.802382:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a163e9d20, -2
[1:1:0712/154844.830084:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/154844.830467:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b4e25c7
[1:1:0712/154844.830819:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b4e25c7
[1:1:0712/154844.831467:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b4e25c7
[1:1:0712/154844.832998:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.833194:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.833383:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.833591:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.834284:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b4e25c7
[1:1:0712/154844.834620:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a2e3607ba
[1:1:0712/154844.834769:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a2e357def, 7f2a2e36077a, 7f2a2e3620cf
[1:1:0712/154844.840835:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b4e25c7
[1:1:0712/154844.841206:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b4e25c7
[1:1:0712/154844.842017:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b4e25c7
[1:1:0712/154844.844143:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.844384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.844614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.844752:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b4e25c7
[1:1:0712/154844.845195:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b4e25c7
[1:1:0712/154844.845357:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a2e3607ba
[1:1:0712/154844.845439:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a2e357def, 7f2a2e36077a, 7f2a2e3620cf
[1:1:0712/154844.847733:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/154844.848066:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/154844.848166:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07119638, 0x7ffe071195b8)
[1:1:0712/154844.861278:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/154844.865728:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/154845.004890:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/154845.005180:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/154845.141960:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x100e0d1ea220
[1:1:0712/154845.142184:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/154845.387230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/154845.392030:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3a5d356ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/154845.392618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/154845.400087:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[33567:33567:0712/154845.455055:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[33567:33567:0712/154845.487782:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[33567:33599:0712/154845.488179:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/154845.488402:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/154845.488663:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/154845.489137:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/154845.489367:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/154845.492149:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1f8efe08, 1
[1:1:0712/154845.492476:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x273211b2, 0
[1:1:0712/154845.492739:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x23c2806c, 3
[1:1:0712/154845.492932:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x19ccdfac, 2
[1:1:0712/154845.493120:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb2113227 08fffffffeffffff8e1f ffffffacffffffdfffffffcc19 6cffffff80ffffffc223 , 10104, 6
[1:1:0712/154845.494104:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[33567:33599:0712/154845.494407:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�2'�����l��#���+
[33567:33599:0712/154845.494472:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �2'�����l��#8`���+
[1:1:0712/154845.494584:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a2c59b0a0, 3
[33567:33599:0712/154845.494788:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 33682, 6, b2113227 08fe8e1f acdfcc19 6c80c223 
[1:1:0712/154845.494824:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a2c726080, 2
[1:1:0712/154845.495026:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2a163e9d20, -2
[33567:33567:0712/154845.515078:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/154845.518211:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/154845.518586:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19ccdfac
[1:1:0712/154845.518907:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19ccdfac
[1:1:0712/154845.519524:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19ccdfac
[1:1:0712/154845.521007:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.521229:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.521465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.521681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.522365:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19ccdfac
[1:1:0712/154845.522685:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a2e3607ba
[1:1:0712/154845.522866:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a2e357def, 7f2a2e36077a, 7f2a2e3620cf
[33567:33580:0712/154845.527660:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[33567:33580:0712/154845.527782:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[33567:33567:0712/154845.527841:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://its.pku.edu.cn/
[33567:33567:0712/154845.527881:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://its.pku.edu.cn/, https://its.pku.edu.cn/index_en.jsp, 1
[33567:33567:0712/154845.527935:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://its.pku.edu.cn/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 22:48:45 GMT Server: Apache Keep-Alive: timeout=5, max=2999 Connection: Keep-Alive Transfer-Encoding: chunked Content-Type: text/html;charset=utf-8  ,0, 6
[1:1:0712/154845.529918:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 19ccdfac
[1:1:0712/154845.530341:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 19ccdfac
[3:3:0712/154845.530495:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/154845.531181:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 19ccdfac
[1:1:0712/154845.532523:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.532822:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.533062:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.533326:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 19ccdfac
[1:1:0712/154845.534255:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 19ccdfac
[1:1:0712/154845.534680:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2a2e3607ba
[1:1:0712/154845.534907:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2a2e357def, 7f2a2e36077a, 7f2a2e3620cf
[1:1:0712/154845.541337:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/154845.541892:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/154845.542076:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe07119638, 0x7ffe071195b8)
[1:1:0712/154845.554872:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/154845.559561:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/154845.616803:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/154845.712083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/154845.712871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3a5d355a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/154845.713116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/154845.774089:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x100e0d235220
[1:1:0712/154845.774354:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/154845.814087:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://its.pku.edu.cn/
[1:1:0712/154846.092453:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[33567:33567:0712/154846.106107:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://its.pku.edu.cn/, https://its.pku.edu.cn/, 1
[33567:33567:0712/154846.106204:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://its.pku.edu.cn/, https://its.pku.edu.cn
[1:1:0712/154846.159999:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/154846.161659:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/154846.161912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3a5d356ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/154846.162180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/154846.214335:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/154846.314452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/154846.320766:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/154846.320995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3a5d356ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/154846.321271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/154846.393370:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/154846.393594:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154846.877746:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154847.210014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f2a16404bd0 0x100e0d3d9ed8 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.223218:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154847.227789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , /*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL
[1:1:0712/154847.227927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
		remove user.f_152307ce -> 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/154847.373470:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f2a16404bd0 0x100e0d3d9ed8 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.378097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f2a16404bd0 0x100e0d3d9ed8 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.393809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f2a16404bd0 0x100e0d3d9ed8 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.442076:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0701151, 117, 1
[1:1:0712/154847.442434:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/154847.707609:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/154847.707865:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.708847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7f2a1609c070 0x100e0d5144e0 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.710014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , 
$(".header .logo a:first-child").hover(function(){
$(this).children("img").attr("src","/img/pkulogo
[1:1:0712/154847.710272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154847.796923:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.088805, 379, 1
[1:1:0712/154847.797116:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/154847.931710:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/154847.931886:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.933233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f2a1609c070 0x100e0d54d7e0 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.935010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , var itc;
$(function(){
	if( "undefined" != typeof(SEC_MENU))
	{
		$("#" + SEC_MENU).addClass("se
[1:1:0712/154847.935388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154847.940635:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f2a1609c070 0x100e0d54d7e0 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.953468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f2a1609c070 0x100e0d54d7e0 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.954863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 233 0x7f2a1609c070 0x100e0d54d7e0 , "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154847.958901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154849.120485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1440
[1:1:0712/154849.120776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154849.121188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 270
[1:1:0712/154849.121419:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 270 0x7f2a1609c070 0x100e0d5bf260 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 233 0x7f2a1609c070 0x100e0d54d7e0 
[1:1:0712/154849.311370:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x1b15e9ea29c8, 0x100e0cbe1440
[1:1:0712/154849.311714:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 600
[1:1:0712/154849.312126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 271
[1:1:0712/154849.312355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 271 0x7f2a1609c070 0x100e0d531860 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 233 0x7f2a1609c070 0x100e0d54d7e0 
[1:1:0712/154849.393942:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 15000
[1:1:0712/154849.394420:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 273
[1:1:0712/154849.394716:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 273 0x7f2a1609c070 0x100e0d5bd960 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 233 0x7f2a1609c070 0x100e0d54d7e0 
[1:1:0712/154850.197790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 270, 7f2a189e1881
[1:1:0712/154850.213968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"233 0x7f2a1609c070 0x100e0d54d7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.214305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"233 0x7f2a1609c070 0x100e0d54d7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.214693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.215305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154850.215536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154850.278688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 271, 7f2a189e1881
[1:1:0712/154850.294954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"233 0x7f2a1609c070 0x100e0d54d7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.295285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"233 0x7f2a1609c070 0x100e0d54d7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.295657:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.296293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){
		$('.sliderContainer .slider .item:eq(' + (args- 1) + ')').fadeIn(1200,"easeInSine");
		$('.s
[1:1:0712/154850.296514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154850.334336:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154850.334615:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154850.334974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 322
[1:1:0712/154850.335211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 322 0x7f2a1609c070 0x100e0d5481e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 271 0x7f2a1609c070 0x100e0d531860 
[1:1:0712/154850.397390:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 13
[1:1:0712/154850.397872:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 325
[1:1:0712/154850.398100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 325 0x7f2a1609c070 0x100e0d327ae0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 271 0x7f2a1609c070 0x100e0d531860 
[1:1:0712/154850.439634:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154850.439921:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 1000
[1:1:0712/154850.440397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 326
[1:1:0712/154850.440619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7f2a1609c070 0x100e0d514de0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 271 0x7f2a1609c070 0x100e0d531860 
[1:1:0712/154850.595225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.596036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , r, (e,i){var s,l,c,p;try{if(r&&(i||4===u.readyState))if(r=t,a&&(u.onreadystatechange=b.noop,$n&&delete 
[1:1:0712/154850.596269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154850.597514:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.599977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.600666:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x178d35672ef0
[1:1:0712/154850.821531:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 322, 7f2a189e1881
[1:1:0712/154850.833289:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"271 0x7f2a1609c070 0x100e0d531860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.833611:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"271 0x7f2a1609c070 0x100e0d531860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.833994:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.834542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154850.834757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154850.836211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 325, 7f2a189e18db
[1:1:0712/154850.850820:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"271 0x7f2a1609c070 0x100e0d531860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.851142:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"271 0x7f2a1609c070 0x100e0d531860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154850.851553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 349
[1:1:0712/154850.851813:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 349 0x7f2a1609c070 0x100e0cde9c60 , 6:3_https://its.pku.edu.cn/, 0, , 325 0x7f2a1609c070 0x100e0d327ae0 
[1:1:0712/154850.852160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154850.852705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154850.852919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154851.064059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 349, 7f2a189e18db
[1:1:0712/154851.079493:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"325 0x7f2a1609c070 0x100e0d327ae0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154851.079838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"325 0x7f2a1609c070 0x100e0d327ae0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154851.080286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 367
[1:1:0712/154851.080521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 367 0x7f2a1609c070 0x100e0d5ac960 , 6:3_https://its.pku.edu.cn/, 0, , 349 0x7f2a1609c070 0x100e0cde9c60 
[1:1:0712/154851.080844:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154851.081450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154851.081669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154851.486708:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 367, 7f2a189e18db
[1:1:0712/154851.505090:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"349 0x7f2a1609c070 0x100e0cde9c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154851.505392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"349 0x7f2a1609c070 0x100e0cde9c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154851.505793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 444
[1:1:0712/154851.506018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 444 0x7f2a1609c070 0x100e0d32ec60 , 6:3_https://its.pku.edu.cn/, 0, , 367 0x7f2a1609c070 0x100e0d5ac960 
[1:1:0712/154851.506369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154851.506906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154851.507137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154851.972879:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://its.pku.edu.cn/_img/selector-shadow.png"
[1:1:0712/154852.264475:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 326, 7f2a189e1881
[1:1:0712/154852.285115:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"271 0x7f2a1609c070 0x100e0d531860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154852.285458:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"271 0x7f2a1609c070 0x100e0d531860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154852.285842:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154852.286470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){
			setBGopacity(args); /* -- zhangy 20180303 --- */
			sliderLoaded(args);
		}
[1:1:0712/154852.286691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154852.453812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154852.454102:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154852.454534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 525
[1:1:0712/154852.454774:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7f2a1609c070 0x100e0df82660 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 326 0x7f2a1609c070 0x100e0d514de0 
[1:1:0712/154852.976838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 444, 7f2a189e18db
[1:1:0712/154852.997611:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"367 0x7f2a1609c070 0x100e0d5ac960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154852.997935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"367 0x7f2a1609c070 0x100e0d5ac960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154852.998380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 533
[1:1:0712/154852.998641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 533 0x7f2a1609c070 0x100e0df827e0 , 6:3_https://its.pku.edu.cn/, 0, , 444 0x7f2a1609c070 0x100e0d32ec60 
[1:1:0712/154852.998987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154852.999628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154852.999893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154854.221456:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 525, 7f2a189e1881
[1:1:0712/154854.243665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"326 0x7f2a1609c070 0x100e0d514de0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154854.244051:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"326 0x7f2a1609c070 0x100e0d514de0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154854.244428:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154854.244994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154854.245209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154854.374119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 533, 7f2a189e18db
[1:1:0712/154854.396390:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"444 0x7f2a1609c070 0x100e0d32ec60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154854.396670:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"444 0x7f2a1609c070 0x100e0d32ec60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154854.397082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 564
[1:1:0712/154854.397324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 564 0x7f2a1609c070 0x100e0d2a1de0 , 6:3_https://its.pku.edu.cn/, 0, , 533 0x7f2a1609c070 0x100e0df827e0 
[1:1:0712/154854.397645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154854.398216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154854.398450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154854.707304:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154854.709760:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154854.710197:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154854.710643:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154854.711092:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/154904.443091:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 273, 7f2a189e18db
[1:1:0712/154904.467383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"233 0x7f2a1609c070 0x100e0d54d7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.467732:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"233 0x7f2a1609c070 0x100e0d54d7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.468185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 616
[1:1:0712/154904.468441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 616 0x7f2a1609c070 0x100e0d5b28e0 , 6:3_https://its.pku.edu.cn/, 0, , 273 0x7f2a1609c070 0x100e0d5bd960 
[1:1:0712/154904.468777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154904.469363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , slideNext, (){
	rand = rand%6+1;
	slideChange(rand);
}
[1:1:0712/154904.469596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154904.521822:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154904.522092:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154904.522514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 617
[1:1:0712/154904.522763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 617 0x7f2a1609c070 0x100e0d5b82e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 273 0x7f2a1609c070 0x100e0d5bd960 
[1:1:0712/154904.540664:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 13
[1:1:0712/154904.541086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 618
[1:1:0712/154904.541362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 618 0x7f2a1609c070 0x100e0e0c49e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 273 0x7f2a1609c070 0x100e0d5bd960 
[1:1:0712/154904.798812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154904.799138:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 600
[1:1:0712/154904.800253:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 619
[1:1:0712/154904.800666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7f2a1609c070 0x100e0e2b0660 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 273 0x7f2a1609c070 0x100e0d5bd960 
[1:1:0712/154904.803558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 617, 7f2a189e1881
[1:1:0712/154904.829102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.829467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.829865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154904.830444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154904.830684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154904.832735:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 618, 7f2a189e18db
[1:1:0712/154904.856847:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.857296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.857892:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 623
[1:1:0712/154904.858248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f2a1609c070 0x100e0d322f60 , 6:3_https://its.pku.edu.cn/, 0, , 618 0x7f2a1609c070 0x100e0e0c49e0 
[1:1:0712/154904.858705:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154904.859372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154904.859760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154904.881699:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 623, 7f2a189e18db
[1:1:0712/154904.905868:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"618 0x7f2a1609c070 0x100e0e0c49e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.906181:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"618 0x7f2a1609c070 0x100e0e0c49e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.906614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 625
[1:1:0712/154904.906865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7f2a1609c070 0x100e0d5b4be0 , 6:3_https://its.pku.edu.cn/, 0, , 623 0x7f2a1609c070 0x100e0d322f60 
[1:1:0712/154904.907198:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154904.907766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154904.908048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154904.948273:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 625, 7f2a189e18db
[1:1:0712/154904.972563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"623 0x7f2a1609c070 0x100e0d322f60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.972866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"623 0x7f2a1609c070 0x100e0d322f60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154904.973303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 627
[1:1:0712/154904.973563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f2a1609c070 0x100e0dd3a360 , 6:3_https://its.pku.edu.cn/, 0, , 625 0x7f2a1609c070 0x100e0d5b4be0 
[1:1:0712/154904.973900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154904.974474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154904.974711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.008557:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 627, 7f2a189e18db
[1:1:0712/154905.032837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"625 0x7f2a1609c070 0x100e0d5b4be0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.033142:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"625 0x7f2a1609c070 0x100e0d5b4be0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.033581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 629
[1:1:0712/154905.033831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f2a1609c070 0x100e0d5c3ae0 , 6:3_https://its.pku.edu.cn/, 0, , 627 0x7f2a1609c070 0x100e0dd3a360 
[1:1:0712/154905.034161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.034731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.034965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.039358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 629, 7f2a189e18db
[1:1:0712/154905.063766:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"627 0x7f2a1609c070 0x100e0dd3a360 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.064058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"627 0x7f2a1609c070 0x100e0dd3a360 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.064490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 631
[1:1:0712/154905.064744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7f2a1609c070 0x100e0d32e160 , 6:3_https://its.pku.edu.cn/, 0, , 629 0x7f2a1609c070 0x100e0d5c3ae0 
[1:1:0712/154905.065176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.065739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.065973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.105860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 631, 7f2a189e18db
[1:1:0712/154905.130371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"629 0x7f2a1609c070 0x100e0d5c3ae0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.130664:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"629 0x7f2a1609c070 0x100e0d5c3ae0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.131067:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 633
[1:1:0712/154905.131347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7f2a1609c070 0x100e0df83fe0 , 6:3_https://its.pku.edu.cn/, 0, , 631 0x7f2a1609c070 0x100e0d32e160 
[1:1:0712/154905.131670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.132277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.132498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.437770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 619, 7f2a189e1881
[1:1:0712/154905.462591:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.462975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.463419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.464081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){
		$('.sliderContainer .slider .item:eq(' + (args- 1) + ')').fadeIn(1200,"easeInSine");
		$('.s
[1:1:0712/154905.464373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.520300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154905.520747:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154905.521473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 635
[1:1:0712/154905.521862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 635 0x7f2a1609c070 0x100e0d549460 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 619 0x7f2a1609c070 0x100e0e2b0660 
[1:1:0712/154905.560854:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 13
[1:1:0712/154905.561473:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 636
[1:1:0712/154905.561759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7f2a1609c070 0x100e0d5b6fe0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 619 0x7f2a1609c070 0x100e0e2b0660 
[1:1:0712/154905.599741:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154905.600051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 1000
[1:1:0712/154905.600484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 637
[1:1:0712/154905.600733:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f2a1609c070 0x100e0d08a160 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 619 0x7f2a1609c070 0x100e0e2b0660 
[1:1:0712/154905.604067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 635, 7f2a189e1881
[1:1:0712/154905.634540:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"619 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.634937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"619 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.635331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.635914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154905.636173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.638179:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 636, 7f2a189e18db
[1:1:0712/154905.663563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"619 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.663948:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"619 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.664485:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 641
[1:1:0712/154905.664752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7f2a1609c070 0x100e0df48460 , 6:3_https://its.pku.edu.cn/, 0, , 636 0x7f2a1609c070 0x100e0d5b6fe0 
[1:1:0712/154905.665090:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.665723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.665967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.670561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 641, 7f2a189e18db
[1:1:0712/154905.695820:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"636 0x7f2a1609c070 0x100e0d5b6fe0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.696174:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"636 0x7f2a1609c070 0x100e0d5b6fe0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.696631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 643
[1:1:0712/154905.696870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 643 0x7f2a1609c070 0x100e0df6f3e0 , 6:3_https://its.pku.edu.cn/, 0, , 641 0x7f2a1609c070 0x100e0df48460 
[1:1:0712/154905.697213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.697809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.698046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.731673:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 643, 7f2a189e18db
[1:1:0712/154905.757031:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"641 0x7f2a1609c070 0x100e0df48460 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.757402:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"641 0x7f2a1609c070 0x100e0df48460 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.757864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 645
[1:1:0712/154905.758100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f2a1609c070 0x100e0e3008e0 , 6:3_https://its.pku.edu.cn/, 0, , 643 0x7f2a1609c070 0x100e0df6f3e0 
[1:1:0712/154905.758454:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.759053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.759291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.804334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 645, 7f2a189e18db
[1:1:0712/154905.819581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"643 0x7f2a1609c070 0x100e0df6f3e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.819980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"643 0x7f2a1609c070 0x100e0df6f3e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.820521:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 647
[1:1:0712/154905.820799:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7f2a1609c070 0x100e0df82d60 , 6:3_https://its.pku.edu.cn/, 0, , 645 0x7f2a1609c070 0x100e0e3008e0 
[1:1:0712/154905.821157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.821793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.822021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.827080:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 647, 7f2a189e18db
[1:1:0712/154905.848476:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"645 0x7f2a1609c070 0x100e0e3008e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.848868:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"645 0x7f2a1609c070 0x100e0e3008e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.849353:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 649
[1:1:0712/154905.849620:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7f2a1609c070 0x100e0df484e0 , 6:3_https://its.pku.edu.cn/, 0, , 647 0x7f2a1609c070 0x100e0df82d60 
[1:1:0712/154905.849945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.850543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.850771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.892156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 649, 7f2a189e18db
[1:1:0712/154905.907686:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"647 0x7f2a1609c070 0x100e0df82d60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.908066:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"647 0x7f2a1609c070 0x100e0df82d60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.908542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 651
[1:1:0712/154905.908868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 651 0x7f2a1609c070 0x100e0e2af7e0 , 6:3_https://its.pku.edu.cn/, 0, , 649 0x7f2a1609c070 0x100e0df484e0 
[1:1:0712/154905.909257:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.909886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.910110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.914780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 651, 7f2a189e18db
[1:1:0712/154905.941984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"649 0x7f2a1609c070 0x100e0df484e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.942337:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"649 0x7f2a1609c070 0x100e0df484e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.942798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 653
[1:1:0712/154905.943055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7f2a1609c070 0x100e0d5a4860 , 6:3_https://its.pku.edu.cn/, 0, , 651 0x7f2a1609c070 0x100e0e2af7e0 
[1:1:0712/154905.943388:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.944009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.944244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154905.965984:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 653, 7f2a189e18db
[1:1:0712/154905.994305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"651 0x7f2a1609c070 0x100e0e2af7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.994710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"651 0x7f2a1609c070 0x100e0e2af7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154905.995167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 655
[1:1:0712/154905.995406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7f2a1609c070 0x100e0d514460 , 6:3_https://its.pku.edu.cn/, 0, , 653 0x7f2a1609c070 0x100e0d5a4860 
[1:1:0712/154905.995816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154905.996387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154905.996650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.035618:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 655, 7f2a189e18db
[1:1:0712/154906.068926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"653 0x7f2a1609c070 0x100e0d5a4860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.069316:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"653 0x7f2a1609c070 0x100e0d5a4860 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.069817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 657
[1:1:0712/154906.070085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 657 0x7f2a1609c070 0x100e0d5cea60 , 6:3_https://its.pku.edu.cn/, 0, , 655 0x7f2a1609c070 0x100e0d514460 
[1:1:0712/154906.070430:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.071048:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.071274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.100153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 657, 7f2a189e18db
[1:1:0712/154906.127722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"655 0x7f2a1609c070 0x100e0d514460 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.128082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"655 0x7f2a1609c070 0x100e0d514460 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.128543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 659
[1:1:0712/154906.128778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 659 0x7f2a1609c070 0x100e0d5bfc60 , 6:3_https://its.pku.edu.cn/, 0, , 657 0x7f2a1609c070 0x100e0d5cea60 
[1:1:0712/154906.129188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.129775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.130009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.134930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 659, 7f2a189e18db
[1:1:0712/154906.168193:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"657 0x7f2a1609c070 0x100e0d5cea60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.168636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"657 0x7f2a1609c070 0x100e0d5cea60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.169112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 661
[1:1:0712/154906.169364:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f2a1609c070 0x100e0d5d6c60 , 6:3_https://its.pku.edu.cn/, 0, , 659 0x7f2a1609c070 0x100e0d5bfc60 
[1:1:0712/154906.169764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.170402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.170746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.175844:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 661, 7f2a189e18db
[1:1:0712/154906.202909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"659 0x7f2a1609c070 0x100e0d5bfc60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.203297:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"659 0x7f2a1609c070 0x100e0d5bfc60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.203841:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 663
[1:1:0712/154906.204097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f2a1609c070 0x100e0e2b0660 , 6:3_https://its.pku.edu.cn/, 0, , 661 0x7f2a1609c070 0x100e0d5d6c60 
[1:1:0712/154906.204438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.205011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.205225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.239821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 663, 7f2a189e18db
[1:1:0712/154906.253055:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"661 0x7f2a1609c070 0x100e0d5d6c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.253498:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"661 0x7f2a1609c070 0x100e0d5d6c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.254018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 665
[1:1:0712/154906.254355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7f2a1609c070 0x100e0d5adae0 , 6:3_https://its.pku.edu.cn/, 0, , 663 0x7f2a1609c070 0x100e0e2b0660 
[1:1:0712/154906.254840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.255602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.255852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.282706:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 665, 7f2a189e18db
[1:1:0712/154906.308911:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"663 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.309369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"663 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.310021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 667
[1:1:0712/154906.310317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7f2a1609c070 0x100e0d5bc360 , 6:3_https://its.pku.edu.cn/, 0, , 665 0x7f2a1609c070 0x100e0d5adae0 
[1:1:0712/154906.310747:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.311377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.311729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.317033:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 667, 7f2a189e18db
[1:1:0712/154906.336705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"665 0x7f2a1609c070 0x100e0d5adae0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.337064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"665 0x7f2a1609c070 0x100e0d5adae0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.337526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 669
[1:1:0712/154906.337840:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7f2a1609c070 0x100e0d512e60 , 6:3_https://its.pku.edu.cn/, 0, , 667 0x7f2a1609c070 0x100e0d5bc360 
[1:1:0712/154906.338245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.338899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.339126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.343807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 669, 7f2a189e18db
[1:1:0712/154906.372112:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"667 0x7f2a1609c070 0x100e0d5bc360 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.372498:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"667 0x7f2a1609c070 0x100e0d5bc360 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.372971:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 671
[1:1:0712/154906.373239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 671 0x7f2a1609c070 0x100e0df47ee0 , 6:3_https://its.pku.edu.cn/, 0, , 669 0x7f2a1609c070 0x100e0d512e60 
[1:1:0712/154906.373629:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.374228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.374476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.413654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 671, 7f2a189e18db
[1:1:0712/154906.442779:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"669 0x7f2a1609c070 0x100e0d512e60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.443186:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"669 0x7f2a1609c070 0x100e0d512e60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.443735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 673
[1:1:0712/154906.443999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 673 0x7f2a1609c070 0x100e0d5adde0 , 6:3_https://its.pku.edu.cn/, 0, , 671 0x7f2a1609c070 0x100e0df47ee0 
[1:1:0712/154906.444343:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.444955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.445191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.450406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 673, 7f2a189e18db
[1:1:0712/154906.482028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"671 0x7f2a1609c070 0x100e0df47ee0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.482420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"671 0x7f2a1609c070 0x100e0df47ee0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.482883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 675
[1:1:0712/154906.483137:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 675 0x7f2a1609c070 0x100e0d5aede0 , 6:3_https://its.pku.edu.cn/, 0, , 673 0x7f2a1609c070 0x100e0d5adde0 
[1:1:0712/154906.483469:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.484134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.484352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.488937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 675, 7f2a189e18db
[1:1:0712/154906.517441:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"673 0x7f2a1609c070 0x100e0d5adde0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.517857:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"673 0x7f2a1609c070 0x100e0d5adde0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.518299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 677
[1:1:0712/154906.518529:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7f2a1609c070 0x100e0d5b9360 , 6:3_https://its.pku.edu.cn/, 0, , 675 0x7f2a1609c070 0x100e0d5aede0 
[1:1:0712/154906.518871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.519428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.519699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.554284:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 677, 7f2a189e18db
[1:1:0712/154906.580706:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"675 0x7f2a1609c070 0x100e0d5aede0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.581083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"675 0x7f2a1609c070 0x100e0d5aede0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.581536:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 679
[1:1:0712/154906.581831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f2a1609c070 0x100e0d5a3ce0 , 6:3_https://its.pku.edu.cn/, 0, , 677 0x7f2a1609c070 0x100e0d5b9360 
[1:1:0712/154906.582204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.582845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.583073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.618047:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 679, 7f2a189e18db
[1:1:0712/154906.644451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"677 0x7f2a1609c070 0x100e0d5b9360 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.644809:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"677 0x7f2a1609c070 0x100e0d5b9360 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.645267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 682
[1:1:0712/154906.645502:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7f2a1609c070 0x100e0df472e0 , 6:3_https://its.pku.edu.cn/, 0, , 679 0x7f2a1609c070 0x100e0d5a3ce0 
[1:1:0712/154906.645857:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.646424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154906.646664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.651259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 637, 7f2a189e1881
[1:1:0712/154906.684619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"619 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.685055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"619 0x7f2a1609c070 0x100e0e2b0660 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154906.685456:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154906.686106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){
			setBGopacity(args); /* -- zhangy 20180303 --- */
			sliderLoaded(args);
		}
[1:1:0712/154906.686327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154906.864790:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154906.865074:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154906.865483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 683
[1:1:0712/154906.865773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 683 0x7f2a1609c070 0x100e0d5a68e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 637 0x7f2a1609c070 0x100e0d08a160 
[1:1:0712/154907.027879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 682, 7f2a189e18db
[1:1:0712/154907.055191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"679 0x7f2a1609c070 0x100e0d5a3ce0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.055516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"679 0x7f2a1609c070 0x100e0d5a3ce0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.055976:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 687
[1:1:0712/154907.056209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7f2a1609c070 0x100e0e2ff960 , 6:3_https://its.pku.edu.cn/, 0, , 682 0x7f2a1609c070 0x100e0df472e0 
[1:1:0712/154907.056531:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.057092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.057318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.078070:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 683, 7f2a189e1881
[1:1:0712/154907.104430:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"637 0x7f2a1609c070 0x100e0d08a160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.104771:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"637 0x7f2a1609c070 0x100e0d08a160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.105141:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.105670:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154907.105898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.134187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 687, 7f2a189e18db
[1:1:0712/154907.160342:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"682 0x7f2a1609c070 0x100e0df472e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.160632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"682 0x7f2a1609c070 0x100e0df472e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.161079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 689
[1:1:0712/154907.161306:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7f2a1609c070 0x100e0d5bf7e0 , 6:3_https://its.pku.edu.cn/, 0, , 687 0x7f2a1609c070 0x100e0e2ff960 
[1:1:0712/154907.161626:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.162182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.162396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.202608:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 689, 7f2a189e18db
[1:1:0712/154907.229166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"687 0x7f2a1609c070 0x100e0e2ff960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.229486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"687 0x7f2a1609c070 0x100e0e2ff960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.229921:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 691
[1:1:0712/154907.230156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7f2a1609c070 0x100e0e2ad160 , 6:3_https://its.pku.edu.cn/, 0, , 689 0x7f2a1609c070 0x100e0d5bf7e0 
[1:1:0712/154907.230494:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.231074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.231295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.243985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 691, 7f2a189e18db
[1:1:0712/154907.270806:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"689 0x7f2a1609c070 0x100e0d5bf7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.271142:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"689 0x7f2a1609c070 0x100e0d5bf7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.271571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 693
[1:1:0712/154907.271845:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 693 0x7f2a1609c070 0x100e0e2ace60 , 6:3_https://its.pku.edu.cn/, 0, , 691 0x7f2a1609c070 0x100e0e2ad160 
[1:1:0712/154907.272176:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.272729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.272945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.283678:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 693, 7f2a189e18db
[1:1:0712/154907.309070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"691 0x7f2a1609c070 0x100e0e2ad160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.309430:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"691 0x7f2a1609c070 0x100e0e2ad160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.309916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 695
[1:1:0712/154907.310156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 695 0x7f2a1609c070 0x100e0df53b60 , 6:3_https://its.pku.edu.cn/, 0, , 693 0x7f2a1609c070 0x100e0e2ace60 
[1:1:0712/154907.310490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.311102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.311346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.319944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 695, 7f2a189e18db
[1:1:0712/154907.354583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"693 0x7f2a1609c070 0x100e0e2ace60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.355074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"693 0x7f2a1609c070 0x100e0e2ace60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.355568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 697
[1:1:0712/154907.355943:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7f2a1609c070 0x100e0d37e760 , 6:3_https://its.pku.edu.cn/, 0, , 695 0x7f2a1609c070 0x100e0df53b60 
[1:1:0712/154907.356532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.357143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.357387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.401668:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 697, 7f2a189e18db
[1:1:0712/154907.428496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"695 0x7f2a1609c070 0x100e0df53b60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.428842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"695 0x7f2a1609c070 0x100e0df53b60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.429272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 699
[1:1:0712/154907.429504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7f2a1609c070 0x100e0df82960 , 6:3_https://its.pku.edu.cn/, 0, , 697 0x7f2a1609c070 0x100e0d37e760 
[1:1:0712/154907.429852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.430423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.430638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.443225:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 699, 7f2a189e18db
[1:1:0712/154907.469490:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"697 0x7f2a1609c070 0x100e0d37e760 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.469801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"697 0x7f2a1609c070 0x100e0d37e760 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.470244:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 701
[1:1:0712/154907.470478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 701 0x7f2a1609c070 0x100e0d5a7be0 , 6:3_https://its.pku.edu.cn/, 0, , 699 0x7f2a1609c070 0x100e0df82960 
[1:1:0712/154907.470828:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.471364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.471581:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.482147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 701, 7f2a189e18db
[1:1:0712/154907.509046:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"699 0x7f2a1609c070 0x100e0df82960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.509348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"699 0x7f2a1609c070 0x100e0df82960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.509761:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 703
[1:1:0712/154907.510002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f2a1609c070 0x100e0df48ce0 , 6:3_https://its.pku.edu.cn/, 0, , 701 0x7f2a1609c070 0x100e0d5a7be0 
[1:1:0712/154907.510319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.510874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.511088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.521880:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 703, 7f2a189e18db
[1:1:0712/154907.553819:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"701 0x7f2a1609c070 0x100e0d5a7be0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.554182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"701 0x7f2a1609c070 0x100e0d5a7be0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.554628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 705
[1:1:0712/154907.554876:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f2a1609c070 0x100e0df467e0 , 6:3_https://its.pku.edu.cn/, 0, , 703 0x7f2a1609c070 0x100e0df48ce0 
[1:1:0712/154907.555201:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.555752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.556011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.596868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 705, 7f2a189e18db
[1:1:0712/154907.615875:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"703 0x7f2a1609c070 0x100e0df48ce0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.616153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"703 0x7f2a1609c070 0x100e0df48ce0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.616555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 707
[1:1:0712/154907.616794:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f2a1609c070 0x100e0d387fe0 , 6:3_https://its.pku.edu.cn/, 0, , 705 0x7f2a1609c070 0x100e0df467e0 
[1:1:0712/154907.617131:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.617664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.617891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.663049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 707, 7f2a189e18db
[1:1:0712/154907.689767:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"705 0x7f2a1609c070 0x100e0df467e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.690064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"705 0x7f2a1609c070 0x100e0df467e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.690471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 709
[1:1:0712/154907.690697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 709 0x7f2a1609c070 0x100e0e2f8260 , 6:3_https://its.pku.edu.cn/, 0, , 707 0x7f2a1609c070 0x100e0d387fe0 
[1:1:0712/154907.691031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.691580:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.691825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.709392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 709, 7f2a189e18db
[1:1:0712/154907.736155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7f2a1609c070 0x100e0d387fe0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.736424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7f2a1609c070 0x100e0d387fe0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.736819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 711
[1:1:0712/154907.737072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f2a1609c070 0x100e0d5b46e0 , 6:3_https://its.pku.edu.cn/, 0, , 709 0x7f2a1609c070 0x100e0e2f8260 
[1:1:0712/154907.737378:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.737901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.738113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.758420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 711, 7f2a189e18db
[1:1:0712/154907.784953:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"709 0x7f2a1609c070 0x100e0e2f8260 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.785219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"709 0x7f2a1609c070 0x100e0e2f8260 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.785611:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 713
[1:1:0712/154907.785835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7f2a1609c070 0x100e0df467e0 , 6:3_https://its.pku.edu.cn/, 0, , 711 0x7f2a1609c070 0x100e0d5b46e0 
[1:1:0712/154907.786153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.786673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.786902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.825441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 713, 7f2a189e18db
[1:1:0712/154907.852005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"711 0x7f2a1609c070 0x100e0d5b46e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.852272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"711 0x7f2a1609c070 0x100e0d5b46e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.852666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 715
[1:1:0712/154907.852891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7f2a1609c070 0x100e0d4ea7e0 , 6:3_https://its.pku.edu.cn/, 0, , 713 0x7f2a1609c070 0x100e0df467e0 
[1:1:0712/154907.853223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.853745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.853984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.897267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 715, 7f2a189e18db
[1:1:0712/154907.907809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"713 0x7f2a1609c070 0x100e0df467e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.908121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"713 0x7f2a1609c070 0x100e0df467e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.908558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 717
[1:1:0712/154907.908796:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f2a1609c070 0x100e0d5b6460 , 6:3_https://its.pku.edu.cn/, 0, , 715 0x7f2a1609c070 0x100e0d4ea7e0 
[1:1:0712/154907.909128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.909667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.909880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.915541:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 717, 7f2a189e18db
[1:1:0712/154907.942725:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"715 0x7f2a1609c070 0x100e0d4ea7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.943047:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"715 0x7f2a1609c070 0x100e0d4ea7e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154907.943447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 719
[1:1:0712/154907.943667:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 719 0x7f2a1609c070 0x100e0df76560 , 6:3_https://its.pku.edu.cn/, 0, , 717 0x7f2a1609c070 0x100e0d5b6460 
[1:1:0712/154907.943996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154907.944524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154907.944736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154907.981887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 719, 7f2a189e18db
[1:1:0712/154908.015552:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"717 0x7f2a1609c070 0x100e0d5b6460 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.015852:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"717 0x7f2a1609c070 0x100e0d5b6460 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.016289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 721
[1:1:0712/154908.016520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f2a1609c070 0x100e0d5aede0 , 6:3_https://its.pku.edu.cn/, 0, , 719 0x7f2a1609c070 0x100e0df76560 
[1:1:0712/154908.016838:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.017385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.017608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.022628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 721, 7f2a189e18db
[1:1:0712/154908.049629:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"719 0x7f2a1609c070 0x100e0df76560 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.049895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"719 0x7f2a1609c070 0x100e0df76560 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.050304:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 723
[1:1:0712/154908.050552:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 723 0x7f2a1609c070 0x100e0d317160 , 6:3_https://its.pku.edu.cn/, 0, , 721 0x7f2a1609c070 0x100e0d5aede0 
[1:1:0712/154908.050860:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.051401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.051648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.092923:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 723, 7f2a189e18db
[1:1:0712/154908.120198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"721 0x7f2a1609c070 0x100e0d5aede0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.120488:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"721 0x7f2a1609c070 0x100e0d5aede0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.120902:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 725
[1:1:0712/154908.121159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f2a1609c070 0x100e0d327de0 , 6:3_https://its.pku.edu.cn/, 0, , 723 0x7f2a1609c070 0x100e0d317160 
[1:1:0712/154908.121482:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.122055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.122281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.128044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 725, 7f2a189e18db
[1:1:0712/154908.155598:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"723 0x7f2a1609c070 0x100e0d317160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.155880:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"723 0x7f2a1609c070 0x100e0d317160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.156310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 727
[1:1:0712/154908.156539:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 727 0x7f2a1609c070 0x100e0d3ecf60 , 6:3_https://its.pku.edu.cn/, 0, , 725 0x7f2a1609c070 0x100e0d327de0 
[1:1:0712/154908.156854:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.157396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.157609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.189165:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 727, 7f2a189e18db
[1:1:0712/154908.216260:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"725 0x7f2a1609c070 0x100e0d327de0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.216561:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"725 0x7f2a1609c070 0x100e0d327de0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.216963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 729
[1:1:0712/154908.217205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 729 0x7f2a1609c070 0x100e0d547de0 , 6:3_https://its.pku.edu.cn/, 0, , 727 0x7f2a1609c070 0x100e0d3ecf60 
[1:1:0712/154908.217516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.218081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.218298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.256176:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 729, 7f2a189e18db
[1:1:0712/154908.283321:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"727 0x7f2a1609c070 0x100e0d3ecf60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.283605:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"727 0x7f2a1609c070 0x100e0d3ecf60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.284055:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 731
[1:1:0712/154908.284289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 731 0x7f2a1609c070 0x100e0e2ac0e0 , 6:3_https://its.pku.edu.cn/, 0, , 729 0x7f2a1609c070 0x100e0d547de0 
[1:1:0712/154908.284599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.285144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.285360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.320671:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 731, 7f2a189e18db
[1:1:0712/154908.348167:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"729 0x7f2a1609c070 0x100e0d547de0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.348467:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"729 0x7f2a1609c070 0x100e0d547de0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.348885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 733
[1:1:0712/154908.349136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f2a1609c070 0x100e0df76560 , 6:3_https://its.pku.edu.cn/, 0, , 731 0x7f2a1609c070 0x100e0e2ac0e0 
[1:1:0712/154908.349465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.350037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.350260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154908.385606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 733, 7f2a189e18db
[1:1:0712/154908.417752:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"731 0x7f2a1609c070 0x100e0e2ac0e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.418074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"731 0x7f2a1609c070 0x100e0e2ac0e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154908.418492:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 735
[1:1:0712/154908.418725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7f2a1609c070 0x100e0e0c36e0 , 6:3_https://its.pku.edu.cn/, 0, , 733 0x7f2a1609c070 0x100e0df76560 
[1:1:0712/154908.419078:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154908.419642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154908.419889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154917.304757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/154917.304971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[33567:33567:0712/154917.643879:INFO:CONSOLE(3)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://its.pku.edu.cn/fonts/fontawesome-webfont.woff2?v=4.5.0", source: https://its.pku.edu.cn/js/jquery-1.9.1.min.js (3)
[33567:33567:0712/154917.672372:INFO:CONSOLE(0)] "[DOM] Input elements should have autocomplete attributes (suggested: "current-password"): (More info: https://goo.gl/9p2vKq) %o", source: https://its.pku.edu.cn/index_en.jsp (0)
[33567:33567:0712/154917.891366:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/154917.934391:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/154919.984549:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154919.985292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , v.handle, (e){return typeof b===i||e&&b.event.triggered===e.type?t:b.event.dispatch.apply(f.elem,arguments)}
[1:1:0712/154919.985509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154920.038536:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 616, 7f2a189e18db
[1:1:0712/154920.070130:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154920.070449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"273 0x7f2a1609c070 0x100e0d5bd960 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154920.070895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 840
[1:1:0712/154920.071121:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7f2a1609c070 0x100e0d4fc560 , 6:3_https://its.pku.edu.cn/, 0, , 616 0x7f2a1609c070 0x100e0d5b28e0 
[1:1:0712/154920.071418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154920.071999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , slideNext, (){
	rand = rand%6+1;
	slideChange(rand);
}
[1:1:0712/154920.072211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154920.119092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154920.119400:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154920.119986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 841
[1:1:0712/154920.120278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7f2a1609c070 0x100e0ec0f160 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 616 0x7f2a1609c070 0x100e0d5b28e0 
[1:1:0712/154920.212752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 13
[1:1:0712/154920.213286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 842
[1:1:0712/154920.213596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7f2a1609c070 0x100e0ebe03e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 616 0x7f2a1609c070 0x100e0d5b28e0 
[1:1:0712/154920.329507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154920.329876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 600
[1:1:0712/154920.330599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 844
[1:1:0712/154920.331098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 844 0x7f2a1609c070 0x100e0ed024e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 616 0x7f2a1609c070 0x100e0d5b28e0 
[1:1:0712/154920.462789:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 841, 7f2a189e1881
[1:1:0712/154920.497407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"616 0x7f2a1609c070 0x100e0d5b28e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154920.497788:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"616 0x7f2a1609c070 0x100e0d5b28e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154920.498236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154920.498817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154920.499053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154920.501188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 842, 7f2a189e18db
[1:1:0712/154920.537897:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"616 0x7f2a1609c070 0x100e0d5b28e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154920.538526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"616 0x7f2a1609c070 0x100e0d5b28e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154920.539366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 855
[1:1:0712/154920.539870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 855 0x7f2a1609c070 0x100e0ebd71e0 , 6:3_https://its.pku.edu.cn/, 0, , 842 0x7f2a1609c070 0x100e0ebe03e0 
[1:1:0712/154920.540480:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154920.541412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154920.541725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.188746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 855, 7f2a189e18db
[1:1:0712/154921.207486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"842 0x7f2a1609c070 0x100e0ebe03e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.208308:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"842 0x7f2a1609c070 0x100e0ebe03e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.209066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 864
[1:1:0712/154921.209360:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7f2a1609c070 0x100e0ec286e0 , 6:3_https://its.pku.edu.cn/, 0, , 855 0x7f2a1609c070 0x100e0ebd71e0 
[1:1:0712/154921.209776:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.210489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154921.210755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.234016:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 844, 7f2a189e1881
[1:1:0712/154921.271728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"616 0x7f2a1609c070 0x100e0d5b28e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.272080:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"616 0x7f2a1609c070 0x100e0d5b28e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.272470:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.273058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){
		$('.sliderContainer .slider .item:eq(' + (args- 1) + ')').fadeIn(1200,"easeInSine");
		$('.s
[1:1:0712/154921.273257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.303574:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154921.303786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154921.303984:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 868
[1:1:0712/154921.304212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f2a1609c070 0x100e0ed02d60 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 844 0x7f2a1609c070 0x100e0ed024e0 
[1:1:0712/154921.336604:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 13
[1:1:0712/154921.337101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 869
[1:1:0712/154921.337271:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7f2a1609c070 0x100e0ec270e0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 844 0x7f2a1609c070 0x100e0ed024e0 
[1:1:0712/154921.352596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154921.352788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 1000
[1:1:0712/154921.352978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 870
[1:1:0712/154921.353166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f2a1609c070 0x100e0ef27de0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 844 0x7f2a1609c070 0x100e0ed024e0 
[1:1:0712/154921.558733:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 868, 7f2a189e1881
[1:1:0712/154921.601665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"844 0x7f2a1609c070 0x100e0ed024e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.602121:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"844 0x7f2a1609c070 0x100e0ed024e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.602691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.603367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){Xn=t}
[1:1:0712/154921.603594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.606587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 869, 7f2a189e18db
[1:1:0712/154921.632258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"844 0x7f2a1609c070 0x100e0ed024e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.632441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"844 0x7f2a1609c070 0x100e0ed024e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.632663:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 882
[1:1:0712/154921.632793:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 882 0x7f2a1609c070 0x100e0e312f60 , 6:3_https://its.pku.edu.cn/, 0, , 869 0x7f2a1609c070 0x100e0ec270e0 
[1:1:0712/154921.632951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.633285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154921.633406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.757323:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 882, 7f2a189e18db
[1:1:0712/154921.770933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"869 0x7f2a1609c070 0x100e0ec270e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.771146:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"869 0x7f2a1609c070 0x100e0ec270e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.771365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 888
[1:1:0712/154921.771480:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f2a1609c070 0x100e0f090c60 , 6:3_https://its.pku.edu.cn/, 0, , 882 0x7f2a1609c070 0x100e0e312f60 
[1:1:0712/154921.771632:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.771915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154921.772038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.846484:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 888, 7f2a189e18db
[1:1:0712/154921.857663:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"882 0x7f2a1609c070 0x100e0e312f60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.857835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"882 0x7f2a1609c070 0x100e0e312f60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.858060:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 898
[1:1:0712/154921.858206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 898 0x7f2a1609c070 0x100e0ec2c6e0 , 6:3_https://its.pku.edu.cn/, 0, , 888 0x7f2a1609c070 0x100e0f090c60 
[1:1:0712/154921.858362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.858665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154921.858779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154921.964922:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 898, 7f2a189e18db
[1:1:0712/154921.975298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"888 0x7f2a1609c070 0x100e0f090c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.975453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"888 0x7f2a1609c070 0x100e0f090c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154921.975672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 903
[1:1:0712/154921.975802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7f2a1609c070 0x100e0ebe6d60 , 6:3_https://its.pku.edu.cn/, 0, , 898 0x7f2a1609c070 0x100e0ec2c6e0 
[1:1:0712/154921.975951:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154921.976260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154921.976399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.024277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 903, 7f2a189e18db
[1:1:0712/154922.035110:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"898 0x7f2a1609c070 0x100e0ec2c6e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.035322:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"898 0x7f2a1609c070 0x100e0ec2c6e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.035533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 908
[1:1:0712/154922.035647:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 908 0x7f2a1609c070 0x100e0d548c60 , 6:3_https://its.pku.edu.cn/, 0, , 903 0x7f2a1609c070 0x100e0ebe6d60 
[1:1:0712/154922.035804:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154922.036094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154922.036239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.067248:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 908, 7f2a189e18db
[1:1:0712/154922.078957:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"903 0x7f2a1609c070 0x100e0ebe6d60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.079128:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"903 0x7f2a1609c070 0x100e0ebe6d60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.079377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 912
[1:1:0712/154922.079508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 912 0x7f2a1609c070 0x100e0ee45160 , 6:3_https://its.pku.edu.cn/, 0, , 908 0x7f2a1609c070 0x100e0d548c60 
[1:1:0712/154922.079659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154922.079940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154922.080056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.118595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 912, 7f2a189e18db
[1:1:0712/154922.129731:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"908 0x7f2a1609c070 0x100e0d548c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.129908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"908 0x7f2a1609c070 0x100e0d548c60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.130113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 916
[1:1:0712/154922.130257:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f2a1609c070 0x100e0ede7e60 , 6:3_https://its.pku.edu.cn/, 0, , 912 0x7f2a1609c070 0x100e0ee45160 
[1:1:0712/154922.130416:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154922.130694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154922.130802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.210027:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 916, 7f2a189e18db
[1:1:0712/154922.245619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"912 0x7f2a1609c070 0x100e0ee45160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.245899:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"912 0x7f2a1609c070 0x100e0ee45160 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.246325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 921
[1:1:0712/154922.246522:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f2a1609c070 0x100e0e8597e0 , 6:3_https://its.pku.edu.cn/, 0, , 916 0x7f2a1609c070 0x100e0ede7e60 
[1:1:0712/154922.246804:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154922.247368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154922.247562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.408353:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 921, 7f2a189e18db
[1:1:0712/154922.446925:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"916 0x7f2a1609c070 0x100e0ede7e60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.447244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"916 0x7f2a1609c070 0x100e0ede7e60 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.447770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://its.pku.edu.cn/, 932
[1:1:0712/154922.448008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7f2a1609c070 0x100e0ee45160 , 6:3_https://its.pku.edu.cn/, 0, , 921 0x7f2a1609c070 0x100e0e8597e0 
[1:1:0712/154922.448361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154922.449068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , b.fx.tick, (){var e,n=b.timers,r=0;for(Xn=b.now();n.length>r;r++)e=n[r],e()||n[r]!==e||n.splice(r--,1);n.length
[1:1:0712/154922.449332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.570746:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 870, 7f2a189e1881
[1:1:0712/154922.607316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3a7800bc2860","ptid":"844 0x7f2a1609c070 0x100e0ed024e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.607665:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://its.pku.edu.cn/","ptid":"844 0x7f2a1609c070 0x100e0ed024e0 ","rf":"6:3_https://its.pku.edu.cn/"}
[1:1:0712/154922.608037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://its.pku.edu.cn/index_en.jsp"
[1:1:0712/154922.608643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://its.pku.edu.cn/, 3a7800bc2860, , , (){
			setBGopacity(args); /* -- zhangy 20180303 --- */
			sliderLoaded(args);
		}
[1:1:0712/154922.608826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://its.pku.edu.cn/index_en.jsp", "its.pku.edu.cn", 3, 1, , , 0
[1:1:0712/154922.752093:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x1b15e9ea29c8, 0x100e0cbe1150
[1:1:0712/154922.752441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://its.pku.edu.cn/index_en.jsp", 0
[1:1:0712/154922.752912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://its.pku.edu.cn/, 937
[1:1:0712/154922.753166:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7f2a1609c070 0x100e0ee80ae0 , 6:3_https://its.pku.edu.cn/, 1, -6:3_https://its.pku.edu.cn/, 870 0x7f2a1609c070 0x100e0ef27de0 
