[0712/155800.264062:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155800.264459:INFO:switcher_clone.cc(787)] backtrace rip is 7fd84b44f891
[0712/155801.268002:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155801.268311:INFO:switcher_clone.cc(787)] backtrace rip is 7f84387a9891
[1:1:0712/155801.279411:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/155801.279646:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/155801.288106:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[34997:34997:0712/155802.746073:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/155802.800998:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155802.801496:INFO:switcher_clone.cc(787)] backtrace rip is 7f68a2192891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/e1e18941-f16a-4e4b-9e81-c78a76189d26
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[35031:35031:0712/155803.036554:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35031
[35042:35042:0712/155803.037414:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=35042
[34997:34997:0712/155803.374256:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[34997:35028:0712/155803.375013:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/155803.375246:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155803.375515:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155803.376265:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155803.376541:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/155803.379965:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2ea1d28, 1
[1:1:0712/155803.380310:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1e25e0f9, 0
[1:1:0712/155803.380497:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x5ece601, 3
[1:1:0712/155803.380680:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1b0271ae, 2
[1:1:0712/155803.380878:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff9ffffffe0251e 281dffffffea02 ffffffae71021b 01ffffffe6ffffffec05 , 10104, 4
[1:1:0712/155803.381760:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34997:35028:0712/155803.381917:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��%(��q��G��2
[34997:35028:0712/155803.381954:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��%(��q���~G��2
[1:1:0712/155803.382029:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f84369e40a0, 3
[34997:35028:0712/155803.382233:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[34997:35028:0712/155803.382270:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35050, 4, f9e0251e 281dea02 ae71021b 01e6ec05 
[1:1:0712/155803.382158:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8436b6f080, 2
[1:1:0712/155803.382610:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8420832d20, -2
[1:1:0712/155803.392339:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155803.393229:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b0271ae
[1:1:0712/155803.394245:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b0271ae
[1:1:0712/155803.395893:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b0271ae
[1:1:0712/155803.397482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.397679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.397863:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.398052:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.398715:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b0271ae
[1:1:0712/155803.399066:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f84387a97ba
[1:1:0712/155803.399201:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f84387a0def, 7f84387a977a, 7f84387ab0cf
[1:1:0712/155803.404985:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1b0271ae
[1:1:0712/155803.405328:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1b0271ae
[1:1:0712/155803.406098:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1b0271ae
[1:1:0712/155803.408139:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.408342:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.408596:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.408785:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1b0271ae
[1:1:0712/155803.410044:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1b0271ae
[1:1:0712/155803.410403:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f84387a97ba
[1:1:0712/155803.410581:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f84387a0def, 7f84387a977a, 7f84387ab0cf
[1:1:0712/155803.418305:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155803.418741:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155803.418898:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdef13c408, 0x7ffdef13c388)
[1:1:0712/155803.434441:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155803.440656:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[34997:34997:0712/155804.121450:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34997:34997:0712/155804.123050:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[34997:35009:0712/155804.135380:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[34997:34997:0712/155804.135416:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[34997:35009:0712/155804.135487:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[34997:34997:0712/155804.135512:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[34997:34997:0712/155804.135706:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,35050, 4
[1:7:0712/155804.137658:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[34997:35022:0712/155804.195098:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/155804.271954:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x31f14f4e7220
[1:1:0712/155804.272130:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/155804.762980:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[34997:34997:0712/155806.308797:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[34997:34997:0712/155806.308943:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155806.325187:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155806.328453:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155807.235970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2fd811341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155807.236185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155807.241224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2fd811341f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155807.241398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155807.262293:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155807.409852:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155807.410037:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155807.646577:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 354, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155807.649870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2fd811341f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155807.650016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155807.667021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155807.669960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2fd811341f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155807.670095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155807.674611:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[34997:34997:0712/155807.678650:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155807.678815:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31f14f4e5e20
[1:1:0712/155807.679022:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[34997:34997:0712/155807.686973:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[34997:34997:0712/155807.719793:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[34997:34997:0712/155807.719951:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155807.778150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155808.434163:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f842240d2e0 0x31f14f70de60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155808.435864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2fd811341f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/155808.436113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155808.438026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[34997:34997:0712/155808.510976:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155808.513488:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x31f14f4e6820
[1:1:0712/155808.513751:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[34997:34997:0712/155808.520589:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/155808.531909:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/155808.532175:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[34997:34997:0712/155808.538354:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[34997:34997:0712/155808.549658:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34997:34997:0712/155808.550676:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[34997:35009:0712/155808.556652:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[34997:35009:0712/155808.556764:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[34997:34997:0712/155808.556907:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[34997:34997:0712/155808.556984:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[34997:34997:0712/155808.557117:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,35050, 4
[1:7:0712/155808.560107:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155808.991412:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/155809.388748:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f842240d2e0 0x31f14eeb71e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155809.390758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2fd811341f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/155809.391042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155809.391862:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[34997:34997:0712/155809.573302:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[34997:34997:0712/155809.573372:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/155809.589515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155810.068502:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[34997:34997:0712/155810.538996:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[34997:35028:0712/155810.539519:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/155810.539932:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155810.540229:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155810.540671:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155810.540819:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/155810.544118:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d09f408, 1
[1:1:0712/155810.544418:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2a078f10, 0
[1:1:0712/155810.544514:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x17909318, 3
[1:1:0712/155810.544560:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155810.544687:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x30b42282, 2
[1:1:0712/155810.544849:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 10ffffff8f072a 08fffffff4091d ffffff8222ffffffb430 18ffffff93ffffff9017 , 10104, 5
[1:1:0712/155810.544750:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155810.545540:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34997:35028:0712/155810.545727:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�*�	�"�0�����2
[1:1:0712/155810.545702:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f84369e40a0, 3
[34997:35028:0712/155810.545829:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �*�	�"�0���k���2
[1:1:0712/155810.545834:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8436b6f080, 2
[1:1:0712/155810.545944:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8420832d20, -2
[34997:35028:0712/155810.546073:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35095, 5, 108f072a 08f4091d 8222b430 18939017 
[1:1:0712/155810.558793:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155810.559183:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30b42282
[1:1:0712/155810.559505:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30b42282
[1:1:0712/155810.560187:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30b42282
[1:1:0712/155810.561624:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.561816:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.562007:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.562226:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.562884:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30b42282
[1:1:0712/155810.563209:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f84387a97ba
[1:1:0712/155810.563354:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f84387a0def, 7f84387a977a, 7f84387ab0cf
[1:1:0712/155810.570229:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 30b42282
[1:1:0712/155810.570710:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 30b42282
[1:1:0712/155810.571619:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 30b42282
[1:1:0712/155810.574205:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.574432:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.574618:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.574812:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 30b42282
[1:1:0712/155810.576374:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 30b42282
[1:1:0712/155810.576850:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f84387a97ba
[1:1:0712/155810.577042:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f84387a0def, 7f84387a977a, 7f84387ab0cf
[1:1:0712/155810.586871:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155810.587557:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155810.587755:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdef13c408, 0x7ffdef13c388)
[1:1:0712/155810.603167:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155810.607485:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/155810.773965:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31f14f484220
[1:1:0712/155810.774983:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/155810.855344:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 543, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155810.859933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2fd81146e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/155810.860294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155810.868534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[34997:34997:0712/155811.329456:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[34997:34997:0712/155811.364133:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[34997:35028:0712/155811.364717:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/155811.364994:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155811.365258:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155811.365810:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155811.365997:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/155811.370344:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2dc54b13, 1
[1:1:0712/155811.370826:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3447a3a4, 0
[1:1:0712/155811.371131:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x223958f2, 3
[1:1:0712/155811.371367:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1955665a, 2
[1:1:0712/155811.371613:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa4ffffffa34734 134bffffffc52d 5a665519 fffffff2583922 , 10104, 6
[1:1:0712/155811.372794:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[34997:35028:0712/155811.373136:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��G4K�-ZfU�X9"���2
[34997:35028:0712/155811.373213:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��G4K�-ZfU�X9"x���2
[34997:35028:0712/155811.373590:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 35111, 6, a4a34734 134bc52d 5a665519 f2583922 
[1:1:0712/155811.373391:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f84369e40a0, 3
[1:1:0712/155811.373781:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8436b6f080, 2
[1:1:0712/155811.373985:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8420832d20, -2
[34997:34997:0712/155811.389875:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/155811.400351:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155811.400749:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1955665a
[1:1:0712/155811.401063:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1955665a
[1:1:0712/155811.401709:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1955665a
[1:1:0712/155811.403201:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.403465:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.403736:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.403958:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.404680:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1955665a
[1:1:0712/155811.405025:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f84387a97ba
[1:1:0712/155811.405219:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f84387a0def, 7f84387a977a, 7f84387ab0cf
[1:1:0712/155811.411107:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1955665a
[1:1:0712/155811.411524:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1955665a
[1:1:0712/155811.412351:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1955665a
[1:1:0712/155811.414423:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.414697:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.414943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.415181:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1955665a
[1:1:0712/155811.416404:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1955665a
[1:1:0712/155811.416836:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f84387a97ba
[1:1:0712/155811.417015:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f84387a0def, 7f84387a977a, 7f84387ab0cf
[1:1:0712/155811.424870:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155811.425531:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155811.425724:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdef13c408, 0x7ffdef13c388)
[34997:35009:0712/155811.436015:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[34997:35009:0712/155811.436117:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[34997:34997:0712/155811.436640:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://bbs.pku.edu.cn/
[34997:34997:0712/155811.436718:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://bbs.pku.edu.cn/, https://bbs.pku.edu.cn/v2/login.php, 1
[34997:34997:0712/155811.436864:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://bbs.pku.edu.cn/, HTTP/1.1 200 OK X-Powered-By: PHP/5.6.31 Strict-Transport-Security: max-age=31536000 Set-Cookie: skey=ea1b3ddf1cf1a770; expires=Fri, 26-Jul-2019 22:58:11 GMT; Max-Age=1209600; path=/; domain=bbs.pku.edu.cn Set-Cookie: uid=15265; expires=Fri, 26-Jul-2019 22:58:11 GMT; Max-Age=1209600; path=/; domain=bbs.pku.edu.cn Set-Cookie: from_mobile_long=0; expires=Fri, 12-Jul-2019 22:58:10 GMT; Max-Age=-1; path=/v2/ Content-Encoding: gzip Vary: Accept-Encoding Content-Type: text/html; charset=UTF-8 Content-Length: 2185 Date: Fri, 12 Jul 2019 22:58:11 GMT Server: lighttpd/1.4.45 X-Cache: MISS from wiki.bdwm.net Via: 1.1 wiki.bdwm.net (squid/4.6) Connection: keep-alive Strict-Transport-Security: max-age=31536000  ,0, 6
[1:1:0712/155811.439513:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155811.444241:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/155811.445637:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/155811.534775:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155811.674741:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x31f14f4ac220
[1:1:0712/155811.675023:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/155811.773110:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://bbs.pku.edu.cn/
[34997:34997:0712/155812.061772:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://bbs.pku.edu.cn/, https://bbs.pku.edu.cn/, 1
[34997:34997:0712/155812.061881:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://bbs.pku.edu.cn/, https://bbs.pku.edu.cn
[1:1:0712/155812.079043:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155812.193576:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155812.302410:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155812.302695:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pku.edu.cn/v2/login.php"
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/155813.367593:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155813.368186:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155813.371479:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155813.372271:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155813.372766:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155813.756479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f84204e5070 0x31f14f1c82e0 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155813.758665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , 
    if (typeof(window.console) == 'undefined')
        window.console = {};
    if (typeof(window.c
[1:1:0712/155813.758912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155813.763996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f84204e5070 0x31f14f1c82e0 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155813.909795:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155814.512632:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f842084dbd0 0x31f14f6c3a58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155814.525570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , ;(function (root, factory) {
	if (typeof exports === "object") {
		// CommonJS
		module.exports = ex
[1:1:0712/155814.525863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155814.626399:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155815.146768:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f842084dbd0 0x31f14f6c3a58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155815.523207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f842084dbd0 0x31f14f6c3a58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155815.555398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f842084dbd0 0x31f14f6c3a58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155815.565539:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7f842084dbd0 0x31f14f6c3a58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155815.805247:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.666508, 0, 0
[1:1:0712/155815.805597:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155816.220753:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155816.221048:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.225072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.232386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , // Generated by CoffeeScript 1.9.2

/*
jQuery Gridly
Copyright 2015 Kevin Sylvestre
1.2.9
 */
[1:1:0712/155816.232722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155816.242484:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.258244:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.305192:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.315729:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.347805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.371371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.384535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.471989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155816.558827:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 313 0x7f84204e5070 0x31f14f6ccd60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155817.313598:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 350 0x7f842084dbd0 0x31f14f627c58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155817.328273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , !function(){window.BDWM||(window.BDWM={}),window.BDWM.storage={};var e="main_";1==window.test&&(e="t
[1:1:0712/155817.328594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155817.531337:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 350 0x7f842084dbd0 0x31f14f627c58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155817.949153:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 350 0x7f842084dbd0 0x31f14f627c58 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155817.965429:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.443216, 68, 1
[1:1:0712/155817.965730:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155818.259189:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155818.259474:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155818.260560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 376 0x7f84204e5070 0x31f14f59ce60 , "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155818.262292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , 
  var bgimg = document.getElementById('bgimg');
  var setMiddle = function () {
    var huge = docu
[1:1:0712/155818.262557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155818.276819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155820.238153:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c220
[1:1:0712/155820.238494:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155820.238933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 392
[1:1:0712/155820.239211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 392 0x7f84204e5070 0x31f150419b60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 376 0x7f84204e5070 0x31f14f59ce60 
[1:1:0712/155820.278795:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x4fbf64c29c8, 0x31f14f33c220
[1:1:0712/155820.279109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 60000
[1:1:0712/155820.279573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 393
[1:1:0712/155820.279926:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 393 0x7f84204e5070 0x31f14fb1ed60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 376 0x7f84204e5070 0x31f14f59ce60 
[1:1:0712/155820.421930:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x4fbf64c29c8, 0x31f14f33c220
[1:1:0712/155820.422123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 0
[1:1:0712/155820.422316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 394
[1:1:0712/155820.422445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 394 0x7f84204e5070 0x31f14f6bf7e0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 376 0x7f84204e5070 0x31f14f59ce60 
[1:1:0712/155820.439903:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 13
[1:1:0712/155820.440153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://bbs.pku.edu.cn/, 395
[1:1:0712/155820.440267:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7f84204e5070 0x31f14fb71360 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 376 0x7f84204e5070 0x31f14f59ce60 
[1:1:0712/155820.512565:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x4fbf64c29c8, 0x31f14f33c220
[1:1:0712/155820.512818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 60000
[1:1:0712/155820.513181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 396
[1:1:0712/155820.513373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 396 0x7f84204e5070 0x31f14f4f14e0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 376 0x7f84204e5070 0x31f14f59ce60 
[34997:34997:0712/155844.918340:INFO:CONSOLE(2)] "%c Welcome To BDWM Reborn!", source: https://bbs.pku.edu.cn/v2/js/all.min.js?v20 (2)
[34997:34997:0712/155844.921907:INFO:CONSOLE(2)] "%c ┏━━━━━━━━━━━━━┫北大未名ＢＢＳ┣━━━━━━━━━━━━━┓", source: https://bbs.pku.edu.cn/v2/js/all.min.js?v20 (2)
[34997:34997:0712/155844.925693:INFO:CONSOLE(2)] "　　┏┳┳┓┏╋━┓　┓┏　　　┓　　┏┳┳┓┏╋━┓━╋━　┣━━┓
　　┏┻┻┓┏╯┓　┏┫┣┛┗━╋┛　┏┻┻┓┏╯┓　┳╋┳┛╯━╮┃
　　┣╋━┫┃┃╋┛　┃┃┓　　┃　　┣╋━┫┃┃╋┛┃┃┃　┏━┻╯
　　　┃╋┓┃┃┃　┏┫┃┃　　┃╮　　┃╋┓┃┃┃　┃┃┃┓┏━━┓
　　┗╯╯╯╰┗┻┛╰┗╰┛┗━╯┛　┗╯╯╯╰┗┻┛╯┛┗╯┗━━╯
", source: https://bbs.pku.edu.cn/v2/js/all.min.js?v20 (2)
[34997:34997:0712/155844.929905:INFO:CONSOLE(2)] "%c ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛", source: https://bbs.pku.edu.cn/v2/js/all.min.js?v20 (2)
[34997:34997:0712/155844.933840:INFO:CONSOLE(2)] "%c No one knows the loneliness of a monkey coder.", source: https://bbs.pku.edu.cn/v2/js/all.min.js?v20 (2)
[34997:34997:0712/155844.934195:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/155844.943089:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/155845.003568:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155845.078630:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155845.305037:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155845.549739:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","https://bbs.pku.edu.cn/v2/libs/font/Tahoma.ttf"
[1:1:0712/155845.581779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/155845.582077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[34997:34997:0712/155846.127227:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: https://bbs.pku.edu.cn/v2/login.php (0)
[1:1:0712/155846.167037:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 394, 7f8422e2a881
[1:1:0712/155846.183406:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"376 0x7f84204e5070 0x31f14f59ce60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155846.184409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"376 0x7f84204e5070 0x31f14f59ce60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155846.184845:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155846.185501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){$a=void 0}
[1:1:0712/155846.185766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155846.212551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://bbs.pku.edu.cn/, 395, 7f8422e2a8db
[1:1:0712/155846.236985:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"376 0x7f84204e5070 0x31f14f59ce60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155846.237391:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"376 0x7f84204e5070 0x31f14f59ce60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155846.237863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://bbs.pku.edu.cn/, 469
[1:1:0712/155846.238111:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f84204e5070 0x31f14f6bf7e0 , 6:3_https://bbs.pku.edu.cn/, 0, , 395 0x7f84204e5070 0x31f14fb71360 
[1:1:0712/155846.238461:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155846.239039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , m.fx.tick, (){var a,b=m.timers,c=0;for($a=m.now();c<b.length;c++)a=b[c],a()||b[c]!==a||b.splice(c--,1);b.length
[1:1:0712/155846.239258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155846.342307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 392, 7f8422e2a881
[1:1:0712/155846.359038:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"376 0x7f84204e5070 0x31f14f59ce60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155846.359411:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"376 0x7f84204e5070 0x31f14f59ce60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155846.359866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155846.360490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155846.360736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155846.445380:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155846.445693:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155846.446106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 475
[1:1:0712/155846.446345:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 475 0x7f84204e5070 0x31f14fcb0060 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 392 0x7f84204e5070 0x31f150419b60 
[1:1:0712/155847.131339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , document.readyState
[1:1:0712/155847.131726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155847.349998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 475, 7f8422e2a881
[1:1:0712/155847.371120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"392 0x7f84204e5070 0x31f150419b60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155847.371487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"392 0x7f84204e5070 0x31f150419b60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155847.371952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155847.372542:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155847.372775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155847.377563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155847.377828:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155847.378571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 512
[1:1:0712/155847.378884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 512 0x7f84204e5070 0x31f1503a1f60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 475 0x7f84204e5070 0x31f14fcb0060 
[1:1:0712/155848.191842:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , document.readyState
[1:1:0712/155848.192160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.302057:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 512, 7f8422e2a881
[1:1:0712/155848.325772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"475 0x7f84204e5070 0x31f14fcb0060 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155848.326265:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"475 0x7f84204e5070 0x31f14fcb0060 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155848.326753:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155848.327563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155848.327902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.352383:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155848.352672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155848.353195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 529
[1:1:0712/155848.353433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7f84204e5070 0x31f14fd1e060 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 512 0x7f84204e5070 0x31f1503a1f60 
[1:1:0712/155848.376508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155848.377438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , () {
	hs.getPageSize();
	if (hs.viewport) for (var i = 0; i < hs.viewport.childNodes.length; i++) 
[1:1:0712/155848.377690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.380162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155848.406558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , document.readyState
[1:1:0712/155848.406901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.601313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , document.readyState
[1:1:0712/155848.601618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.666214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 529, 7f8422e2a881
[1:1:0712/155848.691682:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"512 0x7f84204e5070 0x31f1503a1f60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155848.692127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"512 0x7f84204e5070 0x31f1503a1f60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155848.692526:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155848.693191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155848.693416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.701396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155848.701614:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155848.702035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 546
[1:1:0712/155848.702270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 546 0x7f84204e5070 0x31f14fb706e0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 529 0x7f84204e5070 0x31f14fd1e060 
[1:1:0712/155848.715908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , document.readyState
[1:1:0712/155848.716233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.739208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155848.740056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , W, (){L||(L=!0,!I.initialized&&I.config.autoInitialize&&u())}
[1:1:0712/155848.740316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155848.740767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155848.741594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155849.258952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , document.readyState
[1:1:0712/155849.259274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/155850.836692:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 546, 7f8422e2a881
[1:1:0712/155850.874380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"529 0x7f84204e5070 0x31f14fd1e060 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155850.875105:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"529 0x7f84204e5070 0x31f14fd1e060 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155850.876036:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155850.877257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155850.877704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155850.893192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155850.893620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155850.894428:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 645
[1:1:0712/155850.894890:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f84204e5070 0x31f150a54d60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 546 0x7f84204e5070 0x31f14fb706e0 
[1:1:0712/155851.315463:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155851.316298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , graphic.onload, () { pThis.onGraphicLoad(); }
[1:1:0712/155851.316763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155851.555567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 645, 7f8422e2a881
[1:1:0712/155851.569215:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"546 0x7f84204e5070 0x31f14fb706e0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155851.569716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"546 0x7f84204e5070 0x31f14fb706e0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155851.570342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155851.571549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155851.572006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155851.579663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155851.580004:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155851.580682:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 664
[1:1:0712/155851.581081:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 664 0x7f84204e5070 0x31f150cdf960 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 645 0x7f84204e5070 0x31f150a54d60 
[1:1:0712/155851.892629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 664, 7f8422e2a881
[1:1:0712/155851.903158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"645 0x7f84204e5070 0x31f150a54d60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155851.903509:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"645 0x7f84204e5070 0x31f150a54d60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155851.903973:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155851.904609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155851.904923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155852.003291:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155852.003675:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155852.004136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 678
[1:1:0712/155852.004407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f84204e5070 0x31f1504a6ce0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 664 0x7f84204e5070 0x31f150cdf960 
[1:1:0712/155852.315336:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 678, 7f8422e2a881
[1:1:0712/155852.347455:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"664 0x7f84204e5070 0x31f150cdf960 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155852.347832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"664 0x7f84204e5070 0x31f150cdf960 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155852.348214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155852.348819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155852.349050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155852.356946:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155852.357156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155852.357553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 694
[1:1:0712/155852.357784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7f84204e5070 0x31f150a55fe0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 678 0x7f84204e5070 0x31f1504a6ce0 
[1:1:0712/155852.657769:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 694, 7f8422e2a881
[1:1:0712/155852.687451:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"678 0x7f84204e5070 0x31f1504a6ce0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155852.688203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"678 0x7f84204e5070 0x31f1504a6ce0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155852.689061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155852.690331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155852.690824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155852.704805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155852.705305:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155852.706210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 698
[1:1:0712/155852.706729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7f84204e5070 0x31f150d83e60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 694 0x7f84204e5070 0x31f150a55fe0 
[1:1:0712/155853.006398:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 698, 7f8422e2a881
[1:1:0712/155853.027005:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"694 0x7f84204e5070 0x31f150a55fe0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155853.027780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"694 0x7f84204e5070 0x31f150a55fe0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155853.028851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155853.030375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155853.030998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155853.048790:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155853.049181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155853.049688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 702
[1:1:0712/155853.050035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f84204e5070 0x31f1504a6ce0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 698 0x7f84204e5070 0x31f150d83e60 
[1:1:0712/155853.333216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 702, 7f8422e2a881
[1:1:0712/155853.361400:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"698 0x7f84204e5070 0x31f150d83e60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155853.361840:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"698 0x7f84204e5070 0x31f150d83e60 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155853.362358:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155853.363058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155853.363383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155853.371819:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155853.372207:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155853.372709:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 705
[1:1:0712/155853.373053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 705 0x7f84204e5070 0x31f14f2f77e0 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 702 0x7f84204e5070 0x31f1504a6ce0 
[1:1:0712/155853.655347:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 705, 7f8422e2a881
[1:1:0712/155853.698278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"702 0x7f84204e5070 0x31f1504a6ce0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155853.698700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"702 0x7f84204e5070 0x31f1504a6ce0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155853.699189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155853.699860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155853.700291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155853.708718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155853.709286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155853.710275:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 707
[1:1:0712/155853.710776:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7f84204e5070 0x31f14f6bde60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 705 0x7f84204e5070 0x31f14f2f77e0 
[1:1:0712/155853.999550:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 707, 7f8422e2a881
[1:1:0712/155854.067489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"0534f7022860","ptid":"705 0x7f84204e5070 0x31f14f2f77e0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155854.070380:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://bbs.pku.edu.cn/","ptid":"705 0x7f84204e5070 0x31f14f2f77e0 ","rf":"6:3_https://bbs.pku.edu.cn/"}
[1:1:0712/155854.071291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://bbs.pku.edu.cn/v2/login.php"
[1:1:0712/155854.072694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://bbs.pku.edu.cn/, 0534f7022860, , , (){a.each(function(){var n=$(this),m=n.width(),l=n.height(),o=$.data(this,d);if(m!==o.w||l!==o.h){n.
[1:1:0712/155854.073242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://bbs.pku.edu.cn/v2/login.php", "bbs.pku.edu.cn", 3, 1, , , 0
[1:1:0712/155854.084238:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x4fbf64c29c8, 0x31f14f33c150
[1:1:0712/155854.084692:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://bbs.pku.edu.cn/v2/login.php", 250
[1:1:0712/155854.085669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://bbs.pku.edu.cn/, 711
[1:1:0712/155854.086255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 711 0x7f84204e5070 0x31f14f5a4c60 , 6:3_https://bbs.pku.edu.cn/, 1, -6:3_https://bbs.pku.edu.cn/, 707 0x7f84204e5070 0x31f14f6bde60 
