[0712/054737.883623:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/054737.884042:INFO:switcher_clone.cc(787)] backtrace rip is 7f99cae6d891
[0712/054738.905413:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/054738.905662:INFO:switcher_clone.cc(787)] backtrace rip is 7f603e8f3891
[1:1:0712/054738.917102:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/054738.917349:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/054738.928468:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[85986:85986:0712/054740.071799:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dbf80512-d76e-4528-a1f1-5eb9e65283d6
[85986:85986:0712/054740.377843:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[85986:86015:0712/054740.378633:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/054740.378835:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/054740.379088:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/054740.379690:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/054740.379851:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/054740.382775:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x71e4cc0, 1
[1:1:0712/054740.383110:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x207f062c, 0
[1:1:0712/054740.383280:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3ed74d4c, 3
[1:1:0712/054740.383479:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2166190a, 2
[1:1:0712/054740.383608:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2c067f20 ffffffc04c1e07 0a196621 4c4dffffffd73e , 10104, 4
[1:1:0712/054740.384231:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[85986:86015:0712/054740.384444:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING, �L
f!LM�>�'
[1:1:0712/054740.384413:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f603cb2e0a0, 3
[85986:86015:0712/054740.384521:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is , �L
f!LM�>8�'
[1:1:0712/054740.384557:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f603ccb9080, 2
[1:1:0712/054740.384714:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f602697cd20, -2
[85986:86015:0712/054740.384837:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[85986:86015:0712/054740.384928:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 86031, 4, 2c067f20 c04c1e07 0a196621 4c4dd73e 
[1:1:0712/054740.402866:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/054740.403914:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2166190a
[1:1:0712/054740.405089:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2166190a
[1:1:0712/054740.406987:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2166190a
[1:1:0712/054740.408539:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.408730:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.408919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.409098:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.409828:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2166190a
[1:1:0712/054740.410229:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f603e8f37ba
[1:1:0712/054740.410398:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f603e8eadef, 7f603e8f377a, 7f603e8f50cf
[1:1:0712/054740.415058:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2166190a
[1:1:0712/054740.415250:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2166190a
[1:1:0712/054740.415561:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2166190a
[1:1:0712/054740.416277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.416389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.416675:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.416914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2166190a
[1:1:0712/054740.418493:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2166190a
[1:1:0712/054740.418964:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f603e8f37ba
[1:1:0712/054740.419134:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f603e8eadef, 7f603e8f377a, 7f603e8f50cf
[1:1:0712/054740.424656:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/054740.424996:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/054740.425088:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2cd79648, 0x7fff2cd795c8)
[1:1:0712/054740.439538:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/054740.445455:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[0712/054740.447089:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/054740.447378:INFO:switcher_clone.cc(787)] backtrace rip is 7f5d4303d891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[86017:86017:0712/054740.602485:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=86017
[86045:86045:0712/054740.602956:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=86045
[85986:85986:0712/054740.973635:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[85986:85986:0712/054740.975119:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[85986:85997:0712/054740.991302:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[85986:85986:0712/054740.991383:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[85986:85997:0712/054740.991422:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[85986:85986:0712/054740.991480:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[85986:85986:0712/054740.991688:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,86031, 4
[1:7:0712/054740.994040:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[85986:86008:0712/054741.055404:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/054741.095042:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x15c2ebf1f220
[1:1:0712/054741.095246:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/054741.334108:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/054742.807246:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054742.810926:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[85986:85986:0712/054742.854210:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[85986:85986:0712/054742.854271:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/054744.346426:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054744.489322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/054744.489669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054744.524759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/054744.525084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054744.952878:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054744.953213:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054745.409916:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054745.418036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/054745.418238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054745.453292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054745.463926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/054745.464220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054745.476720:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[85986:85986:0712/054745.478558:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/054745.481813:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x15c2ebf1de20
[1:1:0712/054745.482015:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[85986:85986:0712/054745.486088:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[85986:85986:0712/054745.519713:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[85986:85986:0712/054745.519912:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/054745.579285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054746.303291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f60285572e0 0x15c2ec135160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054746.305043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/054746.305269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054746.305911:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[85986:85986:0712/054746.335953:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/054746.338735:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x15c2ebf1e820
[1:1:0712/054746.339616:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[85986:85986:0712/054746.340726:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/054746.359013:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/054746.359222:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[85986:85986:0712/054746.362291:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[85986:85986:0712/054746.383577:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[85986:85986:0712/054746.383996:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[85986:85986:0712/054746.386249:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[85986:85997:0712/054746.386224:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[85986:85986:0712/054746.386289:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[85986:85997:0712/054746.386321:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[85986:85986:0712/054746.386348:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,86031, 4
[1:7:0712/054746.387829:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/054746.959853:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/054747.359781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7f60285572e0 0x15c2ec2d5ee0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054747.360920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/054747.361201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054747.361971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[85986:85986:0712/054747.472792:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[85986:85986:0712/054747.472862:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/054747.484511:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/054747.948847:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[85986:85986:0712/054748.168199:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[85986:86015:0712/054748.168741:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/054748.169000:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/054748.169252:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/054748.169735:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/054748.169906:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/054748.173635:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1df7857f, 1
[1:1:0712/054748.174148:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3944656b, 0
[1:1:0712/054748.174389:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3cf91e15, 3
[1:1:0712/054748.174574:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x5e3cbf2, 2
[1:1:0712/054748.174746:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6b654439 7fffffff85fffffff71d fffffff2ffffffcbffffffe305 151efffffff93c , 10104, 5
[1:1:0712/054748.175988:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[85986:86015:0712/054748.176250:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGkeD9������<'
[85986:86015:0712/054748.176396:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is keD9������<�B'
[1:1:0712/054748.176545:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f603cb2e0a0, 3
[85986:86015:0712/054748.176691:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 86083, 5, 6b654439 7f85f71d f2cbe305 151ef93c 
[1:1:0712/054748.176786:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f603ccb9080, 2
[1:1:0712/054748.177004:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f602697cd20, -2
[1:1:0712/054748.203151:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/054748.203633:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5e3cbf2
[1:1:0712/054748.204019:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5e3cbf2
[1:1:0712/054748.204810:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5e3cbf2
[1:1:0712/054748.206528:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.206757:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.206981:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.207199:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.208009:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5e3cbf2
[1:1:0712/054748.208430:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f603e8f37ba
[1:1:0712/054748.208602:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f603e8eadef, 7f603e8f377a, 7f603e8f50cf
[1:1:0712/054748.210709:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 5e3cbf2
[1:1:0712/054748.210888:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 5e3cbf2
[1:1:0712/054748.211165:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 5e3cbf2
[1:1:0712/054748.211885:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.212013:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.212112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.212208:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 5e3cbf2
[1:1:0712/054748.213467:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 5e3cbf2
[1:1:0712/054748.213843:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f603e8f37ba
[1:1:0712/054748.213987:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f603e8eadef, 7f603e8f377a, 7f603e8f50cf
[1:1:0712/054748.222733:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/054748.223222:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/054748.223322:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2cd79648, 0x7fff2cd795c8)
[1:1:0712/054748.240582:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/054748.245616:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/054748.426549:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x15c2ebed8220
[1:1:0712/054748.426793:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/054748.462003:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054748.462306:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/054748.947879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/054748.952509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 119755d6e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/054748.952802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/054748.961557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/054749.280084:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/054749.281041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 119755c41f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/054749.281300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/054749.599630:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/054749.601383:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/054749.601567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 119755d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/054749.601835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/054749.763516:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/054749.788814:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/054749.789120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 119755d6e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/054749.789393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[85986:85986:0712/054750.095089:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[85986:85986:0712/054750.103093:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[85986:85997:0712/054750.133080:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[85986:85986:0712/054750.133305:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.amazon.co.uk/
[85986:85997:0712/054750.133604:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[85986:85986:0712/054750.133624:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.amazon.co.uk/, https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc, 1
[85986:85986:0712/054750.133789:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.amazon.co.uk/, HTTP/1.1 200 status:200 content-type:text/html; charset=UTF-8 server:Server date:Fri, 12 Jul 2019 12:47:49 GMT strict-transport-security:max-age=47474747; includeSubDomains; preload x-amz-id-1:8TRD2KRE656BFG70JG71 p3p:policyref="https://www.amazon.co.uk/w3c/p3p.xml",CP="CAO DSP LAW CUR ADM IVAo IVDo CONo OTPo OUR DELi PUBi OTRi BUS PHY ONL UNI PUR FIN COM NAV INT DEM CNT STA HEA PRE LOC GOV OTC " x-frame-options:SAMEORIGIN vary:Accept-Encoding,User-Agent,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment content-encoding:gzip set-cookie:ubid-acbuk=258-5441289-0864652; path=/; domain=.amazon.co.uk; expires=Tue, 01-Jan-2036 00:00:01 GMT set-cookie:session-id-time=2082758401l; path=/; domain=.amazon.co.uk; expires=Tue, 01-Jan-2036 00:00:01 GMT set-cookie:session-id=257-4106731-2641612; path=/; domain=.amazon.co.uk; expires=Tue, 01-Jan-2036 00:00:01 GMT x-amz-rid:8TRD2KRE656BFG70JG71 x-cache:Miss from cloudfront via:1.1 1cf21915c275f27e3131c7fb06d8fe2e.cloudfront.net (CloudFront) x-amz-cf-pop:SFO5-C3 x-amz-cf-id:QhvUNgWZDjzx36oLwHq1CnIZgZqAlPbk6CXc_F4Wq-S8Dj6WVxkRow==  ,86083, 5
[1:7:0712/054750.138589:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/054750.166199:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.amazon.co.uk/
[85986:85986:0712/054750.308803:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.amazon.co.uk/, https://www.amazon.co.uk/, 1
[85986:85986:0712/054750.308999:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.amazon.co.uk/, https://www.amazon.co.uk
[1:1:0712/054750.345996:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/054750.347032:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/054750.459493:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054750.522414:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/054750.591586:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/054750.597335:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054750.597601:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054750.637547:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 137 0x7f602662f070 0x15c2ebc479e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054750.638712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , var ue_t0=ue_t0||+new Date();
[1:1:0712/054750.639001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054750.642901:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 137 0x7f602662f070 0x15c2ebc479e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054750.656785:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054750.757299:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[1:1:0712/054750.783594:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/054750.970672:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/054751.112136:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[1:1:0712/054751.201414:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/054751.277742:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/054751.367060:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/054751.446325:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/054751.521485:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/054751.958208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f602662f070 0x15c2ec099760 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054751.966805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , 
(function(g,h,Q,z){function G(a){x&&x.tag&&x.tag(q(":","aui",a))}function v(a,b){x&&x.count&&x.coun
[1:1:0712/054751.967096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054751.978665:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3612c6347e60
[1:1:0712/054751.993562:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x146d5fb429c8, 0x15c2ebcaf1a0
[1:1:0712/054751.993837:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 20
[1:1:0712/054751.994628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 199
[1:1:0712/054751.994892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 199 0x7f602662f070 0x15c2ebf68f60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 187 0x7f602662f070 0x15c2ec099760 
[1:1:0712/054752.093086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf1a0
[1:1:0712/054752.093430:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054752.094058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 201
[1:1:0712/054752.094318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 201 0x7f602662f070 0x15c2ec09b7e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 187 0x7f602662f070 0x15c2ec099760 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/054757.664673:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054757.667995:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054757.668444:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054757.668988:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054757.669390:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[85986:85986:0712/054809.065179:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/054809.081435:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/054809.239194:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f602662f070 0x15c2ec099760 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054809.245749:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f602662f070 0x15c2ec099760 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054809.261924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f602662f070 0x15c2ec099760 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054809.321882:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf1e0
[1:1:0712/054809.322171:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054809.322788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 251
[1:1:0712/054809.323010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 251 0x7f602662f070 0x15c2ebcab9e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 187 0x7f602662f070 0x15c2ec099760 
[1:1:0712/054809.343236:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f602662f070 0x15c2ec099760 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054809.350162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 187 0x7f602662f070 0x15c2ec099760 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054809.602065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/054809.602354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054810.500077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 199, 7f6028f74881
[1:1:0712/054810.516568:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"187 0x7f602662f070 0x15c2ec099760 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054810.516986:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"187 0x7f602662f070 0x15c2ec099760 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054810.517409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054810.518361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ia, (){h.body?p.trigger("a-bodyBegin"):setTimeout(ia,20)}
[1:1:0712/054810.518626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054810.523054:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 201, 7f6028f74881
[1:1:0712/054810.533557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"187 0x7f602662f070 0x15c2ec099760 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054810.533966:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"187 0x7f602662f070 0x15c2ec099760 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054810.534331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054810.535323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054810.535556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054810.537131:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054810.537340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054810.538059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 295
[1:1:0712/054810.538335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 295 0x7f602662f070 0x15c2ec2b7a60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 201 0x7f602662f070 0x15c2ec09b7e0 
[1:1:0712/054810.667077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054810.667415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054811.056920:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054811.088253:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 251, 7f6028f74881
[1:1:0712/054811.094638:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"187 0x7f602662f070 0x15c2ec099760 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054811.094841:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"187 0x7f602662f070 0x15c2ec099760 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054811.095071:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.095437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054811.095552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054811.109884:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054811.110127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054811.110391:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 324
[1:1:0712/054811.110505:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 324 0x7f602662f070 0x15c2ec0c5660 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 251 0x7f602662f070 0x15c2ebcab9e0 
[1:1:0712/054811.381769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054811.381948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054811.809958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 322 0x7f60285572e0 0x15c2ec2625e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.812019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(f){var c=window.AmazonUIPageJS||window.P,e=c._namespace||c.attributeErrors,g=e?e("CSHelpOm
[1:1:0712/054811.812201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054811.819259:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf1a8
[1:1:0712/054811.819532:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054811.820159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 343
[1:1:0712/054811.820450:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 343 0x7f602662f070 0x15c2ec6cc860 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 322 0x7f60285572e0 0x15c2ec2625e0 
[1:1:0712/054811.891991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.893288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , 
(window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function() {
  (window.AmazonUIP
[1:1:0712/054811.893487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054811.898067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.912711:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.917492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.922650:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.923995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.927576:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.932426:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.934986:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.936848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.939016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.943523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.947435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.951124:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.955915:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.960268:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.967703:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054811.972239:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7f602662f070 0x15c2ec0cd160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054812.005777:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.108828, 172, 1
[1:1:0712/054812.006094:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054812.043309:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054812.044343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){clearTimeout(la);N=4;L()}
[1:1:0712/054812.044463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054812.346250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054812.346643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054812.486653:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 343, 7f6028f74881
[1:1:0712/054812.509151:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"322 0x7f60285572e0 0x15c2ec2625e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054812.509547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"322 0x7f60285572e0 0x15c2ec2625e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054812.509950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054812.510748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054812.510976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054812.511914:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054812.512143:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054812.512826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 414
[1:1:0712/054812.513107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7f602662f070 0x15c2ec0ccae0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 343 0x7f602662f070 0x15c2ec6cc860 
[1:1:0712/054813.352683:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054813.352992:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054813.354195:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f602662f070 0x15c2ec0b16e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054813.355394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , window.navmet.push({key:'Search',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/054813.355643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054813.359471:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 392 0x7f602662f070 0x15c2ec0b16e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054813.368136:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0147982, 64, 1
[1:1:0712/054813.368378:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054813.392488:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 324, 7f6028f74881
[1:1:0712/054813.416712:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"251 0x7f602662f070 0x15c2ebcab9e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054813.417105:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"251 0x7f602662f070 0x15c2ebcab9e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054813.417612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054813.418561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054813.418782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054813.461441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054813.461642:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054813.461887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 426
[1:1:0712/054813.462010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7f602662f070 0x15c2ec0c60e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 324 0x7f602662f070 0x15c2ec0c5660 
[1:1:0712/054813.516167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054813.516431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054813.802854:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 414, 7f6028f74881
[1:1:0712/054813.809419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"343 0x7f602662f070 0x15c2ec6cc860 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054813.809611:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"343 0x7f602662f070 0x15c2ec6cc860 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054813.809940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054813.810892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054813.811142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054813.811782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054813.811890:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054813.812106:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 434
[1:1:0712/054813.812214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 434 0x7f602662f070 0x15c2ec2ab3e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 414 0x7f602662f070 0x15c2ec0ccae0 
[1:1:0712/054814.130802:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054814.131083:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.132493:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f602662f070 0x15c2ebefbbe0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.133933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , window.navmet.push({key:'Tools',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/054814.134289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054814.140069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f602662f070 0x15c2ebefbbe0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.145880:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f602662f070 0x15c2ebefbbe0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.151154:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7f602662f070 0x15c2ebefbbe0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.161705:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.030324, 88, 1
[1:1:0712/054814.161993:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054814.218103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054814.218541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054814.670883:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054814.671203:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.672530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453 0x7f602662f070 0x15c2ebd53d60 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.674250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , window.navmet.push({key:'Subnav',end:+new Date(),begin:window.navmet.tmp});
[1:1:0712/054814.674484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054814.678053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453 0x7f602662f070 0x15c2ebd53d60 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.682113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 453 0x7f602662f070 0x15c2ebd53d60 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.693157:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0216091, 53, 1
[1:1:0712/054814.693473:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054814.717732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054814.718051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054814.823980:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 426, 7f6028f74881
[1:1:0712/054814.847204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"324 0x7f602662f070 0x15c2ec0c5660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054814.847590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"324 0x7f602662f070 0x15c2ec0c5660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054814.848136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054814.848988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054814.849221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054814.895191:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054814.895492:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054814.896152:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 481
[1:1:0712/054814.896388:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 481 0x7f602662f070 0x15c2ebeef260 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 426 0x7f602662f070 0x15c2ec0c60e0 
[1:1:0712/054815.293250:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054815.293540:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054815.295877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f602662f070 0x15c2ec52b160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054815.304331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , <!--

window.$Nav && $Nav.declare("config.navDeviceType", "desktop");

window.$Nav && $Nav.when("dat
[1:1:0712/054815.304785:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054815.411424:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f602662f070 0x15c2ec52b160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054815.415310:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 474 0x7f602662f070 0x15c2ec52b160 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054815.454811:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.161085, 239, 1
[1:1:0712/054815.455229:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054815.478376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054815.478565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054815.513582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7f60285572e0 0x15c2ec0e51e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054815.542674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , /*
 jQuery JavaScript Library v1.6.4
 http://jquery.com/

 Copyright 2011, John Resig
 Dual licensed
[1:1:0712/054815.542927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054816.445620:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf160
[1:1:0712/054816.445973:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054816.446677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 504
[1:1:0712/054816.446918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7f602662f070 0x15c2ec70cce0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 479 0x7f60285572e0 0x15c2ec0e51e0 
[1:1:0712/054817.192026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054817.193464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , i.onload, () {window.uet && uet('ne')}
[1:1:0712/054817.196264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054817.390376:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054817.390640:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054817.391798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 499 0x7f602662f070 0x15c2ec52bf60 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054817.392999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , 
  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-eu.ssl-images-amazon.com/ima
[1:1:0712/054817.393228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054817.420419:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.02948, 88, 1
[1:1:0712/054817.420716:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054817.446235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054817.446596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054817.464553:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 481, 7f6028f74881
[1:1:0712/054817.488660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"426 0x7f602662f070 0x15c2ec0c60e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054817.489069:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"426 0x7f602662f070 0x15c2ec0c60e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054817.489549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054817.490390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054817.490658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054817.546364:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054817.546768:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054817.548076:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 534
[1:1:0712/054817.548355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f602662f070 0x15c2ec8ca460 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 481 0x7f602662f070 0x15c2ebeef260 
[1:1:0712/054817.550298:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 504, 7f6028f74881
[1:1:0712/054817.576727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"479 0x7f60285572e0 0x15c2ec0e51e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054817.577088:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"479 0x7f60285572e0 0x15c2ec0e51e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054817.577645:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054817.578752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054817.579065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054817.580373:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054817.580654:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054817.581502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 537
[1:1:0712/054817.581786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 537 0x7f602662f070 0x15c2ebfc72e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 504 0x7f602662f070 0x15c2ec70cce0 
[1:1:0712/054818.198816:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054818.199049:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054818.200202:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 532 0x7f602662f070 0x15c2ec0316e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054818.201850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , 
  if ( ! window.stageMarkers) {
     window.stageMarkers = {};
     window.stageMarkers.count = {};
[1:1:0712/054818.202093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054818.266451:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.067085, 741, 1
[1:1:0712/054818.266659:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/054818.282441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054818.282655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054818.328816:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 537, 7f6028f74881
[1:1:0712/054818.340325:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"504 0x7f602662f070 0x15c2ec70cce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054818.340544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"504 0x7f602662f070 0x15c2ec70cce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054818.341019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054818.341378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054818.341500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054818.341830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054818.341927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054818.342142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 568
[1:1:0712/054818.342265:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 568 0x7f602662f070 0x15c2ec704660 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 537 0x7f602662f070 0x15c2ebfc72e0 
[1:1:0712/054819.288753:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.293484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , onload, if (typeof uet == 'function') { uet('cf'); }
[1:1:0712/054819.295411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/054819.310097:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.311432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , onload, if (typeof uet == 'function') { uet('cf'); }
[1:1:0712/054819.311753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054819.534165:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/054819.534469:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.535750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.537600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(a,b){a.attachEvent?a.attachEvent("onload",b):a.addEventListener&&a.addEventListener("load"
[1:1:0712/054819.537911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054819.556428:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.569735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.586400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.592806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.600270:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.605976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.611465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.624219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.637595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.651608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.660303:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.676398:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf1d0
[1:1:0712/054819.676677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054819.677311:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 626
[1:1:0712/054819.677563:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7f602662f070 0x15c2ec498be0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.679954:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600000, 0x146d5fb429c8, 0x15c2ebcaf1d0
[1:1:0712/054819.680162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 600000
[1:1:0712/054819.680774:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 627
[1:1:0712/054819.681017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7f602662f070 0x15c2ecdfc6e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.682178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x146d5fb429c8, 0x15c2ebcaf1d0
[1:1:0712/054819.682399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 3000
[1:1:0712/054819.683169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 628
[1:1:0712/054819.683407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7f602662f070 0x15c2ec0c6be0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.740379:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x146d5fb429c8, 0x15c2ebcaf1d0
[1:1:0712/054819.740703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 500
[1:1:0712/054819.741491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 629
[1:1:0712/054819.741803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7f602662f070 0x15c2ecdf4b60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.792205:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 3000
[1:1:0712/054819.792940:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.co.uk/, 630
[1:1:0712/054819.793193:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7f602662f070 0x15c2ecece1e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.798724:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.815531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.824937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.834475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.840721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.850735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.867274:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.871851:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.879500:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.889725:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.895726:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x146d5fb429c8, 0x15c2ebcaf1a0
[1:1:0712/054819.896012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 5000
[1:1:0712/054819.896631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 654
[1:1:0712/054819.896863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 654 0x7f602662f070 0x15c2ecdcbfe0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.899385:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.905016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.918826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.935208:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.945601:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x146d5fb429c8, 0x15c2ebcaf1a0
[1:1:0712/054819.945899:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 10000
[1:1:0712/054819.946524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 663
[1:1:0712/054819.946760:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f602662f070 0x15c2ec0d79e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 560 0x7f602662f070 0x15c2ec8c8ce0 
[1:1:0712/054819.960420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f602662f070 0x15c2ec8c8ce0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.981440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054819.997415:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054820.134273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054820.134572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054820.236789:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566 0x7f60285572e0 0x15c2ec4a7de0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054820.238602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(b){var c=window.AmazonUIPageJS||window.P,d=c._namespace||c.attributeErrors,a=d?d("CSHelpHM
[1:1:0712/054820.238845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054820.306431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 568, 7f6028f74881
[1:1:0712/054820.343959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"537 0x7f602662f070 0x15c2ebfc72e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054820.344377:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"537 0x7f602662f070 0x15c2ebfc72e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054820.344815:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054820.345637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054820.345875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054820.346818:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054820.347012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054820.347683:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 678
[1:1:0712/054820.347942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f602662f070 0x15c2ec0d47e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 568 0x7f602662f070 0x15c2ec704660 
[1:1:0712/054820.354089:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054820.354353:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 16
[1:1:0712/054820.354989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 679
[1:1:0712/054820.355230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f602662f070 0x15c2ebbbef60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 568 0x7f602662f070 0x15c2ec704660 
[1:1:0712/054820.393735:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054820.394029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054820.394628:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 680
[1:1:0712/054820.394910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f602662f070 0x15c2ec4aa0e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 568 0x7f602662f070 0x15c2ec704660 
[1:1:0712/054820.440464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 534, 7f6028f74881
[1:1:0712/054820.459869:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"481 0x7f602662f070 0x15c2ebeef260 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054820.460255:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"481 0x7f602662f070 0x15c2ebeef260 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054820.460722:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054820.461633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054820.461850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054820.546443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054820.546845:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054820.547773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 686
[1:1:0712/054820.548027:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 686 0x7f602662f070 0x15c2ecdcca60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 534 0x7f602662f070 0x15c2ec8ca460 
[1:1:0712/054821.578050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 626, 7f6028f74881
[1:1:0712/054821.597398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.597765:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.598155:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054821.598971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , l, (){var a=b.length;if(0<a){for(var f=[],c=0;c<a;c++){var g=b[c].api;g.ready()?(g.on({ts:e.d,ns:n}),d.
[1:1:0712/054821.599223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054821.632533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054821.632824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054821.691173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 629, 7f6028f74881
[1:1:0712/054821.706772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.707154:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.707560:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054821.708376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){s(function(){f.executed||
a()})}
[1:1:0712/054821.708616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054821.755029:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 678, 7f6028f74881
[1:1:0712/054821.777259:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"568 0x7f602662f070 0x15c2ec704660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.777634:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"568 0x7f602662f070 0x15c2ec704660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.778092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054821.778920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054821.779177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054821.780156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054821.780389:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054821.780995:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 717
[1:1:0712/054821.781277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 717 0x7f602662f070 0x15c2ec499160 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 678 0x7f602662f070 0x15c2ec0d47e0 
[1:1:0712/054821.836334:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 679, 7f6028f74881
[1:1:0712/054821.870502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"568 0x7f602662f070 0x15c2ec704660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.870887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"568 0x7f602662f070 0x15c2ec704660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.871361:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054821.872218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/054821.872439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054821.873497:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054821.873701:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 16
[1:1:0712/054821.874317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 720
[1:1:0712/054821.874564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 720 0x7f602662f070 0x15c2ec49e060 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 679 0x7f602662f070 0x15c2ebbbef60 
[1:1:0712/054821.876064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 680, 7f6028f74881
[1:1:0712/054821.897578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"568 0x7f602662f070 0x15c2ec704660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.898006:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"568 0x7f602662f070 0x15c2ec704660 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054821.898496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054821.899343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){return c.apply(null,
f)}
[1:1:0712/054821.899586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054821.902320:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054821.902543:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 100
[1:1:0712/054821.903187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 721
[1:1:0712/054821.903441:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7f602662f070 0x15c2ec019560 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 680 0x7f602662f070 0x15c2ec4aa0e0 
[1:1:0712/054822.365113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 706 0x7f60285572e0 0x15c2ebc2aa60 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054822.368933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(l){var d=window.AmazonUIPageJS||window.P,m=d._namespace||d.attributeErrors,f=m?m("CSHelpSe
[1:1:0712/054822.369265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054822.439402:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 707 0x7f60285572e0 0x15c2ecde8be0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054822.445970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(g){var f=window.AmazonUIPageJS||window.P,k=f._namespace||f.attributeErrors,b=k?k("CSHelpVi
[1:1:0712/054822.446255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054822.474086:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 686, 7f6028f74881
[1:1:0712/054822.497308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"534 0x7f602662f070 0x15c2ec8ca460 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054822.497880:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"534 0x7f602662f070 0x15c2ec8ca460 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054822.498356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054822.499173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054822.499480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054822.552168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054822.552468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054822.553219:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 732
[1:1:0712/054822.553513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f602662f070 0x15c2ec2912e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 686 0x7f602662f070 0x15c2ecdcca60 
[1:1:0712/054822.574776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054822.575113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054822.777505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){f.executed||
a()}
[1:1:0712/054822.777839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054822.793169:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x146d5fb429c8, 0x15c2ebcaf168
[1:1:0712/054822.793496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 500
[1:1:0712/054822.794243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 745
[1:1:0712/054822.794514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f602662f070 0x15c2ec731360 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 716 0x7f6035940960 0x15c2ed06f6a0 0x15c2ed06f6b0 
[1:1:0712/054822.798152:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 717, 7f6028f74881
[1:1:0712/054822.832273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"678 0x7f602662f070 0x15c2ec0d47e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054822.832667:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"678 0x7f602662f070 0x15c2ec0d47e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054822.833151:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054822.834157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054822.834484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054822.835471:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054822.835704:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054822.836323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 749
[1:1:0712/054822.836560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7f602662f070 0x15c2ecdcfbe0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 717 0x7f602662f070 0x15c2ec499160 
[1:1:0712/054822.839505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054822.839762:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 500
[1:1:0712/054822.840437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 750
[1:1:0712/054822.840682:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7f602662f070 0x15c2ed1452e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 717 0x7f602662f070 0x15c2ec499160 
[1:1:0712/054822.917200:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054822.921179:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054822.922241:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/054823.254081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 720, 7f6028f74881
[1:1:0712/054823.292578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"679 0x7f602662f070 0x15c2ebbbef60 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054823.292952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"679 0x7f602662f070 0x15c2ebbbef60 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054823.293435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.294274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/054823.294514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054823.295578:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054823.295825:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 16
[1:1:0712/054823.296407:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 753
[1:1:0712/054823.296657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f602662f070 0x15c2ec498b60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 720 0x7f602662f070 0x15c2ec49e060 
[1:1:0712/054823.391641:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 721, 7f6028f74881
[1:1:0712/054823.429309:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"680 0x7f602662f070 0x15c2ec4aa0e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054823.429714:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"680 0x7f602662f070 0x15c2ec4aa0e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054823.430210:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.431154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){return c.apply(null,
f)}
[1:1:0712/054823.431381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054823.558689:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.559619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){c[a]||(c[a]=1,D(a))}
[1:1:0712/054823.559807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054823.738498:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 10000
[1:1:0712/054823.739159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.co.uk/, 759
[1:1:0712/054823.739359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7f602662f070 0x15c2ec52e560 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 730 0x7f602662f070 0x15c2ec52c060 
[1:1:0712/054823.759913:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.761530:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.788232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.790378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.827703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.828618:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.829820:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x146d5fb429c8, 0x15c2ebcaf1f0
[1:1:0712/054823.829989:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 300
[1:1:0712/054823.830566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 770
[1:1:0712/054823.830768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7f602662f070 0x15c2ed145e60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 730 0x7f602662f070 0x15c2ec52c060 
[1:1:0712/054823.831130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.835295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x146d5fb429c8, 0x15c2ebcaf1f0
[1:1:0712/054823.835509:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 50
[1:1:0712/054823.836172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 771
[1:1:0712/054823.836384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7f602662f070 0x15c2ecde8be0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 730 0x7f602662f070 0x15c2ec52c060 
[1:1:0712/054823.836845:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.837774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.839118:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054823.850341:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x146d5fb429c8, 0x15c2ebcaf1f0
[1:1:0712/054823.850568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1500
[1:1:0712/054823.851157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 772
[1:1:0712/054823.851370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7f602662f070 0x15c2ec6caf60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 730 0x7f602662f070 0x15c2ec52c060 
[1:1:0712/054823.936956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , document.readyState
[1:1:0712/054823.937235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054823.979442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 628, 7f6028f74881
[1:1:0712/054824.010906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.011320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.011579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054824.011945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){q(!0)}
[1:1:0712/054824.012059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054824.013844:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054824.013965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 4500
[1:1:0712/054824.014192:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 782
[1:1:0712/054824.014304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 782 0x7f602662f070 0x15c2ecff4360 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 628 0x7f602662f070 0x15c2ec0c6be0 
[1:1:0712/054824.147588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.co.uk/, 630, 7f6028f748db
[1:1:0712/054824.182160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.182471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.182883:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.co.uk/, 790
[1:1:0712/054824.183070:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7f602662f070 0x15c2ed2a2b60 , 5:3_https://www.amazon.co.uk/, 0, , 630 0x7f602662f070 0x15c2ecece1e0 
[1:1:0712/054824.183324:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054824.184061:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , f, (){if(s.length){y=G.now();for(var a=0;a<s.length;a++){var b=s[a],c=a;p=s[E];D=b;var d=void 0;if(!(d=
[1:1:0712/054824.184261:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054824.186700:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 749, 7f6028f74881
[1:1:0712/054824.226733:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"717 0x7f602662f070 0x15c2ec499160 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.227099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"717 0x7f602662f070 0x15c2ec499160 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.227671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054824.228757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054824.229045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054824.230015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054824.230177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054824.230855:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 792
[1:1:0712/054824.231101:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f602662f070 0x15c2ec0cd160 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 749 0x7f602662f070 0x15c2ecdcfbe0 
[1:1:0712/054824.840155:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 750
[1:1:0712/054824.840840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 824
[1:1:0712/054824.841054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 824 0x7f602662f070 0x15c2ed5267e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 749 0x7f602662f070 0x15c2ecdcfbe0 
[1:1:0712/054824.922371:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 745, 7f6028f74881
[1:1:0712/054824.954253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"716 0x7f6035940960 0x15c2ed06f6a0 0x15c2ed06f6b0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.954623:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"716 0x7f6035940960 0x15c2ed06f6a0 0x15c2ed06f6b0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054824.955052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054824.955849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){s(function(){f.executed||
a()})}
[1:1:0712/054824.956110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054824.997432:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 753, 7f6028f74881
[1:1:0712/054825.033912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"720 0x7f602662f070 0x15c2ec49e060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.034299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"720 0x7f602662f070 0x15c2ec49e060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.034711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054825.035495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/054825.035688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054825.036752:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054825.036920:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 16
[1:1:0712/054825.037596:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 834
[1:1:0712/054825.037870:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7f602662f070 0x15c2ec705460 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 753 0x7f602662f070 0x15c2ec498b60 
[1:1:0712/054825.039351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 750, 7f6028f74881
[1:1:0712/054825.075558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"717 0x7f602662f070 0x15c2ec499160 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.075889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"717 0x7f602662f070 0x15c2ec499160 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.076321:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054825.077111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){return c.apply(null,
f)}
[1:1:0712/054825.077294:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054825.518721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 732, 7f6028f74881
[1:1:0712/054825.544321:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"686 0x7f602662f070 0x15c2ecdcca60 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.544562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"686 0x7f602662f070 0x15c2ecdcca60 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.544825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054825.545221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , r, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(z(),w(),x(),y(),
[1:1:0712/054825.545335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054825.617895:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054825.618152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054825.618746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 838
[1:1:0712/054825.618948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 838 0x7f602662f070 0x15c2ecdfbbe0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 732 0x7f602662f070 0x15c2ec2912e0 
[1:1:0712/054825.620644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 771, 7f6028f74881
[1:1:0712/054825.646367:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"730 0x7f602662f070 0x15c2ec52c060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.646585:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"730 0x7f602662f070 0x15c2ec52c060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054825.646833:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054825.647211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){s(function(){f.executed||
a()})}
[1:1:0712/054825.647318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054825.986558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 770, 7f6028f74881
[1:1:0712/054826.003278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"730 0x7f602662f070 0x15c2ec52c060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054826.003651:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"730 0x7f602662f070 0x15c2ec52c060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054826.004126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054826.004978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){var el=document.getElementById("sis_pixel_r2");el&&(el.innerHTML='<iframe id="DAsis" src="//aax-e
[1:1:0712/054826.005204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054826.006808:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[85986:85986:0712/054826.008513:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/054826.010798:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x15c2ebed6420
[1:1:0712/054826.011024:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[85986:85986:0712/054826.015350:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/054826.031317:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/054826.031587:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.amazon.co.uk
[85986:85986:0712/054826.032836:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.amazon.co.uk/
[1:1:0712/054826.228749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){f.executed||
a()}
[1:1:0712/054826.229090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054826.249700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x146d5fb429c8, 0x15c2ebcaf168
[1:1:0712/054826.249965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 500
[1:1:0712/054826.250545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 868
[1:1:0712/054826.250771:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f602662f070 0x15c2ed7bece0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 795 0x7f6035940960 0x15c2ecfca880 0x15c2ecfca890 
[1:1:0712/054826.254927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf168
[1:1:0712/054826.255151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054826.255794:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 869
[1:1:0712/054826.256028:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 869 0x7f602662f070 0x15c2ebf71e60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 795 0x7f6035940960 0x15c2ecfca880 0x15c2ecfca890 
[85986:85986:0712/054827.186341:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[85986:85986:0712/054827.187839:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/054827.226599:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 792, 7f6028f74881
[85986:85997:0712/054827.227095:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[85986:85997:0712/054827.227204:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[85986:85986:0712/054827.227425:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://aax-eu.amazon-adsystem.com/
[85986:85986:0712/054827.227504:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://aax-eu.amazon-adsystem.com/, https://aax-eu.amazon-adsystem.com/s/iu3?d=amazon.co.uk&slot=navFooter&a2=0101d9dba3fb9f801e0223d00bbfc61ac9f3de959c15d3f650a9cd3f09139f33e2a9&old_oo=0&ts=1562935670013&s=Ab-8dNwrlKkF6QE6W0MV7ncLedt3GIHk1-vh1gSyxHu8&cb=1562935670013, 4
[85986:85986:0712/054827.227650:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://aax-eu.amazon-adsystem.com/, HTTP/1.1 200 OK Server: Server Date: Fri, 12 Jul 2019 12:48:27 GMT Content-Type: text/html;charset=ISO-8859-1 Content-Length: 246 Connection: keep-alive Cache-Control: max-age=0, no-cache, no-store, private, must-revalidate, s-maxage=0 Pragma: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT p3p: policyref="https://www.amazon.com/w3c/p3p.xml", CP="PSAo PSDo OUR SAM OTR DSP COR" Set-Cookie: ad-id=A9eE-Ezsc0gQh7gjkRVThNw; Domain=.amazon-adsystem.com; Expires=Wed, 01-Apr-2020 12:48:27 GMT; Path=/; HttpOnly Set-Cookie: ad-privacy=0; Domain=.amazon-adsystem.com; Expires=Wed, 01-Apr-2020 12:48:27 GMT; Path=/; HttpOnly Vary: Accept-Encoding,User-Agent Content-Encoding: gzip  ,86083, 5
[1:7:0712/054827.232616:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/054827.263052:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"749 0x7f602662f070 0x15c2ecdcfbe0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.263399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"749 0x7f602662f070 0x15c2ecdcfbe0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.263866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054827.264659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , ba, (){for(var a=R(),b=O();S.length;)if(S.shift()(),50<O()-b)return;clearTimeout(a);T=!1}
[1:1:0712/054827.264887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054827.265807:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054827.266012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 0
[1:1:0712/054827.266607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 890
[1:1:0712/054827.266832:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7f602662f070 0x15c2ed936160 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 792 0x7f602662f070 0x15c2ec0cd160 
[1:1:0712/054827.462763:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x146d5fb429c8, 0x15c2ebcaf150
[1:1:0712/054827.463154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 15
[1:1:0712/054827.464346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 891
[1:1:0712/054827.464717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7f602662f070 0x15c2ed6306e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 792 0x7f602662f070 0x15c2ec0cd160 
[1:1:0712/054827.472822:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 654, 7f6028f74881
[1:1:0712/054827.519988:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.520360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"560 0x7f602662f070 0x15c2ec8c8ce0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.520819:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054827.521851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , c, (){var d=[];a.log&&a.log.isStub&&a.log.replay(function(a){e(d,a)});a.clog&&a.clog.isStub&&a.clog.rep
[1:1:0712/054827.522152:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054827.714023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 834, 7f6028f74881
[1:1:0712/054827.742912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"753 0x7f602662f070 0x15c2ec498b60 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.743544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"753 0x7f602662f070 0x15c2ec498b60 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.744388:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054827.745980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , L, (){if(M){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:l.clientWidth,h:l.clientHeight};5<Ma
[1:1:0712/054827.746405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054827.775232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 772, 7f6028f74881
[1:1:0712/054827.815518:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"730 0x7f602662f070 0x15c2ec52c060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.816110:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"730 0x7f602662f070 0x15c2ec52c060 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.816704:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054827.817539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){return c.apply(null,
f)}
[1:1:0712/054827.817760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054827.895498:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 824, 7f6028f74881
[1:1:0712/054827.928870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"749 0x7f602662f070 0x15c2ecdcfbe0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.929523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"749 0x7f602662f070 0x15c2ecdcfbe0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054827.930425:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054827.933336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , if(window.s_c_il)window.s_c_il[0].mrq("amazoncustomerservice")
[1:1:0712/054827.933623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054827.991868:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.co.uk/, 790, 7f6028f748db
[1:1:0712/054828.027155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"630 0x7f602662f070 0x15c2ecece1e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054828.027516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"630 0x7f602662f070 0x15c2ecece1e0 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054828.028126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.amazon.co.uk/, 902
[1:1:0712/054828.028401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 902 0x7f602662f070 0x15c2ed2a2260 , 5:3_https://www.amazon.co.uk/, 0, , 790 0x7f602662f070 0x15c2ed2a2b60 
[1:1:0712/054828.028749:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054828.029632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , f, (){if(s.length){y=G.now();for(var a=0;a<s.length;a++){var b=s[a],c=a;p=s[E];D=b;var d=void 0;if(!(d=
[1:1:0712/054828.029889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054828.047053:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 845 0x7f60285572e0 0x15c2ec0c1860 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054828.051065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(c,d){function t(c){if(c)return c.replace(/^\s+|\s+$/g,"")}function n(e,d){if(!e)return{};v
[1:1:0712/054828.051399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054828.079353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x146d5fb429c8, 0x15c2ebcaf1b8
[1:1:0712/054828.079737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 1000
[1:1:0712/054828.080743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 904
[1:1:0712/054828.081119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 904 0x7f602662f070 0x15c2ec2b74e0 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 845 0x7f60285572e0 0x15c2ec0c1860 
[1:1:0712/054828.142006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 846 0x7f60285572e0 0x15c2ed340860 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054828.143198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , window.ue_adb_chk = 1;

[1:1:0712/054828.143430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054828.144357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054828.165238:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x146d5fb429c8, 0x15c2ebcaf210
[1:1:0712/054828.165574:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", 10000
[1:1:0712/054828.166016:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 907
[1:1:0712/054828.166347:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7f602662f070 0x15c2ed355b60 , 5:3_https://www.amazon.co.uk/, 1, -5:3_https://www.amazon.co.uk/, 846 0x7f60285572e0 0x15c2ed340860 
[1:1:0712/054828.637757:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 864 0x7f60285572e0 0x15c2ed7b70e0 , "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054828.640717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (function(h){var d=window.AmazonUIPageJS||window.P,k=d._namespace||d.attributeErrors,a=k?k("RetailWe
[1:1:0712/054828.641069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0712/054828.857397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 869, 7f6028f74881
[1:1:0712/054828.902446:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2284fcc02860","ptid":"795 0x7f6035940960 0x15c2ecfca880 0x15c2ecfca890 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054828.902977:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.amazon.co.uk/","ptid":"795 0x7f6035940960 0x15c2ecfca880 0x15c2ecfca890 ","rf":"5:3_https://www.amazon.co.uk/"}
[1:1:0712/054828.903563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc"
[1:1:0712/054828.904674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.amazon.co.uk/, 2284fcc02860, , , (){s(function(){f.executed||
a()})}
[1:1:0712/054828.904943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.amazon.co.uk/gp/help/customer/display.html?ie=UTF8&nodeId=202151760&ref_=help_search_1&nc1=f_cc", "www.amazon.co.uk", 3, 1, , , 0
[1:1:0100/000000.984889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.amazon.co.uk/, 838, 7f6028f74881
