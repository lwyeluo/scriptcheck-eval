[0712/060249.515433:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/060249.515729:INFO:switcher_clone.cc(787)] backtrace rip is 7ff39f0fe891
[0712/060250.538328:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/060250.538595:INFO:switcher_clone.cc(787)] backtrace rip is 7ff6b5a44891
[1:1:0712/060250.542620:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/060250.542788:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/060250.547779:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[87685:87685:0712/060251.605153:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/ca5cd0b3-fe88-41c8-adb9-e142cd80e96f
[0712/060251.972526:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/060251.972944:INFO:switcher_clone.cc(787)] backtrace rip is 7f7a1bfa8891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[87720:87720:0712/060252.172399:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=87720
[87730:87730:0712/060252.172780:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=87730
[87685:87685:0712/060252.178940:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[87685:87718:0712/060252.179772:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/060252.180010:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/060252.180231:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/060252.180852:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/060252.181033:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/060252.183549:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1f89f344, 1
[1:1:0712/060252.183851:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2246b343, 0
[1:1:0712/060252.184093:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x14a6d57f, 3
[1:1:0712/060252.184254:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x28a15104, 2
[1:1:0712/060252.184450:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 43ffffffb34622 44fffffff3ffffff891f 0451ffffffa128 7fffffffd5ffffffa614 , 10104, 4
[1:1:0712/060252.185297:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[87685:87718:0712/060252.185474:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGC�F"D�Q�(զ�s<$
[1:1:0712/060252.185461:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff6b3c7f0a0, 3
[87685:87718:0712/060252.185541:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is C�F"D�Q�(զ(�s<$
[1:1:0712/060252.185579:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff6b3e0a080, 2
[1:1:0712/060252.185667:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff69dacdd20, -2
[87685:87718:0712/060252.185896:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[87685:87718:0712/060252.185991:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 87732, 4, 43b34622 44f3891f 0451a128 7fd5a614 
[1:1:0712/060252.194521:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/060252.195388:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 28a15104
[1:1:0712/060252.196385:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 28a15104
[1:1:0712/060252.198107:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 28a15104
[1:1:0712/060252.199602:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.199793:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.200016:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.200214:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.200838:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 28a15104
[1:1:0712/060252.201189:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff6b5a447ba
[1:1:0712/060252.201329:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff6b5a3bdef, 7ff6b5a4477a, 7ff6b5a460cf
[1:1:0712/060252.207352:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 28a15104
[1:1:0712/060252.207820:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 28a15104
[1:1:0712/060252.208761:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 28a15104
[1:1:0712/060252.211301:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.211550:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.211783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.212046:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 28a15104
[1:1:0712/060252.213608:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 28a15104
[1:1:0712/060252.213991:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff6b5a447ba
[1:1:0712/060252.214104:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff6b5a3bdef, 7ff6b5a4477a, 7ff6b5a460cf
[1:1:0712/060252.221122:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/060252.221573:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/060252.221729:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcf9c85728, 0x7ffcf9c856a8)
[1:1:0712/060252.236704:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/060252.243079:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[87685:87710:0712/060252.868411:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[87685:87685:0712/060252.901350:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[87685:87685:0712/060252.902709:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[87685:87697:0712/060252.921829:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[87685:87697:0712/060252.921929:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[87685:87685:0712/060252.922201:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[87685:87685:0712/060252.922304:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[87685:87685:0712/060252.922473:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,87732, 4
[1:7:0712/060252.927173:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/060253.009459:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1e1f38717220
[1:1:0712/060253.010213:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/060253.397319:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/060255.032602:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060255.036197:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[87685:87685:0712/060255.059586:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[87685:87685:0712/060255.059721:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/060255.981915:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060256.157865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/060256.158184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060256.189679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/060256.189974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060256.361012:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060256.361281:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060256.806606:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060256.814763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/060256.815010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060256.850349:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060256.861006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/060256.861310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060256.866586:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[87685:87685:0712/060256.870598:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/060256.870831:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1e1f38715e20
[1:1:0712/060256.871037:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[87685:87685:0712/060256.877447:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[87685:87685:0712/060256.912318:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[87685:87685:0712/060256.912517:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/060256.917770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060257.405961:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 429 0x7ff69f6a82e0 0x1e1f389d0960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060257.407316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , , var configData = {"googleBaseUrl":"https://www.google.com/","isAccessibleBrowser":false,"isGooglePag
[1:1:0712/060257.407554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060257.409112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[87685:87685:0712/060257.445812:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/060257.447390:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1e1f38716820
[1:1:0712/060257.447669:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[87685:87685:0712/060257.453066:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/060257.460784:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/060257.461014:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[87685:87685:0712/060257.470453:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[87685:87685:0712/060257.479667:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[87685:87685:0712/060257.480682:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[87685:87685:0712/060257.483638:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[87685:87697:0712/060257.483640:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[87685:87685:0712/060257.483680:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[87685:87685:0712/060257.483743:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,87732, 4
[87685:87697:0712/060257.483721:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/060257.488904:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/060258.212428:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/060258.671718:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7ff69f6a82e0 0x1e1f389d0f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060258.672811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/060258.673052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060258.673868:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[87685:87685:0712/060258.848379:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[87685:87685:0712/060258.848455:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/060258.864909:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/060259.207964:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[87685:87685:0712/060259.926447:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[87685:87718:0712/060259.926905:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/060259.927131:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/060259.927328:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/060259.927711:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/060259.927964:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/060259.931183:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xfdc1c50, 1
[1:1:0712/060259.931530:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1cc902e7, 0
[1:1:0712/060259.931690:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb7d95a1, 3
[1:1:0712/060259.931893:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x8746d71, 2
[1:1:0712/060259.931994:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe702ffffffc91c 501cffffffdc0f 716d7408 ffffffa1ffffff957d0b , 10104, 5
[1:1:0712/060259.932635:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[87685:87718:0712/060259.932808:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��P�qmt��}�u<$
[1:1:0712/060259.932791:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff6b3c7f0a0, 3
[87685:87718:0712/060259.932895:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��P�qmt��}��u<$
[1:1:0712/060259.932923:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff6b3e0a080, 2
[1:1:0712/060259.933023:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff69dacdd20, -2
[87685:87718:0712/060259.933161:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 87782, 5, e702c91c 501cdc0f 716d7408 a1957d0b 
[1:1:0712/060259.943056:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/060259.943264:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8746d71
[1:1:0712/060259.943441:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8746d71
[1:1:0712/060259.943706:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8746d71
[1:1:0712/060259.944174:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.944281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.944375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.944467:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.944701:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8746d71
[1:1:0712/060259.944861:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff6b5a447ba
[1:1:0712/060259.944946:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff6b5a3bdef, 7ff6b5a4477a, 7ff6b5a460cf
[1:1:0712/060259.946348:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8746d71
[1:1:0712/060259.946506:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8746d71
[1:1:0712/060259.946773:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8746d71
[1:1:0712/060259.947466:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.947588:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.947685:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.947779:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8746d71
[1:1:0712/060259.949222:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8746d71
[1:1:0712/060259.949583:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff6b5a447ba
[1:1:0712/060259.949716:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff6b5a3bdef, 7ff6b5a4477a, 7ff6b5a460cf
[1:1:0712/060259.957399:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/060259.957903:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/060259.958092:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcf9c85728, 0x7ffcf9c856a8)
[1:1:0712/060259.973214:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/060259.978556:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/060259.985906:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060259.986169:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060300.214805:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1e1f386ba220
[1:1:0712/060300.215095:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/060300.363095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 567, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060300.368329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/060300.368660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060300.375321:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060300.502692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/060300.503468:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7410281f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/060300.503711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/060300.787394:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060300.790803:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/060300.791285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/060300.791936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060300.944767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060300.945721:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/060300.945962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/060300.946246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060301.245756:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://mit.edu/"
[1:1:0712/060301.428577:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.ali213.net/"
[87685:87685:0712/060301.470650:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[87685:87685:0712/060301.479261:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[87685:87697:0712/060301.489282:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[87685:87697:0712/060301.489379:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[87685:87685:0712/060301.489922:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://aws.amazon.com/
[87685:87685:0712/060301.490025:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://aws.amazon.com/, https://aws.amazon.com/it/?nc1=f_ls, 1
[87685:87685:0712/060301.490192:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://aws.amazon.com/, HTTP/1.1 200 status:200 content-type:text/html;charset=UTF-8 server:Server date:Fri, 12 Jul 2019 13:03:01 GMT x-frame-options:SAMEORIGIN x-content-type-options:nosniff x-amz-id-1:CDSA78DP64WA5NJWGVG0 last-modified:Fri, 21 Jun 2019 22:14:03 GMT cache-control:no-store, no-cache, must-revalidate content-encoding:gzip vary:accept-encoding,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment,User-Agent set-cookie:aws-priv=eyJ2IjoxLCJldSI6MCwic3QiOjB9; Version=1; Comment="Anonymous cookie for privacy regulations"; Domain=.amazon.com; Max-Age=94672800; Expires=Tue, 12-Jul-2022 07:03:01 GMT; Path=/ set-cookie:aws-csds-token=b47cbda3-c4b1-41d0-a1be-e4d043080416; Version=1; Comment="Anonymous metrics validation token"; Max-Age=900; Expires=Fri, 12-Jul-2019 13:18:01 GMT; Path=/ set-cookie:aws-mkto-trk=id%3A112-TZM-766%26token%3A_mch-aws.amazon.com-1562935410800-90641; Domain=.amazon.com; Path=/ x-amz-rid:CDSA78DP64WA5NJWGVG0 x-cache:Miss from cloudfront via:1.1 100e7eca600d702a8613a94cb0899fe9.cloudfront.net (CloudFront) x-amz-cf-pop:SFO5-C3 x-amz-cf-id:EFAiszAIjiNXkWfADwzsZydg0wsaHin4LM2uoOdLWWbzL8Ju78EVQw==  ,87782, 5
[1:7:0712/060301.494312:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/060301.544366:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://aws.amazon.com/
[1:1:0712/060301.585431:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.qj.com.cn/"
[87685:87685:0712/060301.664164:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://aws.amazon.com/, https://aws.amazon.com/, 1
[87685:87685:0712/060301.664243:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://aws.amazon.com/, https://aws.amazon.com
[1:1:0712/060301.665912:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://cnn.com/"
[1:1:0712/060301.712919:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/060301.724636:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.sina.com.cn/"
[1:1:0712/060301.811789:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.baidu.com/"
[1:1:0712/060301.857502:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060301.876007:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://glassdoor.com/"
[1:1:0712/060301.930580:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://kp.ru/"
[1:1:0712/060301.946993:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/060302.016511:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060302.016765:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060302.048279:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.049160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/060302.049509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.135648:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.136651:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/060302.137026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.199912:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/060302.224611:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.225512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/060302.225777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.350744:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.351697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/060302.351999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.417072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.418176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/060302.418513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.624380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.625319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/060302.625649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.692842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/060302.693857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c74103ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/060302.694145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/060302.801318:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/060304.096550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7ff69d780070 0x1e1f38429ae0 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060304.097447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , 
  var AWS = {
    PageSettings: {
      supportedLanguages: ['ar', 'en', 'es', 'de', 'fr', 'id', 'i
[1:1:0712/060304.097565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060304.098139:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060304.109598:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7ff69d780070 0x1e1f38429ae0 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060304.437925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0xd8f2cb229c8, 0x1e1f385421f0
[1:1:0712/060304.438246:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 4
[1:1:0712/060304.438702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 265
[1:1:0712/060304.438974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 265 0x7ff69d780070 0x1e1f387f0360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 253 0x7ff69d780070 0x1e1f38429ae0 
[1:1:0712/060304.460285:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0xd8f2cb229c8, 0x1e1f385421f0
[1:1:0712/060304.460522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 4
[1:1:0712/060304.460982:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 266
[1:1:0712/060304.461227:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7ff69d780070 0x1e1f38863960 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 253 0x7ff69d780070 0x1e1f38429ae0 
[1:1:0712/060304.593936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0xd8f2cb229c8, 0x1e1f385421f0
[1:1:0712/060304.594159:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 4
[1:1:0712/060304.594353:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 267
[1:1:0712/060304.594464:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 267 0x7ff69d780070 0x1e1f38862260 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 253 0x7ff69d780070 0x1e1f38429ae0 
[1:1:0712/060304.597834:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7ff69d780070 0x1e1f38429ae0 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060304.689758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0xd8f2cb229c8, 0x1e1f38542260
[1:1:0712/060304.690065:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 30
[1:1:0712/060304.690542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 271
[1:1:0712/060304.690779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 271 0x7ff69d780070 0x1e1f38860fe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 253 0x7ff69d780070 0x1e1f38429ae0 
[1:1:0712/060304.892560:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.793085, 0, 0
[1:1:0712/060304.892787:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060305.046646:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060305.046860:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060305.048237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/060305.048417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060305.049390:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7ff69d780070 0x1e1f38861360 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060305.057987:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 275 0x7ff69d780070 0x1e1f38861360 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060305.253487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd8f2cb229c8, 0x1e1f385421a8
[1:1:0712/060305.253660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 100
[1:1:0712/060305.253824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 330
[1:1:0712/060305.253928:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 330 0x7ff69d780070 0x1e1f382c2de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 275 0x7ff69d780070 0x1e1f38861360 
[1:1:0712/060305.291251:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.244237, 201, 1
[1:1:0712/060305.291437:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060305.598835:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 265, 7ff6a00c5881
[1:1:0712/060305.616512:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060305.616860:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060305.617223:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060305.617843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/060305.618076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060305.637087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 266, 7ff6a00c5881
[1:1:0712/060305.651856:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060305.652194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060305.652496:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060305.653047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/060305.653301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060305.665483:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 267, 7ff6a00c5881
[1:1:0712/060305.682181:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060305.682511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060305.682800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060305.683424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/060305.683680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060310.236339:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060310.236680:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060310.236892:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060310.239862:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060310.240268:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[87685:87685:0712/060319.264866:INFO:CONSOLE(1)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://a0.awsstatic.com/libra-css/fonts/fontawesome/4.7.0/fontawesome-webfont.woff", source: https://a0.awsstatic.com/libra/1.0.283/libra-head.js (1)
[87685:87685:0712/060319.278235:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[3:3:0712/060319.324247:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/060319.556210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060319.556513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060319.556969:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 473
[1:1:0712/060319.557194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 473 0x7ff69d780070 0x1e1f387e8960 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 267 0x7ff69d780070 0x1e1f38862260 
[1:1:0712/060319.567784:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060319.568107:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060319.568631:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 474
[1:1:0712/060319.568873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 474 0x7ff69d780070 0x1e1f38d61e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 267 0x7ff69d780070 0x1e1f38862260 
[1:1:0712/060319.574201:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060319.574433:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 4
[1:1:0712/060319.574846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 475
[1:1:0712/060319.575074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 475 0x7ff69d780070 0x1e1f38866060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 267 0x7ff69d780070 0x1e1f38862260 
[1:1:0712/060319.577477:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060319.577708:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 4
[1:1:0712/060319.578118:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 476
[1:1:0712/060319.578407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 476 0x7ff69d780070 0x1e1f392f62e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 267 0x7ff69d780070 0x1e1f38862260 
[1:1:0712/060319.609090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 271, 7ff6a00c5881
[1:1:0712/060319.629071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060319.629425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"253 0x7ff69d780070 0x1e1f38429ae0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060319.629740:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060319.630380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , AppMeasurement.a.Qa, (){a.b=a.d.body;a.b?(a.v=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["
[1:1:0712/060319.630589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060321.004969:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060321.005284:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060321.006635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/060321.006862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060321.636958:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.63158, 2229, 0
[1:1:0712/060321.637274:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[87685:87685:0712/060322.070391:INFO:CONSOLE(1)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://a0.awsstatic.com/libra-css/fonts/amazon-ember/AmazonEmber_Rg.woff2", source: https://a0.awsstatic.com/libra/1.0.283/libra-head.js (1)
[87685:87685:0712/060322.076098:INFO:CONSOLE(1)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://a0.awsstatic.com/libra-css/fonts/amazon-ember/AmazonEmber_Bd.woff2", source: https://a0.awsstatic.com/libra/1.0.283/libra-head.js (1)
[87685:87685:0712/060322.096039:INFO:CONSOLE(1)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://a0.awsstatic.com/libra-css/fonts/amazon-ember/AmazonEmber_Lt.woff2", source: https://a0.awsstatic.com/libra/1.0.283/libra-head.js (1)
[1:1:0712/060324.045871:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 20
[1:1:0712/060324.046380:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 561
[1:1:0712/060324.047477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7ff69d780070 0x1e1f38d3b9e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 364 0x7ff69d780070 0x1e1f382c08e0 
[1:1:0712/060324.048216:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0xd8f2cb229c8, 0x1e1f39222da0
[1:1:0712/060324.048447:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 10000
[1:1:0712/060324.048876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 562
[1:1:0712/060324.049136:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 562 0x7ff69d780070 0x1e1f391eb460 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 364 0x7ff69d780070 0x1e1f382c08e0 
[1:1:0712/060325.705297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 330, 7ff6a00c5881
[1:1:0712/060325.730821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"275 0x7ff69d780070 0x1e1f38861360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060325.731236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"275 0x7ff69d780070 0x1e1f38861360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060325.731564:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060325.732309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){loop(pollGroup)}
[1:1:0712/060325.732529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060325.758772:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060325.759082:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060325.759566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 622
[1:1:0712/060325.759859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7ff69d780070 0x1e1f391ea4e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060325.896429:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060325.896700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060325.897128:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 624
[1:1:0712/060325.897427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7ff69d780070 0x1e1f3885dfe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060325.991406:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060325.991725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060325.992146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 626
[1:1:0712/060325.992457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7ff69d780070 0x1e1f3885a7e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060326.064891:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060326.065221:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060326.065701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 628
[1:1:0712/060326.065978:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7ff69d780070 0x1e1f39430660 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060326.193851:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060326.194167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060326.194624:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 630
[1:1:0712/060326.194899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7ff69d780070 0x1e1f38860160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060326.306143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060326.306445:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060326.306882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 632
[1:1:0712/060326.307135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 632 0x7ff69d780070 0x1e1f38d3b2e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060326.449215:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060326.449510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060326.449939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 639
[1:1:0712/060326.450173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7ff69d780070 0x1e1f382bed60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060326.555764:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060326.556106:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 100
[1:1:0712/060326.556697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 641
[1:1:0712/060326.556955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 641 0x7ff69d780070 0x1e1f39477160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 330 0x7ff69d780070 0x1e1f382c2de0 
[1:1:0712/060327.546879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/060327.547207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060328.580321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 473, 7ff6a00c5881
[1:1:0712/060328.615378:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.615821:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.616234:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060328.616873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=foresterUrl}
[1:1:0712/060328.617099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060328.626675:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 474, 7ff6a00c5881
[1:1:0712/060328.657549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.657910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.658319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060328.659035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=csdsUrl}
[1:1:0712/060328.659274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060328.709169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 475, 7ff6a00c5881
[1:1:0712/060328.724581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.724987:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.725324:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060328.725951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/060328.726192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060328.745209:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060328.745467:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 50
[1:1:0712/060328.745877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 752
[1:1:0712/060328.746127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7ff69d780070 0x1e1f399d3060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 475 0x7ff69d780070 0x1e1f38866060 
[1:1:0712/060328.756598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 476, 7ff6a00c5881
[1:1:0712/060328.788643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.789054:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"267 0x7ff69d780070 0x1e1f38862260 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060328.789369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060328.789970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/060328.790187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060330.039364:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060330.039643:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060330.253922:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.214187, 796, 1
[1:1:0712/060330.254217:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060330.274448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/060330.274731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060331.105004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 561, 7ff6a00c58db
[1:1:0712/060331.126670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"364 0x7ff69d780070 0x1e1f382c08e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060331.127020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"364 0x7ff69d780070 0x1e1f382c08e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060331.127390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 811
[1:1:0712/060331.127675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 811 0x7ff69d780070 0x1e1f391fb560 , 5:3_https://aws.amazon.com/, 0, , 561 0x7ff69d780070 0x1e1f38d3b9e0 
[1:1:0712/060331.127998:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060331.128593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){var watchedHeaderHeight=Math.floor(document.getElementsByClassName("m-page-header")[0].offsetHeig
[1:1:0712/060331.128807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.129913:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060335.132050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060335.132313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.160022:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542518
[1:1:0712/060335.160306:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.160719:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 822
[1:1:0712/060335.160945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 822 0x7ff69d780070 0x1e1f391f2a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 633
[1:1:0712/060335.174020:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542518
[1:1:0712/060335.174289:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.174784:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 823
[1:1:0712/060335.175047:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 823 0x7ff69d780070 0x1e1f39ad1560 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 633
[1:1:0712/060335.243932:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060335.244742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060335.244974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.254447:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.254730:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.255144:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 829
[1:1:0712/060335.255374:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 829 0x7ff69d780070 0x1e1f391e8be0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 634
[1:1:0712/060335.267273:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.267537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.268035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 830
[1:1:0712/060335.268279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7ff69d780070 0x1e1f38d5bee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 634
[1:1:0712/060335.279462:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.279810:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.280491:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 831
[1:1:0712/060335.280744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7ff69d780070 0x1e1f382c0e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 634
[1:1:0712/060335.430885:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060335.431679:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060335.431938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.449505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.449894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.450482:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 839
[1:1:0712/060335.450825:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 839 0x7ff69d780070 0x1e1f39380de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 635
[1:1:0712/060335.463723:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.463989:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.464397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 840
[1:1:0712/060335.464650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7ff69d780070 0x1e1f39248960 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 635
[1:1:0712/060335.472719:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.472990:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.473450:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 841
[1:1:0712/060335.473703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 841 0x7ff69d780070 0x1e1f38d64360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 635
[1:1:0712/060335.599106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060335.599956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060335.600197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.617986:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.618271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.618702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 849
[1:1:0712/060335.618978:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7ff69d780070 0x1e1f391e2960 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 636
[1:1:0712/060335.629509:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.629774:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.630182:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 850
[1:1:0712/060335.630416:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7ff69d780070 0x1e1f38047be0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 636
[1:1:0712/060335.646051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.646353:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.646859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 851
[1:1:0712/060335.647135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7ff69d780070 0x1e1f39242560 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 636
[1:1:0712/060335.844579:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060335.845316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060335.845545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.863668:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060335.869557:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060335.870116:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060335.876469:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.876652:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.877337:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 861
[1:1:0712/060335.877544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 861 0x7ff69d780070 0x1e1f382be860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 638
[1:1:0712/060335.890438:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060335.890753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060335.891220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 862
[1:1:0712/060335.891457:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7ff69d780070 0x1e1f3939fe60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 638
[1:1:0712/060335.968142:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 622, 7ff6a00c5881
[1:1:0712/060335.981084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060335.981280:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060335.981508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060335.981851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060335.981963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060335.986122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 624, 7ff6a00c5881
[1:1:0712/060336.003201:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.003515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.003925:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.004246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060336.004355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.027655:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 626, 7ff6a00c5881
[1:1:0712/060336.069837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.070271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.070802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.071510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060336.071790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.095155:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.095602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060336.095902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.111681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060336.112002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.112400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 870
[1:1:0712/060336.112593:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7ff69d780070 0x1e1f393f4760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 650
[1:1:0712/060336.122698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060336.122993:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.123447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 871
[1:1:0712/060336.123653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 871 0x7ff69d780070 0x1e1f39c12ae0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 650
[1:1:0712/060336.163988:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 628, 7ff6a00c5881
[1:1:0712/060336.196541:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.196898:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.197290:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.197821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060336.198008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.200094:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 630, 7ff6a00c5881
[1:1:0712/060336.223109:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.223420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.223813:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.224479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060336.224698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.264507:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 632, 7ff6a00c5881
[1:1:0712/060336.283314:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.283655:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.284045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.284738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060336.284972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.310710:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 639, 7ff6a00c5881
[1:1:0712/060336.323244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.323445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.323648:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.324016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060336.324122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.415204:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 641, 7ff6a00c5881
[1:1:0712/060336.426804:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.427040:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"330 0x7ff69d780070 0x1e1f382c2de0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060336.427279:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060336.427590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){loop(pollGroup)}
[1:1:0712/060336.427818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060336.460992:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.461281:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.461745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 876
[1:1:0712/060336.462012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 876 0x7ff69d780070 0x1e1f393e7fe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060336.585471:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.585663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.585900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 881
[1:1:0712/060336.586073:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 881 0x7ff69d780070 0x1e1f39476a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060336.602073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.602368:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.602839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 884
[1:1:0712/060336.603110:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7ff69d780070 0x1e1f39417160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060336.621723:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.621911:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.622112:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 887
[1:1:0712/060336.622224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 887 0x7ff69d780070 0x1e1f39427ce0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060336.639732:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.640078:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.640288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 890
[1:1:0712/060336.640401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7ff69d780070 0x1e1f39addf60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060336.673148:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.673396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060336.673761:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 893
[1:1:0712/060336.673982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 893 0x7ff69d780070 0x1e1f387baee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060336.702638:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060336.702887:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 100
[1:1:0712/060336.703396:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 894
[1:1:0712/060336.703629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7ff69d780070 0x1e1f394781e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 641 0x7ff69d780070 0x1e1f39477160 
[1:1:0712/060338.732656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , document.readyState
[1:1:0712/060338.732993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[87685:87685:0712/060341.222355:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -102
[1:1:0712/060341.507741:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060341.605400:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 752, 7ff6a00c5881
[1:1:0712/060341.643421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"475 0x7ff69d780070 0x1e1f38866060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060341.643803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"475 0x7ff69d780070 0x1e1f38866060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060341.644236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060341.644806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){X=0;D()}
[1:1:0712/060341.645050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060341.648975:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0xd8f2cb229c8, 0x1e1f38542150
[1:1:0712/060341.649280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 50
[1:1:0712/060341.649722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 960
[1:1:0712/060341.649977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7ff69d780070 0x1e1f39af2ae0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 752 0x7ff69d780070 0x1e1f399d3060 
[1:1:0712/060342.788288:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060342.788609:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060342.790009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/060342.790220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060342.958753:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.170037, 706, 1
[1:1:0712/060342.959001:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060343.397582:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 811, 7ff6a00c58db
[1:1:0712/060343.412401:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"561 0x7ff69d780070 0x1e1f38d3b9e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060343.412677:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"561 0x7ff69d780070 0x1e1f38d3b9e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060343.413000:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 987
[1:1:0712/060343.413119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7ff69d780070 0x1e1f392485e0 , 5:3_https://aws.amazon.com/, 0, , 811 0x7ff69d780070 0x1e1f391fb560 
[1:1:0712/060343.413274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060343.413600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){var watchedHeaderHeight=Math.floor(document.getElementsByClassName("m-page-header")[0].offsetHeig
[1:1:0712/060343.413712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.081096:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 562, 7ff6a00c5881
[1:1:0712/060344.116453:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"364 0x7ff69d780070 0x1e1f382c08e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.116844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"364 0x7ff69d780070 0x1e1f382c08e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.117306:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.117958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){clearInterval(watchHeader)}
[1:1:0712/060344.118179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.165137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 822, 7ff6a00c5881
[1:1:0712/060344.183298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"633","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.183652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"633","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.184126:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.184709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.184938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.188478:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 823, 7ff6a00c5881
[1:1:0712/060344.220089:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"633","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.220449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"633","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.220893:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.221682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.221944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.304496:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 829, 7ff6a00c5881
[1:1:0712/060344.334996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"634","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.335349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"634","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.335811:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.336406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.336644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.343429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 830, 7ff6a00c5881
[1:1:0712/060344.361287:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"634","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.361625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"634","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.362080:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.362694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.363060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.403669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 831, 7ff6a00c5881
[1:1:0712/060344.449561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"634","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.449987:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"634","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.450490:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.451297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.451546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.512616:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 839, 7ff6a00c5881
[1:1:0712/060344.534605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"635","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.535057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"635","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.535514:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.536183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.536425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.570374:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 840, 7ff6a00c5881
[1:1:0712/060344.615842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"635","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.616238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"635","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.616678:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.617287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.617506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.622921:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 841, 7ff6a00c5881
[1:1:0712/060344.643585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"635","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.644005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"635","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.644471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.645078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.645320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.707158:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 849, 7ff6a00c5881
[1:1:0712/060344.748185:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"636","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.748582:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"636","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.749142:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.749914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.750157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.754004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 850, 7ff6a00c5881
[1:1:0712/060344.795840:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"636","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.796226:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"636","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.796690:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.797375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.797654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060344.805033:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 851, 7ff6a00c5881
[1:1:0712/060344.839758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"636","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.840153:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"636","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060344.840583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060344.841183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060344.841413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.100416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 861, 7ff6a00c5881
[1:1:0712/060345.140007:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"638","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.140366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"638","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.140795:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.141406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.141626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.148088:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 862, 7ff6a00c5881
[1:1:0712/060345.166735:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"638","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.167101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"638","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.167501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.168244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.168463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.219839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 870, 7ff6a00c5881
[1:1:0712/060345.240344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"650","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.240862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"650","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.241409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.241987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.242255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.289645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 871, 7ff6a00c5881
[1:1:0712/060345.322550:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"650","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.322980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"650","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.323442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.324114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.324374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.713138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 876, 7ff6a00c5881
[1:1:0712/060345.746363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.746753:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.747212:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.747980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.748292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.755475:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 881, 7ff6a00c5881
[1:1:0712/060345.773648:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.774003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.774467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.775042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.775255:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.817511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 884, 7ff6a00c5881
[1:1:0712/060345.854812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.855215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.855686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.856410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.856631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.895069:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.895888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/060345.896202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.910491:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060345.910788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060345.911262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1041
[1:1:0712/060345.911525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7ff69d780070 0x1e1f39bc1160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 913
[1:1:0712/060345.916530:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f38542210
[1:1:0712/060345.916743:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060345.917139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1042
[1:1:0712/060345.917385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7ff69d780070 0x1e1f39c6b860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 913
[1:1:0712/060345.942638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 887, 7ff6a00c5881
[1:1:0712/060345.961417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.961792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.962305:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.962916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.963151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060345.967448:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 890, 7ff6a00c5881
[1:1:0712/060345.992584:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.993010:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060345.993506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060345.994286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060345.994518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060346.023333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 893, 7ff6a00c5881
[1:1:0712/060346.070473:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060346.070858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060346.071317:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060346.071902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060346.072115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060346.283870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , document.readyState
[1:1:0712/060346.284188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060346.444494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 894, 7ff6a00c5881
[1:1:0712/060346.471821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060346.472212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"641 0x7ff69d780070 0x1e1f39477160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060346.472685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060346.473339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){loop(pollGroup)}
[1:1:0712/060346.473587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060348.546221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 958 0x7ff69f6a82e0 0x1e1f39bcfa60 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060348.547349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , /*
 * Copyright (c) 2007-2015, Marketo, Inc. All rights reserved.
 * Marketo marketing automation we
[1:1:0712/060348.547549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060348.549535:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060348.598558:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060348.612265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f385425d8
[1:1:0712/060348.612573:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060348.613058:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1080
[1:1:0712/060348.613318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7ff69d780070 0x1e1f394186e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 958 0x7ff69f6a82e0 0x1e1f39bcfa60 
[1:1:0712/060348.623297:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xd8f2cb229c8, 0x1e1f385425d8
[1:1:0712/060348.623590:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 0
[1:1:0712/060348.624123:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1081
[1:1:0712/060348.624382:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1081 0x7ff69d780070 0x1e1f39bc2060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 958 0x7ff69f6a82e0 0x1e1f39bcfa60 
[87685:87685:0712/060348.633765:INFO:CONSOLE(19)] "Uncaught Error: Load timeout for modules: libra/libra-bundle
http://requirejs.org/docs/errors.html#timeout", source: https://a0.awsstatic.com/libra/1.0.283/libra-head.js (19)
[87685:87685:0712/060348.639978:INFO:CONSOLE(48)] "Uncaught Script error.", source: https://a0.awsstatic.com/libra/1.0.283/libra-head.js (48)
[1:1:0712/060348.908725:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 960, 7ff6a00c5881
[1:1:0712/060348.938422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"752 0x7ff69d780070 0x1e1f399d3060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060348.938629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"752 0x7ff69d780070 0x1e1f399d3060 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060348.938885:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060348.939260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){X=0;D()}
[1:1:0712/060348.939369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060349.375314:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060349.375570:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060349.376449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/060349.376597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060349.403322:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 979 0x7ff69d780070 0x1e1f39c6b6e0 , "https://aws.amazon.com/it/?nc1=f_ls"
		remove user.10_ddd6f4c4 -> 0
		remove user.11_6c45a859 -> 0
		remove user.12_80121b5a -> 0
		remove user.13_e8c6b7b1 -> 0
[1:1:0712/060356.307159:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 6.93169, 0, 0
[1:1:0712/060356.307490:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060356.660339:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){if(!docHead.classList.contains(fontClass)){localStorage.setItem(KEY,fontClass);docHead.classList.
[1:1:0712/060356.660634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060358.543183:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1041, 7ff6a00c5881
[1:1:0712/060358.573905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"913","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060358.574279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"913","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060358.574835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060358.575560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060358.575934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060358.582694:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1042, 7ff6a00c5881
[1:1:0712/060358.632603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"913","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060358.632970:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"913","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060358.633414:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060358.634036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060358.634271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060358.897143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , document.readyState
[1:1:0712/060358.897466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060359.455274:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1080, 7ff6a00c5881
[1:1:0712/060359.491898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"958 0x7ff69f6a82e0 0x1e1f39bcfa60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060359.492094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"958 0x7ff69f6a82e0 0x1e1f39bcfa60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060359.492302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060359.492767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060359.492992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060359.501572:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1081, 7ff6a00c5881
[1:1:0712/060359.551051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"382617042860","ptid":"958 0x7ff69f6a82e0 0x1e1f39bcfa60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060359.551374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"958 0x7ff69f6a82e0 0x1e1f39bcfa60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/060359.551782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060359.552327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , (){(new Image).src=url}
[1:1:0712/060359.552506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
context mismatch in svga_sampler_view_destroy
context mismatch in svga_sampler_view_destroy
[1:1:0712/060400.320809:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1104 0x7ff69f6a82e0 0x1e1f3a0f8be0 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060400.322237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , !function(){var librastandardlib_event_utils_onWindowLoad,librastandardlib_event_utils_onDOMContentL
[1:1:0712/060400.322427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060400.677008:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/060400.677235:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060400.679285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/060400.679498:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060400.682544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1109 0x7ff69d780070 0x1e1f3922b960 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060401.155407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0xd8f2cb229c8, 0x1e1f38542198
[1:1:0712/060401.155638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/it/?nc1=f_ls", 5000
[1:1:0712/060401.156042:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1233
[1:1:0712/060401.156249:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1233 0x7ff69d780070 0x1e1f38ddb6e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1109 0x7ff69d780070 0x1e1f3922b960 
[1:1:0712/060401.171738:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1109 0x7ff69d780070 0x1e1f3922b960 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060401.184700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1109 0x7ff69d780070 0x1e1f3922b960 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060401.187155:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.509766, 2, 0
[1:1:0712/060401.187332:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/060403.235893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1178 0x7ff69f6a82e0 0x1e1f3b595a60 , "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060403.237930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 382617042860, , , /*
 * Copyright (c) 2007-2015, Marketo, Inc. All rights reserved.
 * Marketo marketing automation we
[1:1:0712/060403.238074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/it/?nc1=f_ls", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/060403.246272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/it/?nc1=f_ls"
[1:1:0712/060403.275799:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060403.276322:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/060403.276738:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
