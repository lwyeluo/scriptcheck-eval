[0712/111254.674614:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111254.674884:INFO:switcher_clone.cc(787)] backtrace rip is 7fdb11bfb891
[0712/111255.238959:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111255.239205:INFO:switcher_clone.cc(787)] backtrace rip is 7fa7cf7d2891
[1:1:0712/111255.243134:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111255.243296:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111255.246038:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[1429:1429:0712/111256.000467:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/4909afd2-ea25-4fdb-8d1e-65a65eed990d
[0712/111256.201153:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111256.201429:INFO:switcher_clone.cc(787)] backtrace rip is 7f63934ff891
[1429:1429:0712/111256.281009:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[1429:1461:0712/111256.281370:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111256.287376:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111256.287548:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111256.287859:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111256.287978:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111256.289646:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xeae6d1c, 1
[1:1:0712/111256.289813:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2f80c226, 0
[1:1:0712/111256.289895:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x39c3c4d1, 3
[1:1:0712/111256.289976:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x335513a3, 2
[1:1:0712/111256.290060:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 26ffffffc2ffffff802f 1c6dffffffae0e ffffffa3135533 ffffffd1ffffffc4ffffffc339 , 10104, 4
[1:1:0712/111256.290711:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1429:1461:0712/111256.290819:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING&/m��U3���9�nK
[1429:1461:0712/111256.290854:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is &/m��U3���9�νnK
[1429:1461:0712/111256.290975:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1429:1461:0712/111256.291011:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1477, 4, 26c2802f 1c6dae0e a3135533 d1c4c339 
[1:1:0712/111256.291368:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7cda0c0a0, 3
[1:1:0712/111256.291476:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7cdb98080, 2
[1:1:0712/111256.291558:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7b785ad20, -2
[1:1:0712/111256.299273:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111256.299715:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 335513a3
[1:1:0712/111256.300180:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 335513a3
[1:1:0712/111256.300940:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 335513a3
[1:1:0712/111256.301498:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.301593:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.301688:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.301777:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.302028:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 335513a3
[1:1:0712/111256.302176:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7cf7d27ba
[1:1:0712/111256.302248:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa7cf7c9def, 7fa7cf7d277a, 7fa7cf7d40cf
[1:1:0712/111256.303963:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 335513a3
[1:1:0712/111256.304120:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 335513a3
[1:1:0712/111256.304412:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 335513a3
[1:1:0712/111256.305179:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.305275:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.305378:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.305469:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 335513a3
[1:1:0712/111256.305955:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 335513a3
[1:1:0712/111256.306112:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7cf7d27ba
[1:1:0712/111256.306180:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa7cf7c9def, 7fa7cf7d277a, 7fa7cf7d40cf
[1:1:0712/111256.309199:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111256.309517:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111256.309642:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe6ec5e0c8, 0x7ffe6ec5e048)
[1:1:0712/111256.317063:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111256.320051:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1463:1463:0712/111256.373549:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1463
[1489:1489:0712/111256.386054:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1489
[1429:1429:0712/111256.678593:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1429:1429:0712/111256.679077:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1429:1429:0712/111256.686537:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[1429:1429:0712/111256.686593:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[1429:1429:0712/111256.686661:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,1477, 4
[1429:1442:0712/111256.783385:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[1429:1442:0712/111256.783455:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111256.796838:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111256.850065:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x258ab28e7220
[1:1:0712/111256.851066:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1429:1453:0712/111256.913546:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111257.070473:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/111257.870778:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111257.872505:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1429:1429:0712/111258.042175:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1429:1429:0712/111258.042249:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111258.346246:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111258.440486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111258.440634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111258.449974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111258.450107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111258.484327:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111258.484472:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111258.653708:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111258.656144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111258.656270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111258.668395:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111258.671428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111258.671568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111258.675476:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1429:1429:0712/111258.676136:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111258.677496:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x258ab28e5e20
[1:1:0712/111258.677603:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1429:1429:0712/111258.678402:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1429:1429:0712/111258.691651:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[1429:1429:0712/111258.691732:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111258.710889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111259.043221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7fa7b94352e0 0x258ab2b7d260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111259.043923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/111259.044076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111259.044747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1429:1429:0712/111259.075586:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111259.076682:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x258ab28e6820
[1:1:0712/111259.076834:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1429:1429:0712/111259.078212:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111259.083888:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111259.084037:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[1429:1429:0712/111259.089490:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[1429:1429:0712/111259.095728:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1429:1429:0712/111259.096192:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1429:1429:0712/111259.101446:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[1429:1429:0712/111259.101503:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[1429:1429:0712/111259.101572:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,1477, 4
[1429:1442:0712/111259.101769:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[1429:1442:0712/111259.101947:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111259.107583:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111259.387755:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111259.573388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 480 0x7fa7b94352e0 0x258ab2b9d9e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111259.573930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111259.574048:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111259.574384:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1429:1429:0712/111259.707400:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[1429:1429:0712/111259.707474:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111259.719218:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1429:1429:0712/111259.744160:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[1429:1461:0712/111259.744442:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111259.744569:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111259.744700:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111259.744952:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111259.745066:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111259.747538:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1dfe3b43, 1
[1:1:0712/111259.747764:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x19ff3947, 0
[1:1:0712/111259.747898:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x20149867, 3
[1:1:0712/111259.748018:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1f84593f, 2
[1:1:0712/111259.748196:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4739ffffffff19 433bfffffffe1d 3f59ffffff841f 67ffffff981420 , 10104, 5
[1:1:0712/111259.748914:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1429:1461:0712/111259.749275:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGG9�C;�?Y�g� LoK
[1429:1461:0712/111259.749317:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is G9�C;�?Y�g� �LoK
[1429:1461:0712/111259.749449:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1536, 5, 4739ff19 433bfe1d 3f59841f 67981420 
[1:1:0712/111259.749626:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7cda0c0a0, 3
[1:1:0712/111259.749719:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7cdb98080, 2
[1:1:0712/111259.749810:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fa7b785ad20, -2
[1:1:0712/111259.759189:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111259.759388:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f84593f
[1:1:0712/111259.759546:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f84593f
[1:1:0712/111259.759804:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f84593f
[1:1:0712/111259.760312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.760411:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.760502:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.760592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.760843:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f84593f
[1:1:0712/111259.760969:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7cf7d27ba
[1:1:0712/111259.761054:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa7cf7c9def, 7fa7cf7d277a, 7fa7cf7d40cf
[1:1:0712/111259.762722:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f84593f
[1:1:0712/111259.762930:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f84593f
[1:1:0712/111259.763259:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f84593f
[1:1:0712/111259.764027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.764139:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.764239:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.764344:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f84593f
[1:1:0712/111259.764845:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f84593f
[1:1:0712/111259.765012:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fa7cf7d27ba
[1:1:0712/111259.765104:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fa7cf7c9def, 7fa7cf7d277a, 7fa7cf7d40cf
[1:1:0712/111259.767800:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111259.768083:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111259.768182:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe6ec5e0c8, 0x7ffe6ec5e048)
[1:1:0712/111259.774365:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111259.776425:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111259.885266:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x258ab28b4220
[1:1:0712/111259.885478:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111259.891449:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111300.229833:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111300.229975:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111300.374253:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111300.375944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111300.376105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111300.378793:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111300.455060:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111300.455451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2c921f941f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111300.455583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111300.536090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111300.536997:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111300.537134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111300.537264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111300.605757:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111300.606188:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111300.606288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111300.606415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111300.848151:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/111300.973238:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/111301.013900:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/111301.043641:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/111301.081254:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/111301.199157:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/111301.229074:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/111301.269406:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/111301.361704:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.362181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.362336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.392838:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.393363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.393538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1429:1429:0712/111301.398766:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1429:1429:0712/111301.401888:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1429:1442:0712/111301.425958:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[1429:1442:0712/111301.426028:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1429:1429:0712/111301.426612:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://kdp.amazon.com/
[1429:1429:0712/111301.426658:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kdp.amazon.com/, https://kdp.amazon.com/en_US/, 1
[1429:1429:0712/111301.426727:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://kdp.amazon.com/, HTTP/1.1 200 OK Server: Server Date: Fri, 12 Jul 2019 03:13:01 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive x-amz-id-1: PZ9QDRRQ22XJCCJ29CQW x-amz-id-2: ipw-na-1b-172dd9f9.us-east-1.amazon.com X-Frame-Options: DENY Cache-Control: no-cache, no-store, must-revalidate, max-age=0 Pragma: no-cache Expires: Thu, 01 Jan 1970 00:00:00 GMT X-UA-Compatible: IE=edge,chrome=1 Content-Security-Policy-Report-Only: report-uri /csp-report; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://m.media-amazon.com https://images-na.ssl-images-amazon.com https://c2c.amazon.com https://fls-na.amazon.com https://d2pj26hw09r2m6.cloudfront.net; X-Content-Security-Policy-Report-Only: report-uri /csp-report; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://m.media-amazon.com https://images-na.ssl-images-amazon.com https://c2c.amazon.com https://fls-na.amazon.com https://d2pj26hw09r2m6.cloudfront.net; X-WebKit-CSP-Report-Only: report-uri /csp-report; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://m.media-amazon.com https://images-na.ssl-images-amazon.com https://c2c.amazon.com https://fls-na.amazon.com https://d2pj26hw09r2m6.cloudfront.net; Content-Language: en-US Content-Encoding: gzip Vary: Accept-Encoding,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment,User-Agent Set-Cookie: ubid-main=132-6135697-4605909; Domain=.amazon.com; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ Set-Cookie: kdp-lc-main=en_US; Domain=.amazon.com; Expires=Tue, 01-Jan-2036 08:00:01 GMT; Path=/ x-amz-rid: PZ9QDRRQ22XJCCJ29CQW  ,1536, 5
[1:7:0712/111301.429282:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111301.433132:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.434267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.434413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.446666:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://kdp.amazon.com/
[1:1:0712/111301.462077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.465412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.465577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.503453:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.503879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.504007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1429:1429:0712/111301.505516:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kdp.amazon.com/, https://kdp.amazon.com/, 1
[1429:1429:0712/111301.505569:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://kdp.amazon.com/, https://kdp.amazon.com
[1:1:0712/111301.521151:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111301.552663:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.553143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.553307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.562441:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111301.584595:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111301.584692:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0712/111301.577511:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.585240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.585388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.594594:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7fa7b750d070 0x258ab29fd860 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111301.601429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , var aPageStart = (new Date()).getTime();
[1:1:0712/111301.601600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111301.603019:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7fa7b750d070 0x258ab29fd860 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111301.604528:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 134 0x7fa7b750d070 0x258ab29fd860 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111301.608979:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111301.623809:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.624256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.624431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.650788:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.651282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.651436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.681582:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111301.688370:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111301.690995:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.691461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.691636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.717686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.718193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.718378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.722673:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111301.722796:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0712/111301.753813:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.754255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.754397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.805547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.805938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.806084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.838907:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.845515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.845677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.883982:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.884471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111301.884624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111301.909780:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111301.910296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2c921fa709f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111301.910608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111302.206737:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fa7b750d070 0x258ab238bb60 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.209540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , 
(function(f,h,H,t){function u(a,b){n&&n.count&&n.count("aui:"+a,0===b?0:b||(n.count("aui:"+a)||0)+1
[1:1:0712/111302.209725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111302.213235:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3dead2887f50
[1:1:0712/111302.218590:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20, 0x796aee029c8, 0x258ab24c91a0
[1:1:0712/111302.218766:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 20
[1:1:0712/111302.219012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 193
[1:1:0712/111302.219127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 193 0x7fa7b750d070 0x258ab299d560 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 188 0x7fa7b750d070 0x258ab238bb60 
[1:1:0712/111302.265890:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91a0
[1:1:0712/111302.266098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111302.266342:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 195
[1:1:0712/111302.266526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 195 0x7fa7b750d070 0x258ab238d7e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 188 0x7fa7b750d070 0x258ab238bb60 
[1:1:0712/111302.278515:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 188 0x7fa7b750d070 0x258ab238bb60 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.302919:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111302.303071:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111302.303248:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 205
[1:1:0712/111302.303355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 205 0x7fa7b750d070 0x258ab261eae0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 188 0x7fa7b750d070 0x258ab238bb60 
[1:1:0712/111302.344949:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0692852, 622, 1
[1:1:0712/111302.345143:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.471727:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.472715:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.473830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 217 0x7fa7b750d070 0x258ab29f7960 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.474409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , 
P.when('A').execute(function(A) {
A.on('bidi-shim:add-dir-auto', function() {
A.$('textarea, input[
[1:1:0712/111302.474570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111302.480430:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00708604, 72, 1
[1:1:0712/111302.480599:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.481115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 193, 7fa7b9e52881
[1:1:0712/111302.485273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"188 0x7fa7b750d070 0x258ab238bb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111302.485459:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"188 0x7fa7b750d070 0x258ab238bb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111302.485631:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.485897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , ba, (){h.body?m.trigger("a-bodyBegin"):setTimeout(ba,20)}
[1:1:0712/111302.486014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111302.487986:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 195, 7fa7b9e52881
[1:1:0712/111302.491754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"188 0x7fa7b750d070 0x258ab238bb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111302.509184:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"188 0x7fa7b750d070 0x258ab238bb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111302.510377:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.510724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111302.510809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111302.511276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111302.511354:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111302.511501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 228
[1:1:0712/111302.511585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 228 0x7fa7b750d070 0x258ab2a159e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 195 0x7fa7b750d070 0x258ab238d7e0 
[1:1:0712/111302.544699:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111302.544844:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.545336:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7fa7b750d070 0x258ab289bbe0 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.545952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , 
P.when('A', 'Jele', 'JeleScripterReady', 'ready').execute(function(A, Jele, JeleScripterReady){
Jel
[1:1:0712/111302.546114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111302.549302:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 227 0x7fa7b750d070 0x258ab289bbe0 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.585518:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91e8
[1:1:0712/111302.589193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111302.589397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 240
[1:1:0712/111302.589517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 240 0x7fa7b750d070 0x258ab29f42e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 227 0x7fa7b750d070 0x258ab289bbe0 
[1:1:0712/111302.591532:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.860310:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111302.899511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 240, 7fa7b9e52881
[1:1:0712/111302.903594:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"227 0x7fa7b750d070 0x258ab289bbe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111302.903779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"227 0x7fa7b750d070 0x258ab289bbe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111302.903988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111302.904283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111302.904405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111302.904719:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111302.904815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111302.904974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 260
[1:1:0712/111302.905074:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 260 0x7fa7b750d070 0x258ab2a890e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 240 0x7fa7b750d070 0x258ab29f42e0 
[1:1:0712/111303.110642:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 282 0x7fa7b94352e0 0x258ab2bb7960 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111303.117482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (function(c){var b=window.AmazonUIPageJS||window.P,d=b._namespace||b.attributeErrors,a=d?d("AmazonUI
[1:1:0712/111303.117677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111303.121350:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9160
[1:1:0712/111303.121522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.121765:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 285
[1:1:0712/111303.121939:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 285 0x7fa7b750d070 0x258ab2b9da60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 282 0x7fa7b94352e0 0x258ab2bb7960 
[1:1:0712/111303.277242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 285, 7fa7b9e52881
[1:1:0712/111303.281980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"282 0x7fa7b94352e0 0x258ab2bb7960 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.282134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"282 0x7fa7b94352e0 0x258ab2bb7960 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.282333:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111303.282593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111303.282681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111303.282956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.283052:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.283215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 289
[1:1:0712/111303.283321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 289 0x7fa7b750d070 0x258ab2bf24e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 285 0x7fa7b750d070 0x258ab2b9da60 
[1:1:0712/111303.675278:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 289, 7fa7b9e52881
[1:1:0712/111303.680445:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"285 0x7fa7b750d070 0x258ab2b9da60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.680673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"285 0x7fa7b750d070 0x258ab2b9da60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.680921:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111303.681242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111303.681407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111303.681778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.681934:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.682178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 304
[1:1:0712/111303.682350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 304 0x7fa7b750d070 0x258ab238d9e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 289 0x7fa7b750d070 0x258ab2bf24e0 
[1:1:0712/111303.765658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 205, 7fa7b9e52881
[1:1:0712/111303.769826:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"188 0x7fa7b750d070 0x258ab238bb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.770000:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"188 0x7fa7b750d070 0x258ab238bb60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.770230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111303.770532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0712/111303.770683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111303.777931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.778066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111303.778246:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 309
[1:1:0712/111303.778365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 309 0x7fa7b750d070 0x258ab2bb55e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 205 0x7fa7b750d070 0x258ab261eae0 
[1:1:0712/111303.805153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 304, 7fa7b9e52881
[1:1:0712/111303.809308:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"289 0x7fa7b750d070 0x258ab2bf24e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.809445:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"289 0x7fa7b750d070 0x258ab2bf24e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.809628:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111303.809886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111303.809998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111303.810276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.810379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.810542:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 311
[1:1:0712/111303.810619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 311 0x7fa7b750d070 0x258ab2bb7560 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.830239:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.845211:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.845452:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 312
[1:1:0712/111303.845618:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 312 0x7fa7b750d070 0x258ab29b66e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.848554:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.848715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111303.848877:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 313
[1:1:0712/111303.848976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 313 0x7fa7b750d070 0x258ab2a146e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.850092:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.850248:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.850462:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 314
[1:1:0712/111303.850626:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 314 0x7fa7b750d070 0x258ab2a7e5e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.852517:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.852631:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.852788:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 315
[1:1:0712/111303.852886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 315 0x7fa7b750d070 0x258ab23e5de0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.854629:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.854747:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.854915:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 316
[1:1:0712/111303.855033:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 316 0x7fa7b750d070 0x258ab238c860 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.858242:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.858364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.858578:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 317
[1:1:0712/111303.858690:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 317 0x7fa7b750d070 0x258ab2b909e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.860504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.860624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.860782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 318
[1:1:0712/111303.860887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 318 0x7fa7b750d070 0x258ab2b8b860 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 304 0x7fa7b750d070 0x258ab238d9e0 
[1:1:0712/111303.874833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 311, 7fa7b9e52881
[1:1:0712/111303.880289:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"304 0x7fa7b750d070 0x258ab238d9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.880466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"304 0x7fa7b750d070 0x258ab238d9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111303.880656:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111303.880916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111303.880994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111303.881333:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.881449:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.881670:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 324
[1:1:0712/111303.881785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 324 0x7fa7b750d070 0x258ab29b4ce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 311 0x7fa7b750d070 0x258ab2bb7560 
[1:1:0712/111303.886195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.886356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.886555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 325
[1:1:0712/111303.886684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 325 0x7fa7b750d070 0x258ab2bf25e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 311 0x7fa7b750d070 0x258ab2bb7560 
[1:1:0712/111303.900507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.900678:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111303.900828:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 327
[1:1:0712/111303.900912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 327 0x7fa7b750d070 0x258ab2b9d0e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 311 0x7fa7b750d070 0x258ab2bb7560 
[1:1:0712/111303.912080:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111303.912260:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0712/111303.912456:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 328
[1:1:0712/111303.912560:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 328 0x7fa7b750d070 0x258ab2a8f260 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 311 0x7fa7b750d070 0x258ab2bb7560 
[1:1:0712/111304.055321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 318, 7fa7b9e52881
[1:1:0712/111304.060745:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"304 0x7fa7b750d070 0x258ab238d9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.060904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"304 0x7fa7b750d070 0x258ab238d9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.061111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.061375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){return b.apply(null,f)}
[1:1:0712/111304.061501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.062338:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.062450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 100
[1:1:0712/111304.062622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 331
[1:1:0712/111304.062706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 331 0x7fa7b750d070 0x258ab29e30e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 318 0x7fa7b750d070 0x258ab2b8b860 
[1:1:0712/111304.068861:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 313, 7fa7b9e52881
[1:1:0712/111304.073777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"304 0x7fa7b750d070 0x258ab238d9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.073926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"304 0x7fa7b750d070 0x258ab238d9e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.074119:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.074383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111304.074499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.074853:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.074961:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111304.075136:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 333
[1:1:0712/111304.075262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 333 0x7fa7b750d070 0x258ab2b9eee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 313 0x7fa7b750d070 0x258ab2a146e0 
[1:1:0712/111304.086775:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 324, 7fa7b9e52881
[1:1:0712/111304.092601:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"311 0x7fa7b750d070 0x258ab2bb7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.092799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"311 0x7fa7b750d070 0x258ab2bb7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.092996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.093276:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111304.093400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.093703:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.093814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.093989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 334
[1:1:0712/111304.094099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 334 0x7fa7b750d070 0x258ab2bf24e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 324 0x7fa7b750d070 0x258ab29b4ce0 
[1:1:0712/111304.114011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.114188:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.114400:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 335
[1:1:0712/111304.114530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 335 0x7fa7b750d070 0x258ab238d9e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 324 0x7fa7b750d070 0x258ab29b4ce0 
		remove user.e_dd056b42 -> 0
[1:1:0712/111304.206013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 333, 7fa7b9e52881
[1:1:0712/111304.211129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"313 0x7fa7b750d070 0x258ab2a146e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.211317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"313 0x7fa7b750d070 0x258ab2a146e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.211565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.211886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111304.212045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.212435:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.212531:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111304.212700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 341
[1:1:0712/111304.212797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 341 0x7fa7b750d070 0x258ab238b8e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 333 0x7fa7b750d070 0x258ab2b9eee0 
[1:1:0712/111304.218108:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 334, 7fa7b9e52881
[1:1:0712/111304.222574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"324 0x7fa7b750d070 0x258ab29b4ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.222710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"324 0x7fa7b750d070 0x258ab29b4ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.222892:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.223136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111304.223249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.223536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.223628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.223787:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 342
[1:1:0712/111304.223889:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 342 0x7fa7b750d070 0x258ab2ba4760 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 334 0x7fa7b750d070 0x258ab2bf24e0 
[1:1:0712/111304.231700:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0712/111304.231918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 343
[1:1:0712/111304.232039:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 343 0x7fa7b750d070 0x258ab29f36e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 334 0x7fa7b750d070 0x258ab2bf24e0 
[1:1:0712/111304.278218:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.278390:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.278656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 344
[1:1:0712/111304.278792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 344 0x7fa7b750d070 0x258ab2bb7d60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 334 0x7fa7b750d070 0x258ab2bf24e0 
[1:1:0712/111304.283450:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 331, 7fa7b9e52881
[1:1:0712/111304.289107:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"318 0x7fa7b750d070 0x258ab2b8b860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.289327:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"318 0x7fa7b750d070 0x258ab2b8b860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.289621:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.290085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){return b.apply(null,f)}
[1:1:0712/111304.290207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.300997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 342, 7fa7b9e52881
[1:1:0712/111304.307114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"334 0x7fa7b750d070 0x258ab2bf24e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.307273:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"334 0x7fa7b750d070 0x258ab2bf24e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.307457:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.307745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111304.307850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.308164:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.308259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.308467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 355
[1:1:0712/111304.308568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 355 0x7fa7b750d070 0x258ab23e5de0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 342 0x7fa7b750d070 0x258ab2ba4760 
[1:1:0712/111304.312048:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.312192:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.312369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 356
[1:1:0712/111304.312484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 356 0x7fa7b750d070 0x258ab2a800e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 342 0x7fa7b750d070 0x258ab2ba4760 
[1:1:0712/111304.365013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 341, 7fa7b9e52881
[1:1:0712/111304.369993:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"333 0x7fa7b750d070 0x258ab2b9eee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.370147:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"333 0x7fa7b750d070 0x258ab2b9eee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.370367:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.370687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111304.370802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.371158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.371243:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111304.371395:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 361
[1:1:0712/111304.371486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 361 0x7fa7b750d070 0x258ab2b8ce60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 341 0x7fa7b750d070 0x258ab238b8e0 
[1:1:0712/111304.371908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 343, 7fa7b9e528db
[1:1:0712/111304.376789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"334 0x7fa7b750d070 0x258ab2bf24e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.376913:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"334 0x7fa7b750d070 0x258ab2bf24e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.377122:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 362
[1:1:0712/111304.377237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7fa7b750d070 0x258ab29fd560 , 5:3_https://kdp.amazon.com/, 0, , 343 0x7fa7b750d070 0x258ab29f36e0 
[1:1:0712/111304.377383:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.377613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){k.reduce(g,function(a,b){return a&&"loaded"===b.status},!0)&&(a(),clearInterval(c))}
[1:1:0712/111304.377723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.406899:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 351 0x7fa7b94352e0 0x258ab238d9e0 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.469214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , /*
 Highcharts JS v3.0.10 (2014-03-10)

 (c) 2009-2014 Torstein Honsi

 License: www.highcharts.com/
[1:1:0712/111304.469411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.619538:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 355, 7fa7b9e52881
[1:1:0712/111304.624380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"342 0x7fa7b750d070 0x258ab2ba4760 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.624547:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"342 0x7fa7b750d070 0x258ab2ba4760 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.624750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.625003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111304.625113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.625439:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.625547:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.625720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 367
[1:1:0712/111304.625836:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 367 0x7fa7b750d070 0x258ab2a81ce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 355 0x7fa7b750d070 0x258ab23e5de0 
[1:1:0712/111304.688854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.689231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){e[a]||(e[a]=1,A(a))}
[1:1:0712/111304.689331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.718910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9220
[1:1:0712/111304.719057:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.719228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 372
[1:1:0712/111304.719323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 372 0x7fa7b750d070 0x258ab2b9ef60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7fa7b750d070 0x258ab2bee660 
[1:1:0712/111304.725446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0712/111304.725722:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 373
[1:1:0712/111304.725856:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 373 0x7fa7b750d070 0x258ab2a14460 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7fa7b750d070 0x258ab2bee660 
[1:1:0712/111304.729025:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.732186:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.732528:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.733111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.735226:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91f0
[1:1:0712/111304.735367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.735547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 378
[1:1:0712/111304.735655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 378 0x7fa7b750d070 0x258ab2b9e160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7fa7b750d070 0x258ab2bee660 
[1:1:0712/111304.746434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.750495:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91f0
[1:1:0712/111304.750647:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.750812:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 379
[1:1:0712/111304.750914:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 379 0x7fa7b750d070 0x258ab29ed5e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7fa7b750d070 0x258ab2bee660 
[1:1:0712/111304.752973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91f0
[1:1:0712/111304.753109:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.753290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 380
[1:1:0712/111304.753399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 380 0x7fa7b750d070 0x258ab2750160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7fa7b750d070 0x258ab2bee660 
[1:1:0712/111304.756739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x796aee029c8, 0x258ab24c91f0
[1:1:0712/111304.756869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1500
[1:1:0712/111304.757025:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 381
[1:1:0712/111304.757143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 381 0x7fa7b750d070 0x258ab388e960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 363 0x7fa7b750d070 0x258ab2bee660 
[1:1:0712/111304.764257:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 361, 7fa7b9e52881
[1:1:0712/111304.770689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"341 0x7fa7b750d070 0x258ab238b8e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.770890:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"341 0x7fa7b750d070 0x258ab238b8e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.772191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.785464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111304.788613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.789315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 328, 7fa7b9e52881
[1:1:0712/111304.795064:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"311 0x7fa7b750d070 0x258ab2bb7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.795247:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"311 0x7fa7b750d070 0x258ab2bb7560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.795491:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.795793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){return b.apply(null,f)}
[1:1:0712/111304.795912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.796874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 367, 7fa7b9e52881
[1:1:0712/111304.802129:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"355 0x7fa7b750d070 0x258ab23e5de0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.802273:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"355 0x7fa7b750d070 0x258ab23e5de0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.802463:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.802704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111304.802818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111304.803107:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111304.803216:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111304.803382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 386
[1:1:0712/111304.803496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 386 0x7fa7b750d070 0x258ab29f3460 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 367 0x7fa7b750d070 0x258ab2a81ce0 
[1:1:0712/111304.970618:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 372, 7fa7b9e52881
[1:1:0712/111304.976668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"363 0x7fa7b750d070 0x258ab2bee660 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.976876:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"363 0x7fa7b750d070 0x258ab2bee660 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111304.977099:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111304.977424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , q, (){d.log({k:"rtiming",value:l()+"~"+p()},"csm")}
[1:1:0712/111304.977546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.004311:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 309, 7fa7b9e52881
[1:1:0712/111305.010376:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"205 0x7fa7b750d070 0x258ab261eae0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.010556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"205 0x7fa7b750d070 0x258ab261eae0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.010751:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.011029:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0712/111305.011133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.018466:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.018611:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111305.018800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 392
[1:1:0712/111305.018923:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 392 0x7fa7b750d070 0x258ab38992e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 309 0x7fa7b750d070 0x258ab2bb55e0 
[1:1:0712/111305.024952:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111305.042492:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 386, 7fa7b9e52881
[1:1:0712/111305.048722:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"367 0x7fa7b750d070 0x258ab2a81ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.048973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"367 0x7fa7b750d070 0x258ab2a81ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.049178:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.049434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111305.049511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.049778:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.049852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.050031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 400
[1:1:0712/111305.050178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 400 0x7fa7b750d070 0x258ab37fda60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 386 0x7fa7b750d070 0x258ab29f3460 
[1:1:0712/111305.127805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7fa7b94352e0 0x258ab2b8a860 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.139432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (function(c,e,t){function n(a){for(var b={},c,g,u=0;u<a.length;u++)g=a[u],c=g.r+g.s+g.m,g.c&&(b[c]||
[1:1:0712/111305.139607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.145480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.145651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111305.145861:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 405
[1:1:0712/111305.145989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 405 0x7fa7b750d070 0x258ab2bf4c60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.151660:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.151836:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.152046:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 406
[1:1:0712/111305.152165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 406 0x7fa7b750d070 0x258ab2bb9f60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.152700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 600000, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.152799:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 600000
[1:1:0712/111305.152963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 407
[1:1:0712/111305.153090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7fa7b750d070 0x258ab2b9d960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.161972:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.162138:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0712/111305.162359:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 408
[1:1:0712/111305.162474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 408 0x7fa7b750d070 0x258ab2b9b960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.165311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.165441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.165635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 409
[1:1:0712/111305.165744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 409 0x7fa7b750d070 0x258ab2bf4a60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.174666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.174830:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.175028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 410
[1:1:0712/111305.175144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7fa7b750d070 0x258ab2501e60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.185825:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x796aee029c8, 0x258ab24c91c8
[1:1:0712/111305.185989:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0712/111305.186194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 411
[1:1:0712/111305.186325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 411 0x7fa7b750d070 0x258ab3899ae0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 395 0x7fa7b94352e0 0x258ab2b8a860 
[1:1:0712/111305.241228:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 400, 7fa7b9e52881
[1:1:0712/111305.247821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"386 0x7fa7b750d070 0x258ab29f3460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.248030:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"386 0x7fa7b750d070 0x258ab29f3460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.248298:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.248621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111305.248757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.249114:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.249267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.249499:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 424
[1:1:0712/111305.249666:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 424 0x7fa7b750d070 0x258ab2ba8ee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 400 0x7fa7b750d070 0x258ab37fda60 
[1:1:0712/111305.368344:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 406, 7fa7b9e52881
[1:1:0712/111305.374618:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.374783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.374980:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.375251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , n, (){var b=k.length;if(0<b){for(var c=[],a=0;a<b;a++){var d=k[a].api;d.ready()?(d.on({ts:f.d,ns:y}),p.
[1:1:0712/111305.375335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.375793:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 409, 7fa7b9e52881
[1:1:0712/111305.382375:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.382588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.382812:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.383097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111305.383208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.390846:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 410, 7fa7b9e52881
[1:1:0712/111305.397300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.397505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.397735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.398034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111305.398150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.412422:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 411, 7fa7b9e52881
[1:1:0712/111305.419085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.419301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.419548:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.419862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111305.419992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.427669:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 424, 7fa7b9e52881
[1:1:0712/111305.444035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"400 0x7fa7b750d070 0x258ab37fda60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.444273:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"400 0x7fa7b750d070 0x258ab37fda60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.444541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.444837:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111305.444938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.445248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.445360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.445552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 427
[1:1:0712/111305.445705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 427 0x7fa7b750d070 0x258ab38994e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 424 0x7fa7b750d070 0x258ab2ba8ee0 
		remove user.e_86ae6f8f -> 0
[1:1:0712/111305.478606:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.478765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.478956:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 428
[1:1:0712/111305.479077:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 428 0x7fa7b750d070 0x258ab38933e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 424 0x7fa7b750d070 0x258ab2ba8ee0 
[1:1:0712/111305.511956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 427, 7fa7b9e52881
[1:1:0712/111305.518995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"424 0x7fa7b750d070 0x258ab2ba8ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.519197:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"424 0x7fa7b750d070 0x258ab2ba8ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.519441:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.519755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111305.519888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.520203:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.520343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.520513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 442
[1:1:0712/111305.520619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 442 0x7fa7b750d070 0x258ab29f4a60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 427 0x7fa7b750d070 0x258ab38994e0 
[1:1:0712/111305.665398:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 442, 7fa7b9e52881
[1:1:0712/111305.672384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"427 0x7fa7b750d070 0x258ab38994e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.672544:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"427 0x7fa7b750d070 0x258ab38994e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111305.672735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111305.672996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111305.673105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111305.673378:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111305.673522:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111305.673712:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 462
[1:1:0712/111305.673833:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 462 0x7fa7b750d070 0x258ab388efe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 442 0x7fa7b750d070 0x258ab29f4a60 
[1:1:0712/111306.884639:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111308.779062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 462, 7fa7b9e52881
[1:1:0712/111308.784898:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"442 0x7fa7b750d070 0x258ab29f4a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111308.785059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"442 0x7fa7b750d070 0x258ab29f4a60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111308.785246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111308.785510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111308.785621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111308.785916:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111308.786022:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111308.786188:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 474
[1:1:0712/111308.786268:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 474 0x7fa7b750d070 0x258ab36d7460 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 462 0x7fa7b750d070 0x258ab388efe0 
[1:1:0712/111308.989362:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 392, 7fa7b9e52881
[1:1:0712/111308.996157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"309 0x7fa7b750d070 0x258ab2bb55e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111308.996348:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"309 0x7fa7b750d070 0x258ab2bb55e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111308.996587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111308.996862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0712/111308.996956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.004309:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.004434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111309.004614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 477
[1:1:0712/111309.004722:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 477 0x7fa7b750d070 0x258ab36a66e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 392 0x7fa7b750d070 0x258ab38992e0 
[1:1:0712/111309.005223:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 405, 7fa7b9e52881
[1:1:0712/111309.012193:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.012342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"395 0x7fa7b94352e0 0x258ab2b8a860 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.012531:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.012771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , k, (){for(var a=0;a<B.length;a++)B[a]();q.length&&d(n(q.splice(0,q.length)),N,K,H);A=L=0}
[1:1:0712/111309.012862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.019228:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 381, 7fa7b9e52881
[1:1:0712/111309.026684:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"363 0x7fa7b750d070 0x258ab2bee660 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.026840:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"363 0x7fa7b750d070 0x258ab2bee660 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.027045:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.027327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){a("beforeAfterLoad");a("afterLoad")}
[1:1:0712/111309.027450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.028453:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.028557:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.028729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 478
[1:1:0712/111309.028842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 478 0x7fa7b750d070 0x258ab5b4bc60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 381 0x7fa7b750d070 0x258ab388e960 
[1:1:0712/111309.030727:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.030841:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.031014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 479
[1:1:0712/111309.031144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 479 0x7fa7b750d070 0x258ab5bc7960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 381 0x7fa7b750d070 0x258ab388e960 
[1:1:0712/111309.100771:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 474, 7fa7b9e52881
[1:1:0712/111309.107759:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"462 0x7fa7b750d070 0x258ab388efe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.107955:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"462 0x7fa7b750d070 0x258ab388efe0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.108179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.108472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111309.108569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.108839:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.108907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.109075:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 482
[1:1:0712/111309.109162:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 482 0x7fa7b750d070 0x258ab29f44e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 474 0x7fa7b750d070 0x258ab36d7460 
[1:1:0712/111309.198275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.198486:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 10000
[1:1:0712/111309.199713:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 484
[1:1:0712/111309.199877:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 484 0x7fa7b750d070 0x258ab5f3f4e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 474 0x7fa7b750d070 0x258ab36d7460 
[1:1:0712/111309.218703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111309.229244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.249049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 482, 7fa7b9e52881
[1:1:0712/111309.257316:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"474 0x7fa7b750d070 0x258ab36d7460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.257490:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"474 0x7fa7b750d070 0x258ab36d7460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.257698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.258026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111309.258131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.258422:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.258517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.258698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 497
[1:1:0712/111309.258814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 497 0x7fa7b750d070 0x258ab5bbda60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 482 0x7fa7b750d070 0x258ab29f44e0 
[1:1:0712/111309.468879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 497, 7fa7b9e52881
[1:1:0712/111309.477103:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"482 0x7fa7b750d070 0x258ab29f44e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.477287:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"482 0x7fa7b750d070 0x258ab29f44e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.477512:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.477796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111309.477901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.478199:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.478295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.478465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 515
[1:1:0712/111309.478573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7fa7b750d070 0x258ab2b9bce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 497 0x7fa7b750d070 0x258ab5bbda60 
[3:3:0712/111309.525975:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/111309.659165:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pointerenter", "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.659627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , k, (a){return"undefined"===typeof c||a&&c.event.triggered===a.type?void 0:c.event.handle.apply(k.elem,a
[1:1:0712/111309.659748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.671503:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.684042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pointermove", "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.696488:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.697149:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.706416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.710649:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111309.710788:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0712/111309.710967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 529
[1:1:0712/111309.711112:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 529 0x7fa7b750d070 0x258ab388efe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 
[1:1:0712/111309.714207:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111309.714316:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0712/111309.714467:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 530
[1:1:0712/111309.714569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 530 0x7fa7b750d070 0x258ab5c6cd60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 
[1:1:0712/111309.715135:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111309.715266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.715497:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 531
[1:1:0712/111309.715676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 531 0x7fa7b750d070 0x258ab28899e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 
[1:1:0712/111309.756925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 515, 7fa7b9e52881
[1:1:0712/111309.765024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"497 0x7fa7b750d070 0x258ab5bbda60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.765236:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"497 0x7fa7b750d070 0x258ab5bbda60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.765448:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.765745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111309.765856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111309.766132:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.766245:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.766429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 540
[1:1:0712/111309.766550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 540 0x7fa7b750d070 0x258ab5cdbe60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 515 0x7fa7b750d070 0x258ab2b9bce0 
[1:1:0712/111309.805601:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.805770:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.805961:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 546
[1:1:0712/111309.806071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 546 0x7fa7b750d070 0x258ab393cfe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 515 0x7fa7b750d070 0x258ab2b9bce0 
[1:1:0712/111309.815337:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111309.815668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111309.816426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 548
[1:1:0712/111309.816550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 548 0x7fa7b750d070 0x258ab5b59b60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 515 0x7fa7b750d070 0x258ab2b9bce0 
[1:1:0712/111309.959137:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 531, 7fa7b9e52881
[1:1:0712/111309.967813:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.968015:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111309.968244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111309.968541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111309.968626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.066411:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 530, 7fa7b9e52881
[1:1:0712/111310.074709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.074901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.075115:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.075392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111310.075510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.076039:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 540, 7fa7b9e52881
[1:1:0712/111310.084275:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"515 0x7fa7b750d070 0x258ab2b9bce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.084455:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"515 0x7fa7b750d070 0x258ab2b9bce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.084655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.084946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111310.085056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.085339:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.085446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.085622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 571
[1:1:0712/111310.085746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 571 0x7fa7b750d070 0x258ab5ce1ce0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 540 0x7fa7b750d070 0x258ab5cdbe60 
[1:1:0712/111310.240164:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.240571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){clearTimeout(ea);Q=4;D()}
[1:1:0712/111310.240688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.241287:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9220
[1:1:0712/111310.241391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111310.241564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 580
[1:1:0712/111310.241691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7fa7b750d070 0x258ab637cf60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 
[1:1:0712/111310.241885:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.245745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 100
[1:1:0712/111310.245928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 581
[1:1:0712/111310.246050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 581 0x7fa7b750d070 0x258ab637c1e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 
[1:1:0712/111310.246571:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 200
[1:1:0712/111310.246726:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 582
[1:1:0712/111310.246829:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7fa7b750d070 0x258ab2955ee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 
[1:1:0712/111310.247057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.247480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x796aee029c8, 0x258ab24c91f0
[1:1:0712/111310.247584:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 100
[1:1:0712/111310.247747:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 583
[1:1:0712/111310.247850:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 583 0x7fa7b750d070 0x258ab5f81a60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 
[1:1:0712/111310.249525:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111310.249642:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.249806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 584
[1:1:0712/111310.249925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 584 0x7fa7b750d070 0x258ab238d660 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 
[1:1:0712/111310.299826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 477, 7fa7b9e52881
[1:1:0712/111310.308596:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"392 0x7fa7b750d070 0x258ab38992e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.308803:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"392 0x7fa7b750d070 0x258ab38992e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.309000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.309301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0712/111310.309415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.316585:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.316733:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111310.316906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 594
[1:1:0712/111310.316987:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 594 0x7fa7b750d070 0x258ab29743e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 477 0x7fa7b750d070 0x258ab36a66e0 
[1:1:0712/111310.343786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 571, 7fa7b9e52881
[1:1:0712/111310.352084:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"540 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.352249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"540 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.352443:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.352705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111310.352796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.353095:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.353215:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.353409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 597
[1:1:0712/111310.353527:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 597 0x7fa7b750d070 0x258ab63832e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 571 0x7fa7b750d070 0x258ab5ce1ce0 
[1:1:0712/111310.361948:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.362103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.362287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 598
[1:1:0712/111310.362406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 598 0x7fa7b750d070 0x258ab2972fe0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 571 0x7fa7b750d070 0x258ab5ce1ce0 
[1:1:0712/111310.466340:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 529, 7fa7b9e52881
[1:1:0712/111310.473742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.473892:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"516 0x7fa7c681e960 0x258ab2620d80 0x258ab2620d90 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.474081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.474344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111310.474452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.475059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 584, 7fa7b9e52881
[1:1:0712/111310.482790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.482926:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.483105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.483363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111310.483469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.483920:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 580, 7fa7b9e52881
[1:1:0712/111310.491291:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.491420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.491602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.491813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111310.491895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.492195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.492270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111310.492408:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 605
[1:1:0712/111310.492500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 605 0x7fa7b750d070 0x258ab645f1e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 580 0x7fa7b750d070 0x258ab637cf60 
[1:1:0712/111310.581577:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 581, 7fa7b9e528db
[1:1:0712/111310.590888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.591114:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.591334:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 612
[1:1:0712/111310.591455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 612 0x7fa7b750d070 0x258ab5b4b560 , 5:3_https://kdp.amazon.com/, 0, , 581 0x7fa7b750d070 0x258ab637c1e0 
[1:1:0712/111310.591624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.591905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111310.592006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.598509:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.598665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.598833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 613
[1:1:0712/111310.598930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 613 0x7fa7b750d070 0x258ab5bbd4e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 581 0x7fa7b750d070 0x258ab637c1e0 
[1:1:0712/111310.600295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.600407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.600585:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 614
[1:1:0712/111310.600697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7fa7b750d070 0x258ab5d08960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 581 0x7fa7b750d070 0x258ab637c1e0 
[1:1:0712/111310.609177:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 583, 7fa7b9e52881
[1:1:0712/111310.618574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.618767:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.618991:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.619278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111310.619394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.637219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 597, 7fa7b9e52881
[1:1:0712/111310.644603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"571 0x7fa7b750d070 0x258ab5ce1ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.644723:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"571 0x7fa7b750d070 0x258ab5ce1ce0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.644881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.645156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111310.645340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.645630:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.645717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.645950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 619
[1:1:0712/111310.646062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7fa7b750d070 0x258ab62fa560 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 597 0x7fa7b750d070 0x258ab63832e0 
[1:1:0712/111310.716524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x796aee029c8, 0x258ab24c9270
[1:1:0712/111310.716672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0712/111310.716830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 620
[1:1:0712/111310.716928:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7fa7b750d070 0x258ab5be76e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 597 0x7fa7b750d070 0x258ab63832e0 
[1:1:0712/111310.717586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 582, 7fa7b9e528db
[1:1:0712/111310.726241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.726397:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"562 0x7fa7c681e960 0x258ab62e8b00 0x258ab62e8b10 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.726681:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 625
[1:1:0712/111310.726859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7fa7b750d070 0x258ab62ee8e0 , 5:3_https://kdp.amazon.com/, 0, , 582 0x7fa7b750d070 0x258ab2955ee0 
[1:1:0712/111310.727010:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.727237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0712/111310.727339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.756913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , n, (){var a={w:p.width,aw:p.availWidth,h:p.height,ah:p.availHeight,cd:p.colorDepth,pd:p.pixelDepth},b={
[1:1:0712/111310.757124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.757791:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111310.757901:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0712/111310.758073:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 630
[1:1:0712/111310.758191:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7fa7b750d070 0x258ab6383c60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 604 0x7fa7c681e960 0x258ab63cd6a0 0x258ab63cd6b0 
[1:1:0712/111310.767019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 605, 7fa7b9e52881
[1:1:0712/111310.778118:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"580 0x7fa7b750d070 0x258ab637cf60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.778290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"580 0x7fa7b750d070 0x258ab637cf60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.778520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.778897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111310.779025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.779480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.779562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111310.779756:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 633
[1:1:0712/111310.779840:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 633 0x7fa7b750d070 0x258ab5d33ee0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 605 0x7fa7b750d070 0x258ab645f1e0 
[1:1:0712/111310.817913:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 614, 7fa7b9e52881
[1:1:0712/111310.828100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"581 0x7fa7b750d070 0x258ab637c1e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.828288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"581 0x7fa7b750d070 0x258ab637c1e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.828500:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.828778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){return b.apply(null,f)}
[1:1:0712/111310.828872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.829759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 612, 7fa7b9e528db
[1:1:0712/111310.839183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"581 0x7fa7b750d070 0x258ab637c1e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.839449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"581 0x7fa7b750d070 0x258ab637c1e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.839783:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 639
[1:1:0712/111310.839910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 639 0x7fa7b750d070 0x258ab36d7d60 , 5:3_https://kdp.amazon.com/, 0, , 612 0x7fa7b750d070 0x258ab5b4b560 
[1:1:0712/111310.840068:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.840351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111310.840447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.842870:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 619, 7fa7b9e52881
[1:1:0712/111310.853194:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"597 0x7fa7b750d070 0x258ab63832e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.853395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"597 0x7fa7b750d070 0x258ab63832e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.853608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.853916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111310.854017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.854311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.854404:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111310.854582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 640
[1:1:0712/111310.854710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 640 0x7fa7b750d070 0x258ab63cb960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 619 0x7fa7b750d070 0x258ab62fa560 
[1:1:0712/111310.938233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 620, 7fa7b9e52881
[1:1:0712/111310.945434:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"597 0x7fa7b750d070 0x258ab63832e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.945554:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"597 0x7fa7b750d070 0x258ab63832e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.945727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.945971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111310.946077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.962546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 633, 7fa7b9e52881
[1:1:0712/111310.970216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"605 0x7fa7b750d070 0x258ab645f1e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.970358:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"605 0x7fa7b750d070 0x258ab645f1e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111310.970546:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111310.970805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111310.970917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111310.971241:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 16, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111310.971345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 16
[1:1:0712/111310.971514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 648
[1:1:0712/111310.971634:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 648 0x7fa7b750d070 0x258ab5cf53e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 633 0x7fa7b750d070 0x258ab5d33ee0 
[1:1:0712/111311.000205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 639, 7fa7b9e528db
[1:1:0712/111311.011446:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"612 0x7fa7b750d070 0x258ab5b4b560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.011633:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"612 0x7fa7b750d070 0x258ab5b4b560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.011873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 653
[1:1:0712/111311.011994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 653 0x7fa7b750d070 0x258ab2a80d60 , 5:3_https://kdp.amazon.com/, 0, , 639 0x7fa7b750d070 0x258ab36d7d60 
[1:1:0712/111311.012153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.012433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.012538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.014969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 625, 7fa7b9e528db
[1:1:0712/111311.024163:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"582 0x7fa7b750d070 0x258ab2955ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.024353:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"582 0x7fa7b750d070 0x258ab2955ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.024576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 655
[1:1:0712/111311.024687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 655 0x7fa7b750d070 0x258ab2a5bae0 , 5:3_https://kdp.amazon.com/, 0, , 625 0x7fa7b750d070 0x258ab62ee8e0 
[1:1:0712/111311.024818:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.025093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0712/111311.025217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.027424:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 640, 7fa7b9e52881
[1:1:0712/111311.036837:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"619 0x7fa7b750d070 0x258ab62fa560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.037017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"619 0x7fa7b750d070 0x258ab62fa560 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.037232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.037511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111311.037633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.037919:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111311.038024:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111311.038204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 656
[1:1:0712/111311.038323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7fa7b750d070 0x258ab66b06e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 640 0x7fa7b750d070 0x258ab63cb960 
[1:1:0712/111311.099794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){I=null;m("dwpc",k);d()}
[1:1:0712/111311.099945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.100735:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111311.100815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111311.100963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 662
[1:1:0712/111311.101072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 662 0x7fa7b750d070 0x258ab5ce5460 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 646 0x7fa7c681e960 0x258ab66a5560 0x258ab66a5570 
[1:1:0712/111311.126519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 648, 7fa7b9e52881
[1:1:0712/111311.134544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"633 0x7fa7b750d070 0x258ab5d33ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.134700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"633 0x7fa7b750d070 0x258ab5d33ee0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.134898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.135179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , D, (){if(E){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Ma
[1:1:0712/111311.135291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.135790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 656, 7fa7b9e52881
[1:1:0712/111311.144034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"640 0x7fa7b750d070 0x258ab63cb960 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.144176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"640 0x7fa7b750d070 0x258ab63cb960 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.144359:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.144572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111311.144670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.144955:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111311.145060:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111311.145224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 667
[1:1:0712/111311.145326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 667 0x7fa7b750d070 0x258ab63a3d60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 656 0x7fa7b750d070 0x258ab66b06e0 
[1:1:0712/111311.198533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111311.198789:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 668
[1:1:0712/111311.198918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7fa7b750d070 0x258ab2955be0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 656 0x7fa7b750d070 0x258ab66b06e0 
[1:1:0712/111311.211270:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 3000
[1:1:0712/111311.211514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 669
[1:1:0712/111311.211648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 669 0x7fa7b750d070 0x258ab6857160 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 656 0x7fa7b750d070 0x258ab66b06e0 
[1:1:0712/111311.228178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111311.228366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111311.228578:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 670
[1:1:0712/111311.228764:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 670 0x7fa7b750d070 0x258ab688a660 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 656 0x7fa7b750d070 0x258ab66b06e0 
[1:1:0712/111311.248589:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 653, 7fa7b9e528db
[1:1:0712/111311.257772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"639 0x7fa7b750d070 0x258ab36d7d60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.257963:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"639 0x7fa7b750d070 0x258ab36d7d60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.258206:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 676
[1:1:0712/111311.258326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fa7b750d070 0x258ab62f6060 , 5:3_https://kdp.amazon.com/, 0, , 653 0x7fa7b750d070 0x258ab2a80d60 
[1:1:0712/111311.258479:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.258759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.258878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.271821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 655, 7fa7b9e528db
[1:1:0712/111311.281219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"625 0x7fa7b750d070 0x258ab62ee8e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.281418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"625 0x7fa7b750d070 0x258ab62ee8e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.281659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 678
[1:1:0712/111311.281760:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7fa7b750d070 0x258ab5ce1460 , 5:3_https://kdp.amazon.com/, 0, , 655 0x7fa7b750d070 0x258ab2a5bae0 
[1:1:0712/111311.281886:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.282167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0712/111311.282291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.304058:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 662, 7fa7b9e52881
[1:1:0712/111311.313665:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"646 0x7fa7c681e960 0x258ab66a5560 0x258ab66a5570 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.313862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"646 0x7fa7c681e960 0x258ab66a5560 0x258ab66a5570 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.314077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.314355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111311.314468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.332265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){J.splice(0).forEach(function(a){q(a,{clog:1})})}
[1:1:0712/111311.332430:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.357819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 667, 7fa7b9e52881
[1:1:0712/111311.365612:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"656 0x7fa7b750d070 0x258ab66b06e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.365814:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"656 0x7fa7b750d070 0x258ab66b06e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.366056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.366396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111311.366481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.366741:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111311.366814:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111311.366955:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 685
[1:1:0712/111311.367038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7fa7b750d070 0x258ab688a8e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 667 0x7fa7b750d070 0x258ab63a3d60 
[1:1:0712/111311.368259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 630, 7fa7b9e52881
[1:1:0712/111311.376685:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"604 0x7fa7c681e960 0x258ab63cd6a0 0x258ab63cd6b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.376808:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"604 0x7fa7c681e960 0x258ab63cd6a0 0x258ab63cd6b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.376963:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.377152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111311.377245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.377788:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 594, 7fa7b9e52881
[1:1:0712/111311.386208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"477 0x7fa7b750d070 0x258ab36a66e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.386336:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"477 0x7fa7b750d070 0x258ab36a66e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.386511:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.386740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0712/111311.386834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.393647:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111311.393744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111311.393897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 687
[1:1:0712/111311.393996:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 687 0x7fa7b750d070 0x258ab62f67e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 594 0x7fa7b750d070 0x258ab29743e0 
[1:1:0712/111311.412093:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 676, 7fa7b9e528db
[1:1:0712/111311.421233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"653 0x7fa7b750d070 0x258ab2a80d60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.421381:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"653 0x7fa7b750d070 0x258ab2a80d60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.421590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 689
[1:1:0712/111311.421703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7fa7b750d070 0x258ab68be6e0 , 5:3_https://kdp.amazon.com/, 0, , 676 0x7fa7b750d070 0x258ab62f6060 
[1:1:0712/111311.421855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.422123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.422235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.441854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , n, (){var a={w:p.width,aw:p.availWidth,h:p.height,ah:p.availHeight,cd:p.colorDepth,pd:p.pixelDepth},b={
[1:1:0712/111311.442010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.442464:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111311.442571:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0712/111311.442754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 691
[1:1:0712/111311.442894:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 691 0x7fa7b750d070 0x258ab66901e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 686 0x7fa7c681e960 0x258ab62526a0 0x258ab62526b0 
[1:1:0712/111311.475514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 689, 7fa7b9e528db
[1:1:0712/111311.484972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"676 0x7fa7b750d070 0x258ab62f6060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.485223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"676 0x7fa7b750d070 0x258ab62f6060 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.485459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 697
[1:1:0712/111311.485581:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 697 0x7fa7b750d070 0x258ab647e3e0 , 5:3_https://kdp.amazon.com/, 0, , 689 0x7fa7b750d070 0x258ab68be6e0 
[1:1:0712/111311.485739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.486021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.486135:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.488304:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 678, 7fa7b9e528db
[1:1:0712/111311.497870:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"655 0x7fa7b750d070 0x258ab2a5bae0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.498056:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"655 0x7fa7b750d070 0x258ab2a5bae0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.498310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 698
[1:1:0712/111311.498430:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 698 0x7fa7b750d070 0x258ab29738e0 , 5:3_https://kdp.amazon.com/, 0, , 678 0x7fa7b750d070 0x258ab5ce1460 
[1:1:0712/111311.498579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.498876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0712/111311.498992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.566525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 697, 7fa7b9e528db
[1:1:0712/111311.575002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"689 0x7fa7b750d070 0x258ab68be6e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.575145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"689 0x7fa7b750d070 0x258ab68be6e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.575354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 707
[1:1:0712/111311.575469:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 707 0x7fa7b750d070 0x258ab294ce60 , 5:3_https://kdp.amazon.com/, 0, , 697 0x7fa7b750d070 0x258ab647e3e0 
[1:1:0712/111311.575624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.575886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.575983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.664386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 707, 7fa7b9e528db
[1:1:0712/111311.674928:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"697 0x7fa7b750d070 0x258ab647e3e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.675148:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"697 0x7fa7b750d070 0x258ab647e3e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.675363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 721
[1:1:0712/111311.675460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 721 0x7fa7b750d070 0x258ab388ee60 , 5:3_https://kdp.amazon.com/, 0, , 707 0x7fa7b750d070 0x258ab294ce60 
[1:1:0712/111311.675594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.675841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.675923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.678141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 698, 7fa7b9e528db
[1:1:0712/111311.688690:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"678 0x7fa7b750d070 0x258ab5ce1460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.688882:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"678 0x7fa7b750d070 0x258ab5ce1460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.689135:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 722
[1:1:0712/111311.689262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7fa7b750d070 0x258ab386b0e0 , 5:3_https://kdp.amazon.com/, 0, , 698 0x7fa7b750d070 0x258ab29738e0 
[1:1:0712/111311.689421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.689707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.zoom.handler, (){p(e.ZOOM);var a=w.zoom,b=c.diff(l,a.lastViewport);b.zoom&&(a.lastViewport=c.copy(l),d.trigger(e.Z
[1:1:0712/111311.689832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.843036:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 721, 7fa7b9e528db
[1:1:0712/111311.851548:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"707 0x7fa7b750d070 0x258ab294ce60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.851684:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"707 0x7fa7b750d070 0x258ab294ce60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111311.851884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 740
[1:1:0712/111311.852007:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7fa7b750d070 0x258ab674f860 , 5:3_https://kdp.amazon.com/, 0, , 721 0x7fa7b750d070 0x258ab388ee60 
[1:1:0712/111311.852149:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.852415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111311.852529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111311.874807:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 737 0x7fa7b94352e0 0x258ab6394460 , "https://kdp.amazon.com/en_US/"
[1:1:0712/111311.893890:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , /*
 Copyright (c) 2013 Amazon.com, Inc.  All rights reserved.

 @see "http://z-ecx.images-amazon.com
[1:1:0712/111311.894064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111312.240055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9140
[1:1:0712/111312.240224:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111312.240410:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 743
[1:1:0712/111312.240515:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 743 0x7fa7b750d070 0x258ab5cdbe60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 737 0x7fa7b94352e0 0x258ab6394460 
[1:1:0712/111312.303194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 691, 7fa7b9e52881
[1:1:0712/111312.311700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"686 0x7fa7c681e960 0x258ab62526a0 0x258ab62526b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.311843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"686 0x7fa7c681e960 0x258ab62526a0 0x258ab62526b0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.312037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111312.312305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111312.312420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111312.313001:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 740, 7fa7b9e528db
[1:1:0712/111312.322241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"721 0x7fa7b750d070 0x258ab388ee60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.322378:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"721 0x7fa7b750d070 0x258ab388ee60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.322583:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 754
[1:1:0712/111312.322697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7fa7b750d070 0x258ab2972ae0 , 5:3_https://kdp.amazon.com/, 0, , 740 0x7fa7b750d070 0x258ab674f860 
[1:1:0712/111312.322845:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111312.323092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , w.resize.handler, (){var a=[],b=w.resize;p("resize");var g=c.diff(l,b.lastViewport);g.orientation&&a.push(e.ORIENTATIO
[1:1:0712/111312.323202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111312.325576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 668, 7fa7b9e528db
[1:1:0712/111312.336627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"656 0x7fa7b750d070 0x258ab66b06e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.336835:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"656 0x7fa7b750d070 0x258ab66b06e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.337085:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 755
[1:1:0712/111312.337209:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7fa7b750d070 0x258ab2b8ce60 , 5:3_https://kdp.amazon.com/, 0, , 668 0x7fa7b750d070 0x258ab2955be0 
[1:1:0712/111312.337369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111312.337644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , flush, (e){var c=!1,h=!0;a.each(l.Log.params,function(b,a){c=c||b.length>=l.appConfig.loggingThreshold[a];h
[1:1:0712/111312.337742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111312.340215:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 743, 7fa7b9e52881
[1:1:0712/111312.350830:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"737 0x7fa7b94352e0 0x258ab6394460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.351017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"737 0x7fa7b94352e0 0x258ab6394460 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111312.351230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111312.351525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111312.351659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111312.351953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111312.352047:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111312.352210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 757
[1:1:0712/111312.352328:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7fa7b750d070 0x258ab6ceb960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 743 0x7fa7b750d070 0x258ab5cdbe60 
[1:1:0712/111312.584048:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111312.584222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 30000
[1:1:0712/111312.584419:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 759
[1:1:0712/111312.584545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7fa7b750d070 0x258ab68e86e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 743 0x7fa7b750d070 0x258ab5cdbe60 
[1:1:0712/111313.905641:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x258ab28b3820
[1:1:0712/111313.905812:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/111313.924988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111313.925159:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111313.925350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 769
[1:1:0712/111313.925463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 769 0x7fa7b750d070 0x258ab7f546e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 743 0x7fa7b750d070 0x258ab5cdbe60 
[1:1:0712/111313.936417:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x796aee029c8, 0x258ab24c92f0
[1:1:0712/111313.936588:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 50
[1:1:0712/111313.936781:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 770
[1:1:0712/111313.936904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 770 0x7fa7b750d070 0x258ab7cb6860 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 743 0x7fa7b750d070 0x258ab5cdbe60 
[1:1:0712/111313.980970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , n, (){var a={w:p.width,aw:p.availWidth,h:p.height,ah:p.availHeight,cd:p.colorDepth,pd:p.pixelDepth},b={
[1:1:0712/111313.981204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111313.988140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x796aee029c8, 0x258ab24c9168
[1:1:0712/111313.988334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0712/111313.988547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 789
[1:1:0712/111313.988685:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7fa7b750d070 0x258ab7f52de0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 753 0x7fa7c681e960 0x258ab637e6a0 0x258ab637e6b0 
[1:1:0712/111314.077114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 757, 7fa7b9e52881
[1:1:0712/111314.088630:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"743 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.088845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"743 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.089071:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111314.089535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , U, (){for(var a=I(),b=F();J.length;)if(J.shift()(),50<F()-b)return;
clearTimeout(a);K=!1}
[1:1:0712/111314.089671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111314.090066:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111314.090150:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111314.090393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 796
[1:1:0712/111314.090484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7fa7b750d070 0x258ab78bf1e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 757 0x7fa7b750d070 0x258ab6ceb960 
[1:1:0712/111314.091167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 687, 7fa7b9e52881
[1:1:0712/111314.104540:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"594 0x7fa7b750d070 0x258ab29743e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.104734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"594 0x7fa7b750d070 0x258ab29743e0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.105001:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111314.105299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , s, (){var a;a=d.location&&d.location.protocol?d.location.protocol:void 0;"https:"==a&&(A(),x(),y(),z(),
[1:1:0712/111314.105420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111314.114486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111314.114647:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 1000
[1:1:0712/111314.114844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 798
[1:1:0712/111314.114971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 798 0x7fa7b750d070 0x258ab7f51c60 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 687 0x7fa7b750d070 0x258ab62f67e0 
[1:1:0712/111314.115508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 755, 7fa7b9e528db
[1:1:0712/111314.127622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"668 0x7fa7b750d070 0x258ab2955be0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.127812:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"668 0x7fa7b750d070 0x258ab2955be0 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.128059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://kdp.amazon.com/, 799
[1:1:0712/111314.128184:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7fa7b750d070 0x258ab7fe4460 , 5:3_https://kdp.amazon.com/, 0, , 755 0x7fa7b750d070 0x258ab2b8ce60 
[1:1:0712/111314.128339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111314.128618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , flush, (e){var c=!1,h=!0;a.each(l.Log.params,function(b,a){c=c||b.length>=l.appConfig.loggingThreshold[a];h
[1:1:0712/111314.128726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111314.154596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 769, 7fa7b9e52881
[1:1:0712/111314.165337:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"743 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.165499:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"743 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.165698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111314.165975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){a.apply(c,f)}
[1:1:0712/111314.166095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
[1:1:0712/111314.277377:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111314.277592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 500
[1:1:0712/111314.277835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 806
[1:1:0712/111314.278009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 806 0x7fa7b750d070 0x258ab80f62e0 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 769 0x7fa7b750d070 0x258ab7f546e0 
[1:1:0712/111314.278658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x796aee029c8, 0x258ab24c9150
[1:1:0712/111314.278811:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://kdp.amazon.com/en_US/", 0
[1:1:0712/111314.279018:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 807
[1:1:0712/111314.279140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 807 0x7fa7b750d070 0x258ab5ce5960 , 5:3_https://kdp.amazon.com/, 1, -5:3_https://kdp.amazon.com/, 769 0x7fa7b750d070 0x258ab7f546e0 
[1:1:0712/111314.494784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://kdp.amazon.com/, 770, 7fa7b9e52881
[1:1:0712/111314.504999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"28c0ae302860","ptid":"743 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.505188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://kdp.amazon.com/","ptid":"743 0x7fa7b750d070 0x258ab5cdbe60 ","rf":"5:3_https://kdp.amazon.com/"}
[1:1:0712/111314.505524:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://kdp.amazon.com/en_US/"
[1:1:0712/111314.505881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kdp.amazon.com/, 28c0ae302860, , , (){z(b)}
[1:1:0712/111314.506045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kdp.amazon.com/en_US/", "kdp.amazon.com", 3, 1, , , 0
