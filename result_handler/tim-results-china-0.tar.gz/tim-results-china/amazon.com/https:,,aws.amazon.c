[0712/111114.223465:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111114.223757:INFO:switcher_clone.cc(787)] backtrace rip is 7f020b9bc891
[0712/111114.803343:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111114.803624:INFO:switcher_clone.cc(787)] backtrace rip is 7f8db6c6d891
[1:1:0712/111114.807685:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111114.807863:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111114.810909:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[1048:1048:0712/111115.687972:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/111115.727878:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111115.728119:INFO:switcher_clone.cc(787)] backtrace rip is 7f671f586891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7efd33a6-bf81-434c-88b9-2b3a0792e57d
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1084:1084:0712/111115.934815:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1084
[1096:1096:0712/111115.940340:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1096
[1048:1048:0712/111115.964791:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[1048:1082:0712/111115.965204:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111115.965350:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111115.965527:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111115.965860:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111115.966014:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111115.967663:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e2bf054, 1
[1:1:0712/111115.967843:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1c68cd59, 0
[1:1:0712/111115.967920:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3752454e, 3
[1:1:0712/111115.968006:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2b5a004c, 2
[1:1:0712/111115.968104:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 59ffffffcd681c 54fffffff02b2e 4c005a2b 4e455237 , 10104, 4
[1:1:0712/111115.968823:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1048:1082:0712/111115.968941:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGY�hT�+.L
[1048:1082:0712/111115.968979:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Y�hT�+.L
[1:1:0712/111115.968939:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8db4ea70a0, 3
[1:1:0712/111115.969131:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8db5033080, 2
[1:1:0712/111115.969219:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8d9ecf5d20, -2
[1048:1082:0712/111115.977196:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1048:1082:0712/111115.977235:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1104, 4, 59cd681c 54f02b2e 4c005a2b 4e455237 
[1:1:0712/111115.984665:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111115.985110:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b5a004c
[1:1:0712/111115.985558:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b5a004c
[1:1:0712/111115.986306:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b5a004c
[1:1:0712/111115.986883:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.987018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.987147:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.987245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.987519:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b5a004c
[1:1:0712/111115.987698:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8db6c6d7ba
[1:1:0712/111115.987777:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8db6c64def, 7f8db6c6d77a, 7f8db6c6f0cf
[1:1:0712/111115.989491:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2b5a004c
[1:1:0712/111115.989677:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2b5a004c
[1:1:0712/111115.989996:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2b5a004c
[1:1:0712/111115.990887:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.991009:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.991111:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.991211:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2b5a004c
[1:1:0712/111115.991705:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2b5a004c
[1:1:0712/111115.991887:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8db6c6d7ba
[1:1:0712/111115.991992:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8db6c64def, 7f8db6c6d77a, 7f8db6c6f0cf
[1:1:0712/111115.994619:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111115.994798:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111115.994896:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe532629f8, 0x7ffe53262978)
[1:1:0712/111116.001900:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111116.004544:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1048:1048:0712/111116.483264:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1048:1048:0712/111116.483781:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1048:1060:0712/111116.490294:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[1048:1060:0712/111116.490357:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1048:1048:0712/111116.490401:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[1048:1048:0712/111116.490445:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[1048:1048:0712/111116.490512:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,1104, 4
[1:7:0712/111116.497890:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111116.546097:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1335a16ff220
[1:1:0712/111116.546245:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1048:1073:0712/111116.569315:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111116.727413:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/111117.573293:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111117.574927:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1048:1048:0712/111117.678666:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1048:1048:0712/111117.678734:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111118.040112:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111118.126773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111118.126940:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111118.132127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111118.132252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111118.166517:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111118.166660:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111118.339304:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111118.341948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111118.342093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111118.355039:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111118.358110:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111118.358242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111118.362084:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1048:1048:0712/111118.362762:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111118.363811:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1335a16fde20
[1:1:0712/111118.363912:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1048:1048:0712/111118.366304:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1048:1048:0712/111118.377091:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[1048:1048:0712/111118.377175:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111118.400077:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111118.768760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f8da08d02e0 0x1335a1943f60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111118.769450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/111118.769591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111118.770154:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1048:1048:0712/111118.796589:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111118.797658:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1335a16fe820
[1:1:0712/111118.797820:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1048:1048:0712/111118.801636:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111118.804721:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111118.804891:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[1048:1048:0712/111118.806991:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[1048:1048:0712/111118.815925:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1048:1048:0712/111118.817004:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1048:1048:0712/111118.822163:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[1048:1048:0712/111118.822218:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[1048:1048:0712/111118.822283:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,1104, 4
[1048:1060:0712/111118.822814:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[1048:1060:0712/111118.822858:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111118.823721:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111119.136420:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1048:1048:0712/111119.177737:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[1048:1082:0712/111119.179179:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111119.179337:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111119.179492:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111119.179726:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111119.179807:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111119.183357:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x680136a, 1
[1:1:0712/111119.183666:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15f01e79, 0
[1:1:0712/111119.183773:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xc3b35f2, 3
[1:1:0712/111119.183856:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x238dfde7, 2
[1:1:0712/111119.183933:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 791efffffff015 6a13ffffff8006 ffffffe7fffffffdffffff8d23 fffffff2353b0c , 10104, 5
[1:1:0712/111119.184674:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1048:1082:0712/111119.184881:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGy�j����#�5;��
[1048:1082:0712/111119.184924:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is y�j����#�5;X��
[1:1:0712/111119.184873:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8db4ea70a0, 3
[1:1:0712/111119.184964:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8db5033080, 2
[1048:1082:0712/111119.185074:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1146, 5, 791ef015 6a138006 e7fd8d23 f2353b0c 
[1:1:0712/111119.185074:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f8d9ecf5d20, -2
[1:1:0712/111119.197022:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111119.197233:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 238dfde7
[1:1:0712/111119.197395:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 238dfde7
[1:1:0712/111119.197647:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 238dfde7
[1:1:0712/111119.198144:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.198240:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.198331:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.198418:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.198665:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 238dfde7
[1:1:0712/111119.198789:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8db6c6d7ba
[1:1:0712/111119.198861:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8db6c64def, 7f8db6c6d77a, 7f8db6c6f0cf
[1:1:0712/111119.200579:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 238dfde7
[1:1:0712/111119.200795:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 238dfde7
[1:1:0712/111119.201123:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 238dfde7
[1:1:0712/111119.201902:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.202027:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.202141:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.202253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 238dfde7
[1:1:0712/111119.202755:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 238dfde7
[1:1:0712/111119.202935:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f8db6c6d7ba
[1:1:0712/111119.203016:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f8db6c64def, 7f8db6c6d77a, 7f8db6c6f0cf
[1:1:0712/111119.205534:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111119.205801:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111119.205910:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe532629f8, 0x7ffe53262978)
[1:1:0712/111119.211899:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111119.214158:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111119.318780:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1335a16bc220
[1:1:0712/111119.319471:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111119.397017:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f8da08d02e0 0x1335a1ad5960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111119.397589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111119.397689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111119.398048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1048:1048:0712/111119.459037:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[1048:1048:0712/111119.459107:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111119.470673:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111119.682322:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111119.946647:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111119.946845:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111120.096597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 556, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111120.098335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111120.098546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111120.101020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111120.202835:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111120.203252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 33c6d6801f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111120.203375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111120.304964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111120.305799:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111120.305942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111120.306115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111120.371124:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111120.371673:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111120.371810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111120.371965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111120.544464:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/111120.692905:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/111120.742209:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/111120.862197:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/111120.887932:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/111120.928926:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1048:1048:0712/111120.981088:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1048:1048:0712/111120.984050:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/111120.992107:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1048:1060:0712/111120.998919:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[1048:1060:0712/111120.998997:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1048:1048:0712/111120.999135:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://aws.amazon.com/
[1048:1048:0712/111120.999186:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://aws.amazon.com/, https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter, 1
[1048:1048:0712/111120.999248:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://aws.amazon.com/, HTTP/1.1 200 status:200 content-type:text/html;charset=UTF-8 server:Server date:Fri, 12 Jul 2019 03:11:20 GMT x-frame-options:SAMEORIGIN x-content-type-options:nosniff x-amz-id-1:NETRPZR5H6TQZRXR00F8 last-modified:Tue, 09 Jul 2019 06:33:16 GMT cache-control:no-store, no-cache, must-revalidate content-encoding:gzip vary:accept-encoding,X-Amzn-CDN-Cache,X-Amzn-AX-Treatment,User-Agent set-cookie:aws-priv=eyJ2IjoxLCJldSI6MCwic3QiOjB9; Version=1; Comment="Anonymous cookie for privacy regulations"; Domain=.amazon.com; Max-Age=94672800; Expires=Mon, 11-Jul-2022 21:11:20 GMT; Path=/ set-cookie:aws-csds-token=75df4d96-4b49-4492-9de8-f6326f95f701; Version=1; Comment="Anonymous metrics validation token"; Max-Age=900; Expires=Fri, 12-Jul-2019 03:26:20 GMT; Path=/ set-cookie:aws_lang=en; Domain=.amazon.com; Path=/ x-amz-rid:NETRPZR5H6TQZRXR00F8 x-cache:Miss from cloudfront via:1.1 0afae887d1f4306bda4c7ef1dea46b9b.cloudfront.net (CloudFront) x-amz-cf-pop:SIN52-C2 x-amz-cf-id:3XdQ2LVWDgr12QkHbcR0HdedFRXyr58BLNXJyS5BjjmKp1prFth9lg==  ,1146, 5
[1:7:0712/111121.000606:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111121.016663:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://aws.amazon.com/
[1:1:0712/111121.044304:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1048:1048:0712/111121.070453:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://aws.amazon.com/, https://aws.amazon.com/, 1
[1048:1048:0712/111121.070570:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://aws.amazon.com/, https://aws.amazon.com
[1:1:0712/111121.070476:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.070887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.071008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.084333:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111121.104513:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.104947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.105098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.108650:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111121.130324:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111121.145559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.152552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.152690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.156994:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111121.157179:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111121.190377:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.193474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.193632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.218037:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.218495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.218668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.252312:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.252772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.252897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.275381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.275808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.275943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.318412:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.322398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.322528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.356840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.357329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.357588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.382183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.385526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.385664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.425668:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.426152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.426269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.447623:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.448066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.448209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.478413:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.478805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.478946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.527307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.527724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.527871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.632726:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.633258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111121.633390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111121.666977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111121.667462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 33c6d69309f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111121.667615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111122.197453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 206 0x7f8d9e9a8070 0x1335a18947e0 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111122.198421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , 
  var AWS = {
    PageSettings: {
      supportedLanguages: ['ar', 'en', 'es', 'de', 'fr', 'id', 'i
[1:1:0712/111122.198535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111122.199142:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111122.207874:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111122.258346:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7f8d9ed10bd0 0x1335a17e8ad8 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111122.262515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , /*6b61447d852966a68d491394f7dccddd*/(function(win){"use strict";var listeners=[];var doc=win.documen
[1:1:0712/111122.262672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111122.414351:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497160
[1:1:0712/111122.423116:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111122.423352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 221
[1:1:0712/111122.423458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 221 0x7f8d9e9a8070 0x1335a17e6a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 216 0x7f8d9ed10bd0 0x1335a17e8ad8 
		remove user.d_26f79367 -> 0
		remove user.e_d880f6d1 -> 0
[1:1:0712/111122.431102:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497160
[1:1:0712/111122.431239:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111122.431457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 222
[1:1:0712/111122.431567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 222 0x7f8d9e9a8070 0x1335a18a3060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 216 0x7f8d9ed10bd0 0x1335a17e8ad8 
[1:1:0712/111122.530282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497160
[1:1:0712/111122.530494:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111122.530718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 224
[1:1:0712/111122.530830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 224 0x7f8d9e9a8070 0x1335a18a1c60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 216 0x7f8d9ed10bd0 0x1335a17e8ad8 
[1:1:0712/111122.534605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7f8d9ed10bd0 0x1335a17e8ad8 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111122.588167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x3634538629c8, 0x1335a1497260
[1:1:0712/111122.588364:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 30
[1:1:0712/111122.588603:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 228
[1:1:0712/111122.588710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 228 0x7f8d9e9a8070 0x1335a18a05e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 216 0x7f8d9ed10bd0 0x1335a17e8ad8 
[1:1:0712/111122.697321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7f8d9ed10bd0 0x1335a17e8ad8 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111122.700686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 216 0x7f8d9ed10bd0 0x1335a17e8ad8 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111122.816542:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a14971a8
[1:1:0712/111122.816748:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111122.816988:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 262
[1:1:0712/111122.817158:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 262 0x7f8d9e9a8070 0x1335a18952e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 216 0x7f8d9ed10bd0 0x1335a17e8ad8 
[1:1:0712/111122.860673:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.328685, 219, 1
[1:1:0712/111122.860819:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111123.637534:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111123.637733:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111123.638465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/111123.638618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111123.799290:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.161467, 1830, 1
[1:1:0712/111123.799496:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111124.374371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 20
[1:1:0712/111124.374729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 414
[1:1:0712/111124.374854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7f8d9e9a8070 0x1335a1f64660 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 308 0x7f8d9e9a8070 0x1335a1b53d60 
[1:1:0712/111124.375138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x3634538629c8, 0x1335a1fa3b00
[1:1:0712/111124.375247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 10000
[1:1:0712/111124.375488:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 415
[1:1:0712/111124.375608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 415 0x7f8d9e9a8070 0x1335a1b53de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 308 0x7f8d9e9a8070 0x1335a1b53d60 
[1:1:0712/111124.477116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 221, 7f8da12ed881
[1:1:0712/111124.483709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111124.483897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111124.484121:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111124.484449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111124.484545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111124.490747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 222, 7f8da12ed881
[1:1:0712/111124.497544:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111124.497736:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111124.497960:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111124.498314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111124.498434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111124.503004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 224, 7f8da12ed881
[1:1:0712/111124.510160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111124.511065:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111124.511294:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111124.511625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111124.511726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111124.711375:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/111128.597021:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/111128.726456:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.726639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111128.726882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 450
[1:1:0712/111128.726990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f8d9e9a8070 0x1335a1757f60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 224 0x7f8d9e9a8070 0x1335a18a1c60 
[1:1:0712/111128.730812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.731007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111128.738323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 451
[1:1:0712/111128.738460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 451 0x7f8d9e9a8070 0x1335a1ffa860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 224 0x7f8d9e9a8070 0x1335a18a1c60 
[1:1:0712/111128.740712:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.741195:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111128.741634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 452
[1:1:0712/111128.741780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 452 0x7f8d9e9a8070 0x1335a186c560 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 224 0x7f8d9e9a8070 0x1335a18a1c60 
[1:1:0712/111128.742762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.742889:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111128.743105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 453
[1:1:0712/111128.743213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 453 0x7f8d9e9a8070 0x1335a20921e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 224 0x7f8d9e9a8070 0x1335a18a1c60 
[1:1:0712/111128.763113:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 228, 7f8da12ed881
[1:1:0712/111128.772225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111128.772420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111128.772634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111128.773005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , AppMeasurement.a.Qa, (){a.b=a.d.body;a.b?(a.v=function(c){var b,d,f,e,g;if(!(a.d&&a.d.getElementById("cppXYctnr")||c&&c["
[1:1:0712/111128.773133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111128.774581:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 262, 7f8da12ed881
[1:1:0712/111128.781987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111128.782158:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"216 0x7f8d9ed10bd0 0x1335a17e8ad8 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111128.782391:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111128.782710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){loop(pollGroup)}
[1:1:0712/111128.782820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111128.800999:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.801176:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111128.801393:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 462
[1:1:0712/111128.801498:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 462 0x7f8d9e9a8070 0x1335a1b64560 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 262 0x7f8d9e9a8070 0x1335a18952e0 
[1:1:0712/111128.865658:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.865812:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111128.866067:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 464
[1:1:0712/111128.866206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 464 0x7f8d9e9a8070 0x1335a1b62060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 262 0x7f8d9e9a8070 0x1335a18952e0 
[1:1:0712/111128.907179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111128.907345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111128.907591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 466
[1:1:0712/111128.907712:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7f8d9e9a8070 0x1335a18a5fe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 262 0x7f8d9e9a8070 0x1335a18952e0 
[1:1:0712/111129.794860:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111129.795030:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111129.795680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/111129.795801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111129.800945:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 404 0x7f8d9e9a8070 0x1335a1f6b0e0 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111130.391167:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111131.947924:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 2.15311, 0, 0
[1:1:0712/111131.948416:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111132.087662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 414, 7f8da12ed8db
[1:1:0712/111132.094746:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"308 0x7f8d9e9a8070 0x1335a1b53d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.094892:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"308 0x7f8d9e9a8070 0x1335a1b53d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.095101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 573
[1:1:0712/111132.095226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f8d9e9a8070 0x1335a1740a60 , 5:3_https://aws.amazon.com/, 0, , 414 0x7f8d9e9a8070 0x1335a1f64660 
[1:1:0712/111132.095385:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.095717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){var watchedHeaderHeight=Math.floor(document.getElementsByClassName("m-page-header")[0].offsetHeig
[1:1:0712/111132.095852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.248106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111132.248313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.560138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 450, 7f8da12ed881
[1:1:0712/111132.569550:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.569742:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.569950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.570272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=foresterUrl}
[1:1:0712/111132.570385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.583255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 451, 7f8da12ed881
[1:1:0712/111132.591268:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.591428:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.591646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.592347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=csdsUrl}
[1:1:0712/111132.592456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.604554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 452, 7f8da12ed881
[1:1:0712/111132.612185:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.612322:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.612517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.612836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111132.612930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.627401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111132.627563:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111132.627825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 582
[1:1:0712/111132.627944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7f8d9e9a8070 0x1335a1fe40e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 452 0x7f8d9e9a8070 0x1335a186c560 
[1:1:0712/111132.630308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 453, 7f8da12ed881
[1:1:0712/111132.639386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.639579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"224 0x7f8d9e9a8070 0x1335a18a1c60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.639791:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.640115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111132.640216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.687661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 462, 7f8da12ed881
[1:1:0712/111132.697499:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"262 0x7f8d9e9a8070 0x1335a18952e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.697730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"262 0x7f8d9e9a8070 0x1335a18952e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.697993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.698460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111132.698626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.701598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 464, 7f8da12ed881
[1:1:0712/111132.711433:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"262 0x7f8d9e9a8070 0x1335a18952e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.711638:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"262 0x7f8d9e9a8070 0x1335a18952e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.711865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.712202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111132.712318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.784303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 466, 7f8da12ed881
[1:1:0712/111132.793553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"262 0x7f8d9e9a8070 0x1335a18952e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.793731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"262 0x7f8d9e9a8070 0x1335a18952e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111132.793931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111132.794237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){loop(pollGroup)}
[1:1:0712/111132.794337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111132.795586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111132.795682:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111132.795874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 589
[1:1:0712/111132.795965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 589 0x7f8d9e9a8070 0x1335a1fba660 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 466 0x7f8d9e9a8070 0x1335a18a5fe0 
[1:1:0712/111133.192179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111133.193318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/111133.193448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111133.203988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497518
[1:1:0712/111133.204145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111133.204365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 602
[1:1:0712/111133.204462:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7f8d9e9a8070 0x1335a16caee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 508
[1:1:0712/111133.209505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497518
[1:1:0712/111133.209693:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111133.209977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 603
[1:1:0712/111133.210076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 603 0x7f8d9e9a8070 0x1335a1b58760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 508
[1:1:0712/111133.219709:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3634538629c8, 0x1335a1497518
[1:1:0712/111133.219894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 200
[1:1:0712/111133.220100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 604
[1:1:0712/111133.220195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7f8d9e9a8070 0x1335a17f01e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 508
[1:1:0712/111133.242234:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111133.242690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/111133.242798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111133.250394:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111133.250544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111133.250748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 609
[1:1:0712/111133.250841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f8d9e9a8070 0x1335a1444ce0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 509
[1:1:0712/111133.254839:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111133.254932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111133.255120:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 610
[1:1:0712/111133.255232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f8d9e9a8070 0x1335a1fd77e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 509
[1:1:0712/111133.266356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111133.266512:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111133.266737:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 614
[1:1:0712/111133.266859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 614 0x7f8d9e9a8070 0x1335a2092160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 509
[1:1:0712/111134.406763:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 558 0x7f8da08d02e0 0x1335a18b0260 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.408313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , !function(){var librastandardlib_event_utils_onWindowLoad,librastandardlib_event_utils_onDOMContentL
[1:1:0712/111134.408471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111134.479118:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111134.479298:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.480194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , checkDOMforElem, (){var len=listeners.length;var listener;var elems;var elem;for(var i=0;i<len;i++){listener=listener
[1:1:0712/111134.480332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111134.481780:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f8d9e9a8070 0x1335a1877d60 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.710677:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3634538629c8, 0x1335a1497198
[1:1:0712/111134.710905:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 5000
[1:1:0712/111134.711236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 670
[1:1:0712/111134.711384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 670 0x7f8d9e9a8070 0x1335a4380be0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 565 0x7f8d9e9a8070 0x1335a1877d60 
[1:1:0712/111134.715728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f8d9e9a8070 0x1335a1877d60 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.718897:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f8d9e9a8070 0x1335a1877d60 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.720543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.722310:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.722736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.723059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.723360:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.724307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.726441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111134.726561:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111134.726767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 678
[1:1:0712/111134.726875:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f8d9e9a8070 0x1335a4383b60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 565 0x7f8d9e9a8070 0x1335a1877d60 
[1:1:0712/111134.727245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111134.727337:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111134.727525:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 679
[1:1:0712/111134.727634:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f8d9e9a8070 0x1335a1fde160 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 565 0x7f8d9e9a8070 0x1335a1877d60 
[1:1:0712/111134.727942:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111134.728036:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111134.728224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 680
[1:1:0712/111134.728341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f8d9e9a8070 0x1335a1fbb860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 565 0x7f8d9e9a8070 0x1335a1877d60 
[1:1:0712/111134.728656:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111134.728746:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111134.728942:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 681
[1:1:0712/111134.729051:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7f8d9e9a8070 0x1335a1fe63e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 565 0x7f8d9e9a8070 0x1335a1877d60 
[1:1:0712/111134.729228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.865447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.870491:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.871677:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.984767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 573, 7f8da12ed8db
[1:1:0712/111134.995812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"414 0x7f8d9e9a8070 0x1335a1f64660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111134.996049:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"414 0x7f8d9e9a8070 0x1335a1f64660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111134.996394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://aws.amazon.com/, 702
[1:1:0712/111134.996525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f8d9e9a8070 0x1335a44afc60 , 5:3_https://aws.amazon.com/, 0, , 573 0x7f8d9e9a8070 0x1335a1740a60 
[1:1:0712/111134.996691:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111134.997014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){var watchedHeaderHeight=Math.floor(document.getElementsByClassName("m-page-header")[0].offsetHeig
[1:1:0712/111134.997153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.010968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111135.011117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.188060:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 582, 7f8da12ed881
[1:1:0712/111135.199225:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"452 0x7f8d9e9a8070 0x1335a186c560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.199392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"452 0x7f8d9e9a8070 0x1335a186c560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.199602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.199927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111135.200034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.201548:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111135.201650:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111135.201912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 722
[1:1:0712/111135.202023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7f8d9e9a8070 0x1335a47654e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 582 0x7f8d9e9a8070 0x1335a1fe40e0 
[1:1:0712/111135.315744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 589, 7f8da12ed881
[1:1:0712/111135.327352:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"466 0x7f8d9e9a8070 0x1335a18a5fe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.327536:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"466 0x7f8d9e9a8070 0x1335a18a5fe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.327746:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.328063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){loop(pollGroup)}
[1:1:0712/111135.328161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.329781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111135.329899:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111135.330133:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 739
[1:1:0712/111135.330258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 739 0x7f8d9e9a8070 0x1335a156abe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 589 0x7f8d9e9a8070 0x1335a1fba660 
[1:1:0712/111135.444449:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 602, 7f8da12ed881
[1:1:0712/111135.454646:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"508","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.454840:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"508","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.455053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.455394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111135.455510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.457969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 603, 7f8da12ed881
[1:1:0712/111135.470829:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"508","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.471020:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"508","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.471247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.471553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111135.471641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.560520:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 609, 7f8da12ed881
[1:1:0712/111135.572652:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"509","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.572838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"509","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.573068:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.573398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111135.573522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.576139:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 610, 7f8da12ed881
[1:1:0712/111135.588805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"509","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.588977:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"509","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.589205:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.589547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111135.589691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.592367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 614, 7f8da12ed881
[1:1:0712/111135.605061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"509","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.605272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"509","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.605529:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.605924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111135.606029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.636549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 604, 7f8da12ed881
[1:1:0712/111135.648719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"508","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.648937:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"508","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.649190:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.649589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){if(id===count){that.logger.info("Saw new content event");that.processAspects();that.processEvents
[1:1:0712/111135.649749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111135.702525:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111135.702731:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111135.703030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 752
[1:1:0712/111135.703138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7f8d9e9a8070 0x1335a1b590e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 604 0x7f8d9e9a8070 0x1335a17f01e0 
[1:1:0712/111135.797666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111135.797816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111135.798041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 755
[1:1:0712/111135.798131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f8d9e9a8070 0x1335a1fd2560 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 604 0x7f8d9e9a8070 0x1335a17f01e0 
[1:1:0712/111135.902627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 415, 7f8da12ed881
[1:1:0712/111135.912972:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"308 0x7f8d9e9a8070 0x1335a1b53d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.913146:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"308 0x7f8d9e9a8070 0x1335a1b53d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111135.913325:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111135.913655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){clearInterval(watchHeader)}
[1:1:0712/111135.913768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111136.560695:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 678, 7f8da12ed881
[1:1:0712/111136.571459:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111136.571641:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111136.571901:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111136.572247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111136.572400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1048:1048:0712/111137.302934:INFO:CONSOLE(75)] "chrome.loadTimes() is deprecated, instead use standardized API: Paint Timing. https://www.chromestatus.com/features/5637885046816768.", source: https://a0.awsstatic.com/libra/1.0.284/libra-head.js (75)
[1:1:0712/111137.310936:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.311137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.311442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 784
[1:1:0712/111137.311565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 784 0x7f8d9e9a8070 0x1335a58e0ce0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 678 0x7f8d9e9a8070 0x1335a4383b60 
[1:1:0712/111137.314799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.314981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.315257:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 785
[1:1:0712/111137.315399:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 785 0x7f8d9e9a8070 0x1335a591fbe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 678 0x7f8d9e9a8070 0x1335a4383b60 
[1:1:0712/111137.316852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.316960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.317147:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 786
[1:1:0712/111137.317298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 786 0x7f8d9e9a8070 0x1335a4388a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 678 0x7f8d9e9a8070 0x1335a4383b60 
[1:1:0712/111137.321993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 679, 7f8da12ed881
[1:1:0712/111137.335330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.335505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.335726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111137.336058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111137.336177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111137.338109:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.338258:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.338478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 792
[1:1:0712/111137.338571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f8d9e9a8070 0x1335a4389b60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 679 0x7f8d9e9a8070 0x1335a1fde160 
[1:1:0712/111137.339167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 680, 7f8da12ed881
[1:1:0712/111137.352956:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.353169:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.353402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111137.353782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111137.353892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111137.354659:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.354765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111137.355070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 794
[1:1:0712/111137.355165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7f8d9e9a8070 0x1335a1fb3760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 680 0x7f8d9e9a8070 0x1335a1fbb860 
[1:1:0712/111137.357185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.357318:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.357727:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 795
[1:1:0712/111137.357862:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 795 0x7f8d9e9a8070 0x1335a4512de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 680 0x7f8d9e9a8070 0x1335a1fbb860 
[1:1:0712/111137.385859:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 681, 7f8da12ed881
[1:1:0712/111137.403197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.403535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.403816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111137.406154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111137.406291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111137.406769:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.406882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111137.407116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 799
[1:1:0712/111137.407251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7f8d9e9a8070 0x1335a438d7e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 681 0x7f8d9e9a8070 0x1335a1fe63e0 
[1:1:0712/111137.408798:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.408894:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.409140:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 800
[1:1:0712/111137.409265:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7f8d9e9a8070 0x1335a1fb92e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 681 0x7f8d9e9a8070 0x1335a1fe63e0 
[1:1:0712/111137.438057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111137.438497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/111137.438690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111137.445833:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111137.446009:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111137.446248:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 804
[1:1:0712/111137.446370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f8d9e9a8070 0x1335a44564e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 696
[1:1:0712/111137.457005:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111137.457179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 200
[1:1:0712/111137.457387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 806
[1:1:0712/111137.457509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 806 0x7f8d9e9a8070 0x1335a1b5ebe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 696
[1:1:0712/111137.567154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111137.567327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111137.975731:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 722, 7f8da12ed881
[1:1:0712/111137.988751:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"582 0x7f8d9e9a8070 0x1335a1fe40e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.988933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"582 0x7f8d9e9a8070 0x1335a1fe40e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111137.989170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111137.989477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111137.989572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111137.990808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111137.990898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111137.991083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 821
[1:1:0712/111137.991171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f8d9e9a8070 0x1335a1444860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 722 0x7f8d9e9a8070 0x1335a47654e0 
[1:1:0712/111138.177918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 737 0x7f8da08d02e0 0x1335a47639e0 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111138.179019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , /*
 * Copyright (c) 2007-2015, Marketo, Inc. All rights reserved.
 * Marketo marketing automation we
[1:1:0712/111138.179224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111138.180553:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111138.293869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){if(!docHead.classList.contains(fontClass)){localStorage.setItem(KEY,fontClass);docHead.classList.
[1:1:0712/111138.294106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111138.295728:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 739, 7f8da12ed881
[1:1:0712/111138.310300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"589 0x7f8d9e9a8070 0x1335a1fba660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.310525:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"589 0x7f8d9e9a8070 0x1335a1fba660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.310743:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111138.311320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){loop(pollGroup)}
[1:1:0712/111138.311451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111138.518596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 752, 7f8da12ed881
[1:1:0712/111138.531335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"604 0x7f8d9e9a8070 0x1335a17f01e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.531540:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"604 0x7f8d9e9a8070 0x1335a17f01e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.531818:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111138.532173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111138.532329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111138.532821:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111138.532922:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111138.533191:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 849
[1:1:0712/111138.533284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 849 0x7f8d9e9a8070 0x1335a1f6a960 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 752 0x7f8d9e9a8070 0x1335a1b590e0 
[1:1:0712/111138.534806:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111138.534906:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111138.535095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 850
[1:1:0712/111138.535182:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 850 0x7f8d9e9a8070 0x1335a541f660 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 752 0x7f8d9e9a8070 0x1335a1b590e0 
[1:1:0712/111138.535741:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 755, 7f8da12ed881
[1:1:0712/111138.550279:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"604 0x7f8d9e9a8070 0x1335a17f01e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.550477:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"604 0x7f8d9e9a8070 0x1335a17f01e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.550705:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111138.551999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111138.553239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111138.554771:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111138.554927:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111138.555178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 851
[1:1:0712/111138.555318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7f8d9e9a8070 0x1335a4381c60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 755 0x7f8d9e9a8070 0x1335a1fd2560 
[1:1:0712/111138.556718:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111138.556801:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111138.556972:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 852
[1:1:0712/111138.557088:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f8d9e9a8070 0x1335a5b51260 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 755 0x7f8d9e9a8070 0x1335a1fd2560 
[1:1:0712/111138.974964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 784, 7f8da12ed881
[1:1:0712/111138.987503:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"678 0x7f8d9e9a8070 0x1335a4383b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.987671:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"678 0x7f8d9e9a8070 0x1335a4383b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111138.987876:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111138.988200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=foresterUrl}
[1:1:0712/111138.988316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111139.005938:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 785, 7f8da12ed881
[1:1:0712/111139.021693:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"678 0x7f8d9e9a8070 0x1335a4383b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.021908:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"678 0x7f8d9e9a8070 0x1335a4383b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.022138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111139.022477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=csdsUrl}
[1:1:0712/111139.022614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111139.046391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 786, 7f8da12ed881
[1:1:0712/111139.061061:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"678 0x7f8d9e9a8070 0x1335a4383b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.061288:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"678 0x7f8d9e9a8070 0x1335a4383b60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.061515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111139.061846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111139.061966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111139.063889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 792, 7f8da12ed881
[1:1:0712/111139.077977:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"679 0x7f8d9e9a8070 0x1335a1fde160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.078173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"679 0x7f8d9e9a8070 0x1335a1fde160 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.078387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111139.078705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111139.078830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111139.109996:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 795, 7f8da12ed881
[1:1:0712/111139.122849:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"680 0x7f8d9e9a8070 0x1335a1fbb860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.123035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"680 0x7f8d9e9a8070 0x1335a1fbb860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.123239:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111139.123563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111139.123662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111139.125506:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 800, 7f8da12ed881
[1:1:0712/111139.139917:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"681 0x7f8d9e9a8070 0x1335a1fe63e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.140099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"681 0x7f8d9e9a8070 0x1335a1fe63e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111139.140292:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111139.140634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111139.140732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111140.024180:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 804, 7f8da12ed881
[1:1:0712/111140.039497:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"696","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.039730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"696","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.039992:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111140.040357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111140.040491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111140.115373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111140.115658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111140.172306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 806, 7f8da12ed881
[1:1:0712/111140.188085:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"696","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.188315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"696","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.188565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111140.188929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){if(id===count){that.logger.info("Saw new content event");that.processAspects();that.processEvents
[1:1:0712/111140.189063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111140.280149:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111140.280338:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111140.280599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 917
[1:1:0712/111140.280691:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7f8d9e9a8070 0x1335a1757660 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 806 0x7f8d9e9a8070 0x1335a1b5ebe0 
[1:1:0712/111140.408396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111140.408586:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111140.408856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 919
[1:1:0712/111140.408980:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f8d9e9a8070 0x1335a5af84e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 806 0x7f8d9e9a8070 0x1335a1b5ebe0 
[1:1:0712/111140.483619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 821, 7f8da12ed881
[1:1:0712/111140.498422:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"722 0x7f8d9e9a8070 0x1335a47654e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.498618:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"722 0x7f8d9e9a8070 0x1335a47654e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.498838:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111140.499157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111140.499260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111140.500229:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111140.500340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111140.500573:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 924
[1:1:0712/111140.500702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7f8d9e9a8070 0x1335a279cd60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 821 0x7f8d9e9a8070 0x1335a1444860 
[1:1:0712/111140.515607:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 794, 7f8da12ed881
[1:1:0712/111140.529932:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"680 0x7f8d9e9a8070 0x1335a1fbb860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.530117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"680 0x7f8d9e9a8070 0x1335a1fbb860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111140.530339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111140.530691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0712/111140.530814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111141.301161:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111141.301337:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 1000
[1:1:0712/111141.301558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 929
[1:1:0712/111141.301683:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f8d9e9a8070 0x1335a58e09e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 794 0x7f8d9e9a8070 0x1335a1fb3760 
[1:1:0712/111141.318527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 799, 7f8da12ed881
[1:1:0712/111141.335556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"681 0x7f8d9e9a8070 0x1335a1fe63e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111141.335741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"681 0x7f8d9e9a8070 0x1335a1fe63e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111141.335945:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111141.336285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0712/111141.336383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111141.662083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 850, 7f8da12ed881
[1:1:0712/111141.675517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"752 0x7f8d9e9a8070 0x1335a1b590e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111141.675722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"752 0x7f8d9e9a8070 0x1335a1b590e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111141.675956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111141.676303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111141.676388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111141.678095:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 852, 7f8da12ed881
[1:1:0712/111141.692306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"755 0x7f8d9e9a8070 0x1335a1fd2560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111141.692491:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"755 0x7f8d9e9a8070 0x1335a1fd2560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111141.692693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111141.692988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111141.693137:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111142.126192:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 849, 7f8da12ed881
[1:1:0712/111142.140810:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"752 0x7f8d9e9a8070 0x1335a1b590e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111142.141005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"752 0x7f8d9e9a8070 0x1335a1b590e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111142.141237:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111142.141585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0712/111142.141740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111142.749482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 851, 7f8da12ed881
[1:1:0712/111142.765265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"755 0x7f8d9e9a8070 0x1335a1fd2560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111142.765447:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"755 0x7f8d9e9a8070 0x1335a1fd2560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111142.765688:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111142.766052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0712/111142.766555:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111142.876356:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 670, 7f8da12ed881
[1:1:0712/111142.891024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111142.891213:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"565 0x7f8d9e9a8070 0x1335a1877d60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111142.891417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111142.891725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){b.F&&(b.complete?b.va():(a.trackOffline&&b.abort&&b.abort(),b.Ga()))}
[1:1:0712/111142.891829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.152145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111143.152302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.231022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 917, 7f8da12ed881
[1:1:0712/111143.249294:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"806 0x7f8d9e9a8070 0x1335a1b5ebe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.249486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"806 0x7f8d9e9a8070 0x1335a1b5ebe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.249678:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.249995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111143.250078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.250515:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111143.250633:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111143.250862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 978
[1:1:0712/111143.250959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 978 0x7f8d9e9a8070 0x1335a451da60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 917 0x7f8d9e9a8070 0x1335a1757660 
[1:1:0712/111143.252342:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111143.252439:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111143.252652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 979
[1:1:0712/111143.252763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7f8d9e9a8070 0x1335a2093fe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 917 0x7f8d9e9a8070 0x1335a1757660 
[1:1:0712/111143.253496:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 919, 7f8da12ed881
[1:1:0712/111143.273019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"806 0x7f8d9e9a8070 0x1335a1b5ebe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.273238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"806 0x7f8d9e9a8070 0x1335a1b5ebe0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.273516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.273909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111143.274027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.274515:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111143.274958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111143.275177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 982
[1:1:0712/111143.275281:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7f8d9e9a8070 0x1335a607ebe0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 919 0x7f8d9e9a8070 0x1335a5af84e0 
[1:1:0712/111143.276708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111143.276818:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111143.277471:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 984
[1:1:0712/111143.277574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7f8d9e9a8070 0x1335a1f266e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 919 0x7f8d9e9a8070 0x1335a5af84e0 
[1:1:0712/111143.295730:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 924, 7f8da12ed881
[1:1:0712/111143.315771:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"821 0x7f8d9e9a8070 0x1335a1444860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.315957:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"821 0x7f8d9e9a8070 0x1335a1444860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.316167:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.316497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111143.316612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.317586:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111143.317687:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111143.317926:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 991
[1:1:0712/111143.318036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7f8d9e9a8070 0x1335a6074a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 924 0x7f8d9e9a8070 0x1335a279cd60 
[1:1:0712/111143.376164:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 936 0x7f8da08d02e0 0x1335a607dee0 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.378298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , /*
 * Copyright (c) 2007-2015, Marketo, Inc. All rights reserved.
 * Marketo marketing automation we
[1:1:0712/111143.378457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.383770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.475890:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.476382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , b.onload.b.va, (){a.ab(c);b.Da();a.rb();a.ga();a.q=0;a.ka();if(b.Ba){b.Ba=!1;try{a.doPostbacks(a.X(b.responseText))
[1:1:0712/111143.476501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.804023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 929, 7f8da12ed881
[1:1:0712/111143.818189:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"794 0x7f8d9e9a8070 0x1335a1fb3760 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.818374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"794 0x7f8d9e9a8070 0x1335a1fb3760 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111143.818592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111143.818923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){if(that.viewportQueue.hasOwnProperty(key)){item.top=item.$elem.offset().top;item.left=item.$elem.
[1:1:0712/111143.819045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111143.987958:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111143.988126:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 5000
[1:1:0712/111143.988396:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1039
[1:1:0712/111143.988538:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1039 0x7f8d9e9a8070 0x1335a5af9de0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 929 0x7f8d9e9a8070 0x1335a58e09e0 
[1:1:0712/111144.124333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111144.124540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111144.337263:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 979, 7f8da12ed881
[1:1:0712/111144.355188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"917 0x7f8d9e9a8070 0x1335a1757660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111144.355405:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"917 0x7f8d9e9a8070 0x1335a1757660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111144.355615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111144.355972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111144.356067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111144.427841:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 984, 7f8da12ed881
[1:1:0712/111144.443454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"919 0x7f8d9e9a8070 0x1335a5af84e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111144.443636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"919 0x7f8d9e9a8070 0x1335a5af84e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111144.443856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111144.444189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111144.444298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111144.507918:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 991, 7f8da12ed881
[1:1:0712/111144.522370:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"924 0x7f8d9e9a8070 0x1335a279cd60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111144.522526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"924 0x7f8d9e9a8070 0x1335a279cd60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111144.522728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111144.523062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111144.523187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111144.524124:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111144.524238:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111144.524494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1051
[1:1:0712/111144.524614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1051 0x7f8d9e9a8070 0x1335a6059560 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 991 0x7f8d9e9a8070 0x1335a6074a60 
[1:1:0712/111144.731409:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111144.731934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , O.d.onreadystatechange, (){2<=d.readyState&&d.abort()}
[1:1:0712/111144.732053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111145.470365:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 978, 7f8da12ed881
[1:1:0712/111145.487542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"917 0x7f8d9e9a8070 0x1335a1757660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111145.487743:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"917 0x7f8d9e9a8070 0x1335a1757660 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111145.487984:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111145.488350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0712/111145.488459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111145.580906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 982, 7f8da12ed881
[1:1:0712/111145.596976:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"919 0x7f8d9e9a8070 0x1335a5af84e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111145.597230:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"919 0x7f8d9e9a8070 0x1335a5af84e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111145.597433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111145.597750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){that.loadEventRegistry.layoutReadyForViewportEvents=true;that.processViewportQueue()}
[1:1:0712/111145.597837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111145.726275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111145.726490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111145.900211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1051, 7f8da12ed881
[1:1:0712/111145.918735:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"991 0x7f8d9e9a8070 0x1335a6074a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111145.918935:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"991 0x7f8d9e9a8070 0x1335a6074a60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111145.919167:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111145.919508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111145.919652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111145.920632:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111145.920722:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111145.920912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1101
[1:1:0712/111145.921003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7f8d9e9a8070 0x1335a18a2760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1051 0x7f8d9e9a8070 0x1335a6059560 
[1:1:0712/111146.077820:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111146.077998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.208386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1101, 7f8da12ed881
[1:1:0712/111146.226204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1051 0x7f8d9e9a8070 0x1335a6059560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111146.226387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1051 0x7f8d9e9a8070 0x1335a6059560 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111146.226606:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111146.226959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111146.227053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.227977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111146.228086:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111146.228317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1120
[1:1:0712/111146.228437:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f8d9e9a8070 0x1335a279cd60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1101 0x7f8d9e9a8070 0x1335a18a2760 
[1:1:0712/111146.262816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111146.262969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.363485:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111146.364003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , b.onload.b.va, (){a.ab(c);b.Da();a.rb();a.ga();a.q=0;a.ka();if(b.Ba){b.Ba=!1;try{a.doPostbacks(a.X(b.responseText))
[1:1:0712/111146.364115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.383770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111146.383953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.421630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1120, 7f8da12ed881
[1:1:0712/111146.439613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1101 0x7f8d9e9a8070 0x1335a18a2760 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111146.439807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1101 0x7f8d9e9a8070 0x1335a18a2760 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111146.440022:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111146.440348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111146.440448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.441432:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111146.441530:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111146.441750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1134
[1:1:0712/111146.441856:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1134 0x7f8d9e9a8070 0x1335a17f7e60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1120 0x7f8d9e9a8070 0x1335a279cd60 
[1:1:0712/111146.471912:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1130 0x7f8da08d02e0 0x1335a591f460 , "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111146.481683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (function(){define("libra/core/libra-namespace",[],function(){if(typeof Libra!=="object"){Libra={}}r
[1:1:0712/111146.481912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111146.525004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111149.322528:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111149.322699:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111149.322963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1147
[1:1:0712/111149.323106:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1147 0x7f8d9e9a8070 0x1335a82aff60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111150.683816:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111150.684024:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111150.684298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1163
[1:1:0712/111150.684451:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1163 0x7f8d9e9a8070 0x1335a88c77e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111150.688787:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111150.688925:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111150.689172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1164
[1:1:0712/111150.689295:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1164 0x7f8d9e9a8070 0x1335a875c3e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111150.692607:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111150.692716:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111150.692907:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1165
[1:1:0712/111150.693002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1165 0x7f8d9e9a8070 0x1335a88c4d60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.002782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.002965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.003208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1167
[1:1:0712/111151.003326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f8d9e9a8070 0x1335a84780e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.006958:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.007103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.007345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1168
[1:1:0712/111151.007473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1168 0x7f8d9e9a8070 0x1335a875f8e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.011208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.011370:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.011600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1169
[1:1:0712/111151.011708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7f8d9e9a8070 0x1335a438ca60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.015443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.015603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.015829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1170
[1:1:0712/111151.015935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7f8d9e9a8070 0x1335a6049360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.019710:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.019855:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.020110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1171
[1:1:0712/111151.020204:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1171 0x7f8d9e9a8070 0x1335a1b52060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.023561:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.023676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.023874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1172
[1:1:0712/111151.023980:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7f8d9e9a8070 0x1335a875cee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.027788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.027958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.028253:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1173
[1:1:0712/111151.028398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7f8d9e9a8070 0x1335a88c31e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.032053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.032203:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 4
[1:1:0712/111151.032439:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1174
[1:1:0712/111151.032548:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f8d9e9a8070 0x1335a847d6e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.123106:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.123280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111151.123554:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1175
[1:1:0712/111151.123677:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7f8d9e9a8070 0x1335a7fa8760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.126753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.126899:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111151.127142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1176
[1:1:0712/111151.127298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7f8d9e9a8070 0x1335a6060860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.128596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.128673:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111151.128853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1177
[1:1:0712/111151.128931:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7f8d9e9a8070 0x1335a604d3e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1130 0x7f8da08d02e0 0x1335a591f460 
[1:1:0712/111151.215749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111151.215934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111151.349106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111151.349551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/111151.349682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111151.356898:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.357021:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111151.357260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1220
[1:1:0712/111151.357382:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1220 0x7f8d9e9a8070 0x1335a73fa760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1140
[1:1:0712/111151.868603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.869158:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 200
[1:1:0712/111151.869504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1222
[1:1:0712/111151.869676:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1222 0x7f8d9e9a8070 0x1335a604d360 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1140
[1:1:0712/111151.874800:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111151.875012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111151.875293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1223
[1:1:0712/111151.875401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1223 0x7f8d9e9a8070 0x1335a846c3e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1140
[1:1:0712/111151.995520:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111151.995959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){if(document.readyState==="complete"){cb.call(ctx)}}
[1:1:0712/111151.996082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.156935:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111152.157139:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 5000
[1:1:0712/111152.157426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1261
[1:1:0712/111152.157592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1261 0x7f8d9e9a8070 0x1335a78d96e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1149 0x7f8da08d02e0 0x1335a7fa8860 
[1:1:0712/111152.159761:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.160396:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.161110:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a14971e0
[1:1:0712/111152.161245:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111152.161532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1263
[1:1:0712/111152.161704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1263 0x7f8d9e9a8070 0x1335a8470460 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1149 0x7f8da08d02e0 0x1335a7fa8860 
[1:1:0712/111152.162006:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.162451:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.163018:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.278198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.280711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.282254:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.282701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.596231:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1134, 7f8da12ed881
[1:1:0712/111152.613312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1120 0x7f8d9e9a8070 0x1335a279cd60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.613489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1120 0x7f8d9e9a8070 0x1335a279cd60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.613707:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.614056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111152.614177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.650038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , document.readyState
[1:1:0712/111152.650252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.651635:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1147, 7f8da12ed881
[1:1:0712/111152.670661:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.670859:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.671077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.671413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111152.671502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.674266:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111152.674396:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111152.674626:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1291
[1:1:0712/111152.674750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1291 0x7f8d9e9a8070 0x1335a84735e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1147 0x7f8d9e9a8070 0x1335a82aff60 
[1:1:0712/111152.675335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1163, 7f8da12ed881
[1:1:0712/111152.694115:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.694290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.694508:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.694822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.694934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.709413:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111152.709576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111152.709811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1293
[1:1:0712/111152.709947:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1293 0x7f8d9e9a8070 0x1335a847d8e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1163 0x7f8d9e9a8070 0x1335a88c77e0 
[1:1:0712/111152.713207:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1164, 7f8da12ed881
[1:1:0712/111152.732379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.732556:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.732759:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.733115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.733232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.785285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1165, 7f8da12ed881
[1:1:0712/111152.806001:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.806193:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.806421:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.806756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.806862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.818781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1167, 7f8da12ed881
[1:1:0712/111152.839155:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.839362:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.839602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.839946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.840077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.858301:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1168, 7f8da12ed881
[1:1:0712/111152.876166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.876325:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.876515:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.876800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.876887:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.927350:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1169, 7f8da12ed881
[1:1:0712/111152.943144:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.943311:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.943505:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.943812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.943924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.962616:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1170, 7f8da12ed881
[1:1:0712/111152.980374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.980549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111152.980772:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111152.981125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111152.981246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111152.993773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1171, 7f8da12ed881
[1:1:0712/111153.013984:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.014185:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.014435:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.014795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111153.014943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.065070:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1172, 7f8da12ed881
[1:1:0712/111153.084615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.084788:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.084977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.085297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111153.085400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.097873:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1173, 7f8da12ed881
[1:1:0712/111153.115335:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.115499:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.115697:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.116008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111153.116117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.127752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1174, 7f8da12ed881
[1:1:0712/111153.144658:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.144852:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.145056:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.145419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){J();
n=r(i(null,a));n.skipMap=j.skipMap;n.init(c,d,p,{enabled:!0});D()}
[1:1:0712/111153.145529:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.191964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1175, 7f8da12ed881
[1:1:0712/111153.209152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.209321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.209522:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.209836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){this._firedPixel=url;(new Image).src=url}
[1:1:0712/111153.209950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.212445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1176, 7f8da12ed881
[1:1:0712/111153.232894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.233082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.233297:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.233615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){this._firedPixel=url;(new Image).src=url}
[1:1:0712/111153.233735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.525805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1177, 7f8da12ed881
[1:1:0712/111153.545417:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.545619:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1130 0x7f8da08d02e0 0x1335a591f460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.545879:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.546242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){loop(pollGroup)}
[1:1:0712/111153.546357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.549888:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111153.550007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111153.550210:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1314
[1:1:0712/111153.550318:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7f8d9e9a8070 0x1335a18b0a60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1177 0x7f8d9e9a8070 0x1335a604d3e0 
[1:1:0712/111153.585156:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1220, 7f8da12ed881
[1:1:0712/111153.601363:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1140","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.601505:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1140","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.601685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.601979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111153.602086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111153.604592:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1223, 7f8da12ed881
[1:1:0712/111153.622487:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1140","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.622663:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1140","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111153.622864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111153.623174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=url}
[1:1:0712/111153.623283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111154.254946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1222, 7f8da12ed881
[1:1:0712/111154.271484:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1140","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111154.271640:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1140","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111154.271832:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111154.272163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){if(id===count){that.logger.info("Saw new content event");that.processAspects();that.processEvents
[1:1:0712/111154.272273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111154.325392:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111154.325547:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111154.325766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1320
[1:1:0712/111154.325893:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7f8d9e9a8070 0x1335a8479ce0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1222 0x7f8d9e9a8070 0x1335a604d360 
[1:1:0712/111154.419153:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111154.419331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111154.419574:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1321
[1:1:0712/111154.419702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7f8d9e9a8070 0x1335a604c860 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1222 0x7f8d9e9a8070 0x1335a604d360 
[1:1:0712/111154.479737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1263, 7f8da12ed881
[1:1:0712/111154.496865:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1149 0x7f8da08d02e0 0x1335a7fa8860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111154.497055:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1149 0x7f8da08d02e0 0x1335a7fa8860 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111154.497345:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111154.497773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){PerfLogger.checkMetric("windowLoad",PerfLogger.getElapsedTimeSinceResponseEnd());PerfLogger.check
[1:1:0712/111154.497959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111154.506210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111154.506399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111154.506654:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1326
[1:1:0712/111154.506800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1326 0x7f8d9e9a8070 0x1335a18853e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1263 0x7f8d9e9a8070 0x1335a8470460 
[1:1:0712/111154.509881:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111154.509974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111154.510157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1327
[1:1:0712/111154.510256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7f8d9e9a8070 0x1335a9b56660 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1263 0x7f8d9e9a8070 0x1335a8470460 
[1:1:0712/111154.984289:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1291, 7f8da12ed881
[1:1:0712/111155.001828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1147 0x7f8d9e9a8070 0x1335a82aff60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.002008:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1147 0x7f8d9e9a8070 0x1335a82aff60 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.002216:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.002547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111155.002666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.004179:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1293, 7f8da12ed881
[1:1:0712/111155.021784:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1163 0x7f8d9e9a8070 0x1335a88c77e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.021986:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1163 0x7f8d9e9a8070 0x1335a88c77e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.022232:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.022652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){X=0;D()}
[1:1:0712/111155.022798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.026841:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111155.026998:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 50
[1:1:0712/111155.027243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1345
[1:1:0712/111155.027372:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7f8d9e9a8070 0x1335a17729e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1293 0x7f8d9e9a8070 0x1335a847d8e0 
[1:1:0712/111155.402127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1314, 7f8da12ed881
[1:1:0712/111155.418513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1177 0x7f8d9e9a8070 0x1335a604d3e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.418668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1177 0x7f8d9e9a8070 0x1335a604d3e0 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.418861:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.419166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){loop(pollGroup)}
[1:1:0712/111155.419285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.421957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111155.422062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 100
[1:1:0712/111155.422271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1366
[1:1:0712/111155.422385:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1366 0x7f8d9e9a8070 0x1335a845f460 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1314 0x7f8d9e9a8070 0x1335a18b0a60 
[1:1:0712/111155.483814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1320, 7f8da12ed881
[1:1:0712/111155.503227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1222 0x7f8d9e9a8070 0x1335a604d360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.503424:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1222 0x7f8d9e9a8070 0x1335a604d360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.503643:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.503969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111155.504086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.504509:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111155.504602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111155.504806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1371
[1:1:0712/111155.504886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1371 0x7f8d9e9a8070 0x1335a9ddaee0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1320 0x7f8d9e9a8070 0x1335a8479ce0 
[1:1:0712/111155.506219:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111155.506331:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111155.506532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1372
[1:1:0712/111155.506650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1372 0x7f8d9e9a8070 0x1335a607a9e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1320 0x7f8d9e9a8070 0x1335a8479ce0 
[1:1:0712/111155.507183:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1321, 7f8da12ed881
[1:1:0712/111155.527577:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1222 0x7f8d9e9a8070 0x1335a604d360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.527798:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1222 0x7f8d9e9a8070 0x1335a604d360 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.528031:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.528375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , k, (){try{j()}catch(a){r.Deferred.exceptionHook&&r.Deferred.exceptionHook(a,k.stackTrace),b+1>=f&&(d!==
[1:1:0712/111155.528488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.528947:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111155.529048:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 800
[1:1:0712/111155.529292:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1373
[1:1:0712/111155.529422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1373 0x7f8d9e9a8070 0x1335a875c3e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1321 0x7f8d9e9a8070 0x1335a604c860 
[1:1:0712/111155.530840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497150
[1:1:0712/111155.530921:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111155.531126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1374
[1:1:0712/111155.531216:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1374 0x7f8d9e9a8070 0x1335a60514e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1321 0x7f8d9e9a8070 0x1335a604c860 
[1:1:0712/111155.589640:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1326, 7f8da12ed881
[1:1:0712/111155.608228:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1263 0x7f8d9e9a8070 0x1335a8470460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.608394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1263 0x7f8d9e9a8070 0x1335a8470460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.608591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.608894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=foresterUrl}
[1:1:0712/111155.608981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.610767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1327, 7f8da12ed881
[1:1:0712/111155.629419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e9381a22860","ptid":"1263 0x7f8d9e9a8070 0x1335a8470460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.629586:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://aws.amazon.com/","ptid":"1263 0x7f8d9e9a8070 0x1335a8470460 ","rf":"5:3_https://aws.amazon.com/"}
[1:1:0712/111155.629785:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.630091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){(new Image).src=csdsUrl}
[1:1:0712/111155.630188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.689516:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111155.689932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/111155.690057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111155.696953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111155.697117:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111155.697388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1386
[1:1:0712/111155.697489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1386 0x7f8d9e9a8070 0x1335a9dca760 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1336 0x7f8db5033080 0x1335a9dd84c0 1 0 0x1335a9dd84d8 
[1:1:0712/111157.317113:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111157.317293:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 200
[1:1:0712/111157.317570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1393
[1:1:0712/111157.317669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1393 0x7f8d9e9a8070 0x1335a543bd60 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1336 0x7f8db5033080 0x1335a9dd84c0 1 0 0x1335a9dd84d8 
[1:1:0712/111157.321865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111157.322002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111157.322263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1394
[1:1:0712/111157.322380:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1394 0x7f8d9e9a8070 0x1335a488e060 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1336 0x7f8db5033080 0x1335a9dd84c0 1 0 0x1335a9dd84d8 
[1:1:0712/111157.446792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter"
[1:1:0712/111157.447213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://aws.amazon.com/, 1e9381a22860, , , (){c&&(c=d=h.onload=h.onerror=h.onabort=h.onreadystatechange=null,"abort"===a?h.abort():"error"===a?
[1:1:0712/111157.447315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", "aws.amazon.com", 3, 1, , , 0
[1:1:0712/111157.479532:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111157.479708:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111157.479944:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1437
[1:1:0712/111157.480103:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1437 0x7f8d9e9a8070 0x1335a12f24e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1346 0x7f8db5033080 0x1335a9cf9920 1 0 0x1335a9cf9938 
[1:1:0712/111157.483908:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3634538629c8, 0x1335a1497210
[1:1:0712/111157.484063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://aws.amazon.com/what-is-cloud-computing/?sc_channel=EL&sc_campaign=amazonfooter", 0
[1:1:0712/111157.484294:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://aws.amazon.com/, 1438
[1:1:0712/111157.484406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1438 0x7f8d9e9a8070 0x1335aa86c3e0 , 5:3_https://aws.amazon.com/, 1, -5:3_https://aws.amazon.com/, 1346 0x7f8db5033080 0x1335a9cf9920 1 0 0x1335a9cf9938 
