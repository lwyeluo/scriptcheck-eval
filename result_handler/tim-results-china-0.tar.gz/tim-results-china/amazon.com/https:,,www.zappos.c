[0712/111645.318875:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111645.319113:INFO:switcher_clone.cc(787)] backtrace rip is 7f3414216891
[0712/111645.899713:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111645.899971:INFO:switcher_clone.cc(787)] backtrace rip is 7f73d0f7b891
[1:1:0712/111645.903884:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/111645.904066:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/111645.906857:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[1969:1969:0712/111646.760967:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2b393728-96b6-426a-9d88-e7f4253068c8
[0712/111646.863901:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/111646.864207:INFO:switcher_clone.cc(787)] backtrace rip is 7f4f52659891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[2005:2005:0712/111647.023076:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2005
[2019:2019:0712/111647.031646:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2019
[1969:1969:0712/111647.047265:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[1969:2003:0712/111647.047632:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/111647.047741:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111647.047881:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111647.048171:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111647.048281:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/111647.051131:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x6fe6356, 1
[1:1:0712/111647.051325:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2ec301d6, 0
[1:1:0712/111647.051400:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xcaf5ab8, 3
[1:1:0712/111647.051465:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xef66f7e, 2
[1:1:0712/111647.051542:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd601ffffffc32e 5663fffffffe06 7e6ffffffff60e ffffffb85affffffaf0c , 10104, 4
[1:1:0712/111647.052223:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1969:2003:0712/111647.052349:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��.Vc�~o��Z��u
[1969:2003:0712/111647.052388:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��.Vc�~o��Z����u
[1969:2003:0712/111647.052532:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1969:2003:0712/111647.052564:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2027, 4, d601c32e 5663fe06 7e6ff60e b85aaf0c 
[1:1:0712/111647.052800:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73cf1b50a0, 3
[1:1:0712/111647.052903:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73cf341080, 2
[1:1:0712/111647.052987:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73b9003d20, -2
[1:1:0712/111647.062436:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111647.062901:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ef66f7e
[1:1:0712/111647.063404:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ef66f7e
[1:1:0712/111647.064835:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ef66f7e
[1:1:0712/111647.065439:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.065549:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.065650:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.065742:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.065996:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ef66f7e
[1:1:0712/111647.066146:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73d0f7b7ba
[1:1:0712/111647.066219:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73d0f72def, 7f73d0f7b77a, 7f73d0f7d0cf
[1:1:0712/111647.067968:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal ef66f7e
[1:1:0712/111647.068142:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal ef66f7e
[1:1:0712/111647.068447:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal ef66f7e
[1:1:0712/111647.070312:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.070426:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.070508:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.070585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal ef66f7e
[1:1:0712/111647.071076:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal ef66f7e
[1:1:0712/111647.071227:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73d0f7b7ba
[1:1:0712/111647.071324:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73d0f72def, 7f73d0f7b77a, 7f73d0f7d0cf
[1:1:0712/111647.073961:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111647.074167:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111647.074281:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9a8b9048, 0x7ffc9a8b8fc8)
[1:1:0712/111647.081456:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111647.084269:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1969:1969:0712/111647.352322:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[1969:1969:0712/111647.353822:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[1:1:0712/111647.594471:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x63918d6220
[1:1:0712/111647.594724:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1969:1969:0712/111647.604400:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1969:1969:0712/111647.604861:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1969:1969:0712/111647.625304:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[1969:1969:0712/111647.625364:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[1969:1969:0712/111647.625428:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,2027, 4
[1969:1981:0712/111647.627876:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[1969:1981:0712/111647.627938:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111647.629830:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1969:1994:0712/111647.753623:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/111647.897242:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/111648.608874:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111648.610402:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1969:1969:0712/111648.647521:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1969:1969:0712/111648.647579:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111649.068645:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111649.120823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111649.120965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111649.125879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/111649.125996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111649.174362:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111649.174510:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111649.340162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111649.342649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111649.342776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111649.359294:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111649.362247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/111649.362371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111649.366225:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1969:1969:0712/111649.366858:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111649.367949:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x63918d4e20
[1:1:0712/111649.368779:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1969:1969:0712/111649.369284:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1969:1969:0712/111649.381637:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[1969:1969:0712/111649.381728:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/111649.403020:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111649.733103:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f73babde2e0 0x6391b68360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111649.733829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/111649.733995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111649.734644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1969:1969:0712/111649.763914:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/111649.765634:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x63918d5820
[1:1:0712/111649.766155:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1969:1969:0712/111649.772437:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/111649.773803:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/111649.774078:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[1969:1969:0712/111649.781456:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[1969:1969:0712/111649.788537:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1969:1969:0712/111649.789183:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1969:1969:0712/111649.795444:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[1969:1969:0712/111649.795500:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[1969:1969:0712/111649.795565:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,2027, 4
[1969:1981:0712/111649.801135:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[1969:1981:0712/111649.801201:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111649.801722:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111650.066450:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/111650.264758:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f73babde2e0 0x6391d133e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111650.265350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/111650.265509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111650.265854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1969:1969:0712/111650.416951:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[1969:1969:0712/111650.417055:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/111650.428920:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1969:1969:0712/111650.460137:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[1969:2003:0712/111650.460407:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/111650.460538:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/111650.460673:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/111650.460862:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/111650.460943:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/111650.474127:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x274e78ec, 1
[1:1:0712/111650.474371:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3d0b950, 0
[1:1:0712/111650.474483:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x28c157bf, 3
[1:1:0712/111650.474570:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a1ad31a, 2
[1:1:0712/111650.474648:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 50ffffffb9ffffffd003 ffffffec784e27 1affffffd31a2a ffffffbf57ffffffc128 , 10104, 5
[1:1:0712/111650.475372:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1969:2003:0712/111650.475523:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGP���xN'�*�W�(cw
[1969:2003:0712/111650.475565:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is P���xN'�*�W�(x�cw
[1969:2003:0712/111650.475703:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2104, 5, 50b9d003 ec784e27 1ad31a2a bf57c128 
[1:1:0712/111650.475897:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73cf1b50a0, 3
[1:1:0712/111650.475997:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73cf341080, 2
[1:1:0712/111650.476097:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f73b9003d20, -2
[1:1:0712/111650.485512:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/111650.485697:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1ad31a
[1:1:0712/111650.485859:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1ad31a
[1:1:0712/111650.486111:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1ad31a
[1:1:0712/111650.486612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.486708:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.486798:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.486886:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.487539:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1ad31a
[1:1:0712/111650.487675:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73d0f7b7ba
[1:1:0712/111650.487760:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73d0f72def, 7f73d0f7b77a, 7f73d0f7d0cf
[1:1:0712/111650.489542:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1ad31a
[1:1:0712/111650.489776:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1ad31a
[1:1:0712/111650.490145:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1ad31a
[1:1:0712/111650.490977:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.491153:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.491267:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.491372:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1ad31a
[1:1:0712/111650.491872:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1ad31a
[1:1:0712/111650.492044:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f73d0f7b7ba
[1:1:0712/111650.492128:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f73d0f72def, 7f73d0f7b77a, 7f73d0f7d0cf
[1:1:0712/111650.494745:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/111650.495011:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/111650.495108:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc9a8b9048, 0x7ffc9a8b8fc8)
[1:1:0712/111650.501406:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/111650.508358:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/111650.629903:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111650.655919:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x63918b8220
[1:1:0712/111650.656298:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/111650.939352:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111650.939703:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.052279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 553, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.054120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/111651.054342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111651.056883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.124752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/111651.125171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d9f2f3c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/111651.125276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/111651.192586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.193423:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111651.193561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111651.193717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111651.272074:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.272632:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/111651.273203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/111651.274969:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111651.623444:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/111651.667696:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/111651.706770:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/111651.735370:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/111651.787223:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/111651.815015:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/111651.854156:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/111651.881137:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/111651.912622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.913109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111651.913266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111651.970929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111651.971418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111651.971600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111651.996352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.001535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.001758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.034619:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.035097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.035290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.058837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.059301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.059447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.090597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.091103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.091258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.111942:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.112373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.112522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.140488:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.140909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.141086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.163754:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.164199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.164329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.220034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.220497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.220640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.283561:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.284016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.284175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.334321:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.334745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.334877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.364211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.364636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.364786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1969:1969:0712/111652.381095:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1969:1969:0712/111652.385326:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1969:1969:0712/111652.401339:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.zappos.com/
[1969:1969:0712/111652.401398:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.zappos.com/, https://www.zappos.com/, 1
[1969:1969:0712/111652.401457:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.zappos.com/, HTTP/1.1 200 status:200 content-type:text/html; charset=utf-8 server:Server vary:Accept-Encoding x-dns-prefetch-control:off x-frame-options:SAMEORIGIN x-download-options:noopen surrogate-control:no-store x-content-type-options:nosniff x-xss-protection:1; mode=block content-security-policy:frame-ancestors potserviceui-gamma.zappos.com potserviceui-gamma.6pm.com drive-render.corp.amazon.com cscentral-na-beta.vipinteg.amazon.com cscentral.amazon.com link:</marty-assets/marty-zappos.app.7c3c2bed4c4dbd731267.css>; rel=preload; as=style link:</marty-assets/marty-zappos.Landing.3e7de67152e757de7a4a.css>; rel=preload; as=style link:<https://amazon.zappos.com>;rel="preconnect",<https://dfapvmql-q.global.ssl.fastly.net>;rel="preconnect",<https://m.media-amazon.com>;rel="preconnect",<https://cdn.branch.io>;rel="preconnect" x-core-value:2. Embrace and Drive Change x-recruiting:If you're reading this, maybe you should be working at Zappos instead.  Check out jobs.zappos.com x-uuid:7e653c8e-a453-11e9-b14e-759c8d90e61c strict-transport-security:max-age=31536000; includeSubDomains; preload content-encoding:gzip x-akamai-transformed:9 46624 0 pmb=mRUM,1 expires:Fri, 12 Jul 2019 03:16:52 GMT cache-control:max-age=0, no-cache, no-store pragma:no-cache date:Fri, 12 Jul 2019 03:16:52 GMT set-cookie:zfc=Cg0Ijon5u7Wu4wIQ7vZjEg4KBG1vbmUQARgCIAEoABIOCgRoZXZ3EAEYAyABKAASDQoDc2pwEAMYAiABKAASCwoDYWpwEAEYAiAB; path=/; domain=.zappos.com; expires=Tue, 09-Jan-2035 00:00:00 GMT set-cookie:clouddc=east1; Path=/; Domain=.zappos.com set-cookie:AKA_A2=A; expires=Fri, 12-Jul-2019 04:16:52 GMT; path=/; domain=zappos.com; secure; HttpOnly set-cookie:ak_bmsc=99D4FE866DBEBB35D5146FF98C18215AB832575E6D1B0000A4FB275D0F371452~plXt10iSW+eRz9yDsk6TYakoo+X9DYWFO77xBnezT4iP06Ei97FwVavDJb1s4fsat8F1uloXZB7dz1h9Y82wfL6wQpOIPN/RbnP1/UAidBfN9nwTe5kab1m14BG78kCluAm8DVdfzlQWhXoDZgINwivEWfT9XbqykWh2XuBj6U4MkOps/iUfx08c8JygYDAEQOvgL5KoM78ij778+WWcht7x4j/ueVG/mmXl4G870JqR4=; expires=Fri, 12 Jul 2019 05:16:52 GMT; max-age=7200; path=/; domain=.zappos.com; HttpOnly  ,2104, 5
[1969:1981:0712/111652.410756:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[1969:1981:0712/111652.410824:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/111652.411352:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/111652.428867:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.zappos.com/
[1:1:0712/111652.456725:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.460629:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.460840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1969:1969:0712/111652.501730:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.zappos.com/, https://www.zappos.com/, 1
[1969:1969:0712/111652.501794:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.zappos.com/, https://www.zappos.com
[1:1:0712/111652.504776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.505260:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/111652.505595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.522123:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111652.544440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/111652.544929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3d9f2f4f09f8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/111652.545095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/111652.596939:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111652.639349:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111652.681730:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111652.681888:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zappos.com/"
[1:1:0712/111652.703260:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 142 0x7f73b8cb6070 0x6391a12a60 , "https://www.zappos.com/"
[1:1:0712/111652.704187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , 
(function(a){var b={},c=encodeURIComponent,d=a.zfcUUID,e;a.onerror=function(a,f,g){return e="/err.c
[1:1:0712/111652.704319:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111652.705438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 142 0x7f73b8cb6070 0x6391a12a60 , "https://www.zappos.com/"
[1:1:0712/111652.707501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 142 0x7f73b8cb6070 0x6391a12a60 , "https://www.zappos.com/"
[1:1:0712/111652.708907:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111652.715764:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 142 0x7f73b8cb6070 0x6391a12a60 , "https://www.zappos.com/"
[1:1:0712/111652.755967:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111652.813664:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/111652.960564:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111653.624015:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f73b901ebd0 0x63919e2d58 , "https://www.zappos.com/"
[1:1:0712/111653.630013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , var Protobuf={Messages:{}};
Protobuf.Messages.zfcCookie={"zfc.Cookie.Session":{1:{rule:"required",na
[1:1:0712/111653.630204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111653.855046:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x63918b5a20
[1:1:0712/111653.855207:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/111653.886492:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 166af5f54420, 5:3_https://www.zappos.com/, 5:4_https://www.zappos.com/, about:blank
[1:1:0712/111653.886699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, , void(0)
[1:1:0712/111653.886893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "www.zappos.com", 4, 2, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111653.887744:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	a.setup (https://www.zappos.com/:14:41)
	e (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.executeTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.setupTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.init (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	Object.<anonymous> (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	a.publish (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	Object.g.register (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111653.890686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zappos.com/"
[1:1:0712/111653.891748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, doc.open._l, (){var js=this.createElement("script");if(dom)this.domain=dom;js.id="boomr-if-as";js.src="https://s.
[1:1:0712/111653.891894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 3, , , 0
[1:1:0712/111653.892633:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	onload (https://www.zappos.com/:1:31)
	a.setup (https://www.zappos.com/:14:41)
	e (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.executeTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.setupTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.init (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	Object.<anonymous> (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	a.publish (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	Object.g.register (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111653.892960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, createElement, 
[1:1:0712/111653.893120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 4, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111653.894258:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	HTMLDocument.doc.open._l (https://www.zappos.com/:14:41)
	onload (https://www.zappos.com/:1:31)
	a.setup (https://www.zappos.com/:14:41)
	e (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.executeTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.setupTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.init (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	Object.<anonymous> (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	a.publish (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	Object.g.register (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111653.896436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, Date, 
[1:1:0712/111653.896574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 5, , , 0
[1:1:0712/111653.897634:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	HTMLDocument.doc.open._l (https://www.zappos.com/:14:41)
	onload (https://www.zappos.com/:1:31)
	a.setup (https://www.zappos.com/:14:41)
	e (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.executeTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.setupTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.init (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	Object.<anonymous> (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	a.publish (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	Object.g.register (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111653.898332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, appendChild, 
[1:1:0712/111653.898492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 6, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111653.899520:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	HTMLDocument.doc.open._l (https://www.zappos.com/:14:41)
	onload (https://www.zappos.com/:1:31)
	a.setup (https://www.zappos.com/:14:41)
	e (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.executeTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.setupTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.init (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	Object.<anonymous> (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	a.publish (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	Object.g.register (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111653.902317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, e, (c){var a;c.callback?(a=d.VariantUtils(c.assignment),c.callback.apply(a,c.args||[])):console.error("
[1:1:0712/111653.902507:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 7, , , 0
[1:1:0712/111653.903198:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	d.executeTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.setupTests (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d.init (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	d (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	Object.<anonymous> (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	a.publish (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	Object.g.register (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111653.913021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f73b901ebd0 0x63919e2d58 , "https://www.zappos.com/"
[1:1:0712/111654.134227:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f73b901ebd0 0x63919e2d58 , "https://www.zappos.com/"
[1:1:0712/111654.136318:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f73b901ebd0 0x63919e2d58 , "https://www.zappos.com/"
[1:1:0712/111654.143406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f73b901ebd0 0x63919e2d58 , "https://www.zappos.com/"
[1:1:0712/111654.218133:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.306892, 2106, 1
[1:1:0712/111654.218279:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111654.733932:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111654.737251:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zappos.com/"
[1:1:0712/111654.737765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111654.738360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , 
    function upgradeBrowserPrompt() {
      var latestUnsupportedIE = 10;
      if (document.docume
[1:1:0712/111654.738478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111654.739668:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111654.744835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111654.772021:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111654.777873:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111654.800067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111654.929443:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 323 0x7f73b8cb6070 0x6391e18f60 , "https://www.zappos.com/"
[1:1:0712/111655.744724:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111658.741351:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/111659.463193:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x1b55530029c8, 0x6391745108
[1:1:0712/111659.463405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 120000
[1:1:0712/111659.463580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 393
[1:1:0712/111659.463696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 393 0x7f73b8cb6070 0x6394aa0e60 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 323 0x7f73b8cb6070 0x6391e18f60 
[1:1:0712/111659.473301:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 4.73603, 1, 0
[1:1:0712/111659.473488:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/111659.745859:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358 0x7f73babde2e0 0x6391d90fe0 , "https://www.zappos.com/"
[1:1:0712/111659.747678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0712/111659.747846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1969:1969:0712/111700.214897:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1969:1969:0712/111700.217108:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1969:1969:0712/111700.224328:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.zappos.com/, https://www.zappos.com/, 4
[1969:1969:0712/111700.224410:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.zappos.com/, https://www.zappos.com
[3:3:0712/111700.256560:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1969:1969:0712/111700.259835:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/111701.006508:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359 0x7f73babde2e0 0x6391d71a60 , "https://www.zappos.com/"
[1:1:0712/111701.009419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , /*
Copyright 2010 Google Inc.
Copyright 2016 Akamai Technolgies

Licensed under the Apache License, 
[1:1:0712/111701.009609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111701.060714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362 0x7f73babde2e0 0x6391d51760 , "https://www.zappos.com/"
[1:1:0712/111701.062530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (window.webpackJsonp=window.webpackJsonp||[]).push([[22],{1070:function(t,e,n){"use strict";e.__esMo
[1:1:0712/111701.062693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111708.212018:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x6391744198
[1:1:0712/111708.212230:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111708.212454:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 491
[1:1:0712/111708.212602:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 491 0x7f73b8cb6070 0x639a27d8e0 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 362 0x7f73babde2e0 0x6391d51760 
[1:1:0712/111709.987521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x1b55530029c8, 0x6391744198
[1:1:0712/111709.987701:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 200
[1:1:0712/111709.987887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 499
[1:1:0712/111709.988014:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 499 0x7f73b8cb6070 0x639b845c60 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 362 0x7f73babde2e0 0x6391d51760 
[1:1:0712/111709.991018:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x6391744198
[1:1:0712/111709.991175:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111709.991352:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 500
[1:1:0712/111709.991473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 500 0x7f73b8cb6070 0x639b17c760 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 362 0x7f73babde2e0 0x6391d51760 
[1969:1969:0712/111711.350223:INFO:CONSOLE(1)] "Marty Client:", source: https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js (1)
[1969:1969:0712/111711.366809:INFO:CONSOLE(1)] "Marty Client:", source: https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js (1)
[1969:1969:0712/111716.689789:INFO:CONSOLE(1)] "Marty Client:", source: https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js (1)
[1:1:0712/111716.997430:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zappos.com/"
[1:1:0712/111717.153901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://www.zappos.com/"
[1:1:0712/111717.155099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , Ar, (t,n){if(jr){var r=Ut(n);if(null===(r=I(r))||"number"!=typeof r.tag||2===rr(r)||(r=null),Or.length){
[1:1:0712/111717.155239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111717.189716:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363 0x7f73babde2e0 0x6391ed0760 , "https://www.zappos.com/"
[1:1:0712/111717.192145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , // Copyright 2008-2017 Monetate, Inc.
// 2017-01-18T14:14:21Z t1484745711 entry_masks_only.js
(funct
[1:1:0712/111717.192342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111717.220017:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x1b55530029c8, 0x6391744190
[1:1:0712/111717.220188:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 4000
[1:1:0712/111717.228268:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 553
[1:1:0712/111717.229911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 553 0x7f73b8cb6070 0x6391d9f760 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 363 0x7f73babde2e0 0x6391ed0760 
[1:1:0712/111717.557015:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/111717.557199:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zappos.com/"
[1:1:0712/111717.557854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f73b8cb6070 0x6394acb760 , "https://www.zappos.com/"
[1:1:0712/111717.558645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , 
(function(e,b,h,i){function g(f,c,a,d){a=new Date((new Date).getTime()+864E5*a);f=f+"="+c+"; Path=/
[1:1:0712/111717.558801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111717.564822:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f73b8cb6070 0x6394acb760 , "https://www.zappos.com/"
[1:1:0712/111717.566054:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f73b8cb6070 0x6394acb760 , "https://www.zappos.com/"
[1:1:0712/111717.568679:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xa0e1cf9eaf0
[1:1:0712/111717.630515:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x63917441b0
[1:1:0712/111717.630696:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111717.630866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 576
[1:1:0712/111717.630968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 576 0x7f73b8cb6070 0x63a08c7960 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 396 0x7f73b8cb6070 0x6394acb760 
[1:1:0712/111717.640592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111717.640899:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 577
[1:1:0712/111717.640988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 577 0x7f73b8cb6070 0x63a0c984e0 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 396 0x7f73b8cb6070 0x6394acb760 
[1:1:0712/111717.719244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.zappos.com/"
[1:1:0712/111717.720142:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.zappos.com/"
[1:1:0712/111717.720806:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.zappos.com/"
[1:1:0712/111717.977518:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zappos.com/"
[1:1:0712/111717.978037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , Ar, (t,n){if(jr){var r=Ut(n);if(null===(r=I(r))||"number"!=typeof r.tag||2===rr(r)||(r=null),Or.length){
[1:1:0712/111717.978172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111718.016651:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zappos.com/"
[1:1:0712/111718.017083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , Ar, (t,n){if(jr){var r=Ut(n);if(null===(r=I(r))||"number"!=typeof r.tag||2===rr(r)||(r=null),Or.length){
[1:1:0712/111718.017191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111718.083304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/111718.083485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111719.097528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/111719.097754:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111719.106551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/111719.106711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1969:1969:0712/111719.111786:INFO:CONSOLE(1)] "Marty Client:", source: https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js (1)
[1:1:0712/111721.924249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 491, 7f73bb5fb881
[1:1:0712/111721.933419:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"362 0x7f73babde2e0 0x6391d51760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111721.933578:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"362 0x7f73babde2e0 0x6391d51760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111721.933744:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111721.934019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111721.934140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111721.955133:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 500, 7f73bb5fb881
[1:1:0712/111721.963560:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"362 0x7f73babde2e0 0x6391d51760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111721.963711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"362 0x7f73babde2e0 0x6391d51760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111721.963858:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111721.964112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111721.964205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111729.877740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 499, 7f73bb5fb881
[1:1:0712/111729.889452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"362 0x7f73babde2e0 0x6391d51760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111729.889666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"362 0x7f73babde2e0 0x6391d51760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111729.889878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111729.890186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , k, (){var t=m(),r=w(t);if(i=arguments,o=this,c=t,r){if(void 0===a)return function(t){return f=t,a=setTi
[1:1:0712/111729.890351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111729.890871:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x6391744150
[1:1:0712/111729.890985:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111729.891174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 637
[1:1:0712/111729.891301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 637 0x7f73b8cb6070 0x6391b7f460 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 499 0x7f73b8cb6070 0x639b845c60 
[1:1:0712/111730.754502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111730.754707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111731.228186:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 576, 7f73bb5fb881
[1:1:0712/111731.240233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"396 0x7f73b8cb6070 0x6394acb760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.240454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"396 0x7f73b8cb6070 0x6394acb760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.240665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111731.240936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){c.flushEvents(!0)}
[1:1:0712/111731.241076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111731.241581:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111731.241692:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111731.241866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 702
[1:1:0712/111731.241986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f73b8cb6070 0x63a8bea960 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 576 0x7f73b8cb6070 0x63a08c7960 
[1:1:0712/111731.254342:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 577, 7f73bb5fb8db
[1:1:0712/111731.267131:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"396 0x7f73b8cb6070 0x6394acb760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.267307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"396 0x7f73b8cb6070 0x6394acb760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.267479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 703
[1:1:0712/111731.267599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 703 0x7f73b8cb6070 0x63a89b1ae0 , 5:3_https://www.zappos.com/, 0, , 577 0x7f73b8cb6070 0x63a0c984e0 
[1:1:0712/111731.267775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111731.268043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111731.268126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111731.370352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 553, 7f73bb5fb881
[1:1:0712/111731.383056:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"363 0x7f73babde2e0 0x6391ed0760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.383243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"363 0x7f73babde2e0 0x6391ed0760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.383424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111731.383702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){try{return b.apply(this,arguments)}catch(c){try{L({entry:a,xname:c.name,xmsg:c.message,msg:a})}ca
[1:1:0712/111731.383813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111731.481521:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 637, 7f73bb5fb881
[1:1:0712/111731.495752:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"499 0x7f73b8cb6070 0x639b845c60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.495964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"499 0x7f73b8cb6070 0x639b845c60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111731.496160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111731.496493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111731.496616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111735.051574:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 641 0x7f73babde2e0 0x63a86739e0 , "https://www.zappos.com/"
[1:1:0712/111735.061374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (function() {var aa="function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,c)
[1:1:0712/111735.061559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111735.346403:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 660 0x7f73babde2e0 0x63a09ee060 , "https://www.zappos.com/"
[1:1:0712/111735.355012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , /*
 * Copyright (c) 2011, Yahoo! Inc.  All rights reserved.
 * Copyright (c) 2011-2012, Log-Normal, 
[1:1:0712/111735.355207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.357313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, CustomEvent, 
[1:1:0712/111735.357447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111735.358000:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.359875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, replace, 
[1:1:0712/111735.360055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.360264:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.365537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, , (){return"function"==typeof this&&this[u]||s.call(this)}
[1:1:0712/111735.365717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111735.365934:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.366181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, test, 
[1:1:0712/111735.366337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.366595:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.367142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, setItem, 
[1:1:0712/111735.367302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111735.367576:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkLocalStorageSupport (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.368262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, , (){var a;for(a in c)c.hasOwnProperty(a)&&(BOOMR[a]=c[a]);BOOMR.xhr_excludes||(BOOMR.xhr_excludes={})
[1:1:0712/111735.368488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.368759:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.374123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, CustomEvent, 
[1:1:0712/111735.374371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 8, , , 0
[1:1:0712/111735.374688:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.375008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, setImmediate, (b,c,d,e){var f,g;f=function(){b.call(e||null,c,d||{},g);f=null};a.requestIdleCallback?a.requestIdle
[1:1:0712/111735.375186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 9, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.375428:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.375838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestIdleCallback, 
[1:1:0712/111735.376019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 10, , , 0
[1:1:0712/111735.376388:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.setImmediate (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.377750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, , (){if(!BOOMR.plugins.ConfigOverride){var a={safeConfigOverride:function(b,c,d){for(var e in c)if(b.h
[1:1:0712/111735.389386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 11, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.389676:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.401123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, XMLHttpRequest, 
[1:1:0712/111735.401380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 12, , , 0
[1:1:0712/111735.401618:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.402177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, d, (){this.watch=0;this.timer=null;this.pending_events=[];this.lastSpaLocation=null}
[1:1:0712/111735.402386:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 13, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.402587:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.438290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestIdleCallback, 
[1:1:0712/111735.438627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 14, , , 0
[1:1:0712/111735.438967:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.setImmediate (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.439442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, subscribe, (c,d,e,f,g){var h,i,j;c=c.toLowerCase();b.translate_events[c]&&(c=b.translate_events[c]);b.events.ha
[1:1:0712/111735.439669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 15, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.439939:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.442946:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.443232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 16, , , 0
[1:1:0712/111735.443653:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.444504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.444913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 17, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.445368:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.446043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.446347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 18, , , 0
[1:1:0712/111735.446826:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.447802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.448067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 19, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.448616:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.451051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, createElement, 
[1:1:0712/111735.451296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 20, , , 0
[1:1:0712/111735.451559:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.451985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, pluginConfig, (a,b,c,d){var e,f=0;if(!b||!b[c])return!1;for(e=0;e<d.length;e++)if(void 0!==b[c][d[e]]){a[d[e]]=b[c
[1:1:0712/111735.452232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 21, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.452481:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.461019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.461364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 22, , , 0
[1:1:0712/111735.461811:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.462469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.462756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 23, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.463121:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.463336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.463563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 24, , , 0
[1:1:0712/111735.463918:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.464115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.464360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 25, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.464745:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.469701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.469962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 26, , , 0
[1:1:0712/111735.470304:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.470536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.470792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 27, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.471145:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.472378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.472690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 28, , , 0
[1:1:0712/111735.473138:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.473445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.473707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 29, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.474057:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.475226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, getBattery, 
[1:1:0712/111735.475570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 30, , , 0
[1:1:0712/111735.477789:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.505838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, subscribe, (c,d,e,f,g){var h,i,j;c=c.toLowerCase();b.translate_events[c]&&(c=b.translate_events[c]);b.events.ha
[1:1:0712/111735.506291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 31, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.506641:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.510256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestIdleCallback, 
[1:1:0712/111735.510644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 32, , , 0
[1:1:0712/111735.511081:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.setImmediate (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.511714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, hasBrowserOnloadFired, (){var b=BOOMR.getPerformance();return d.readyState&&"complete"===d.readyState||b&&b.timing&&b.timin
[1:1:0712/111735.512138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 33, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.512387:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.513733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.514091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 34, , , 0
[1:1:0712/111735.514508:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.attach_page_ready (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.515059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.515464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 35, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.515818:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.attach_page_ready (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.516068:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.516378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 36, , , 0
[1:1:0712/111735.516660:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.516996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.517360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 37, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.517656:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.520120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.520476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 38, , , 0
[1:1:0712/111735.520797:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.521113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.521470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 39, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.521794:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.522605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 40, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.522989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 40, , , 0
[1:1:0712/111735.523358:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.523732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 41, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.524114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 41, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.524423:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.524572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 42, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, getElementsByTagName, 
[1:1:0712/111735.524898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 42, , , 0
[1:1:0712/111735.525199:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.526095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 43, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, xb_handler, (c){return function(d){var e;d||(d=a.event);d.target?e=d.target:d.srcElement&&(e=d.srcElement);3===e
[1:1:0712/111735.526472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 43, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.526727:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.527039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 44, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.527382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 44, , , 0
[1:1:0712/111735.527653:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.527903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 45, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.528310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 45, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.528808:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.529206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 46, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.529542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 46, , , 0
[1:1:0712/111735.529788:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.529999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 47, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.530362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 47, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.530628:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.530974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 48, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.531393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 48, , , 0
[1:1:0712/111735.531722:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.531939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 49, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.532351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 49, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.532625:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.532931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 50, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.533353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 50, , , 0
[1:1:0712/111735.533635:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.533848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 51, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.534237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 51, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.534502:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.534830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 52, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111735.535245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 52, , , 0
[1:1:0712/111735.535555:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.535785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 53, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111735.536419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 53, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111735.536845:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111735.657710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111735.657905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.047668:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.048166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , k, (){var t=m(),r=w(t);if(i=arguments,o=this,c=t,r){if(void 0===a)return function(t){return f=t,a=setTi
[1:1:0712/111736.048359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.048931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x6391744220
[1:1:0712/111736.049018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111736.049216:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 753
[1:1:0712/111736.049312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 753 0x7f73b8cb6070 0x63a872fde0 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 
[1:1:0712/111736.049515:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.050055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x63917441f0
[1:1:0712/111736.050137:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111736.050272:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 754
[1:1:0712/111736.050365:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 754 0x7f73b8cb6070 0x63915ca060 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 
[1:1:0712/111736.050593:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.051163:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x63917441f0
[1:1:0712/111736.051256:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111736.051415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 755
[1:1:0712/111736.051496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f73b8cb6070 0x63a0477ae0 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 
[1:1:0712/111736.051687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.052012:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.053138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x63917441f0
[1:1:0712/111736.053249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111736.053453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 756
[1:1:0712/111736.053589:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f73b8cb6070 0x6391521960 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 
[1:1:0712/111736.084570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.085290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x1b55530029c8, 0x63917441f0
[1:1:0712/111736.085418:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111736.085607:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 757
[1:1:0712/111736.085739:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f73b8cb6070 0x6394b91d60 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 
[1:1:0712/111736.085943:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.zappos.com/"
[1:1:0712/111736.168746:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zappos.com/"
[1:1:0712/111736.169179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){Annapurna.Observer("tracker:onload").publish(c)}
[1:1:0712/111736.169290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.403698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zappos.com/"
[1:1:0712/111736.404207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0712/111736.404395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.458099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 703, 7f73bb5fb8db
[1:1:0712/111736.471082:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"577 0x7f73b8cb6070 0x63a0c984e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111736.471292:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"577 0x7f73b8cb6070 0x63a0c984e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111736.471518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 776
[1:1:0712/111736.471684:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 776 0x7f73b8cb6070 0x6394d4b1e0 , 5:3_https://www.zappos.com/, 0, , 703 0x7f73b8cb6070 0x63a89b1ae0 
[1:1:0712/111736.471829:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111736.472091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111736.472193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.476196:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 702, 7f73bb5fb881
[1:1:0712/111736.495806:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"576 0x7f73b8cb6070 0x63a08c7960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111736.496023:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"576 0x7f73b8cb6070 0x63a08c7960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111736.496224:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111736.496538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){c.flushEvents(!0)}
[1:1:0712/111736.496672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.497055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111736.497237:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111736.497477:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 778
[1:1:0712/111736.497601:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7f73b8cb6070 0x6394b88460 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 702 0x7f73b8cb6070 0x63a8bea960 
[1:1:0712/111736.786972:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111736.787151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (a){h=a}
[1:1:0712/111736.787292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111736.831137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111736.831327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.964688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 753, 7f73bb5fb881
[1:1:0712/111736.979062:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111736.979257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111736.979438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111736.979726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111736.979828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111736.981208:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 754, 7f73bb5fb881
[1:1:0712/111736.997729:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111737.000409:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111737.000594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111737.000909:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111737.001060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111739.762103:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 755, 7f73bb5fb881
[1:1:0712/111739.778440:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111739.778655:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111739.778898:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111739.779236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111739.779380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111739.858753:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 756, 7f73bb5fb881
[1:1:0712/111739.872117:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111739.872338:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111739.872504:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111739.872823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111739.872910:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111739.873931:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 757, 7f73bb5fb881
[1:1:0712/111739.887535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111739.887747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"689 0x7f73c7fc7960 0x63a896cc40 0x63a896cc50 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111739.887923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111739.888640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , E, (){var t=m();if(w(t))return O(t);a=setTimeout(E,function(t){var r=n-(t-c);return h?p(r,u-(t-f)):r}(t
[1:1:0712/111739.888780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111740.068668:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111740.068891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , f, (){b.call(e||null,c,d||{},g);f=null}
[1:1:0712/111740.069019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.069680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, dispatchEvent, 
[1:1:0712/111740.069804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111740.070038:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.070598:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "onBoomerangLoaded", "https://www.zappos.com/"
[1:1:0712/111740.071151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, hook, (a,b,e){e=e||{};e.disableHardNav=d.disableHardNav;if(d.hooked)return this;if(c(a)){BOOMR.plugins.SPA
[1:1:0712/111740.071320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.072511:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	i (https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js:1:1)
	HTMLDocument.<anonymous> (https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.074003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111740.074196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111740.074991:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.hook (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	i (https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js:1:1)
	HTMLDocument.<anonymous> (https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.075295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, subscribe, (c,d,e,f,g){var h,i,j;c=c.toLowerCase();b.translate_events[c]&&(c=b.translate_events[c]);b.events.ha
[1:1:0712/111740.075475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.076293:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.hook (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	i (https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js:1:1)
	HTMLDocument.<anonymous> (https://www.zappos.com/marty-assets/marty-zappos.app.3e7de67152e757de7a4a.js:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.105517:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111740.105672:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , f, (){b.call(e||null,c,d||{},g);f=null}
[1:1:0712/111740.105801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.161480:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111740.161669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , f, (){b.call(e||null,c,d||{},g);f=null}
[1:1:0712/111740.161807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.164097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, getItem, 
[1:1:0712/111740.164222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111740.164491:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getLocalStorage (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.164697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, hasOwnProperty, 
[1:1:0712/111740.164927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.165210:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.168284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111740.168404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111740.168823:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.169007:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111740.169154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111740.169574:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	f (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111740.204593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 776, 7f73bb5fb8db
[1:1:0712/111740.218549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"703 0x7f73b8cb6070 0x63a89b1ae0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111740.218764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"703 0x7f73b8cb6070 0x63a89b1ae0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111740.218967:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 814
[1:1:0712/111740.219106:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 814 0x7f73b8cb6070 0x63a43b9fe0 , 5:3_https://www.zappos.com/, 0, , 776 0x7f73b8cb6070 0x6394d4b1e0 
[1:1:0712/111740.219274:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111740.219600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111740.219688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111740.274076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7f73babde2e0 0x63a0f66de0 , "https://www.zappos.com/"
[1:1:0712/111740.300657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , // Copyright 2008-2019 Monetate, Inc.
// 2019-06-25T11:27:08Z t1561461773 zappos.js
(function(){var 
[1:1:0712/111740.300828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111740.398403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111740.398624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111740.613505:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 778, 7f73bb5fb881
[1:1:0712/111740.628392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"702 0x7f73b8cb6070 0x63a8bea960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111740.628612:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"702 0x7f73b8cb6070 0x63a8bea960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111740.628822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111740.629129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){c.flushEvents(!0)}
[1:1:0712/111740.629290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111740.629648:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111740.629794:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111740.629977:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 831
[1:1:0712/111740.630087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 831 0x7f73b8cb6070 0x6394def4e0 , 5:3_https://www.zappos.com/, 1, -5:3_https://www.zappos.com/, 778 0x7f73b8cb6070 0x6394b88460 
[1:1:0712/111740.920838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111740.921023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111741.018163:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 814, 7f73bb5fb8db
[1:1:0712/111741.033731:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"776 0x7f73b8cb6070 0x6394d4b1e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111741.033925:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"776 0x7f73b8cb6070 0x6394d4b1e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111741.034101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 861
[1:1:0712/111741.034199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 861 0x7f73b8cb6070 0x63ad015560 , 5:3_https://www.zappos.com/, 0, , 814 0x7f73b8cb6070 0x63a43b9fe0 
[1:1:0712/111741.034326:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111741.034599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111741.034693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111741.405328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111741.405523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111741.736837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zappos.com/"
[1:1:0712/111741.737235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c.onreadystatechange, (){4===c.readyState&&200===c.status&&e(c.responseText,a)}
[1:1:0712/111741.737377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.737897:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zappos.com/"
[1:1:0712/111741.739471:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zappos.com/"
[1:1:0712/111741.740407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111741.740525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111741.741103:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.741349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111741.741556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.742075:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.746124:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 330000, 0x1b555300b610, 0x6391744210
[1:1:0712/111741.746381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 330000
[1:1:0712/111741.746582:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 916
[1:1:0712/111741.746704:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7f73b8cb6070 0x63ad161ce0 , 5:3_https://www.zappos.com/, 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 872
[1:1:0712/111741.751503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111741.751726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111741.752341:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.752586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111741.753218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.753914:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.756572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, PerformanceObserver, 
[1:1:0712/111741.756725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111741.757170:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	u (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.758026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, b, (a,b,c){z[a]||(z[a]=[]);A[a]={compressMode:b||f,backfillLast:c}}
[1:1:0712/111741.758197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.758611:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	u (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.759893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111741.760051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 8, , , 0
[1:1:0712/111741.760568:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	w (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.760741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111741.760898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 9, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.761451:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	w (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.761623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111741.761780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 10, , , 0
[1:1:0712/111741.762161:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	w (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.763193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, B, (b,c,d){function e(b,d,e){d=d||BOOMR.now();if(x){t++;p||(p=d);var f=0;if(e&&e.timeStamp){f=e.timeSta
[1:1:0712/111741.763381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 11, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.763728:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.787394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111741.787657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 12, , , 0
[1:1:0712/111741.788257:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	x (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.788727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111741.788946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 13, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.789475:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	x (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.789679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111741.789863:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 919
[1:1:0712/111741.789975:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f73b8cb6070 0x63ad156f60 , 5:3_https://www.zappos.com/, 13, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 872
[1:1:0712/111741.791133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111741.791327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 14, , , 0
[1:1:0712/111741.791820:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	z (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.792645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111741.792876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 15, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.793363:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	z (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.794314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111741.794538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 16, , , 0
[1:1:0712/111741.795023:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	y (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.795356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111741.795605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 17, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.796097:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	y (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.797892:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 100
[1:1:0712/111741.798099:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 920
[1:1:0712/111741.798214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 920 0x7f73b8cb6070 0x63ad143de0 , 5:3_https://www.zappos.com/, 17, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 872
[1:1:0712/111741.798584:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 250
[1:1:0712/111741.798752:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 921
[1:1:0712/111741.798859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f73b8cb6070 0x63acf405e0 , 5:3_https://www.zappos.com/, 17, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 872
[1:1:0712/111741.799377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111741.799604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 18, , , 0
[1:1:0712/111741.800131:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	A (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.800495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111741.800751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 19, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.801271:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	A (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.802888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111741.803117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 20, , , 0
[1:1:0712/111741.803592:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	D (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.803893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111741.804136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 21, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.804607:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	D (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.805668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, getElementsByTagName, 
[1:1:0712/111741.805916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 22, , , 0
[1:1:0712/111741.806330:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	E (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.806548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, setInterval, 
[1:1:0712/111741.806788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 23, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.807203:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	E (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.807351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111741.807505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 922
[1:1:0712/111741.807584:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7f73b8cb6070 0x63ad1393e0 , 5:3_https://www.zappos.com/, 23, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 872
[1:1:0712/111741.807982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, getBattery, 
[1:1:0712/111741.808216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 24, , , 0
[1:1:0712/111741.808660:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	E (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.809270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, toString, 
[1:1:0712/111741.809561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 25, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.809966:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.815632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestIdleCallback, 
[1:1:0712/111741.815931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 26, , , 0
[1:1:0712/111741.816409:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.setImmediate (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.816795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, subscribe, (c,d,e,f,g){var h,i,j;c=c.toLowerCase();b.translate_events[c]&&(c=b.translate_events[c]);b.events.ha
[1:1:0712/111741.817131:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 27, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.817530:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.818769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, createElement, 
[1:1:0712/111741.819050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 28, , , 0
[1:1:0712/111741.819428:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.819664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, pluginConfig, (a,b,c,d){var e,f=0;if(!b||!b[c])return!1;for(e=0;e<d.length;e++)if(void 0!==b[c][d[e]]){a[d[e]]=b[c
[1:1:0712/111741.819943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 29, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.820313:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.827128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, addEventListener, 
[1:1:0712/111741.827844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 30, , , 0
[1:1:0712/111741.828419:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.828743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, push, 
[1:1:0712/111741.829089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 31, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.829685:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.addListener (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1
	Object.subscribe (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.830325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, getBattery, 
[1:1:0712/111741.830685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 32, , , 0
[1:1:0712/111741.831112:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.831563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, hasOwnProperty, 
[1:1:0712/111741.831897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 33, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.832275:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.834843:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xa0e1ce67d78
[1:1:0712/111741.837595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestIdleCallback, 
[1:1:0712/111741.837959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 34, , , 0
[1:1:0712/111741.838457:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.setImmediate (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.838897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, j.function.j.now.test.j.timing.j.timing.navigationStart.c.now, (){return Math.round(j.now()+j.timing.navigationStart)}
[1:1:0712/111741.839257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 35, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.839679:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.839872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111741.840199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 36, , , 0
[1:1:0712/111741.840828:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111741.841081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111741.841428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 37, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111741.842003:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.init (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	XMLHttpRequest.c.onreadystatechange (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111742.169457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111742.169616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111742.458019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 831, 7f73bb5fb881
[1:1:0712/111742.474074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860","ptid":"778 0x7f73b8cb6070 0x6394b88460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.474306:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/","ptid":"778 0x7f73b8cb6070 0x6394b88460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.474535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111742.474857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){c.flushEvents(!0)}
[1:1:0712/111742.475037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111742.475397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111742.475552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 2, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.475810:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111742.477174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111742.477322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 3, , , 0
[1:1:0712/111742.477605:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1

[1:1:0712/111742.477803:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111742.477914:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111742.478126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 938
[1:1:0712/111742.478256:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 938 0x7f73b8cb6070 0x63ad1bae60 , 5:3_https://www.zappos.com/, 3, -5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 831 0x7f73b8cb6070 0x6394def4e0 
[1:1:0712/111742.512397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 861, 7f73bb5fb8db
[1:1:0712/111742.530785:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"814 0x7f73b8cb6070 0x63a43b9fe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.531000:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"814 0x7f73b8cb6070 0x63a43b9fe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.531228:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 939
[1:1:0712/111742.531358:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 939 0x7f73b8cb6070 0x63ad1515e0 , 5:3_https://www.zappos.com/, 0, , 861 0x7f73b8cb6070 0x63ad015560 
[1:1:0712/111742.531528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111742.531833:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111742.531949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111742.741132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111742.741425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.742552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111742.742707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111742.743269:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111742.743485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111742.743633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.744082:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111742.744435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111742.744543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111742.744737:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111742.808581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111742.808790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.809931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111742.810069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111742.810586:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111742.810790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111742.810935:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.811397:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111742.812009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 919, 7f73bb5fb8db
[1:1:0712/111742.829703:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.830058:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.830306:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 944
[1:1:0712/111742.830402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 944 0x7f73b8cb6070 0x63950fae60 , 5:3_https://www.zappos.com/, 0, , 919 0x7f73b8cb6070 0x63ad156f60 
[1:1:0712/111742.830592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111742.830908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111742.831026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.848474:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 920, 7f73bb5fb8db
[1:1:0712/111742.863817:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.864111:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.864298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 947
[1:1:0712/111742.864423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 947 0x7f73b8cb6070 0x63ad1c80e0 , 5:3_https://www.zappos.com/, 0, , 920 0x7f73b8cb6070 0x63ad143de0 
[1:1:0712/111742.864583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111742.864922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111742.865080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.865897:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 921, 7f73bb5fb8db
[1:1:0712/111742.881966:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.882301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.882502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 948
[1:1:0712/111742.882628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 948 0x7f73b8cb6070 0x63ad1387e0 , 5:3_https://www.zappos.com/, 0, , 921 0x7f73b8cb6070 0x63acf405e0 
[1:1:0712/111742.882782:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111742.883130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111742.883263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111742.899611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111742.899792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111742.962417:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 939, 7f73bb5fb8db
[1:1:0712/111742.980741:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"861 0x7f73b8cb6070 0x63ad015560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.980913:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"861 0x7f73b8cb6070 0x63ad015560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111742.981137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 952
[1:1:0712/111742.981247:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 952 0x7f73b8cb6070 0x63950f9e60 , 5:3_https://www.zappos.com/, 0, , 939 0x7f73b8cb6070 0x63ad1515e0 
[1:1:0712/111742.981406:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111742.981813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111742.981938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.012082:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.012282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111743.012448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.012900:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.012991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.013489:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.013715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.013857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.014347:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.014668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111743.014797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.016180:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.082267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 922, 7f73bb5fb8db
[1:1:0712/111743.097892:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420166af5e22860166af5f54420","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.098307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/","ptid":"872","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.098547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 958
[1:1:0712/111743.098706:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7f73b8cb6070 0x63950f4de0 , 5:3_https://www.zappos.com/, 0, , 922 0x7f73b8cb6070 0x63ad1393e0 
[1:1:0712/111743.098887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.099189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111743.099325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.100471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.100588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.101060:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.101274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.101417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.101828:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.116453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.116653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.117196:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.117424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.117563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.118049:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.118443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.118599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111743.119029:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.119213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.119383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.119793:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.136374:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.136548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , f, (){b.call(e||null,c,d||{},g);f=null}
[1:1:0712/111743.136686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.153384:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.153540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , f, (){b.call(e||null,c,d||{},g);f=null}
[1:1:0712/111743.153680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.169761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111743.169929:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.187760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 944, 7f73bb5fb8db
[1:1:0712/111743.205273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"919 0x7f73b8cb6070 0x63ad156f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.205477:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"919 0x7f73b8cb6070 0x63ad156f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.205680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 961
[1:1:0712/111743.205809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 961 0x7f73b8cb6070 0x63ad144b60 , 5:3_https://www.zappos.com/, 0, , 944 0x7f73b8cb6070 0x63950fae60 
[1:1:0712/111743.205986:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.206293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111743.206442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.207042:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 947, 7f73bb5fb8db
[1:1:0712/111743.229821:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"920 0x7f73b8cb6070 0x63ad143de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.230005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"920 0x7f73b8cb6070 0x63ad143de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.230195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 962
[1:1:0712/111743.230306:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7f73b8cb6070 0x63ad168de0 , 5:3_https://www.zappos.com/, 0, , 947 0x7f73b8cb6070 0x63ad1c80e0 
[1:1:0712/111743.230447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.230725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111743.230861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.267067:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.267275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111743.267454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.267902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.269156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.269701:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.269993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.270451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.271038:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.271275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111743.271397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.271561:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.349992:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.350172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111743.350341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.351142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.351265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.351741:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.351932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.352087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.352529:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.353102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 948, 7f73bb5fb8db
[1:1:0712/111743.369599:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"921 0x7f73b8cb6070 0x63acf405e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.369766:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"921 0x7f73b8cb6070 0x63acf405e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.369918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 967
[1:1:0712/111743.370000:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 967 0x7f73b8cb6070 0x63ad10ace0 , 5:3_https://www.zappos.com/, 0, , 948 0x7f73b8cb6070 0x63ad1387e0 
[1:1:0712/111743.370129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.370365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111743.370465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.386239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111743.386398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.405291:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.405486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111743.405642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.406125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.406249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.406760:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.407002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.407164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.407707:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.407968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111743.408077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.408241:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.492050:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 961, 7f73bb5fb8db
[1:1:0712/111743.509523:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"944 0x7f73b8cb6070 0x63950fae60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.509730:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"944 0x7f73b8cb6070 0x63950fae60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.509963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 973
[1:1:0712/111743.510110:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 973 0x7f73b8cb6070 0x63ad1157e0 , 5:3_https://www.zappos.com/, 0, , 961 0x7f73b8cb6070 0x63ad144b60 
[1:1:0712/111743.510296:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.510619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111743.510979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.511551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 962, 7f73bb5fb8db
[1:1:0712/111743.528382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"947 0x7f73b8cb6070 0x63ad1c80e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.528539:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"947 0x7f73b8cb6070 0x63ad1c80e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.528702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 974
[1:1:0712/111743.528820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 974 0x7f73b8cb6070 0x63ad11c2e0 , 5:3_https://www.zappos.com/, 0, , 962 0x7f73b8cb6070 0x63ad168de0 
[1:1:0712/111743.528955:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.529262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111743.529407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.547317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111743.547510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.567163:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.567312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111743.567436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.567804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.567906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.568331:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.568487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.568612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.569018:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.569263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111743.569364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.569518:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.649763:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.649933:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111743.650072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.650718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.650844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.651358:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.651541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.651668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.652117:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.652628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 938, 7f73bb5fb881
[1:1:0712/111743.670586:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5e22860166af5f54420166af5e22860","ptid":"831 0x7f73b8cb6070 0x6394def4e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.670830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"831 0x7f73b8cb6070 0x6394def4e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.671043:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.671356:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.671465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111743.671607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.672271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111743.672410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.672626:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111743.672982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111743.673154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.673543:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111743.674272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111743.674450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.676061:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111743.676299:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111743.677134:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111743.677329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 982
[1:1:0712/111743.677446:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7f73b8cb6070 0x63ad167e60 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 938 0x7f73b8cb6070 0x63ad1bae60 
[1:1:0712/111743.678129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 967, 7f73bb5fb8db
[1:1:0712/111743.706774:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"948 0x7f73b8cb6070 0x63ad1387e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.712107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"948 0x7f73b8cb6070 0x63ad1387e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.712383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 983
[1:1:0712/111743.712506:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 983 0x7f73b8cb6070 0x63ad125c60 , 5:3_https://www.zappos.com/, 0, , 967 0x7f73b8cb6070 0x63ad10ace0 
[1:1:0712/111743.712683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.712962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111743.713108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.731105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111743.731306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.764820:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.764983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111743.765116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.765612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.765788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.766322:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.766525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.766673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.767141:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.767343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111743.767456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111743.767614:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.811872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 973, 7f73bb5fb8db
[1:1:0712/111743.827173:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"961 0x7f73b8cb6070 0x63ad144b60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.827339:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"961 0x7f73b8cb6070 0x63ad144b60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.827503:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 991
[1:1:0712/111743.827630:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7f73b8cb6070 0x63ad168fe0 , 5:3_https://www.zappos.com/, 0, , 973 0x7f73b8cb6070 0x63ad1157e0 
[1:1:0712/111743.827806:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.828291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111743.828442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.828992:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 974, 7f73bb5fb8db
[1:1:0712/111743.844571:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"962 0x7f73b8cb6070 0x63ad168de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.844884:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"962 0x7f73b8cb6070 0x63ad168de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.845086:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 992
[1:1:0712/111743.845217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 992 0x7f73b8cb6070 0x63ad129ee0 , 5:3_https://www.zappos.com/, 0, , 974 0x7f73b8cb6070 0x63ad11c2e0 
[1:1:0712/111743.845380:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.845660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111743.845809:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.846361:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 952, 7f73bb5fb8db
[1:1:0712/111743.863004:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"939 0x7f73b8cb6070 0x63ad1515e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.863188:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"939 0x7f73b8cb6070 0x63ad1515e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.863390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 993
[1:1:0712/111743.863519:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f73b8cb6070 0x63ad152de0 , 5:3_https://www.zappos.com/, 0, , 952 0x7f73b8cb6070 0x63950f9e60 
[1:1:0712/111743.863680:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.863992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111743.864147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.904882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111743.905070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111743.942879:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111743.943873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111743.944182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.944843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111743.944950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111743.945502:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.945716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111743.945855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.946330:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111743.946835:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 983, 7f73bb5fb8db
[1:1:0712/111743.964208:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"967 0x7f73b8cb6070 0x63ad10ace0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.964394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"967 0x7f73b8cb6070 0x63ad10ace0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.964598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 998
[1:1:0712/111743.964714:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 998 0x7f73b8cb6070 0x63ad11a1e0 , 5:3_https://www.zappos.com/, 0, , 983 0x7f73b8cb6070 0x63ad125c60 
[1:1:0712/111743.964870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111743.965161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111743.965307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111743.983238:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 958, 7f73bb5fb8db
[1:1:0712/111743.999696:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"922 0x7f73b8cb6070 0x63ad1393e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111743.999862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"922 0x7f73b8cb6070 0x63ad1393e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.000029:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 999
[1:1:0712/111744.000125:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 999 0x7f73b8cb6070 0x63ad1123e0 , 5:3_https://www.zappos.com/, 0, , 958 0x7f73b8cb6070 0x63950f4de0 
[1:1:0712/111744.000265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.000513:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111744.000625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.001189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.001334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.001764:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.001929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.002044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.002439:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.015667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.015856:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.016337:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.016527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.016678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.017232:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.017618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.017764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111744.018192:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.018383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.018550:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.018987:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.036491:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.036661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111744.036792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.037235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.037357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.037827:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.038023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.038171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.038608:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.038822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111744.038953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.039142:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.102049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 991, 7f73bb5fb8db
[1:1:0712/111744.132018:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"973 0x7f73b8cb6070 0x63ad1157e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.132201:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"973 0x7f73b8cb6070 0x63ad1157e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.132387:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1005
[1:1:0712/111744.132492:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1005 0x7f73b8cb6070 0x63ad0eb160 , 5:3_https://www.zappos.com/, 0, , 991 0x7f73b8cb6070 0x63ad168fe0 
[1:1:0712/111744.132689:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.132961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111744.133124:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.165958:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 992, 7f73bb5fb8db
[1:1:0712/111744.182662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"974 0x7f73b8cb6070 0x63ad11c2e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.182875:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"974 0x7f73b8cb6070 0x63ad11c2e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.183134:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1006
[1:1:0712/111744.183299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1006 0x7f73b8cb6070 0x63ad1037e0 , 5:3_https://www.zappos.com/, 0, , 992 0x7f73b8cb6070 0x63ad129ee0 
[1:1:0712/111744.183520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.183810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111744.183993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.201533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111744.201704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111744.220573:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.220780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111744.220918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.221334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.221470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.221947:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.222134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.222278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.222728:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.222939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111744.223057:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.223219:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.284418:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.284577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111744.284699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.285270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.285401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.285868:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.286052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.286194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.286633:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.304275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 998, 7f73bb5fb8db
[1:1:0712/111744.322068:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"983 0x7f73b8cb6070 0x63ad125c60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.322244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"983 0x7f73b8cb6070 0x63ad125c60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.322416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1012
[1:1:0712/111744.322503:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1012 0x7f73b8cb6070 0x63950f9460 , 5:3_https://www.zappos.com/, 0, , 998 0x7f73b8cb6070 0x63ad11a1e0 
[1:1:0712/111744.322684:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.322932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111744.323038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.341025:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1005, 7f73bb5fb8db
[1:1:0712/111744.359078:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"991 0x7f73b8cb6070 0x63ad168fe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.365285:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"991 0x7f73b8cb6070 0x63ad168fe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.367061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1013
[1:1:0712/111744.367219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7f73b8cb6070 0x63ad108ee0 , 5:3_https://www.zappos.com/, 0, , 1005 0x7f73b8cb6070 0x63ad0eb160 
[1:1:0712/111744.367420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.367732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111744.367934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.389139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111744.389291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111744.407895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1006, 7f73bb5fb8db
[1:1:0712/111744.424866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"992 0x7f73b8cb6070 0x63ad129ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.425120:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"992 0x7f73b8cb6070 0x63ad129ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.425372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1016
[1:1:0712/111744.425581:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1016 0x7f73b8cb6070 0x63ad125de0 , 5:3_https://www.zappos.com/, 0, , 1006 0x7f73b8cb6070 0x63ad1037e0 
[1:1:0712/111744.425823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.426135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111744.426279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.443141:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.443285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111744.443397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.443784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.443914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.465731:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.466039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.466180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.466630:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.466848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111744.466967:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.467155:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.529371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111744.529534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111744.530925:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1013, 7f73bb5fb8db
[1:1:0712/111744.549222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1005 0x7f73b8cb6070 0x63ad0eb160 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.549431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1005 0x7f73b8cb6070 0x63ad0eb160 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.549976:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1022
[1:1:0712/111744.550398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7f73b8cb6070 0x63a0f5db60 , 5:3_https://www.zappos.com/, 0, , 1013 0x7f73b8cb6070 0x63ad108ee0 
[1:1:0712/111744.550599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.550880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111744.551010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.590197:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.592779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111744.592927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.593565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.593678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.594200:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.594405:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.594569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.595041:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.595621:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1016, 7f73bb5fb8db
[1:1:0712/111744.614271:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1006 0x7f73b8cb6070 0x63ad1037e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.614471:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1006 0x7f73b8cb6070 0x63ad1037e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.614701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1025
[1:1:0712/111744.614898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1025 0x7f73b8cb6070 0x63ad147460 , 5:3_https://www.zappos.com/, 0, , 1016 0x7f73b8cb6070 0x63ad125de0 
[1:1:0712/111744.615122:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.615397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111744.615532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.634347:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.634502:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111744.634626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.635005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.635122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.635581:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.635749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.635889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.636312:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.636526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111744.636631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.636792:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.698297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111744.698473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111744.716747:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1012, 7f73bb5fb8db
[1:1:0712/111744.733360:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"998 0x7f73b8cb6070 0x63ad11a1e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.733534:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"998 0x7f73b8cb6070 0x63ad11a1e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.733714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1033
[1:1:0712/111744.733835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1033 0x7f73b8cb6070 0x63ad153460 , 5:3_https://www.zappos.com/, 0, , 1012 0x7f73b8cb6070 0x63950f9460 
[1:1:0712/111744.734037:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.734336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111744.734484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.734952:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1022, 7f73bb5fb8db
[1:1:0712/111744.751443:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1013 0x7f73b8cb6070 0x63ad108ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.751616:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1013 0x7f73b8cb6070 0x63ad108ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.751793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1034
[1:1:0712/111744.751887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7f73b8cb6070 0x63ad104360 , 5:3_https://www.zappos.com/, 0, , 1022 0x7f73b8cb6070 0x63a0f5db60 
[1:1:0712/111744.752066:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.752306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111744.752416:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.770843:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.770998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111744.771120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.771747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.771882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.772418:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.772607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.772762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.773241:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.773762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 993, 7f73bb5fb8db
[1:1:0712/111744.791999:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"952 0x7f73b8cb6070 0x63950f9e60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.793994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"952 0x7f73b8cb6070 0x63950f9e60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.794218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1035
[1:1:0712/111744.794317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7f73b8cb6070 0x63ad103860 , 5:3_https://www.zappos.com/, 0, , 993 0x7f73b8cb6070 0x63ad152de0 
[1:1:0712/111744.794544:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.794834:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111744.794939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111744.820132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 982, 7f73bb5fb881
[1:1:0712/111744.838101:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"938 0x7f73b8cb6070 0x63ad1bae60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.839197:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"938 0x7f73b8cb6070 0x63ad1bae60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.839454:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.839895:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.839985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111744.840097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.840361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111744.840456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.840628:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111744.840914:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111744.841023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.841326:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111744.841891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111744.841999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.842263:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111744.842434:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111744.842531:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111744.842700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1040
[1:1:0712/111744.842817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7f73b8cb6070 0x63ad10a9e0 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 982 0x7f73b8cb6070 0x63ad167e60 
[1:1:0712/111744.862421:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111744.862578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111744.862707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.863183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111744.863291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111744.863798:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.863966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111744.864085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.864518:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.864744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111744.864921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111744.865114:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111744.928131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111744.928309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111744.929636:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1025, 7f73bb5fb8db
[1:1:0712/111744.947051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1016 0x7f73b8cb6070 0x63ad125de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.947234:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1016 0x7f73b8cb6070 0x63ad125de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111744.947423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1045
[1:1:0712/111744.947553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7f73b8cb6070 0x63ad0f2960 , 5:3_https://www.zappos.com/, 0, , 1025 0x7f73b8cb6070 0x63ad147460 
[1:1:0712/111744.947816:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111744.948086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111744.948277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111744.982259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1034, 7f73bb5fb8db
[1:1:0712/111745.002442:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1022 0x7f73b8cb6070 0x63a0f5db60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.002624:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1022 0x7f73b8cb6070 0x63a0f5db60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.002821:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1046
[1:1:0712/111745.002934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f73b8cb6070 0x63ad14ebe0 , 5:3_https://www.zappos.com/, 0, , 1034 0x7f73b8cb6070 0x63ad104360 
[1:1:0712/111745.003132:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.003398:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111745.003528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.004111:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1033, 7f73bb5fb8db
[1:1:0712/111745.022830:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1012 0x7f73b8cb6070 0x63950f9460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.023018:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1012 0x7f73b8cb6070 0x63950f9460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.023202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1048
[1:1:0712/111745.023386:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1048 0x7f73b8cb6070 0x63ad1da8e0 , 5:3_https://www.zappos.com/, 0, , 1033 0x7f73b8cb6070 0x63ad153460 
[1:1:0712/111745.023603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.023885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111745.024018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.024530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 999, 7f73bb5fb8db
[1:1:0712/111745.043575:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"958 0x7f73b8cb6070 0x63950f4de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.045632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"958 0x7f73b8cb6070 0x63950f4de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.045887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1049
[1:1:0712/111745.046042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1049 0x7f73b8cb6070 0x63ad1526e0 , 5:3_https://www.zappos.com/, 0, , 999 0x7f73b8cb6070 0x63ad1123e0 
[1:1:0712/111745.046273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.046587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111745.046749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.047226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.047334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.047850:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.053318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.053489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.054547:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.068164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.068374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111745.068896:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.072980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.073215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.073742:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.074165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.074335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111745.074842:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.074998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.075142:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.075560:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.111769:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.111937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111745.112070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.112675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.112796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.113377:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.113575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.113724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.114168:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.132284:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.132459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111745.132582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.132956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.133114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.133661:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.133908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.134071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.134563:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.134799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111745.134937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111745.135131:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.197728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111745.197907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111745.199182:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1045, 7f73bb5fb8db
[1:1:0712/111745.216634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1025 0x7f73b8cb6070 0x63ad147460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.217168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1025 0x7f73b8cb6070 0x63ad147460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.217369:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1057
[1:1:0712/111745.217494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1057 0x7f73b8cb6070 0x63ad146de0 , 5:3_https://www.zappos.com/, 0, , 1045 0x7f73b8cb6070 0x63ad0f2960 
[1:1:0712/111745.217710:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.217985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111745.218114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.235541:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1048, 7f73bb5fb8db
[1:1:0712/111745.252776:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1033 0x7f73b8cb6070 0x63ad153460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.252952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1033 0x7f73b8cb6070 0x63ad153460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.253153:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1058
[1:1:0712/111745.253279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7f73b8cb6070 0x63ad0f8060 , 5:3_https://www.zappos.com/, 0, , 1048 0x7f73b8cb6070 0x63ad1da8e0 
[1:1:0712/111745.253516:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.253843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111745.253978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.254486:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1046, 7f73bb5fb8db
[1:1:0712/111745.272477:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1034 0x7f73b8cb6070 0x63ad104360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.272666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1034 0x7f73b8cb6070 0x63ad104360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.272842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1059
[1:1:0712/111745.272925:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7f73b8cb6070 0x63ad153860 , 5:3_https://www.zappos.com/, 0, , 1046 0x7f73b8cb6070 0x63ad14ebe0 
[1:1:0712/111745.273137:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.273440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111745.274034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.293321:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.293466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111745.293596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.294163:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.295631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.296231:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.296421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.297894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.298407:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.321391:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.325464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111745.325737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.326232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.328192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.328787:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.328997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.329286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.329761:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.329986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111745.330108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111745.330282:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.411114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111745.411468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111745.412780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1059, 7f73bb5fb8db
[1:1:0712/111745.430504:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1046 0x7f73b8cb6070 0x63ad14ebe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.431940:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1046 0x7f73b8cb6070 0x63ad14ebe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.432137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1067
[1:1:0712/111745.432300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1067 0x7f73b8cb6070 0x63914caae0 , 5:3_https://www.zappos.com/, 0, , 1059 0x7f73b8cb6070 0x63ad153860 
[1:1:0712/111745.432534:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.432818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111745.432936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.433445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1057, 7f73bb5fb8db
[1:1:0712/111745.449936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1045 0x7f73b8cb6070 0x63ad0f2960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.450106:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1045 0x7f73b8cb6070 0x63ad0f2960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.450288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1068
[1:1:0712/111745.450411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1068 0x7f73b8cb6070 0x63ad129de0 , 5:3_https://www.zappos.com/, 0, , 1057 0x7f73b8cb6070 0x63ad146de0 
[1:1:0712/111745.450605:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.450876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111745.451012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.451521:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1058, 7f73bb5fb8db
[1:1:0712/111745.467951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1048 0x7f73b8cb6070 0x63ad1da8e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.468127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1048 0x7f73b8cb6070 0x63ad1da8e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.468306:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1069
[1:1:0712/111745.468412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1069 0x7f73b8cb6070 0x63ad10a460 , 5:3_https://www.zappos.com/, 0, , 1058 0x7f73b8cb6070 0x63ad0f8060 
[1:1:0712/111745.468589:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.468897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111745.469000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.506927:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.507097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111745.507226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.507796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.507898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.508432:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.508626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.508755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.509231:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.529581:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.529735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111745.529849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.530246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.530345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.530830:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.531229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.534815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.536202:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.537045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111745.537340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111745.537640:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.608669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111745.608853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111745.610155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1067, 7f73bb5fb8db
[1:1:0712/111745.627577:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1059 0x7f73b8cb6070 0x63ad153860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.627783:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1059 0x7f73b8cb6070 0x63ad153860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.627995:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1077
[1:1:0712/111745.628104:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f73b8cb6070 0x63ad1093e0 , 5:3_https://www.zappos.com/, 0, , 1067 0x7f73b8cb6070 0x63914caae0 
[1:1:0712/111745.628328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.628635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111745.628780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.647450:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1068, 7f73bb5fb8db
[1:1:0712/111745.663578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1057 0x7f73b8cb6070 0x63ad146de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.663725:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1057 0x7f73b8cb6070 0x63ad146de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.663923:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1079
[1:1:0712/111745.664037:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7f73b8cb6070 0x63ad0ebce0 , 5:3_https://www.zappos.com/, 0, , 1068 0x7f73b8cb6070 0x63ad129de0 
[1:1:0712/111745.664210:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.664487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111745.664633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.682829:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.682996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111745.683133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.683499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.683621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.684070:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.684254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.684398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.684804:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.685001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111745.685134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111745.685318:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.753425:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.753598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111745.753743:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.754357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.754491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.756593:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.758146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.758303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.758830:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.759392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1069, 7f73bb5fb8db
[1:1:0712/111745.778242:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1058 0x7f73b8cb6070 0x63ad0f8060 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.780037:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1058 0x7f73b8cb6070 0x63ad0f8060 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.780264:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1084
[1:1:0712/111745.780384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7f73b8cb6070 0x63ad0b60e0 , 5:3_https://www.zappos.com/, 0, , 1069 0x7f73b8cb6070 0x63ad10a460 
[1:1:0712/111745.780592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.781283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111745.781421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.818447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111745.818678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111745.820130:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1035, 7f73bb5fb8db
[1:1:0712/111745.837946:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"993 0x7f73b8cb6070 0x63ad152de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.838152:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"993 0x7f73b8cb6070 0x63ad152de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.838411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1088
[1:1:0712/111745.838577:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7f73b8cb6070 0x63ace612e0 , 5:3_https://www.zappos.com/, 0, , 1035 0x7f73b8cb6070 0x63ad103860 
[1:1:0712/111745.838802:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.839121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111745.839219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111745.843318:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1077, 7f73bb5fb8db
[1:1:0712/111745.861619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1067 0x7f73b8cb6070 0x63914caae0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.861843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1067 0x7f73b8cb6070 0x63914caae0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.862087:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1091
[1:1:0712/111745.862303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1091 0x7f73b8cb6070 0x63ad125f60 , 5:3_https://www.zappos.com/, 0, , 1077 0x7f73b8cb6070 0x63ad1093e0 
[1:1:0712/111745.862578:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.862906:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111745.863051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.863579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1079, 7f73bb5fb8db
[1:1:0712/111745.880954:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1068 0x7f73b8cb6070 0x63ad129de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.881138:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1068 0x7f73b8cb6070 0x63ad129de0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.881329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1092
[1:1:0712/111745.881456:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1092 0x7f73b8cb6070 0x63ad1383e0 , 5:3_https://www.zappos.com/, 0, , 1079 0x7f73b8cb6070 0x63ad0ebce0 
[1:1:0712/111745.881683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111745.881959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111745.882103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.916765:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111745.916920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111745.917067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.917499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111745.917583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111745.918038:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.918189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111745.918303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111745.918746:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.918966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111745.919067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111745.919225:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111745.968220:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1084, 7f73bb5fb8db
[1:1:0712/111745.990345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1069 0x7f73b8cb6070 0x63ad10a460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.990550:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1069 0x7f73b8cb6070 0x63ad10a460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111745.990760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1098
[1:1:0712/111745.990899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1098 0x7f73b8cb6070 0x63ad15fd60 , 5:3_https://www.zappos.com/, 0, , 1084 0x7f73b8cb6070 0x63ad0b60e0 
[1:1:0712/111746.001369:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.001728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111746.001908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.003061:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1049, 7f73bb5fb8db
[1:1:0712/111746.021852:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"999 0x7f73b8cb6070 0x63ad1123e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.022053:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"999 0x7f73b8cb6070 0x63ad1123e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.022284:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1099
[1:1:0712/111746.022421:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7f73b8cb6070 0x63ad0b3ee0 , 5:3_https://www.zappos.com/, 0, , 1049 0x7f73b8cb6070 0x63ad1526e0 
[1:1:0712/111746.022614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.022917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111746.023073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.023573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.023677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.024176:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.024349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.024486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.024913:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.038112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.038289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.038771:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.038958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.039102:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.039574:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.039954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.040071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111746.040502:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.040677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.040829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.041310:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.059396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111746.059566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111746.097119:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1040, 7f73bb5fb881
[1:1:0712/111746.115034:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"982 0x7f73b8cb6070 0x63ad167e60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.115239:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"982 0x7f73b8cb6070 0x63ad167e60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.115449:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.115754:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.115852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111746.115963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.116166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111746.116257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.116438:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111746.116711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111746.116826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.117098:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111746.117655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111746.117774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.118041:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111746.118216:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111746.118308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111746.118466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1102
[1:1:0712/111746.118573:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1102 0x7f73b8cb6070 0x63ad0f3560 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1040 0x7f73b8cb6070 0x63ad10a9e0 
[1:1:0712/111746.119148:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1091, 7f73bb5fb8db
[1:1:0712/111746.137137:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1077 0x7f73b8cb6070 0x63ad1093e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.137346:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1077 0x7f73b8cb6070 0x63ad1093e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.137549:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1103
[1:1:0712/111746.137652:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1103 0x7f73b8cb6070 0x63ad0d8be0 , 5:3_https://www.zappos.com/, 0, , 1091 0x7f73b8cb6070 0x63ad125f60 
[1:1:0712/111746.137840:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.138134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111746.138278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.138826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1092, 7f73bb5fb8db
[1:1:0712/111746.156613:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1079 0x7f73b8cb6070 0x63ad0ebce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.156792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1079 0x7f73b8cb6070 0x63ad0ebce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.156964:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1104
[1:1:0712/111746.157086:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7f73b8cb6070 0x63ad144a60 , 5:3_https://www.zappos.com/, 0, , 1092 0x7f73b8cb6070 0x63ad1383e0 
[1:1:0712/111746.157280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.157548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111746.157689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.192898:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.193065:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111746.193230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.193809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.193924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.194485:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.194652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.194767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.195227:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.216033:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.216208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111746.216338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.216732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.216835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.217319:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.219315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.219501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.220023:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.220255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111746.220372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.220543:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.296750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111746.296947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111746.298217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1098, 7f73bb5fb8db
[1:1:0712/111746.316452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1084 0x7f73b8cb6070 0x63ad0b60e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.316691:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1084 0x7f73b8cb6070 0x63ad0b60e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.316895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1111
[1:1:0712/111746.316994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1111 0x7f73b8cb6070 0x63ad0ff9e0 , 5:3_https://www.zappos.com/, 0, , 1098 0x7f73b8cb6070 0x63ad15fd60 
[1:1:0712/111746.317219:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.317495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111746.317636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.335994:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1103, 7f73bb5fb8db
[1:1:0712/111746.353193:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1091 0x7f73b8cb6070 0x63ad125f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.353374:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1091 0x7f73b8cb6070 0x63ad125f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.353571:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1112
[1:1:0712/111746.353696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7f73b8cb6070 0x63ad0daee0 , 5:3_https://www.zappos.com/, 0, , 1103 0x7f73b8cb6070 0x63ad0d8be0 
[1:1:0712/111746.353923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.354240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111746.354378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.373633:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.373800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111746.373939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.374483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.374607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.375095:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.375299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.375452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.375920:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.376420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1104, 7f73bb5fb8db
[1:1:0712/111746.393280:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1092 0x7f73b8cb6070 0x63ad1383e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.393432:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1092 0x7f73b8cb6070 0x63ad1383e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.393601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1113
[1:1:0712/111746.393695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7f73b8cb6070 0x63ad0b7d60 , 5:3_https://www.zappos.com/, 0, , 1104 0x7f73b8cb6070 0x63ad144a60 
[1:1:0712/111746.393870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.394120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111746.394232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.412149:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.412326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111746.412483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.412880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.412997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.413494:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.413667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.413823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.414348:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.414661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111746.414769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.414935:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.500739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111746.500916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111746.502227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1112, 7f73bb5fb8db
[1:1:0712/111746.521680:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1103 0x7f73b8cb6070 0x63ad0d8be0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.521862:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1103 0x7f73b8cb6070 0x63ad0d8be0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.523008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1120
[1:1:0712/111746.523143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1120 0x7f73b8cb6070 0x63ad0e47e0 , 5:3_https://www.zappos.com/, 0, , 1112 0x7f73b8cb6070 0x63ad0daee0 
[1:1:0712/111746.523353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.523626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111746.523744:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.543791:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.543961:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111746.544089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.544633:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.544758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.545287:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.545488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.545643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.546349:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.565495:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.565928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111746.566069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.566459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.566585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.567073:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.567262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.567411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.567846:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.568052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111746.568170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.568347:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.630852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1113, 7f73bb5fb8db
[1:1:0712/111746.647346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1104 0x7f73b8cb6070 0x63ad144a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.647524:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1104 0x7f73b8cb6070 0x63ad144a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.647718:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1126
[1:1:0712/111746.647842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1126 0x7f73b8cb6070 0x63acfe4f60 , 5:3_https://www.zappos.com/, 0, , 1113 0x7f73b8cb6070 0x63ad0b7d60 
[1:1:0712/111746.648055:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.648860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111746.648989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.668676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111746.668824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111746.689021:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.695459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111746.695637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.696270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.696874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.698873:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.700235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.700421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.701007:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.722426:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.722642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111746.722773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.723168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.723271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.723734:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.723929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.724067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.724522:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.724779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111746.724893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.725073:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.790059:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1111, 7f73bb5fb8db
[1:1:0712/111746.807547:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1098 0x7f73b8cb6070 0x63ad15fd60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.807726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1098 0x7f73b8cb6070 0x63ad15fd60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.807912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1133
[1:1:0712/111746.808032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1133 0x7f73b8cb6070 0x63ad144ce0 , 5:3_https://www.zappos.com/, 0, , 1111 0x7f73b8cb6070 0x63ad0ff9e0 
[1:1:0712/111746.808250:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.808530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111746.808651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.809530:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1120, 7f73bb5fb8db
[1:1:0712/111746.827986:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1112 0x7f73b8cb6070 0x63ad0daee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.828173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1112 0x7f73b8cb6070 0x63ad0daee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.828372:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1135
[1:1:0712/111746.828482:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1135 0x7f73b8cb6070 0x63ad0da5e0 , 5:3_https://www.zappos.com/, 0, , 1120 0x7f73b8cb6070 0x63ad0e47e0 
[1:1:0712/111746.828665:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.828948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111746.829089:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.829626:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1088, 7f73bb5fb8db
[1:1:0712/111746.847134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1035 0x7f73b8cb6070 0x63ad103860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.848595:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1035 0x7f73b8cb6070 0x63ad103860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.848778:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1136
[1:1:0712/111746.848884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1136 0x7f73b8cb6070 0x63ad0af8e0 , 5:3_https://www.zappos.com/, 0, , 1088 0x7f73b8cb6070 0x63ace612e0 
[1:1:0712/111746.849103:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.849371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111746.849485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111746.871723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111746.871893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111746.892010:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1126, 7f73bb5fb8db
[1:1:0712/111746.911718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1113 0x7f73b8cb6070 0x63ad0b7d60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.911954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1113 0x7f73b8cb6070 0x63ad0b7d60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111746.912154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1140
[1:1:0712/111746.912278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7f73b8cb6070 0x63ad1ba6e0 , 5:3_https://www.zappos.com/, 0, , 1126 0x7f73b8cb6070 0x63acfe4f60 
[1:1:0712/111746.912493:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111746.912802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111746.912914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.934535:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.937278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111746.937524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.938211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.938387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.938961:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.939247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.939455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.940976:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.974679:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111746.974843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111746.974972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.975351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111746.975447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111746.975926:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.976109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111746.976237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111746.976724:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111746.976921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111746.977054:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111746.977249:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.022455:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1099, 7f73bb5fb8db
[1:1:0712/111747.041760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1049 0x7f73b8cb6070 0x63ad1526e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.041934:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1049 0x7f73b8cb6070 0x63ad1526e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.042111:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1145
[1:1:0712/111747.042206:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1145 0x7f73b8cb6070 0x63ad129060 , 5:3_https://www.zappos.com/, 0, , 1099 0x7f73b8cb6070 0x63ad0b3ee0 
[1:1:0712/111747.042392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.042667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111747.042806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.043273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.043396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.043856:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.044041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.044174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.044614:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.057139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.057303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.057742:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.057950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.058099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.058580:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.059009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.059172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111747.059730:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.059934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.060123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.060783:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.114319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111747.114660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111747.116528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1135, 7f73bb5fb8db
[1:1:0712/111747.136142:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1120 0x7f73b8cb6070 0x63ad0e47e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.136309:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1120 0x7f73b8cb6070 0x63ad0e47e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.136487:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1148
[1:1:0712/111747.136583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1148 0x7f73b8cb6070 0x63ad0b24e0 , 5:3_https://www.zappos.com/, 0, , 1135 0x7f73b8cb6070 0x63ad0da5e0 
[1:1:0712/111747.136784:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.137079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111747.137697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.159152:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.159303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111747.159418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.159799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.159897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.160372:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.160547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.160682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.161170:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.161385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111747.161500:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.161665:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.254861:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.255075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111747.255270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.255903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.256050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.256573:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.256777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.256909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.257376:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.257867:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1140, 7f73bb5fb8db
[1:1:0712/111747.275894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1126 0x7f73b8cb6070 0x63acfe4f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.276080:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1126 0x7f73b8cb6070 0x63acfe4f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.276267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1153
[1:1:0712/111747.276398:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1153 0x7f73b8cb6070 0x63ad1baf60 , 5:3_https://www.zappos.com/, 0, , 1140 0x7f73b8cb6070 0x63ad1ba6e0 
[1:1:0712/111747.276609:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.276913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111747.277024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.277800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1133, 7f73bb5fb8db
[1:1:0712/111747.296677:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1111 0x7f73b8cb6070 0x63ad0ff9e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.296897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1111 0x7f73b8cb6070 0x63ad0ff9e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.297109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1154
[1:1:0712/111747.297276:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1154 0x7f73b8cb6070 0x63ad0da560 , 5:3_https://www.zappos.com/, 0, , 1133 0x7f73b8cb6070 0x63ad144ce0 
[1:1:0712/111747.297564:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.297921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111747.298114:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.317594:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111747.317796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111747.337654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1102, 7f73bb5fb881
[1:1:0712/111747.356079:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1040 0x7f73b8cb6070 0x63ad10a9e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.356300:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1040 0x7f73b8cb6070 0x63ad10a9e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.356562:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.356893:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.356987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111747.357270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.357582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111747.357717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.357959:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111747.358258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111747.358381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.358658:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111747.359205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111747.359322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.359596:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111747.359782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111747.359870:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111747.360024:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1158
[1:1:0712/111747.360114:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1158 0x7f73b8cb6070 0x63ad0f2860 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1102 0x7f73b8cb6070 0x63ad0f3560 
[1:1:0712/111747.382305:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.382471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111747.382610:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.383321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.383463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.383967:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.384161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.384312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.384776:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.384991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111747.385115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.385318:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.446653:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1148, 7f73bb5fb8db
[1:1:0712/111747.465967:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1135 0x7f73b8cb6070 0x63ad0da5e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.466129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1135 0x7f73b8cb6070 0x63ad0da5e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.466307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1162
[1:1:0712/111747.466417:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1162 0x7f73b8cb6070 0x63ad166560 , 5:3_https://www.zappos.com/, 0, , 1148 0x7f73b8cb6070 0x63ad0b24e0 
[1:1:0712/111747.466616:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.466864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111747.466975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.467494:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1153, 7f73bb5fb8db
[1:1:0712/111747.486089:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1140 0x7f73b8cb6070 0x63ad1ba6e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.486244:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1140 0x7f73b8cb6070 0x63ad1ba6e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.486409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1163
[1:1:0712/111747.486514:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1163 0x7f73b8cb6070 0x63ad0d9260 , 5:3_https://www.zappos.com/, 0, , 1153 0x7f73b8cb6070 0x63ad1baf60 
[1:1:0712/111747.486693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.486943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111747.487063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.525744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111747.525908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111747.527323:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1154, 7f73bb5fb8db
[1:1:0712/111747.546965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1133 0x7f73b8cb6070 0x63ad144ce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.547142:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1133 0x7f73b8cb6070 0x63ad144ce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.547298:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1167
[1:1:0712/111747.547505:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f73b8cb6070 0x63ad0c25e0 , 5:3_https://www.zappos.com/, 0, , 1154 0x7f73b8cb6070 0x63ad0da560 
[1:1:0712/111747.547716:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.548012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111747.548164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.566640:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.566796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111747.566931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.567456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.567575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.568048:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.568233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.568378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.568823:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.589542:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.589710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111747.589863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.590261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.590384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.590871:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.591064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.591199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.591657:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.591879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111747.591993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.592150:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.657955:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1162, 7f73bb5fb8db
[1:1:0712/111747.678124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1148 0x7f73b8cb6070 0x63ad0b24e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.678341:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1148 0x7f73b8cb6070 0x63ad0b24e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.678540:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1173
[1:1:0712/111747.678665:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7f73b8cb6070 0x63ad0ecde0 , 5:3_https://www.zappos.com/, 0, , 1162 0x7f73b8cb6070 0x63ad166560 
[1:1:0712/111747.678891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.679280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111747.679426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.679997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1163, 7f73bb5fb8db
[1:1:0712/111747.699421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1153 0x7f73b8cb6070 0x63ad1baf60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.699575:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1153 0x7f73b8cb6070 0x63ad1baf60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.699761:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1174
[1:1:0712/111747.699867:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f73b8cb6070 0x63ad0e6f60 , 5:3_https://www.zappos.com/, 0, , 1163 0x7f73b8cb6070 0x63ad0d9260 
[1:1:0712/111747.700041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.700283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111747.700405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.719627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111747.719803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111747.721153:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1167, 7f73bb5fb8db
[1:1:0712/111747.741069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1154 0x7f73b8cb6070 0x63ad0da560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.741299:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1154 0x7f73b8cb6070 0x63ad0da560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.741480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1177
[1:1:0712/111747.741579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7f73b8cb6070 0x63ad14e260 , 5:3_https://www.zappos.com/, 0, , 1167 0x7f73b8cb6070 0x63ad0c25e0 
[1:1:0712/111747.741835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.742155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111747.742293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.779281:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.779449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111747.779600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.780165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.780268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.780758:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.780927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.781071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.781593:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.801219:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.801423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111747.801595:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.802005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.802103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.802597:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.802765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.802875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.803289:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.803494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111747.803625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.803816:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.851351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1136, 7f73bb5fb8db
[1:1:0712/111747.871930:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1088 0x7f73b8cb6070 0x63ace612e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.872101:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1088 0x7f73b8cb6070 0x63ace612e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.872278:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1184
[1:1:0712/111747.872387:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7f73b8cb6070 0x63ad0b6760 , 5:3_https://www.zappos.com/, 0, , 1136 0x7f73b8cb6070 0x63ad0af8e0 
[1:1:0712/111747.872557:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.872807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111747.872895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111747.882098:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1173, 7f73bb5fb8db
[1:1:0712/111747.906471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1162 0x7f73b8cb6070 0x63ad166560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.906642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1162 0x7f73b8cb6070 0x63ad166560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111747.906830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1186
[1:1:0712/111747.906941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7f73b8cb6070 0x63ad0e3ce0 , 5:3_https://www.zappos.com/, 0, , 1173 0x7f73b8cb6070 0x63ad0ecde0 
[1:1:0712/111747.907152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111747.907403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111747.907520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.946718:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111747.946861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111747.967840:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.967999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111747.968119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.968630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.968721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.969204:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.969389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.969541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.969978:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.988978:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111747.989211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111747.989402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.989854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111747.990022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111747.990538:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.990735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111747.990885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111747.991323:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111747.991550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111747.991671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111747.991865:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.036976:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1174, 7f73bb5fb8db
[1:1:0712/111748.058177:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1163 0x7f73b8cb6070 0x63ad0d9260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.058368:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1163 0x7f73b8cb6070 0x63ad0d9260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.058553:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1192
[1:1:0712/111748.058646:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1192 0x7f73b8cb6070 0x63ad0d8ee0 , 5:3_https://www.zappos.com/, 0, , 1174 0x7f73b8cb6070 0x63ad0e6f60 
[1:1:0712/111748.058854:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.059120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111748.059246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.080689:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1177, 7f73bb5fb8db
[1:1:0712/111748.103681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1167 0x7f73b8cb6070 0x63ad0c25e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.103885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1167 0x7f73b8cb6070 0x63ad0c25e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.104098:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1193
[1:1:0712/111748.104211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1193 0x7f73b8cb6070 0x63ad134d60 , 5:3_https://www.zappos.com/, 0, , 1177 0x7f73b8cb6070 0x63ad14e260 
[1:1:0712/111748.104417:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.104687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111748.104818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.105363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1145, 7f73bb5fb8db
[1:1:0712/111748.126311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1099 0x7f73b8cb6070 0x63ad0b3ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.126501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1099 0x7f73b8cb6070 0x63ad0b3ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.126705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1195
[1:1:0712/111748.127914:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1195 0x7f73b8cb6070 0x63ad104560 , 5:3_https://www.zappos.com/, 0, , 1145 0x7f73b8cb6070 0x63ad129060 
[1:1:0712/111748.128166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.128931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111748.129098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.129577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.129702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.130270:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.130463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.130654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.131155:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.144187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.144362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111748.144903:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.145122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.145275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.145817:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.146233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.146378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111748.146829:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.146997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.147202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.147682:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.187892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111748.188096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111748.228590:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.228761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111748.228892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.229288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.229412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.229895:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.230081:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.230221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.230691:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.230921:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111748.231034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111748.231208:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.296390:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.304899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111748.305071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.305764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.305920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.306462:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.306677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.306831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.307342:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.307901:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1186, 7f73bb5fb8db
[1:1:0712/111748.329100:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1173 0x7f73b8cb6070 0x63ad0ecde0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.329296:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1173 0x7f73b8cb6070 0x63ad0ecde0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.329507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1200
[1:1:0712/111748.329627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1200 0x7f73b8cb6070 0x63ad0e1660 , 5:3_https://www.zappos.com/, 0, , 1186 0x7f73b8cb6070 0x63ad0e3ce0 
[1:1:0712/111748.329941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.330246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111748.330363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.330901:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1192, 7f73bb5fb8db
[1:1:0712/111748.351021:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1174 0x7f73b8cb6070 0x63ad0e6f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.351214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1174 0x7f73b8cb6070 0x63ad0e6f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.351425:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1201
[1:1:0712/111748.351553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1201 0x7f73b8cb6070 0x63ad005360 , 5:3_https://www.zappos.com/, 0, , 1192 0x7f73b8cb6070 0x63ad0d8ee0 
[1:1:0712/111748.351762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.352053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111748.352194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.392187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111748.392355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111748.414486:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.414650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111748.414788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.415251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.415374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.415843:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.416008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.416128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.416562:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.416780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111748.416885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111748.417074:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.461482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1193, 7f73bb5fb8db
[1:1:0712/111748.479910:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1177 0x7f73b8cb6070 0x63ad14e260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.480094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1177 0x7f73b8cb6070 0x63ad14e260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.480289:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1209
[1:1:0712/111748.480389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1209 0x7f73b8cb6070 0x63a0f6d560 , 5:3_https://www.zappos.com/, 0, , 1193 0x7f73b8cb6070 0x63ad134d60 
[1:1:0712/111748.480615:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.480910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111748.481071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.481575:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1158, 7f73bb5fb881
[1:1:0712/111748.500564:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1102 0x7f73b8cb6070 0x63ad0f3560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.500763:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1102 0x7f73b8cb6070 0x63ad0f3560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.500907:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.501200:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.501298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111748.501423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.501675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111748.501756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.501922:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111748.502188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111748.502331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.502596:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111748.503152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111748.503273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111748.503551:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111748.503737:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111748.503833:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111748.504000:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1210
[1:1:0712/111748.504095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1210 0x7f73b8cb6070 0x63ad086ee0 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1158 0x7f73b8cb6070 0x63ad0f2860 
[1:1:0712/111748.525634:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1200, 7f73bb5fb8db
[1:1:0712/111748.546685:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1186 0x7f73b8cb6070 0x63ad0e3ce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.546851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1186 0x7f73b8cb6070 0x63ad0e3ce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.547027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1211
[1:1:0712/111748.547186:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1211 0x7f73b8cb6070 0x63ad0df760 , 5:3_https://www.zappos.com/, 0, , 1200 0x7f73b8cb6070 0x63ad0e1660 
[1:1:0712/111748.547678:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.547948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111748.548067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.569769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111748.569937:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111748.592033:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.592197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111748.592341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.592940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.593894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.594595:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.594799:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.594930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.595400:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.596040:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1201, 7f73bb5fb8db
[1:1:0712/111748.615644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1192 0x7f73b8cb6070 0x63ad0d8ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.616218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1192 0x7f73b8cb6070 0x63ad0d8ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.616435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1215
[1:1:0712/111748.616568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1215 0x7f73b8cb6070 0x63ad1479e0 , 5:3_https://www.zappos.com/, 0, , 1201 0x7f73b8cb6070 0x63ad005360 
[1:1:0712/111748.616884:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.617177:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111748.617328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.656795:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.656940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111748.657055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.657466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.657570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.657997:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.658152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.658263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.658671:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.658862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111748.659012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111748.659221:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.705045:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1209, 7f73bb5fb8db
[1:1:0712/111748.725277:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1193 0x7f73b8cb6070 0x63ad134d60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.725457:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1193 0x7f73b8cb6070 0x63ad134d60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.725629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1221
[1:1:0712/111748.725754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1221 0x7f73b8cb6070 0x63ad1661e0 , 5:3_https://www.zappos.com/, 0, , 1209 0x7f73b8cb6070 0x63a0f6d560 
[1:1:0712/111748.725944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.726213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111748.726335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.748221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111748.748383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111748.749689:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1211, 7f73bb5fb8db
[1:1:0712/111748.771027:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1200 0x7f73b8cb6070 0x63ad0e1660 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.771215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1200 0x7f73b8cb6070 0x63ad0e1660 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.771406:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1223
[1:1:0712/111748.771544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1223 0x7f73b8cb6070 0x63ad0cf860 , 5:3_https://www.zappos.com/, 0, , 1211 0x7f73b8cb6070 0x63ad0df760 
[1:1:0712/111748.771754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.772018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111748.772144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.827278:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.827465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111748.827623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.828034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.828157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.828662:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.828863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.828989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.829524:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.829784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111748.829923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111748.830109:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.893918:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111748.894096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111748.894228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.894802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111748.894927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111748.895421:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.895622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111748.895774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.896290:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111748.896805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1184, 7f73bb5fb8db
[1:1:0712/111748.915674:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1136 0x7f73b8cb6070 0x63ad0af8e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.915849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1136 0x7f73b8cb6070 0x63ad0af8e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.916040:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1229
[1:1:0712/111748.916165:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1229 0x7f73b8cb6070 0x63ad0173e0 , 5:3_https://www.zappos.com/, 0, , 1184 0x7f73b8cb6070 0x63ad0b6760 
[1:1:0712/111748.916364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.916658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111748.916765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111748.920567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1215, 7f73bb5fb8db
[1:1:0712/111748.940380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1201 0x7f73b8cb6070 0x63ad005360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.940564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1201 0x7f73b8cb6070 0x63ad005360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111748.940746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1231
[1:1:0712/111748.940831:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1231 0x7f73b8cb6070 0x63ad08f660 , 5:3_https://www.zappos.com/, 0, , 1215 0x7f73b8cb6070 0x63ad1479e0 
[1:1:0712/111748.941017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111748.941293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111748.941395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111748.983590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111748.983827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111748.987083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1223, 7f73bb5fb8db
[1:1:0712/111749.008968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1211 0x7f73b8cb6070 0x63ad0df760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.009366:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1211 0x7f73b8cb6070 0x63ad0df760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.009577:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1233
[1:1:0712/111749.009702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1233 0x7f73b8cb6070 0x63ad112d60 , 5:3_https://www.zappos.com/, 0, , 1223 0x7f73b8cb6070 0x63ad0cf860 
[1:1:0712/111749.009952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.010224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111749.010350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.010983:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1221, 7f73bb5fb8db
[1:1:0712/111749.032300:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1209 0x7f73b8cb6070 0x63a0f6d560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.032473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1209 0x7f73b8cb6070 0x63a0f6d560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.032655:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1235
[1:1:0712/111749.032757:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1235 0x7f73b8cb6070 0x63ad0c0ee0 , 5:3_https://www.zappos.com/, 0, , 1221 0x7f73b8cb6070 0x63ad1661e0 
[1:1:0712/111749.032953:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.033543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111749.033701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.054533:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.054697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111749.054834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.055232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.055363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.055888:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.056444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.056574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.057024:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.057275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111749.057394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111749.057577:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.128493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1195, 7f73bb5fb8db
[1:1:0712/111749.147961:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1145 0x7f73b8cb6070 0x63ad129060 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.148144:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1145 0x7f73b8cb6070 0x63ad129060 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.148368:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1241
[1:1:0712/111749.148499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1241 0x7f73b8cb6070 0x63ad0a84e0 , 5:3_https://www.zappos.com/, 0, , 1195 0x7f73b8cb6070 0x63ad104560 
[1:1:0712/111749.148716:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.149057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111749.149190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.149641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.149763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.150228:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.150414:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.150588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.151025:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.163332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.163515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111749.163977:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.164159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.164320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.164823:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.165244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.165396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111749.165973:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.166176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.166318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.166734:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.209982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111749.210798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111749.212580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1231, 7f73bb5fb8db
[1:1:0712/111749.235204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1215 0x7f73b8cb6070 0x63ad1479e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.245093:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1215 0x7f73b8cb6070 0x63ad1479e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.245332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1243
[1:1:0712/111749.245445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1243 0x7f73b8cb6070 0x63ad0ab7e0 , 5:3_https://www.zappos.com/, 0, , 1231 0x7f73b8cb6070 0x63ad08f660 
[1:1:0712/111749.245654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.245929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111749.246056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.289606:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.289812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111749.289951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.290557:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.290716:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.291279:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.291500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.291623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.292066:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.312936:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.313113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111749.313250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.313654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.313768:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.314239:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.314442:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.314601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.315115:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.315347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111749.315486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111749.315672:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.360406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1235, 7f73bb5fb8db
[1:1:0712/111749.379705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1221 0x7f73b8cb6070 0x63ad1661e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.379889:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1221 0x7f73b8cb6070 0x63ad1661e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.380059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1248
[1:1:0712/111749.380150:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1248 0x7f73b8cb6070 0x63ace5a560 , 5:3_https://www.zappos.com/, 0, , 1235 0x7f73b8cb6070 0x63ad0c0ee0 
[1:1:0712/111749.380322:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.380623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111749.380761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.381279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1233, 7f73bb5fb8db
[1:1:0712/111749.401057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1223 0x7f73b8cb6070 0x63ad0cf860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.401240:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1223 0x7f73b8cb6070 0x63ad0cf860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.401404:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1249
[1:1:0712/111749.401508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1249 0x7f73b8cb6070 0x63ad0b51e0 , 5:3_https://www.zappos.com/, 0, , 1233 0x7f73b8cb6070 0x63ad112d60 
[1:1:0712/111749.401700:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.401951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111749.402073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.445197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111749.445373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111749.469130:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.481217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111749.481587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.482312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.482474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.487356:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.487609:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.487775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.488477:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.489101:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1243, 7f73bb5fb8db
[1:1:0712/111749.510379:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1231 0x7f73b8cb6070 0x63ad08f660 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.510606:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1231 0x7f73b8cb6070 0x63ad08f660 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.510844:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1251
[1:1:0712/111749.511010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f73b8cb6070 0x63ad105360 , 5:3_https://www.zappos.com/, 0, , 1243 0x7f73b8cb6070 0x63ad0ab7e0 
[1:1:0712/111749.511245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.511538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111749.511692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.533245:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.533441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111749.533580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.533979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.534105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.534583:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.534772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.534919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.535352:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.535561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111749.535686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111749.535861:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.618852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111749.619019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111749.620292:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1249, 7f73bb5fb8db
[1:1:0712/111749.641320:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1233 0x7f73b8cb6070 0x63ad112d60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.641535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1233 0x7f73b8cb6070 0x63ad112d60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.641798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1260
[1:1:0712/111749.641898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1260 0x7f73b8cb6070 0x63ad0e33e0 , 5:3_https://www.zappos.com/, 0, , 1249 0x7f73b8cb6070 0x63ad0b51e0 
[1:1:0712/111749.642101:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.642370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111749.642484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.643077:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1210, 7f73bb5fb881
[1:1:0712/111749.664957:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1158 0x7f73b8cb6070 0x63ad0f2860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.665197:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1158 0x7f73b8cb6070 0x63ad0f2860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.665391:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.665667:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.665754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111749.665859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.666063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111749.666156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.666333:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111749.667070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111749.667221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.667767:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111749.668377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111749.668515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111749.668829:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111749.669014:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111749.669123:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111749.669581:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1262
[1:1:0712/111749.669747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1262 0x7f73b8cb6070 0x63ad0b5ce0 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1210 0x7f73b8cb6070 0x63ad086ee0 
[1:1:0712/111749.698564:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.698745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111749.698909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.699523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.699679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.700216:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.700402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.700540:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.701016:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.744592:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111749.744732:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111749.744832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.745231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111749.745317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111749.745820:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.745997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111749.746130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.746635:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.746880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111749.746997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111749.747147:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111749.792981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1248, 7f73bb5fb8db
[1:1:0712/111749.814283:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1235 0x7f73b8cb6070 0x63ad0c0ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.814465:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1235 0x7f73b8cb6070 0x63ad0c0ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.814658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1270
[1:1:0712/111749.814780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7f73b8cb6070 0x63ad0c3fe0 , 5:3_https://www.zappos.com/, 0, , 1248 0x7f73b8cb6070 0x63ace5a560 
[1:1:0712/111749.814978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.815250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111749.815389:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.815887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1251, 7f73bb5fb8db
[1:1:0712/111749.835705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1243 0x7f73b8cb6070 0x63ad0ab7e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.835879:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1243 0x7f73b8cb6070 0x63ad0ab7e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.836061:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1272
[1:1:0712/111749.836168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1272 0x7f73b8cb6070 0x63ad00f460 , 5:3_https://www.zappos.com/, 0, , 1251 0x7f73b8cb6070 0x63ad105360 
[1:1:0712/111749.836372:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.836638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111749.836764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111749.856400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , document.readyState
[1:1:0712/111749.856569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111749.878029:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1229, 7f73bb5fb8db
[1:1:0712/111749.900378:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1184 0x7f73b8cb6070 0x63ad0b6760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.905267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1184 0x7f73b8cb6070 0x63ad0b6760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.905508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1273
[1:1:0712/111749.905636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7f73b8cb6070 0x63ad1163e0 , 5:3_https://www.zappos.com/, 0, , 1229 0x7f73b8cb6070 0x63ad0173e0 
[1:1:0712/111749.905855:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.906156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111749.906266:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111749.910477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1260, 7f73bb5fb8db
[1:1:0712/111749.934356:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1249 0x7f73b8cb6070 0x63ad0b51e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.935133:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1249 0x7f73b8cb6070 0x63ad0b51e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111749.938080:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1276
[1:1:0712/111749.938220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1276 0x7f73b8cb6070 0x63ad09b1e0 , 5:3_https://www.zappos.com/, 0, , 1260 0x7f73b8cb6070 0x63ad0e33e0 
[1:1:0712/111749.938430:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111749.938704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111749.938829:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.053912:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.054134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111750.054317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.054977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.055136:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.055700:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.055886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.056020:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.056457:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.077580:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.077727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111750.077828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.078199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.078350:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.078940:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.079152:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.079375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.079927:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.080283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111750.080406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.080620:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.153366:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1241, 7f73bb5fb8db
[1:1:0712/111750.178192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1195 0x7f73b8cb6070 0x63ad104560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.178388:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1195 0x7f73b8cb6070 0x63ad104560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.178598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1284
[1:1:0712/111750.178723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1284 0x7f73b8cb6070 0x63ad083a60 , 5:3_https://www.zappos.com/, 0, , 1241 0x7f73b8cb6070 0x63ad0a84e0 
[1:1:0712/111750.178938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.179209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111750.179323:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.179829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.179927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.180501:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.180677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.180799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.181284:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.194470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.194692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.195260:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.206683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.206862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.207584:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.208028:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.208168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111750.208822:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.208992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.209155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.209593:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.255819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1272, 7f73bb5fb8db
[1:1:0712/111750.277808:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1251 0x7f73b8cb6070 0x63ad105360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.278018:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1251 0x7f73b8cb6070 0x63ad105360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.278221:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1286
[1:1:0712/111750.278330:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1286 0x7f73b8cb6070 0x63ad0b3e60 , 5:3_https://www.zappos.com/, 0, , 1272 0x7f73b8cb6070 0x63ad00f460 
[1:1:0712/111750.278532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.278797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111750.278923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.279430:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1276, 7f73bb5fb8db
[1:1:0712/111750.300383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1260 0x7f73b8cb6070 0x63ad0e33e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.300570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1260 0x7f73b8cb6070 0x63ad0e33e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.300746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1287
[1:1:0712/111750.300846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1287 0x7f73b8cb6070 0x63a0c33260 , 5:3_https://www.zappos.com/, 0, , 1276 0x7f73b8cb6070 0x63ad09b1e0 
[1:1:0712/111750.301005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.301281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111750.301420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.301954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1270, 7f73bb5fb8db
[1:1:0712/111750.322445:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1248 0x7f73b8cb6070 0x63ace5a560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.322611:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1248 0x7f73b8cb6070 0x63ace5a560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.322789:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1289
[1:1:0712/111750.322895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7f73b8cb6070 0x63acfe7560 , 5:3_https://www.zappos.com/, 0, , 1270 0x7f73b8cb6070 0x63ad0c3fe0 
[1:1:0712/111750.323085:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.323341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111750.323464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.364985:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.365166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111750.365310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.365894:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.366016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.366494:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.366681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.366827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.367278:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.387781:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.387932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111750.388076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.388562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.388730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.389225:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.389417:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.389561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.390034:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.390263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111750.390402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.390598:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.511717:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1286, 7f73bb5fb8db
[1:1:0712/111750.533545:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1272 0x7f73b8cb6070 0x63ad00f460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.533699:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1272 0x7f73b8cb6070 0x63ad00f460 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.533870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1294
[1:1:0712/111750.533971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1294 0x7f73b8cb6070 0x63ab2808e0 , 5:3_https://www.zappos.com/, 0, , 1286 0x7f73b8cb6070 0x63ad0b3e60 
[1:1:0712/111750.534170:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.534419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111750.534541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.555904:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.556096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111750.556258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.556838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.556944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.557439:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.557662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.557794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.558224:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.558947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1287, 7f73bb5fb8db
[1:1:0712/111750.578848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1276 0x7f73b8cb6070 0x63ad09b1e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.579056:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1276 0x7f73b8cb6070 0x63ad09b1e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.579241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1296
[1:1:0712/111750.579355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1296 0x7f73b8cb6070 0x63ad0857e0 , 5:3_https://www.zappos.com/, 0, , 1287 0x7f73b8cb6070 0x63a0c33260 
[1:1:0712/111750.579571:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.579845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111750.579961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.601291:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.601455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111750.601590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.601957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.602080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.602533:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.602711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.602853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.603284:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.603473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111750.603588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.603759:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.671030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1289, 7f73bb5fb8db
[1:1:0712/111750.692884:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1270 0x7f73b8cb6070 0x63ad0c3fe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.693076:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1270 0x7f73b8cb6070 0x63ad0c3fe0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.693286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1304
[1:1:0712/111750.693420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1304 0x7f73b8cb6070 0x63ad0d0560 , 5:3_https://www.zappos.com/, 0, , 1289 0x7f73b8cb6070 0x63acfe7560 
[1:1:0712/111750.693643:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.693932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111750.694064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.717860:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.718033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111750.718163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.718724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.718845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.719359:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.719558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.719710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.720180:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.742692:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.742840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111750.742952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.743348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.743440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.743922:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.744095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.744218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.744912:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.745161:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111750.745274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.745450:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.790525:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1296, 7f73bb5fb8db
[1:1:0712/111750.810959:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1287 0x7f73b8cb6070 0x63a0c33260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.811141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1287 0x7f73b8cb6070 0x63a0c33260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.811348:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1308
[1:1:0712/111750.811475:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1308 0x7f73b8cb6070 0x63ad008a60 , 5:3_https://www.zappos.com/, 0, , 1296 0x7f73b8cb6070 0x63ad0857e0 
[1:1:0712/111750.811686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.811978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111750.812108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.833633:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1294, 7f73bb5fb8db
[1:1:0712/111750.853525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1286 0x7f73b8cb6070 0x63ad0b3e60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.853711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1286 0x7f73b8cb6070 0x63ad0b3e60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.853898:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1311
[1:1:0712/111750.854021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1311 0x7f73b8cb6070 0x63ad0e47e0 , 5:3_https://www.zappos.com/, 0, , 1294 0x7f73b8cb6070 0x63ab2808e0 
[1:1:0712/111750.854217:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.854480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111750.854617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.855116:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1273, 7f73bb5fb8db
[1:1:0712/111750.874529:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1229 0x7f73b8cb6070 0x63ad0173e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.874704:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1229 0x7f73b8cb6070 0x63ad0173e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.874900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1312
[1:1:0712/111750.875021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1312 0x7f73b8cb6070 0x63a869d9e0 , 5:3_https://www.zappos.com/, 0, , 1273 0x7f73b8cb6070 0x63ad1163e0 
[1:1:0712/111750.875221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.875517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111750.875637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111750.900282:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.900425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111750.900548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.901101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.901208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.901667:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.901836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.901962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.902383:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.902830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1262, 7f73bb5fb881
[1:1:0712/111750.924856:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1210 0x7f73b8cb6070 0x63ad086ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.925115:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1210 0x7f73b8cb6070 0x63ad086ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111750.925318:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111750.925608:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.925697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111750.925803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.925999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111750.926093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.926272:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111750.926569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111750.926692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.926942:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111750.927484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111750.927597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.927870:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111750.928052:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111750.928129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111750.928333:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1316
[1:1:0712/111750.928422:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1316 0x7f73b8cb6070 0x63ad0b51e0 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1262 0x7f73b8cb6070 0x63ad0b5ce0 
[1:1:0712/111750.974496:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111750.974669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111750.975987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.977548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111750.977667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111750.978159:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.978335:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111750.986590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111750.989542:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111750.989841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111750.989988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111750.990215:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.042214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1304, 7f73bb5fb8db
[1:1:0712/111751.064276:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1289 0x7f73b8cb6070 0x63acfe7560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.064473:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1289 0x7f73b8cb6070 0x63acfe7560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.064675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1320
[1:1:0712/111751.064790:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7f73b8cb6070 0x63ad108a60 , 5:3_https://www.zappos.com/, 0, , 1304 0x7f73b8cb6070 0x63ad0d0560 
[1:1:0712/111751.064996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.065427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111751.065556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.066022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1284, 7f73bb5fb8db
[1:1:0712/111751.086348:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1241 0x7f73b8cb6070 0x63ad0a84e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.086533:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1241 0x7f73b8cb6070 0x63ad0a84e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.086734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1321
[1:1:0712/111751.086864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7f73b8cb6070 0x63ad004be0 , 5:3_https://www.zappos.com/, 0, , 1284 0x7f73b8cb6070 0x63ad083a60 
[1:1:0712/111751.087077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.087370:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111751.087522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.088006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.088154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.088674:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.088880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.089009:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.089465:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.101712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.101876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111751.102322:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.102496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.102638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.103101:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.103446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.103578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111751.104002:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.104171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.104337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.104756:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.145219:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1308, 7f73bb5fb8db
[1:1:0712/111751.167273:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1296 0x7f73b8cb6070 0x63ad0857e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.167436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1296 0x7f73b8cb6070 0x63ad0857e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.167596:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1322
[1:1:0712/111751.167683:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1322 0x7f73b8cb6070 0x63ad0e8260 , 5:3_https://www.zappos.com/, 0, , 1308 0x7f73b8cb6070 0x63ad008a60 
[1:1:0712/111751.167864:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.168120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111751.168222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.168734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1311, 7f73bb5fb8db
[1:1:0712/111751.190069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1294 0x7f73b8cb6070 0x63ab2808e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.190262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1294 0x7f73b8cb6070 0x63ab2808e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.190462:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1323
[1:1:0712/111751.190584:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1323 0x7f73b8cb6070 0x63ad0fe960 , 5:3_https://www.zappos.com/, 0, , 1311 0x7f73b8cb6070 0x63ad0e47e0 
[1:1:0712/111751.190781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.191051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111751.191197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.214942:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.219535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111751.219701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.222319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.222825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.223417:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.223650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.223794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.224259:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.247089:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.247249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111751.247356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.247744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.247871:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.248362:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.248556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.248699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.249215:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.249463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111751.249604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111751.249796:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.316752:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1322, 7f73bb5fb8db
[1:1:0712/111751.337467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1308 0x7f73b8cb6070 0x63ad008a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.337758:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1308 0x7f73b8cb6070 0x63ad008a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.337987:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1330
[1:1:0712/111751.338121:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1330 0x7f73b8cb6070 0x63ad017ee0 , 5:3_https://www.zappos.com/, 0, , 1322 0x7f73b8cb6070 0x63ad0e8260 
[1:1:0712/111751.338332:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.338610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111751.338731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.339273:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1323, 7f73bb5fb8db
[1969:1981:0712/111751.356192:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/111751.359694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1311 0x7f73b8cb6070 0x63ad0e47e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.359877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1311 0x7f73b8cb6070 0x63ad0e47e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.360066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1331
[1:1:0712/111751.360178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1331 0x7f73b8cb6070 0x63ad0913e0 , 5:3_https://www.zappos.com/, 0, , 1323 0x7f73b8cb6070 0x63ad0fe960 
[1:1:0712/111751.360401:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.361598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111751.361714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.382665:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.382823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111751.382963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.383504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.383627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.384116:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.384302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.384447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.384902:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.406397:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.406569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111751.406711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.407109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.407236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.407747:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.407938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.408082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.408537:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.408757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111751.408876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111751.409053:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.479126:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1320, 7f73bb5fb8db
[1:1:0712/111751.507235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1304 0x7f73b8cb6070 0x63ad0d0560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.507460:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1304 0x7f73b8cb6070 0x63ad0d0560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.507697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1337
[1:1:0712/111751.508036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7f73b8cb6070 0x63915794e0 , 5:3_https://www.zappos.com/, 0, , 1320 0x7f73b8cb6070 0x63ad108a60 
[1:1:0712/111751.509880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.510232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111751.510365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.535797:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.535989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111751.536150:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.536576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.536717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.537327:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.537895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.538021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.538532:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.538758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111751.538872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111751.539056:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.605972:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.606114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111751.606231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.606742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.606844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.607285:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.607449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.607563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.607964:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.608437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1330, 7f73bb5fb8db
[1:1:0712/111751.629642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1322 0x7f73b8cb6070 0x63ad0e8260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.629828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1322 0x7f73b8cb6070 0x63ad0e8260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.630030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1341
[1:1:0712/111751.630149:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1341 0x7f73b8cb6070 0x63918f6b60 , 5:3_https://www.zappos.com/, 0, , 1330 0x7f73b8cb6070 0x63ad017ee0 
[1:1:0712/111751.630355:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.630601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111751.630714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.651860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1331, 7f73bb5fb8db
[1:1:0712/111751.672862:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1323 0x7f73b8cb6070 0x63ad0fe960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.673068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1323 0x7f73b8cb6070 0x63ad0fe960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.673267:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1343
[1:1:0712/111751.673393:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1343 0x7f73b8cb6070 0x63a41d2b60 , 5:3_https://www.zappos.com/, 0, , 1331 0x7f73b8cb6070 0x63ad0913e0 
[1:1:0712/111751.673611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.673888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111751.674024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.674559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1337, 7f73bb5fb8db
[1:1:0712/111751.697910:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1320 0x7f73b8cb6070 0x63ad108a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.698072:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1320 0x7f73b8cb6070 0x63ad108a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.698243:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1344
[1:1:0712/111751.698338:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1344 0x7f73b8cb6070 0x63ad0830e0 , 5:3_https://www.zappos.com/, 0, , 1337 0x7f73b8cb6070 0x63915794e0 
[1:1:0712/111751.698523:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.698785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111751.698918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.724080:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.724269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111751.724399:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.724797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.724907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.725449:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.725693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.725818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.726320:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.726523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111751.726626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111751.726798:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.775597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1312, 7f73bb5fb8db
[1:1:0712/111751.798832:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1273 0x7f73b8cb6070 0x63ad1163e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.799035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1273 0x7f73b8cb6070 0x63ad1163e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.799236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1350
[1:1:0712/111751.799357:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1350 0x7f73b8cb6070 0x63ad0ac360 , 5:3_https://www.zappos.com/, 0, , 1312 0x7f73b8cb6070 0x63a869d9e0 
[1:1:0712/111751.799549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.799816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111751.799925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111751.825125:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1341, 7f73bb5fb8db
[1:1:0712/111751.847205:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1330 0x7f73b8cb6070 0x63ad017ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.847441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1330 0x7f73b8cb6070 0x63ad017ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.847771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1354
[1:1:0712/111751.848444:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1354 0x7f73b8cb6070 0x63ad0b38e0 , 5:3_https://www.zappos.com/, 0, , 1341 0x7f73b8cb6070 0x63918f6b60 
[1:1:0712/111751.848731:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.849076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111751.849257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.849785:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1343, 7f73bb5fb8db
[1:1:0712/111751.871069:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1331 0x7f73b8cb6070 0x63ad0913e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.871262:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1331 0x7f73b8cb6070 0x63ad0913e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111751.871464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1355
[1:1:0712/111751.871578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1355 0x7f73b8cb6070 0x63ad0e36e0 , 5:3_https://www.zappos.com/, 0, , 1343 0x7f73b8cb6070 0x63a41d2b60 
[1:1:0712/111751.871775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111751.872042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111751.872170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.893872:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.894050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111751.894198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.894586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.894711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.895204:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.895401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.895553:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.896175:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.896412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111751.896542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111751.896729:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.968000:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111751.968213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111751.968374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.968979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111751.969097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111751.969657:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111751.971093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111751.971270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111751.971801:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.017895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1344, 7f73bb5fb8db
[1:1:0712/111752.041359:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1337 0x7f73b8cb6070 0x63915794e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.041530:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1337 0x7f73b8cb6070 0x63915794e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.041717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1361
[1:1:0712/111752.041878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1361 0x7f73b8cb6070 0x6391578960 , 5:3_https://www.zappos.com/, 0, , 1344 0x7f73b8cb6070 0x63ad0830e0 
[1:1:0712/111752.042152:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.042494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111752.042695:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.043424:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1321, 7f73bb5fb8db
[1:1:0712/111752.065708:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1284 0x7f73b8cb6070 0x63ad083a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.065895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1284 0x7f73b8cb6070 0x63ad083a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.066127:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1362
[1:1:0712/111752.066288:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1362 0x7f73b8cb6070 0x63a0c3a3e0 , 5:3_https://www.zappos.com/, 0, , 1321 0x7f73b8cb6070 0x63ad004be0 
[1:1:0712/111752.066532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.066819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111752.066939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.067387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.067485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.067949:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.068108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.068227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.068657:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.081601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.081794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.082304:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.082509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.082660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.083165:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.083602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.083748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111752.084177:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.084346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.084506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.084941:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.108762:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.108928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111752.109050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.109474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.109603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.110089:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.110264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.110398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.110837:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.111066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111752.111183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.111356:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.181777:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1354, 7f73bb5fb8db
[1:1:0712/111752.204553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1341 0x7f73b8cb6070 0x63918f6b60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.204747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1341 0x7f73b8cb6070 0x63918f6b60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.204937:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1367
[1:1:0712/111752.205021:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1367 0x7f73b8cb6070 0x63ad0e73e0 , 5:3_https://www.zappos.com/, 0, , 1354 0x7f73b8cb6070 0x63ad0b38e0 
[1:1:0712/111752.205288:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.205576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111752.205724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.206306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1355, 7f73bb5fb8db
[1:1:0712/111752.254580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1343 0x7f73b8cb6070 0x63a41d2b60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.254838:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1343 0x7f73b8cb6070 0x63a41d2b60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.255082:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1368
[1:1:0712/111752.255259:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1368 0x7f73b8cb6070 0x63a0f74f60 , 5:3_https://www.zappos.com/, 0, , 1355 0x7f73b8cb6070 0x63ad0e36e0 
[1:1:0712/111752.255535:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.255857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111752.255986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.256679:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1316, 7f73bb5fb881
[1:1:0712/111752.279439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1262 0x7f73b8cb6070 0x63ad0b5ce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.279673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1262 0x7f73b8cb6070 0x63ad0b5ce0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.279968:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.280258:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.281154:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111752.281327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.281852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111752.281992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.282197:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111752.282562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111752.282730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.282993:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111752.283565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111752.283688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.283963:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111752.284144:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111752.284220:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111752.284388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1370
[1:1:0712/111752.284499:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1370 0x7f73b8cb6070 0x63a0f5f560 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1316 0x7f73b8cb6070 0x63ad0b51e0 
[1:1:0712/111752.306957:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.307104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111752.307248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.307622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.307750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.308204:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.308399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.308528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.309386:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.309971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111752.310112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.310322:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.375727:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1361, 7f73bb5fb8db
[1:1:0712/111752.396237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1344 0x7f73b8cb6070 0x63ad0830e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.396453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1344 0x7f73b8cb6070 0x63ad0830e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.396653:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1375
[1:1:0712/111752.396795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1375 0x7f73b8cb6070 0x63a0f5af60 , 5:3_https://www.zappos.com/, 0, , 1361 0x7f73b8cb6070 0x6391578960 
[1:1:0712/111752.397000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.397293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111752.397427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.421312:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.421511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111752.421688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.422322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.422449:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.422981:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.423211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.423359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.423885:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.452521:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.452746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111752.452899:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.453363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.453502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.454054:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.454270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.454431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.454937:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.455195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111752.455321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.455534:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.520358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1367, 7f73bb5fb8db
[1:1:0712/111752.543124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1354 0x7f73b8cb6070 0x63ad0b38e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.543332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1354 0x7f73b8cb6070 0x63ad0b38e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.543520:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1379
[1:1:0712/111752.543633:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1379 0x7f73b8cb6070 0x63ad014860 , 5:3_https://www.zappos.com/, 0, , 1367 0x7f73b8cb6070 0x63ad0e73e0 
[1:1:0712/111752.543820:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.544073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111752.544187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.566981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1368, 7f73bb5fb8db
[1:1:0712/111752.588833:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1355 0x7f73b8cb6070 0x63ad0e36e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.589003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1355 0x7f73b8cb6070 0x63ad0e36e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.589231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1381
[1:1:0712/111752.589412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1381 0x7f73b8cb6070 0x63ad0100e0 , 5:3_https://www.zappos.com/, 0, , 1368 0x7f73b8cb6070 0x63a0f74f60 
[1:1:0712/111752.589667:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.589995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111752.590181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.611623:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.611827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111752.611960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.612421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.612521:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.613053:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.613251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.613405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.613889:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.614299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111752.614426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.614611:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.684831:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.685047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111752.685233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.685880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.686017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.686551:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.686756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.686892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.687468:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.688000:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1375, 7f73bb5fb8db
[1:1:0712/111752.725303:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1361 0x7f73b8cb6070 0x6391578960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.725531:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1361 0x7f73b8cb6070 0x6391578960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.725770:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1387
[1:1:0712/111752.725952:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1387 0x7f73b8cb6070 0x63ad0a8ee0 , 5:3_https://www.zappos.com/, 0, , 1375 0x7f73b8cb6070 0x63a0f5af60 
[1:1:0712/111752.726221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.726561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111752.726811:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.750278:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1379, 7f73bb5fb8db
[1:1:0712/111752.771750:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1367 0x7f73b8cb6070 0x63ad0e73e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.771906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1367 0x7f73b8cb6070 0x63ad0e73e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.772083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1388
[1:1:0712/111752.772177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1388 0x7f73b8cb6070 0x63ad005360 , 5:3_https://www.zappos.com/, 0, , 1379 0x7f73b8cb6070 0x63ad014860 
[1:1:0712/111752.772375:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.772615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111752.772723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.773232:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1381, 7f73bb5fb8db
[1:1:0712/111752.794831:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1368 0x7f73b8cb6070 0x63a0f74f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.795017:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1368 0x7f73b8cb6070 0x63a0f74f60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.795219:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1389
[1:1:0712/111752.795346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1389 0x7f73b8cb6070 0x63ad140a60 , 5:3_https://www.zappos.com/, 0, , 1381 0x7f73b8cb6070 0x63ad0100e0 
[1:1:0712/111752.795597:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.795889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111752.796049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.819024:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.819183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111752.819326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.819749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.819869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.822794:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.823178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.823335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.823828:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.824049:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111752.824181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111752.824373:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.868938:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1350, 7f73bb5fb8db
[1:1:0712/111752.892036:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1312 0x7f73b8cb6070 0x63a869d9e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.898928:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1312 0x7f73b8cb6070 0x63a869d9e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.899825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1397
[1:1:0712/111752.899959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1397 0x7f73b8cb6070 0x6394bd6fe0 , 5:3_https://www.zappos.com/, 0, , 1350 0x7f73b8cb6070 0x63ad0ac360 
[1:1:0712/111752.900171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.900472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111752.900560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111752.928811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1388, 7f73bb5fb8db
[1:1:0712/111752.961019:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1379 0x7f73b8cb6070 0x63ad014860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.961219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1379 0x7f73b8cb6070 0x63ad014860 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111752.961424:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1399
[1:1:0712/111752.961550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1399 0x7f73b8cb6070 0x63aceb9260 , 5:3_https://www.zappos.com/, 0, , 1388 0x7f73b8cb6070 0x63ad005360 
[1:1:0712/111752.961764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111752.962055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111752.962200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.985106:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111752.985245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111752.985354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.985872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111752.985965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111752.986434:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111752.986586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111752.986739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111752.987195:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.010349:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.010518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111753.010658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.011039:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.011159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.011633:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.011821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.011970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.012463:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.012695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111753.012826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.013011:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.058004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1389, 7f73bb5fb8db
[1:1:0712/111753.079511:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1381 0x7f73b8cb6070 0x63ad0100e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.079694:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1381 0x7f73b8cb6070 0x63ad0100e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.079879:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1404
[1:1:0712/111753.079997:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7f73b8cb6070 0x63ad1402e0 , 5:3_https://www.zappos.com/, 0, , 1389 0x7f73b8cb6070 0x63ad140a60 
[1:1:0712/111753.080197:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.080448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111753.080565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.102813:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1387, 7f73bb5fb8db
[1:1:0712/111753.126486:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1375 0x7f73b8cb6070 0x63a0f5af60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.126661:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1375 0x7f73b8cb6070 0x63a0f5af60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.126832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1406
[1:1:0712/111753.126928:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1406 0x7f73b8cb6070 0x63ad0e9060 , 5:3_https://www.zappos.com/, 0, , 1387 0x7f73b8cb6070 0x63ad0a8ee0 
[1:1:0712/111753.127111:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.127369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111753.127482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.127946:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1362, 7f73bb5fb8db
[1:1:0712/111753.151288:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1321 0x7f73b8cb6070 0x63ad004be0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.151448:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1321 0x7f73b8cb6070 0x63ad004be0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.151613:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1407
[1:1:0712/111753.151715:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1407 0x7f73b8cb6070 0x63ad0922e0 , 5:3_https://www.zappos.com/, 0, , 1362 0x7f73b8cb6070 0x63a0c3a3e0 
[1:1:0712/111753.151937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.152221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111753.152354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.152796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.152912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.153423:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.154042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.154210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.154728:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.167869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.168040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.168519:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.168706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.168854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.169331:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.169737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.169880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111753.170346:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.173295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.173488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.174003:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.224336:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.224529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111753.224663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.225239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.225384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.225944:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.226150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.226306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.226793:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.272344:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.272500:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111753.272609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.272976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.273097:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.273594:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.273780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.273914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.274366:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.274586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111753.274702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.274876:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.318919:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1399, 7f73bb5fb8db
[1:1:0712/111753.342448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1388 0x7f73b8cb6070 0x63ad005360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.342635:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1388 0x7f73b8cb6070 0x63ad005360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.342811:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1413
[1:1:0712/111753.342904:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1413 0x7f73b8cb6070 0x63ad000ae0 , 5:3_https://www.zappos.com/, 0, , 1399 0x7f73b8cb6070 0x63aceb9260 
[1:1:0712/111753.343085:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.343341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111753.343450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.344019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1404, 7f73bb5fb8db
[1:1:0712/111753.376735:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1389 0x7f73b8cb6070 0x63ad140a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.376955:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1389 0x7f73b8cb6070 0x63ad140a60 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.377162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1414
[1:1:0712/111753.378127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1414 0x7f73b8cb6070 0x63ad094960 , 5:3_https://www.zappos.com/, 0, , 1404 0x7f73b8cb6070 0x63ad1402e0 
[1:1:0712/111753.378356:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.378792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111753.378931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.406001:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.406188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111753.406315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.406725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.406834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.407343:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.407556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.407692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.408176:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.408402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111753.408517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.408707:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.500598:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.500782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111753.500956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.501508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.501659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.502177:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.502403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.502593:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.503055:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.503544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1370, 7f73bb5fb881
[1:1:0712/111753.524879:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1316 0x7f73b8cb6070 0x63ad0b51e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.525129:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1316 0x7f73b8cb6070 0x63ad0b51e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.525284:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.525544:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.525625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111753.525739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.525942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111753.526036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.526214:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111753.526493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111753.526775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.527033:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111753.527674:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111753.527817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.528119:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111753.528325:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111753.528438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111753.528615:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1419
[1:1:0712/111753.528735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1419 0x7f73b8cb6070 0x63ad13f260 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1370 0x7f73b8cb6070 0x63a0f5f560 
[1:1:0712/111753.529318:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1406, 7f73bb5fb8db
[1:1:0712/111753.551777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1387 0x7f73b8cb6070 0x63ad0a8ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.551962:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1387 0x7f73b8cb6070 0x63ad0a8ee0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.552154:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1420
[1:1:0712/111753.552280:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1420 0x7f73b8cb6070 0x63a09346e0 , 5:3_https://www.zappos.com/, 0, , 1406 0x7f73b8cb6070 0x63ad0e9060 
[1:1:0712/111753.552495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.552764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111753.552891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.579738:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.579913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111753.580046:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.580439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.580525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.581017:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.581333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.581572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.582176:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.582423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111753.582566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.582754:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.666031:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1413, 7f73bb5fb8db
[1:1:0712/111753.689368:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1399 0x7f73b8cb6070 0x63aceb9260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.689581:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1399 0x7f73b8cb6070 0x63aceb9260 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.689833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1425
[1:1:0712/111753.689989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1425 0x7f73b8cb6070 0x63ad09b160 , 5:3_https://www.zappos.com/, 0, , 1413 0x7f73b8cb6070 0x63ad000ae0 
[1:1:0712/111753.690215:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.690541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111753.690692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.691254:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1414, 7f73bb5fb8db
[1:1:0712/111753.713619:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1404 0x7f73b8cb6070 0x63ad1402e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.713779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1404 0x7f73b8cb6070 0x63ad1402e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.713956:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1427
[1:1:0712/111753.714072:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1427 0x7f73b8cb6070 0x639195ace0 , 5:3_https://www.zappos.com/, 0, , 1414 0x7f73b8cb6070 0x63ad094960 
[1:1:0712/111753.714299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.714589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111753.714724:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.737870:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.738033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111753.738169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.738717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.738837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.739325:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.739517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.739649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.740099:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.763521:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.763710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111753.763852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.764283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.764391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.764979:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.765191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.765349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.765865:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.766087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111753.766221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.766449:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.839580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1397, 7f73bb5fb8db
[1:1:0712/111753.868887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1350 0x7f73b8cb6070 0x63ad0ac360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.869145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1350 0x7f73b8cb6070 0x63ad0ac360 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.869422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1434
[1:1:0712/111753.869565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1434 0x7f73b8cb6070 0x63ad10a560 , 5:3_https://www.zappos.com/, 0, , 1397 0x7f73b8cb6070 0x6394bd6fe0 
[1:1:0712/111753.869799:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.870121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.zappos.com/, 166af5e22860, , , (){m=new Date;n=m.getTime()-g.getTime();n>f&&(c=a.windowStorage.get("windowId"),b=Annapurna.CookieSt
[1:1:0712/111753.870272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 1, , , 0
[1:1:0712/111753.877000:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1425, 7f73bb5fb8db
[1:1:0712/111753.900053:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1413 0x7f73b8cb6070 0x63ad000ae0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.900275:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1413 0x7f73b8cb6070 0x63ad000ae0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111753.900504:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1436
[1:1:0712/111753.900643:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1436 0x7f73b8cb6070 0x63918d14e0 , 5:3_https://www.zappos.com/, 0, , 1425 0x7f73b8cb6070 0x63ad09b160 
[1:1:0712/111753.900869:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111753.901151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111753.901291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.924004:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.924145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111753.924253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.924775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.924875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.925372:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.925576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.925723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.926390:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.950401:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111753.950596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111753.950773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.951207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111753.951365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111753.951844:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.952008:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111753.952125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111753.952619:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111753.952831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111753.952934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111753.953114:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.019629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1427, 7f73bb5fb8db
[1:1:0712/111754.043039:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1414 0x7f73b8cb6070 0x63ad094960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.043204:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1414 0x7f73b8cb6070 0x63ad094960 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.043373:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1441
[1:1:0712/111754.043467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7f73b8cb6070 0x63a0f62160 , 5:3_https://www.zappos.com/, 0, , 1427 0x7f73b8cb6070 0x639195ace0 
[1:1:0712/111754.043708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.043978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111754.044091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.044604:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1420, 7f73bb5fb8db
[1:1:0712/111754.070161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1406 0x7f73b8cb6070 0x63ad0e9060 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.070332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1406 0x7f73b8cb6070 0x63ad0e9060 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.070500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1442
[1:1:0712/111754.070805:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1442 0x7f73b8cb6070 0x63915007e0 , 5:3_https://www.zappos.com/, 0, , 1420 0x7f73b8cb6070 0x63a09346e0 
[1:1:0712/111754.071014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.071312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111754.071457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.071947:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1407, 7f73bb5fb8db
[1:1:0712/111754.103718:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1362 0x7f73b8cb6070 0x63a0c3a3e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.103920:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1362 0x7f73b8cb6070 0x63a0c3a3e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.104156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1443
[1:1:0712/111754.104302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1443 0x7f73b8cb6070 0x63a8d6de60 , 5:3_https://www.zappos.com/, 0, , 1407 0x7f73b8cb6070 0x63ad0922e0 
[1:1:0712/111754.104495:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.104769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (){var a=q&&q.memory&&q.memory.usedJSHeapSize;a&&b.set("mem",a);r=s.length;b.set("domsz",l.documentE
[1:1:0712/111754.104897:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.105377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.105480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.105952:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.106117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.106237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.106672:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.119787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.120022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111754.120517:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.120695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.120854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 5, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.121400:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.121782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.121921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 6, , , 0
[1:1:0712/111754.122357:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.122516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.122660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 7, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.123101:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.g [as set] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.190557:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.190711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111754.190833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.191348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.191451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.191915:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.192100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.192238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.192721:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.216480:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.216622:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111754.216725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.217103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.217193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.217684:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.217867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.218011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.218445:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.218671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111754.218801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111754.218973:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.262836:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1436, 7f73bb5fb8db
[1:1:0712/111754.288266:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1425 0x7f73b8cb6070 0x63ad09b160 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.288452:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1425 0x7f73b8cb6070 0x63ad09b160 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.288656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1449
[1:1:0712/111754.288763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1449 0x7f73b8cb6070 0x63ad08c760 , 5:3_https://www.zappos.com/, 0, , 1436 0x7f73b8cb6070 0x63918d14e0 
[1:1:0712/111754.288944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.289212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111754.289359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.289906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1441, 7f73bb5fb8db
[1:1:0712/111754.316858:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1427 0x7f73b8cb6070 0x639195ace0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.317057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1427 0x7f73b8cb6070 0x639195ace0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.317297:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1450
[1:1:0712/111754.317658:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1450 0x7f73b8cb6070 0x63ad087260 , 5:3_https://www.zappos.com/, 0, , 1441 0x7f73b8cb6070 0x63a0f62160 
[1:1:0712/111754.317955:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.318445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111754.318575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.367513:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.367675:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111754.367812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.368362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.368471:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.368955:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.369172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.369368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.369841:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.394638:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.394814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111754.394955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.395352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.395464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.395917:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.396072:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.396186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.396630:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.396841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111754.396972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111754.398541:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.442397:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1449, 7f73bb5fb8db
[1:1:0712/111754.465605:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1436 0x7f73b8cb6070 0x63918d14e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.465782:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1436 0x7f73b8cb6070 0x63918d14e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.465964:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1457
[1:1:0712/111754.466086:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1457 0x7f73b8cb6070 0x63a09e7460 , 5:3_https://www.zappos.com/, 0, , 1449 0x7f73b8cb6070 0x63ad08c760 
[1:1:0712/111754.466283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.466587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111754.466725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.467221:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1442, 7f73bb5fb8db
[1:1:0712/111754.489074:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1420 0x7f73b8cb6070 0x63a09346e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.489263:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1420 0x7f73b8cb6070 0x63a09346e0 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.489445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1458
[1:1:0712/111754.489565:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1458 0x7f73b8cb6070 0x63ad0ab060 , 5:3_https://www.zappos.com/, 0, , 1442 0x7f73b8cb6070 0x63915007e0 
[1:1:0712/111754.489765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.490038:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , i, (){if(s!==p||t!==q){if(Math.round(Math.sqrt(Math.pow(t-q,2)+Math.pow(s-p,2)))>=n){b.log(k,BOOMR.now(
[1:1:0712/111754.490177:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.539006:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.539182:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , d, (a){var b,d;if(p){b=a.getEntries();Array.prototype.push.apply(o,b);for(d=0;d<b.length;d++)q+=b[d].du
[1:1:0712/111754.539312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.539873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.539985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.540516:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.540694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.540815:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.541333:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	PerformanceObserver.d (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.541839:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1450, 7f73bb5fb8db
[1:1:0712/111754.566861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1441 0x7f73b8cb6070 0x63a0f62160 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.577476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1441 0x7f73b8cb6070 0x63a0f62160 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.577672:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1461
[1:1:0712/111754.577785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1461 0x7f73b8cb6070 0x63ad007ee0 , 5:3_https://www.zappos.com/, 0, , 1450 0x7f73b8cb6070 0x63ad087260 
[1:1:0712/111754.578009:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.578316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(u,100);0!==a&&b.set("mousepct",a);u=0}
[1:1:0712/111754.585409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.610881:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.611101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , c, (d){if(n){d-j>=k&&m++;j=d;l++;b.increment("fps");a.requestAnimationFrame(c)}}
[1:1:0712/111754.611331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.611917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, now, 
[1:1:0712/111754.612083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.612688:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.612908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, round, 
[1:1:0712/111754.613080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.613560:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.j.function.j.now.test.j.timing.j.timing.navigationStart.c.now (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	Object.h [as increment] (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.613774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, requestAnimationFrame, 
[1:1:0712/111754.613895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111754.614132:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)

[1:1:0712/111754.658603:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1457, 7f73bb5fb8db
[1:1:0712/111754.681979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1449 0x7f73b8cb6070 0x63ad08c760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.682137:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1449 0x7f73b8cb6070 0x63ad08c760 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.682308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1468
[1:1:0712/111754.682411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1468 0x7f73b8cb6070 0x63ad08fd60 , 5:3_https://www.zappos.com/, 0, , 1457 0x7f73b8cb6070 0x63a09e7460 
[1:1:0712/111754.682598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.682845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , g, (){var a=Math.min(q,100);0!==a&&b.set("scrollpct",a);q=0}
[1:1:0712/111754.682965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.705509:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1419, 7f73bb5fb881
[1:1:0712/111754.727158:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"166af5f54420166af5e22860166af5f54420166af5e22860","ptid":"1370 0x7f73b8cb6070 0x63a0f5f560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.727399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/","ptid":"1370 0x7f73b8cb6070 0x63a0f5f560 ","rf":"5:3_https://www.zappos.com/"}
[1:1:0712/111754.727585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zappos.com/"
[1:1:0712/111754.727875:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:4_https://www.zappos.com/, 5:3_https://www.zappos.com/
[1:1:0712/111754.727990:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.zappos.com/, 166af5f54420, , , (){try{return a.apply(c,arguments)}catch(e){if(-2146823277===e.number&&(d===BOOMR.plugins.Errors.VIA
[1:1:0712/111754.728115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 1, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.728344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111754.728469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 2, , , 0
[1:1:0712/111754.728665:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111754.728977:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/, 166af5f54420, 166af5e22860, c.(anonymous function), (){try{var i=Array.prototype.slice.call(arguments),j=i[e],k=d?this===window?BOOMR.window:this:c,l=b.
[1:1:0712/111754.729123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 4, 3, https://www.zappos.com, www.zappos.com, 3
[1:1:0712/111754.730667:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111754.731270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 166af5e22860, 166af5f54420, apply, 
[1:1:0712/111754.731414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zappos.com/", "www.zappos.com", 3, 4, , , 0
[1:1:0712/111754.731742:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	c.(anonymous function) (https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1)
	e.flushEvents (https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1)
	https://www.zappos.com/karakoram/js/main.f3394d9.js:1:1
	https://s.go-mpulse.net/boomerang/4R6KY-DUC9X-4J4BJ-TW8RG-UMPUN:1:1

[1:1:0712/111754.731934:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x1b55530029c8, 0x6391744150
[1:1:0712/111754.732031:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zappos.com/", 1000
[1:1:0712/111754.732195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.zappos.com/, 1470
[1:1:0712/111754.732319:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1470 0x7f73b8cb6070 0x6391579360 , 5:3_https://www.zappos.com/, 4, -5:4_https://www.zappos.com/-5:3_https://www.zappos.com/-5:4_https://www.zappos.com/-5:3_https://www.zappos.com/, 1419 0x7f73b8cb6070 0x63ad13f260 
[1:1:0712/111754.732912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://www.zappos.com/, 1458, 7f73bb5fb8db
