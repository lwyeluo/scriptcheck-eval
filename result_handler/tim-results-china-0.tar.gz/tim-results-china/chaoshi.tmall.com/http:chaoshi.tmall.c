[0712/143522.283819:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143522.284057:INFO:switcher_clone.cc(787)] backtrace rip is 7f148feb6891
[0712/143522.843423:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143522.843668:INFO:switcher_clone.cc(787)] backtrace rip is 7f5850596891
[1:1:0712/143522.847466:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/143522.847633:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/143522.850339:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[5184:5184:0712/143523.582510:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0a03d00b-0a1c-4dc4-b565-aff180673811
[0712/143523.665516:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/143523.665773:INFO:switcher_clone.cc(787)] backtrace rip is 7f2253948891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5216:5216:0712/143523.812268:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5216
[5229:5229:0712/143523.812663:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5229
[5184:5184:0712/143523.844470:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5184:5214:0712/143523.844886:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/143523.845002:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143523.845172:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143523.845490:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143523.845611:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/143523.847408:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x7b3ce4d, 1
[1:1:0712/143523.847605:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2f63c766, 0
[1:1:0712/143523.847701:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xfe10721, 3
[1:1:0712/143523.847781:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x38838ab1, 2
[1:1:0712/143523.847879:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 66ffffffc7632f 4dffffffceffffffb307 ffffffb1ffffff8affffff8338 2107ffffffe10f , 10104, 4
[1:1:0712/143523.848599:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5184:5214:0712/143523.848719:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGf�c/Mγ���8!�!�'
[5184:5214:0712/143523.848760:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is f�c/Mγ���8!��x!�'
[5184:5214:0712/143523.848899:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[5184:5214:0712/143523.848929:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5237, 4, 66c7632f 4dceb307 b18a8338 2107e10f 
[1:1:0712/143523.849178:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f584e7d00a0, 3
[1:1:0712/143523.849281:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f584e95c080, 2
[1:1:0712/143523.849365:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f583861ed20, -2
[1:1:0712/143523.857357:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143523.857836:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38838ab1
[1:1:0712/143523.858352:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38838ab1
[1:1:0712/143523.859168:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38838ab1
[1:1:0712/143523.859752:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.859872:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.859988:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.860099:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.860356:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38838ab1
[1:1:0712/143523.860488:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58505967ba
[1:1:0712/143523.860545:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f585058ddef, 7f585059677a, 7f58505980cf
[1:1:0712/143523.862317:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 38838ab1
[1:1:0712/143523.862503:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 38838ab1
[1:1:0712/143523.862824:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 38838ab1
[1:1:0712/143523.863665:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.863773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.863850:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.863924:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 38838ab1
[1:1:0712/143523.864433:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 38838ab1
[1:1:0712/143523.864603:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58505967ba
[1:1:0712/143523.864668:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f585058ddef, 7f585059677a, 7f58505980cf
[1:1:0712/143523.867363:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143523.867536:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143523.867603:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff19f4c9d8, 0x7fff19f4c958)
[1:1:0712/143523.874417:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143523.877242:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5184:5184:0712/143524.275398:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5184:5184:0712/143524.275917:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5184:5196:0712/143524.283871:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5184:5196:0712/143524.283939:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[5184:5184:0712/143524.283962:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5184:5184:0712/143524.284003:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5184:5184:0712/143524.284064:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5237, 4
[1:7:0712/143524.285662:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143524.333099:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2be4b572b220
[1:1:0712/143524.333254:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[5184:5207:0712/143524.383942:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/143524.534273:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[5184:5184:0712/143525.215195:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5184:5184:0712/143525.215272:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/143525.231137:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143525.232720:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143525.668829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3caa5a261f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/143525.669010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143525.678940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3caa5a261f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/143525.679072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143525.698901:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143525.815849:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143525.816004:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143525.954027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143525.956487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3caa5a261f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/143525.956625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143525.968878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143525.971866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3caa5a261f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/143525.971999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143525.975916:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[5184:5184:0712/143525.976573:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/143525.977681:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2be4b5729e20
[1:1:0712/143525.977782:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5184:5184:0712/143525.979127:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[5184:5184:0712/143525.990483:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5184:5184:0712/143525.990562:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/143526.010345:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143526.323672:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 426 0x7f583a1f92e0 0x2be4b52c9c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143526.324306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3caa5a261f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/143526.324440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143526.324980:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5184:5184:0712/143526.350025:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/143526.351155:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2be4b572a820
[1:1:0712/143526.351292:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5184:5184:0712/143526.352542:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/143526.358167:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/143526.358334:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5184:5184:0712/143526.359499:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5184:5184:0712/143526.363556:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5184:5184:0712/143526.363972:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5184:5196:0712/143526.368532:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5184:5196:0712/143526.368585:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5184:5184:0712/143526.368608:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5184:5184:0712/143526.368647:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5184:5184:0712/143526.368708:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5237, 4
[1:7:0712/143526.370134:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143526.634251:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/143526.754363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 475 0x7f583a1f92e0 0x2be4b5a718e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/143526.754991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3caa5a261f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/143526.755171:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/143526.755540:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5184:5184:0712/143526.901701:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5184:5184:0712/143526.901777:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/143526.913067:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143527.070040:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[5184:5184:0712/143527.267320:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5184:5214:0712/143527.267620:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/143527.267747:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143527.267882:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143527.268079:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143527.268168:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/143527.270141:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143527.270287:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1fb563ad, 1
[1:1:0712/143527.270284:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/143527.270478:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x33419f54, 0
[1:1:0712/143527.270579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x34ef8bbf, 3
[1:1:0712/143527.270667:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x31d2538e, 2
[1:1:0712/143527.270744:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 54ffffff9f4133 ffffffad63ffffffb51f ffffff8e53ffffffd231 ffffffbfffffff8bffffffef34 , 10104, 5
[1:1:0712/143527.271490:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5184:5214:0712/143527.271714:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGT�A3�c��S�1���4&�'
[5184:5214:0712/143527.271764:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is T�A3�c��S�1���4�m&�'
[5184:5214:0712/143527.271920:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5279, 5, 549f4133 ad63b51f 8e53d231 bf8bef34 
[1:1:0712/143527.272113:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f584e7d00a0, 3
[1:1:0712/143527.272216:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f584e95c080, 2
[1:1:0712/143527.272309:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f583861ed20, -2
[1:1:0712/143527.281410:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143527.281650:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 31d2538e
[1:1:0712/143527.282065:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 31d2538e
[1:1:0712/143527.282393:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 31d2538e
[1:1:0712/143527.282974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.283101:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.283214:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.283332:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.283630:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 31d2538e
[1:1:0712/143527.283775:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58505967ba
[1:1:0712/143527.283859:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f585058ddef, 7f585059677a, 7f58505980cf
[1:1:0712/143527.285869:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 31d2538e
[1:1:0712/143527.286096:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 31d2538e
[1:1:0712/143527.286419:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 31d2538e
[1:1:0712/143527.287230:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.287350:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.287450:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.287547:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 31d2538e
[1:1:0712/143527.288065:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 31d2538e
[1:1:0712/143527.288235:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58505967ba
[1:1:0712/143527.288311:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f585058ddef, 7f585059677a, 7f58505980cf
[1:1:0712/143527.291413:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143527.291750:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143527.291890:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff19f4c9d8, 0x7fff19f4c958)
[1:1:0712/143527.299560:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143527.302189:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/143527.386456:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2be4b56b8220
[1:1:0712/143527.386645:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/143527.451490:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 548, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/143527.453231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3caa5a38e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/143527.453446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/143527.456211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[5184:5184:0712/143528.687060:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5184:5184:0712/143528.700685:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[5184:5214:0712/143528.700927:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/143528.701070:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/143528.701200:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/143528.701382:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/143528.701473:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/143528.703204:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd087a7c, 1
[1:1:0712/143528.703427:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2910ef80, 0
[1:1:0712/143528.703518:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b49dcb2, 3
[1:1:0712/143528.703594:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x20b91e1a, 2
[1:1:0712/143528.703672:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff80ffffffef1029 7c7a080d 1a1effffffb920 ffffffb2ffffffdc493b , 10104, 6
[1:1:0712/143528.704354:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5184:5214:0712/143528.704483:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��)|z� ��I;�'
[1:1:0712/143528.704484:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f584e7d00a0, 3
[5184:5214:0712/143528.704541:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��)|z� ��I;8��'
[1:1:0712/143528.704566:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f584e95c080, 2
[1:1:0712/143528.704654:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f583861ed20, -2
[5184:5214:0712/143528.704686:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5291, 6, 80ef1029 7c7a080d 1a1eb920 b2dc493b 
[1:1:0712/143528.714418:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/143528.714601:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20b91e1a
[1:1:0712/143528.714747:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20b91e1a
[1:1:0712/143528.715002:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20b91e1a
[1:1:0712/143528.715507:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.715628:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.715741:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.715853:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.716110:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20b91e1a
[1:1:0712/143528.716245:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58505967ba
[1:1:0712/143528.716317:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f585058ddef, 7f585059677a, 7f58505980cf
[1:1:0712/143528.717965:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20b91e1a
[1:1:0712/143528.718152:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20b91e1a
[1:1:0712/143528.718463:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20b91e1a
[1:1:0712/143528.719227:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.719355:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.719473:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[1:1:0712/143528.719586:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20b91e1a
[5184:5184:0712/143528.719770:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/143528.720098:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20b91e1a
[1:1:0712/143528.720604:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f58505967ba
[1:1:0712/143528.720687:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f585058ddef, 7f585059677a, 7f58505980cf
[1:1:0712/143528.723309:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/143528.723552:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/143528.723675:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff19f4c9d8, 0x7fff19f4c958)
[1:1:0712/143528.732123:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/143528.734258:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5184:5196:0712/143528.736334:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[5184:5196:0712/143528.736396:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[5184:5184:0712/143528.737214:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://chaoshi.tmall.com/
[5184:5184:0712/143528.737270:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://chaoshi.tmall.com/, https://chaoshi.tmall.com/, 1
[5184:5184:0712/143528.737345:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://chaoshi.tmall.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 06:35:28 GMT content-type:text/html; charset=utf-8 ufe-result:A6 vary:Accept-Encoding s:STATUS_NOT_EXISTED set-cookie:sm4=110100; Domain=.tmall.com; Expires=Sun, 11-Aug-2019 06:35:28 GMT; Path=/ p3p:CP='CURa ADMa DEVa PSAo PSDo OUR BUS UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR' content-language:zh-CN x-response-time:45 content-encoding:gzip server:Tengine/Aserver eagleeye-traceid:0bb1b81415629133284382875eb73e strict-transport-security:max-age=31536000 timing-allow-origin:*  ,0, 6
[3:3:0712/143528.744944:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/143528.768603:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/143528.828019:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2be4b56db220
[1:1:0712/143528.828159:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/143528.858006:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://chaoshi.tmall.com/
[5184:5184:0712/143528.954252:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://chaoshi.tmall.com/, https://chaoshi.tmall.com/, 1
[5184:5184:0712/143528.954335:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://chaoshi.tmall.com/, https://chaoshi.tmall.com
[1:1:0712/143528.970386:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143529.021856:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143529.035383:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/143529.067744:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143529.067912:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://chaoshi.tmall.com/"
[1:1:0712/143529.079413:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 115 0x7f58382d1070 0x2be4b56b9f60 , "https://chaoshi.tmall.com/"
[1:1:0712/143529.080192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , 
    window.g_config = {
        devId: 'pc',
        headerVersion: '1.4.0',
        loadModulesLat
[1:1:0712/143529.080351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[5184:5196:0712/143529.300860:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/143529.636237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f58382d1070 0x2be4b5839de0 , "https://chaoshi.tmall.com/"
[1:1:0712/143529.636882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , window.g_config = window.g_config || {};window.g_config.loadedCss = window.g_config.loadedCss || [];
[1:1:0712/143529.636990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143529.638571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f58382d1070 0x2be4b5839de0 , "https://chaoshi.tmall.com/"
[1:1:0712/143529.639523:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 150 0x7f58382d1070 0x2be4b5839de0 , "https://chaoshi.tmall.com/"
[1:1:0712/143529.654444:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0170891, 166, 1
[1:1:0712/143529.654650:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143529.702162:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143529.702341:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://chaoshi.tmall.com/"
[1:1:0712/143529.702799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 165 0x7f58382d1070 0x2be4b57ce9e0 , "https://chaoshi.tmall.com/"
[1:1:0712/143529.703411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , 
(function (d) {
var t=d.createElement("script");t.type="text/javascript";t.async=true;t.id="tb-beac
[1:1:0712/143529.703530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143529.704049:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143529.735716:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.033335, 487, 1
[1:1:0712/143529.735897:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143529.773631:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143529.773768:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://chaoshi.tmall.com/"
[1:1:0712/143529.774730:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 178 0x7f58382d1070 0x2be4b58813e0 , "https://chaoshi.tmall.com/"
[1:1:0712/143529.777324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , window.g_config = window.g_config || {};window.g_config.seed = window.g_config.seed || {"packages":{
[1:1:0712/143529.777452:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143529.997208:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143531.989046:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f583a1f92e0 0x2be4b58a01e0 , "https://chaoshi.tmall.com/"
[1:1:0712/143531.990385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , /* v6.1.10,6.1.11,1 2016-04-19 11:03:03 */
!function e(t,r,o){function n(i,l){if(!r[i]){if(!t[i]){va
[1:1:0712/143531.990547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143532.496234:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/143538.285405:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/143538.359940:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7f5838639bd0 0x2be4b57cd258 , "https://chaoshi.tmall.com/"
[1:1:0712/143538.373328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , var feloader=function(t){!function(t){"use strict";for(var e,r,n={},i=function(){},o="memory".split(
[1:1:0712/143538.373534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143538.946132:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x25f3715229c8, 0x2be4b554c160
[1:1:0712/143538.946352:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 3000
[1:1:0712/143538.946609:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 281
[1:1:0712/143538.946784:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 281 0x7f58382d1070 0x2be4b5f2f0e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
		remove user.d_db19c679 -> 0
		remove user.e_263641d6 -> 0
[1:1:0712/143539.747574:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x25f3715229c8, 0x2be4b554c160
[1:1:0712/143539.747786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 5000
[1:1:0712/143539.748026:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 283
[1:1:0712/143539.748205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 283 0x7f58382d1070 0x2be4b608dee0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
[1:1:0712/143539.748504:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x25f3715229c8, 0x2be4b554c160
[1:1:0712/143539.748642:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 50
[1:1:0712/143539.748827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 284
[1:1:0712/143539.748924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 284 0x7f58382d1070 0x2be4b5ea43e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
[1:1:0712/143539.749271:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x25f3715229c8, 0x2be4b554c160
[1:1:0712/143539.749371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 5000
[1:1:0712/143539.749500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 285
[1:1:0712/143539.749580:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 285 0x7f58382d1070 0x2be4b62a1460 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
[1:1:0712/143539.749795:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x25f3715229c8, 0x2be4b554c160
[1:1:0712/143539.749862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 50
[1:1:0712/143539.750016:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 286
[1:1:0712/143539.750096:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 286 0x7f58382d1070 0x2be4b62a13e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
[1:1:0712/143539.755745:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 8000, 0x25f3715229c8, 0x2be4b554c160
[1:1:0712/143539.755891:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 8000
[1:1:0712/143539.756070:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 287
[1:1:0712/143539.756190:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 287 0x7f58382d1070 0x2be4b60bfd60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
[5184:5184:0712/143542.717491:INFO:CONSOLE(2)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://at.alicdn.com/t/font_1401963178_8135476.woff", source: https://g.alicdn.com/??mui/feloader/4.0.39/feloader-min.js,mui/common/4.0.105/js/mod-config.js,mui/babel-polyfill/6.2.7/index.js,mui/bat/4.0.37/index.js,mui/common/4.0.105/js/event.js,mui/custom-event/4.0.3/index.js,mui/common/4.0.105/js/tm.js,mui/common/4.0.105/js/tool.js,mui/common/4.0.105/js/site-nav.js,mui/common/4.0.105/js/plugin-pc.js,mui/common/4.0.105/index-pc.js,tm/chaoshi/4.1.52/seed.js,mui/kissy/4.0.10/seed-min.js,mui/kissy-polyfill/4.0.16/index.js,mui/xtemplate/4.0.11/runtime/escape-html.js,mui/xtemplate/4.0.11/runtime/util.js,mui/xtemplate/4.0.11/runtime/scope.js,mui/xtemplate/4.0.11/runtime/commands.js,mui/xtemplate/4.0.11/runtime/linked-buffer.js,mui/xtemplate/4.0.11/runtime.js,mui/zepto/4.0.9/zepto.js,mui/zepto/4.0.9/event.js,mui/chaoshi-app/4.0.27/site-info.js,mui/mtb-windvane/4.0.3/index.js,mui/mtop/4.1.9/index.js,mui/chaoshi-app/4.0.27/user-info.js,mui/fetch/4.1.12/fetch.js,mui/fetch/4.1.12/tool.js,mui/fetch/4.1.12/jsonp.js,tm/chaoshi/4.1.52/mods/category/popup.tpl.js,tm/chaoshi/4.1.52/mods/category/index.tpl.js,tm/chaoshi/4.1.52/mods/category/index.js,tm/chaoshi/4.1.52/mods/util/util.js,mui/zepto/4.0.9/touch.js,mui/popbox/4.0.6/index-pc.js,mui/chaoshi-city-selector/4.0.26/city-list.js,tm/chaoshi/4.1.52/mods/cart/index.js,tm/chaoshi/4.1.52/app.js,tm/chaoshi/4.1.52/mods/floor/floor.tpl.js,mui/chaoshi-ald/4.1.17/index.js (2)
[5184:5184:0712/143542.722039:INFO:CONSOLE(2)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://at.alicdn.com/t/font_w6m45mp1l3h257b9.woff", source: https://g.alicdn.com/??mui/feloader/4.0.39/feloader-min.js,mui/common/4.0.105/js/mod-config.js,mui/babel-polyfill/6.2.7/index.js,mui/bat/4.0.37/index.js,mui/common/4.0.105/js/event.js,mui/custom-event/4.0.3/index.js,mui/common/4.0.105/js/tm.js,mui/common/4.0.105/js/tool.js,mui/common/4.0.105/js/site-nav.js,mui/common/4.0.105/js/plugin-pc.js,mui/common/4.0.105/index-pc.js,tm/chaoshi/4.1.52/seed.js,mui/kissy/4.0.10/seed-min.js,mui/kissy-polyfill/4.0.16/index.js,mui/xtemplate/4.0.11/runtime/escape-html.js,mui/xtemplate/4.0.11/runtime/util.js,mui/xtemplate/4.0.11/runtime/scope.js,mui/xtemplate/4.0.11/runtime/commands.js,mui/xtemplate/4.0.11/runtime/linked-buffer.js,mui/xtemplate/4.0.11/runtime.js,mui/zepto/4.0.9/zepto.js,mui/zepto/4.0.9/event.js,mui/chaoshi-app/4.0.27/site-info.js,mui/mtb-windvane/4.0.3/index.js,mui/mtop/4.1.9/index.js,mui/chaoshi-app/4.0.27/user-info.js,mui/fetch/4.1.12/fetch.js,mui/fetch/4.1.12/tool.js,mui/fetch/4.1.12/jsonp.js,tm/chaoshi/4.1.52/mods/category/popup.tpl.js,tm/chaoshi/4.1.52/mods/category/index.tpl.js,tm/chaoshi/4.1.52/mods/category/index.js,tm/chaoshi/4.1.52/mods/util/util.js,mui/zepto/4.0.9/touch.js,mui/popbox/4.0.6/index-pc.js,mui/chaoshi-city-selector/4.0.26/city-list.js,tm/chaoshi/4.1.52/mods/cart/index.js,tm/chaoshi/4.1.52/app.js,tm/chaoshi/4.1.52/mods/floor/floor.tpl.js,mui/chaoshi-ald/4.1.17/index.js (2)
[1:1:0712/143543.393595:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7f5838639bd0 0x2be4b57cd258 , "https://chaoshi.tmall.com/"
[1:1:0712/143543.516618:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7f5838639bd0 0x2be4b57cd258 , "https://chaoshi.tmall.com/"
[1:1:0712/143545.093261:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c198
[1:1:0712/143545.093473:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143545.093717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 338
[1:1:0712/143545.093883:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 338 0x7f58382d1070 0x2be4ba71c1e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 248 0x7f5838639bd0 0x2be4b57cd258 
[1:1:0712/143545.099387:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.70859, 0, 0
[1:1:0712/143545.099568:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/143545.143241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/143545.143443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143545.332457:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143545.333202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , a, (){o.responseText?t(o.responseText):r()}
[1:1:0712/143545.333388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143545.336799:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289, "https://chaoshi.tmall.com/"
[1:1:0712/143545.397109:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x25f3715229c8, 0x2be4b554c468
[1:1:0712/143545.397305:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 200
[1:1:0712/143545.397535:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 362
[1:1:0712/143545.397697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7f58382d1070 0x2be4ba975760 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 289
[1:1:0712/143552.225375:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x25f3715229c8, 0x2be4b554c468
[1:1:0712/143552.225581:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 1
[1:1:0712/143552.225819:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 369
[1:1:0712/143552.225989:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 369 0x7f58382d1070 0x2be4bfe53260 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 289
[1:1:0712/143552.232584:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x25f3715229c8, 0x2be4b554c468
[1:1:0712/143552.232780:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 100
[1:1:0712/143552.232943:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 370
[1:1:0712/143552.233110:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7f58382d1070 0x2be4c00af7e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 289
[1:1:0712/143552.234187:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x25f3715229c8, 0x2be4b554c468
[1:1:0712/143552.234280:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 500
[1:1:0712/143552.234423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 371
[1:1:0712/143552.234525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 371 0x7f58382d1070 0x2be4bfbe4fe0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 289
[1:1:0712/143552.630266:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/143552.630409:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://chaoshi.tmall.com/"
[1:1:0712/143552.632475:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f58382d1070 0x2be4ba768ae0 , "https://chaoshi.tmall.com/"
[1:1:0712/143552.639093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , /*!2019-06-15 16:18 */function tanxssp_show(a){var b=document;a.i||(a.i=a.pid);var c="tanx-a-"+a.i||
[1:1:0712/143552.639239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143552.669895:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f58382d1070 0x2be4ba768ae0 , "https://chaoshi.tmall.com/"
[1:1:0712/143552.671212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 339 0x7f58382d1070 0x2be4ba768ae0 , "https://chaoshi.tmall.com/"
[1:1:0712/143552.672883:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://chaoshi.tmall.com/"
[1:1:0712/143552.673527:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://chaoshi.tmall.com/"
[1:1:0712/143552.674847:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x25f3715229c8, 0x2be4b554c1e0
[1:1:0712/143552.674974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 1000
[1:1:0712/143552.675175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 414
[1:1:0712/143552.675317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 414 0x7f58382d1070 0x2be4bfe53ee0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 339 0x7f58382d1070 0x2be4ba768ae0 
[1:1:0712/143552.676352:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://chaoshi.tmall.com/"
[1:1:0712/143552.686891:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://chaoshi.tmall.com/"
[1:1:0712/143552.758720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 284, 7f583ac16881
[1:1:0712/143552.765366:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.765537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.765762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143552.766051:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){var e=s.getElementById(n);if(e&&e.childNodes){t()}else if(!i){setTimeout(arguments.callee,50)}}
[1:1:0712/143552.766166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143552.773522:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143552.773711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 3000
[1:1:0712/143552.773923:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 423
[1:1:0712/143552.774076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 423 0x7f58382d1070 0x2be4c034bd60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 284 0x7f58382d1070 0x2be4b5ea43e0 
[1:1:0712/143552.784737:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 286, 7f583ac16881
[1:1:0712/143552.790885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.791005:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.791179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143552.791452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){var e=s.getElementById(n);if(e&&e.childNodes){t()}else if(!i){setTimeout(arguments.callee,50)}}
[1:1:0712/143552.791547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143552.877523:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 281, 7f583ac16881
[1:1:0712/143552.883888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.884045:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.884216:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143552.884472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){e.sendQueue(),e.sendingTask=null,(e.queue.length>0||e.fullQueue.length>0)&&e.waitSendStart()}
[1:1:0712/143552.884567:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143552.909613:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 283, 7f583ac16881
[1:1:0712/143552.917024:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.917280:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.917492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143552.917767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){i=true}
[1:1:0712/143552.917882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143552.925719:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 285, 7f583ac16881
[1:1:0712/143552.932673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.932887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143552.933147:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143552.933412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){i=true}
[1:1:0712/143552.933511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143552.967552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , document.readyState
[1:1:0712/143552.967714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.199453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 362, 7f583ac16881
[1:1:0712/143553.207602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.207822:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.208089:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143553.208473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){try{processGoldlogQueue(),setTimeout(e,200)}catch(t){}}
[1:1:0712/143553.208569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.209171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143553.209286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 200
[1:1:0712/143553.209509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 469
[1:1:0712/143553.209636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 469 0x7f58382d1070 0x2be4ba71ede0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 362 0x7f58382d1070 0x2be4ba975760 
[1:1:0712/143553.218860:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 287, 7f583ac16881
[1:1:0712/143553.228304:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.229915:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"248 0x7f5838639bd0 0x2be4b57cd258 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.230346:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143553.231293:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , n, (){setTimeout(function(){e(true)},0);if(u){o.detach(r,w,t)}if(c){o.detach(i,L,t)}if(d){clearTimeout(
[1:1:0712/143553.231453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.231966:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143553.232062:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 0
[1:1:0712/143553.232262:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 471
[1:1:0712/143553.232412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 471 0x7f58382d1070 0x2be4c041cfe0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 287 0x7f58382d1070 0x2be4b60bfd60 
[1:1:0712/143553.246490:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 369, 7f583ac16881
[1:1:0712/143553.254590:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.256599:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.256873:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143553.257173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){Math.random()>1e-4||goldlog.emit("global_sample",{type:"timer",t:time_end-time_start})}
[1:1:0712/143553.257316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.292768:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 370, 7f583ac16881
[1:1:0712/143553.301405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.301600:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.301837:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143553.302150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , Z, (){if(!Be){if(!_e.spmData)return void(Oe||setTimeout(arguments.callee,100));Be=ve;var e,t,a,r,n=_e.s
[1:1:0712/143553.302280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.423849:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 394 0x7f583a1f92e0 0x2be4c02bce60 , "https://chaoshi.tmall.com/"
[1:1:0712/143553.424949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , define("tm/chaoshi/mods/direction-top/index",["mui/chaoshi-ald/","./index.tpl","mui/zepto/zepto"],fu
[1:1:0712/143553.425101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.435190:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143553.486842:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f583a1f92e0 0x2be4b58bb260 , "https://chaoshi.tmall.com/"
[1:1:0712/143553.487792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , define("tm/chaoshi/mods/search-hot/index",["mui/chaoshi-ald/","./index.tpl","mui/zepto/zepto","./ind
[1:1:0712/143553.487916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.501388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143553.524443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143553.524870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , l, (){var t=x.readyState;t&&"loaded"!==t&&"complete"!==t||(x.onreadystatechange=x.onload=null,b(0))}
[1:1:0712/143553.524954:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.598261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 399 0x7f583a1f92e0 0x2be4c0359160 , "https://chaoshi.tmall.com/"
[1:1:0712/143553.599066:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , define("tm/chaoshi/mods/navbar/index",["./info","mui/chaoshi-app/site-info","mui/zepto/zepto","./ind
[1:1:0712/143553.599225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.614945:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143553.630188:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 400 0x7f583a1f92e0 0x2be4b8b7d1e0 , "https://chaoshi.tmall.com/"
[1:1:0712/143553.632267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , ,  mtopjsonp1({"api":"mtop.chaoshi.supermarket.getuserinfo","data":{},"ret":["FAIL_SYS_TOKEN_EMPTY::�
[1:1:0712/143553.632418:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.716996:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143553.717177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143553.717378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 494
[1:1:0712/143553.717508:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 494 0x7f58382d1070 0x2be4c0bf65e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 400 0x7f583a1f92e0 0x2be4b8b7d1e0 
[1:1:0712/143553.750312:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143553.750724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , l, (){var t=x.readyState;t&&"loaded"!==t&&"complete"!==t||(x.onreadystatechange=x.onload=null,b(0))}
[1:1:0712/143553.750831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.833630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 371, 7f583ac16881
[1:1:0712/143553.841624:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.841875:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"289","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143553.842165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143553.842520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){t++,t>10&&(a=3e3),ee(),setTimeout(e,a)}
[1:1:0712/143553.842693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143553.843366:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143553.843462:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 500
[1:1:0712/143553.843654:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 504
[1:1:0712/143553.843750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 504 0x7f58382d1070 0x2be4c0c3f5e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 371 0x7f58382d1070 0x2be4bfbe4fe0 
[1:1:0712/143553.967034:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , document.readyState
[1:1:0712/143553.967201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143554.602406:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f583a1f92e0 0x2be4bc033160 , "https://chaoshi.tmall.com/"
[1:1:0712/143554.603665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , define("mui/common-script/index-pc",function(e,o,t){function a(){var e=window,o=document,t=e.g_confi
[1:1:0712/143554.603851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143554.605223:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143554.684323:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 471, 7f583ac16881
[1:1:0712/143554.693912:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"287 0x7f58382d1070 0x2be4b60bfd60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143554.694091:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"287 0x7f58382d1070 0x2be4b60bfd60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143554.694319:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143554.694592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){e(true)}
[1:1:0712/143554.694726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[5184:5184:0712/143554.700794:INFO:CONSOLE(2)] "%c 安全警告！", source: https://g.alicdn.com/??mui/feloader/4.0.39/feloader-min.js,mui/common/4.0.105/js/mod-config.js,mui/babel-polyfill/6.2.7/index.js,mui/bat/4.0.37/index.js,mui/common/4.0.105/js/event.js,mui/custom-event/4.0.3/index.js,mui/common/4.0.105/js/tm.js,mui/common/4.0.105/js/tool.js,mui/common/4.0.105/js/site-nav.js,mui/common/4.0.105/js/plugin-pc.js,mui/common/4.0.105/index-pc.js,tm/chaoshi/4.1.52/seed.js,mui/kissy/4.0.10/seed-min.js,mui/kissy-polyfill/4.0.16/index.js,mui/xtemplate/4.0.11/runtime/escape-html.js,mui/xtemplate/4.0.11/runtime/util.js,mui/xtemplate/4.0.11/runtime/scope.js,mui/xtemplate/4.0.11/runtime/commands.js,mui/xtemplate/4.0.11/runtime/linked-buffer.js,mui/xtemplate/4.0.11/runtime.js,mui/zepto/4.0.9/zepto.js,mui/zepto/4.0.9/event.js,mui/chaoshi-app/4.0.27/site-info.js,mui/mtb-windvane/4.0.3/index.js,mui/mtop/4.1.9/index.js,mui/chaoshi-app/4.0.27/user-info.js,mui/fetch/4.1.12/fetch.js,mui/fetch/4.1.12/tool.js,mui/fetch/4.1.12/jsonp.js,tm/chaoshi/4.1.52/mods/category/popup.tpl.js,tm/chaoshi/4.1.52/mods/category/index.tpl.js,tm/chaoshi/4.1.52/mods/category/index.js,tm/chaoshi/4.1.52/mods/util/util.js,mui/zepto/4.0.9/touch.js,mui/popbox/4.0.6/index-pc.js,mui/chaoshi-city-selector/4.0.26/city-list.js,tm/chaoshi/4.1.52/mods/cart/index.js,tm/chaoshi/4.1.52/app.js,tm/chaoshi/4.1.52/mods/floor/floor.tpl.js,mui/chaoshi-ald/4.1.17/index.js (2)
[5184:5184:0712/143554.701626:INFO:CONSOLE(2)] "%c 此浏览器功能专供开发者使用。请不要在此粘贴执行任何内容，这可能会导致您的账户受到攻击，给您带来损失 ！", source: https://g.alicdn.com/??mui/feloader/4.0.39/feloader-min.js,mui/common/4.0.105/js/mod-config.js,mui/babel-polyfill/6.2.7/index.js,mui/bat/4.0.37/index.js,mui/common/4.0.105/js/event.js,mui/custom-event/4.0.3/index.js,mui/common/4.0.105/js/tm.js,mui/common/4.0.105/js/tool.js,mui/common/4.0.105/js/site-nav.js,mui/common/4.0.105/js/plugin-pc.js,mui/common/4.0.105/index-pc.js,tm/chaoshi/4.1.52/seed.js,mui/kissy/4.0.10/seed-min.js,mui/kissy-polyfill/4.0.16/index.js,mui/xtemplate/4.0.11/runtime/escape-html.js,mui/xtemplate/4.0.11/runtime/util.js,mui/xtemplate/4.0.11/runtime/scope.js,mui/xtemplate/4.0.11/runtime/commands.js,mui/xtemplate/4.0.11/runtime/linked-buffer.js,mui/xtemplate/4.0.11/runtime.js,mui/zepto/4.0.9/zepto.js,mui/zepto/4.0.9/event.js,mui/chaoshi-app/4.0.27/site-info.js,mui/mtb-windvane/4.0.3/index.js,mui/mtop/4.1.9/index.js,mui/chaoshi-app/4.0.27/user-info.js,mui/fetch/4.1.12/fetch.js,mui/fetch/4.1.12/tool.js,mui/fetch/4.1.12/jsonp.js,tm/chaoshi/4.1.52/mods/category/popup.tpl.js,tm/chaoshi/4.1.52/mods/category/index.tpl.js,tm/chaoshi/4.1.52/mods/category/index.js,tm/chaoshi/4.1.52/mods/util/util.js,mui/zepto/4.0.9/touch.js,mui/popbox/4.0.6/index-pc.js,mui/chaoshi-city-selector/4.0.26/city-list.js,tm/chaoshi/4.1.52/mods/cart/index.js,tm/chaoshi/4.1.52/app.js,tm/chaoshi/4.1.52/mods/floor/floor.tpl.js,mui/chaoshi-ald/4.1.17/index.js (2)
[1:1:0712/143555.054172:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/143556.102342:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 469, 7f583ac16881
[1:1:0712/143556.113615:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"362 0x7f58382d1070 0x2be4ba975760 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143556.113786:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"362 0x7f58382d1070 0x2be4ba975760 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143556.113978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143556.114235:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){try{processGoldlogQueue(),setTimeout(e,200)}catch(t){}}
[1:1:0712/143556.114321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143556.114939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143556.115053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 200
[1:1:0712/143556.115231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 624
[1:1:0712/143556.115348:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7f58382d1070 0x2be4b8db9de0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 469 0x7f58382d1070 0x2be4ba71ede0 
[1:1:0712/143556.249549:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 414, 7f583ac16881
[1:1:0712/143556.259834:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"339 0x7f58382d1070 0x2be4ba768ae0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143556.260062:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"339 0x7f58382d1070 0x2be4ba768ae0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143556.260282:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143556.260568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){addScript("//g.alicdn.com/secdev/entry/index.js?t="+t)}
[1:1:0712/143556.260684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143556.462302:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7f583a1f92e0 0x2be4ba6a2060 , "https://chaoshi.tmall.com/"
[1:1:0712/143556.462915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , ,  mtopjsonp2({"api":"mtop.chaoshi.supermarket.getuserinfo","data":{"isWap":"true","isNewUser":"false"
[1:1:0712/143556.463042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143556.546607:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143556.546798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143556.546994:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 645
[1:1:0712/143556.547120:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 645 0x7f58382d1070 0x2be4c1330460 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 512 0x7f583a1f92e0 0x2be4ba6a2060 
[1:1:0712/143556.610610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , document.readyState
[1:1:0712/143556.610750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143556.833502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 504, 7f583ac16881
[1:1:0712/143556.844986:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"371 0x7f58382d1070 0x2be4bfbe4fe0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143556.845173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"371 0x7f58382d1070 0x2be4bfbe4fe0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143556.845387:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143556.845671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){t++,t>10&&(a=3e3),ee(),setTimeout(e,a)}
[1:1:0712/143556.845793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143556.846433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143556.846542:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 500
[1:1:0712/143556.846703:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 663
[1:1:0712/143556.846815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 663 0x7f58382d1070 0x2be4c18d4c60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 504 0x7f58382d1070 0x2be4c0c3f5e0 
[1:1:0712/143558.141943:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 423, 7f583ac16881
[1:1:0712/143558.156119:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"284 0x7f58382d1070 0x2be4b5ea43e0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143558.156320:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"284 0x7f58382d1070 0x2be4b5ea43e0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143558.156566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143558.156881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){b(1)}
[1:1:0712/143558.156979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143558.410268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 624, 7f583ac16881
[1:1:0712/143558.424327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"469 0x7f58382d1070 0x2be4ba71ede0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143558.424516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"469 0x7f58382d1070 0x2be4ba71ede0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143558.424728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143558.425033:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){try{processGoldlogQueue(),setTimeout(e,200)}catch(t){}}
[1:1:0712/143558.425133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143558.425712:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143558.425807:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 200
[1:1:0712/143558.425976:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 775
[1:1:0712/143558.426082:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7f58382d1070 0x2be4c051ad60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 624 0x7f58382d1070 0x2be4b8db9de0 
[1:1:0712/143558.499116:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 637 0x7f583a1f92e0 0x2be4c18d4e60 , "https://chaoshi.tmall.com/"
[1:1:0712/143558.500179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , define("mui/view-port-listen/index",function(e,t,o){var n=function(){function e(e,t){for(var o=0;o<t
[1:1:0712/143558.500339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143558.501626:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143558.749772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , document.readyState
[1:1:0712/143558.749942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143559.270097:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 663, 7f583ac16881
[1:1:0712/143559.284885:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"504 0x7f58382d1070 0x2be4c0c3f5e0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143559.285117:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"504 0x7f58382d1070 0x2be4c0c3f5e0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143559.285340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143559.285659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){t++,t>10&&(a=3e3),ee(),setTimeout(e,a)}
[1:1:0712/143559.285786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143559.286446:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143559.286551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 500
[1:1:0712/143559.286727:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 821
[1:1:0712/143559.286901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 821 0x7f58382d1070 0x2be4c1d3bde0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 663 0x7f58382d1070 0x2be4c18d4c60 
[1:1:0712/143559.513697:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 693 0x7f583a1f92e0 0x2be4ba24fa60 , "https://chaoshi.tmall.com/"
[1:1:0712/143559.514402:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , ,  mtopjsonp3({"api":"mtop.chaoshi.supermarket.getsiteinfo","data":{"tpId":"725677994","chooseAreaId":
[1:1:0712/143559.514525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143559.535373:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143559.535535:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 2000
[1:1:0712/143559.535721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 832
[1:1:0712/143559.535838:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 832 0x7f58382d1070 0x2be4c1e90860 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143559.719885:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143559.720099:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 50
[1:1:0712/143559.720327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 840
[1:1:0712/143559.720512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7f58382d1070 0x2be4c1ee4760 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143559.839990:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143559.840204:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 5000
[1:1:0712/143559.840414:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 852
[1:1:0712/143559.840579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f58382d1070 0x2be4b8da2060 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143559.915113:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143559.915279:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 5000
[1:1:0712/143559.915480:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 859
[1:1:0712/143559.917094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 859 0x7f58382d1070 0x2be4b53d0a60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143600.281494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143600.281668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 2000
[1:1:0712/143600.281870:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 884
[1:1:0712/143600.282054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f58382d1070 0x2be4c26c3a60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
		remove user.f_b56edaf0 -> 0
[1:1:0712/143603.963727:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143603.963915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143603.964102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1055
[1:1:0712/143603.964215:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1055 0x7f58382d1070 0x2be4c5026e60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143603.970027:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143603.970210:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143603.970417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1057
[1:1:0712/143603.970559:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1057 0x7f58382d1070 0x2be4c464ffe0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143603.976233:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143603.976391:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143603.976622:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1059
[1:1:0712/143603.976747:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7f58382d1070 0x2be4c25f68e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143603.996358:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143603.996527:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143603.996744:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1062
[1:1:0712/143603.996873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1062 0x7f58382d1070 0x2be4c2721b60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.002525:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.002688:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.002867:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1063
[1:1:0712/143604.003008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1063 0x7f58382d1070 0x2be4c2880760 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.008783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.008940:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.009169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1066
[1:1:0712/143604.009351:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1066 0x7f58382d1070 0x2be4c4d23b60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.015248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.015433:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.015649:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1069
[1:1:0712/143604.015783:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1069 0x7f58382d1070 0x2be4c5377660 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.021274:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.021408:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.021570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1070
[1:1:0712/143604.022058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1070 0x7f58382d1070 0x2be4ba8c95e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.027867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.028024:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.028341:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1072
[1:1:0712/143604.029627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1072 0x7f58382d1070 0x2be4c266f660 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.035308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.035492:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.035701:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1074
[1:1:0712/143604.035800:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7f58382d1070 0x2be4c53c8360 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.044521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.044712:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.044921:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1077
[1:1:0712/143604.045279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7f58382d1070 0x2be4c53c81e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.051034:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.051174:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.051325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1079
[1:1:0712/143604.051427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7f58382d1070 0x2be4c53e75e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.057617:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.057778:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.057992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1080
[1:1:0712/143604.058135:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7f58382d1070 0x2be4c53f1260 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.064342:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.064513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.064697:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1083
[1:1:0712/143604.064809:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7f58382d1070 0x2be4c3133e60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.070868:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.071036:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.071218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1085
[1:1:0712/143604.071334:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1085 0x7f58382d1070 0x2be4c53772e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.076941:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.078712:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.079882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1088
[1:1:0712/143604.080043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1088 0x7f58382d1070 0x2be4c54194e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.093977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.094170:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.094416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1090
[1:1:0712/143604.094591:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1090 0x7f58382d1070 0x2be4c54280e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.100519:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.100704:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.100885:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1092
[1:1:0712/143604.100999:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1092 0x7f58382d1070 0x2be4c5428d60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.111061:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.111242:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.111486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1095
[1:1:0712/143604.111617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7f58382d1070 0x2be4c5245ae0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.120228:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.120758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.120950:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1097
[1:1:0712/143604.122425:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7f58382d1070 0x2be4c543f960 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.128156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.128436:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.128695:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1099
[1:1:0712/143604.129694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7f58382d1070 0x2be4ba8c9360 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.135473:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.135638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.135823:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1101
[1:1:0712/143604.135956:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7f58382d1070 0x2be4c543fce0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.142075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.142237:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.142409:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1105
[1:1:0712/143604.142504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7f58382d1070 0x2be4c5457d60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.148376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.149127:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.149356:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1106
[1:1:0712/143604.149567:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f58382d1070 0x2be4c545fbe0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.155356:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.158043:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.158265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1109
[1:1:0712/143604.158426:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7f58382d1070 0x2be4c5457de0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143604.165246:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x25f3715229c8, 0x2be4b554c180
[1:1:0712/143604.165406:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 20000
[1:1:0712/143604.165612:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1112
[1:1:0712/143604.165746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1112 0x7f58382d1070 0x2be4c545fde0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 693 0x7f583a1f92e0 0x2be4ba24fa60 
[1:1:0712/143606.688846:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 775, 7f583ac16881
[1:1:0712/143606.711786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"624 0x7f58382d1070 0x2be4b8db9de0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143606.711987:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"624 0x7f58382d1070 0x2be4b8db9de0 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143606.712219:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143606.712515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){try{processGoldlogQueue(),setTimeout(e,200)}catch(t){}}
[1:1:0712/143606.712619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143606.713236:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143606.713348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 200
[1:1:0712/143606.713524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1303
[1:1:0712/143606.713634:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7f58382d1070 0x2be4c3d62a60 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 775 0x7f58382d1070 0x2be4c051ad60 
[1:1:0712/143606.936552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , document.readyState
[1:1:0712/143606.936769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143607.106238:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143607.106690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , l, (){var t=x.readyState;t&&"loaded"!==t&&"complete"!==t||(x.onreadystatechange=x.onload=null,b(0))}
[1:1:0712/143607.106832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143607.226350:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 806 0x7f583a1f92e0 0x2be4c1f53460 , "https://chaoshi.tmall.com/"
[1:1:0712/143607.227025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , var userCookie={dnk:'',_nk_:'',_l_g_:'',ck1:'',tracknick:'',mt:'ci=-1_0',l:'cBIu2GtrqOnrcnNwBOCwourz
[1:1:0712/143607.227138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143607.227820:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143617.706132:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 821, 7f583ac16881
[1:1:0712/143617.740556:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"663 0x7f58382d1070 0x2be4c18d4c60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143617.740739:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"663 0x7f58382d1070 0x2be4c18d4c60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143617.740952:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143617.741240:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){t++,t>10&&(a=3e3),ee(),setTimeout(e,a)}
[1:1:0712/143617.741336:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143617.741937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143617.742050:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 500
[1:1:0712/143617.742212:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 2010
[1:1:0712/143617.742320:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2010 0x7f58382d1070 0x2be4b5c463e0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 821 0x7f58382d1070 0x2be4c1d3bde0 
[1:1:0712/143617.742814:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 832, 7f583ac16881
[1:1:0712/143617.778340:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143617.778511:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143617.778711:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143617.779005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){r(new Error("JSONP request to "+n+" timed out"));e[u]=function(){a(u);f(h)}}
[1:1:0712/143617.779126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143617.815969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 884, 7f583ac16881
[1:1:0712/143617.850878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143617.851079:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143617.851308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143617.851697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){r(new Error("JSONP request to "+n+" timed out"));e[u]=function(){a(u);f(h)}}
[1:1:0712/143617.851835:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143619.155882:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 852, 7f583ac16881
[1:1:0712/143619.190987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143619.191168:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143619.191376:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143619.191655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){d(a,{})}
[1:1:0712/143619.191746:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143619.352627:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 859, 7f583ac16881
[1:1:0712/143619.388646:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143619.388831:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"693 0x7f583a1f92e0 0x2be4ba24fa60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143619.389052:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143619.389333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (){d(a,{})}
[1:1:0712/143619.389434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143623.538805:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1260 0x7f583a1f92e0 0x2be4c0da41e0 , "https://chaoshi.tmall.com/"
[1:1:0712/143623.541228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , KISSY.add("mui/minicart/minicart",function(t,a,e,i,r,n,s){var o={};var c=0;t.mix(o,{version:"%VERSIO
[1:1:0712/143623.541382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143623.574964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143623.616221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1261 0x7f583a1f92e0 0x2be4b5405860 , "https://chaoshi.tmall.com/"
[1:1:0712/143623.617733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0712/143623.617916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143626.551894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143626.552396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , a.onload.a.onerror, (){win[r]=null}
[1:1:0712/143626.552519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143626.896090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://chaoshi.tmall.com/"
[1:1:0712/143626.896515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , a.onload.a.onerror, (){win[r]=null}
[1:1:0712/143626.896648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143627.112214:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 1303, 7f583ac16881
[1:1:0712/143627.154452:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1ef6153a2860","ptid":"775 0x7f58382d1070 0x2be4c051ad60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143627.154643:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://chaoshi.tmall.com/","ptid":"775 0x7f58382d1070 0x2be4c051ad60 ","rf":"6:3_https://chaoshi.tmall.com/"}
[1:1:0712/143627.154863:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://chaoshi.tmall.com/"
[1:1:0712/143627.155149:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , e, (){try{processGoldlogQueue(),setTimeout(e,200)}catch(t){}}
[1:1:0712/143627.155250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
[1:1:0712/143627.155879:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x25f3715229c8, 0x2be4b554c150
[1:1:0712/143627.155983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://chaoshi.tmall.com/", 200
[1:1:0712/143627.156211:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://chaoshi.tmall.com/, 2445
[1:1:0712/143627.156370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2445 0x7f58382d1070 0x2be4b8ee5be0 , 6:3_https://chaoshi.tmall.com/, 1, -6:3_https://chaoshi.tmall.com/, 1303 0x7f58382d1070 0x2be4c3d62a60 
[1:1:0712/143627.283159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://chaoshi.tmall.com/, 1ef6153a2860, , , document.readyState
[1:1:0712/143627.283411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://chaoshi.tmall.com/", "chaoshi.tmall.com", 3, 1, , , 0
