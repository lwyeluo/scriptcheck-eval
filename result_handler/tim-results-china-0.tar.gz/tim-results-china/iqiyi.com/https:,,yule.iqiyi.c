[0712/114031.589091:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114031.589334:INFO:switcher_clone.cc(787)] backtrace rip is 7faf91a2c891
[0712/114032.157342:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114032.157610:INFO:switcher_clone.cc(787)] backtrace rip is 7faf8493f891
[1:1:0712/114032.161887:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/114032.162063:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/114032.164935:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[6412:6412:0712/114033.006367:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/68ae0829-eb82-4cd8-8785-cc69e59afe56
[0712/114033.115462:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/114033.115741:INFO:switcher_clone.cc(787)] backtrace rip is 7fcc2a8f2891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[6445:6445:0712/114033.290359:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6445
[6456:6456:0712/114033.290668:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=6456
[6412:6412:0712/114033.302692:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[6412:6440:0712/114033.303100:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/114033.305656:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114033.305830:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114033.306164:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114033.306286:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/114033.312388:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2440f038, 1
[1:1:0712/114033.316143:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1723caea, 0
[1:1:0712/114033.316286:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x25d12cbc, 3
[1:1:0712/114033.316745:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2579d201, 2
[1:1:0712/114033.316854:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffeaffffffca2317 38fffffff04024 01ffffffd27925 ffffffbc2cffffffd125 , 10104, 4
[1:1:0712/114033.317574:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6412:6440:0712/114033.317772:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��#8�@$�y%�,�%�o$
[6412:6440:0712/114033.317822:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��#8�@$�y%�,�%�h�o$
[1:1:0712/114033.317765:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf82b790a0, 3
[6412:6440:0712/114033.317972:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/114033.317970:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf82d05080, 2
[6412:6440:0712/114033.318004:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6464, 4, eaca2317 38f04024 01d27925 bc2cd125 
[1:1:0712/114033.318046:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf6c9c7d20, -2
[1:1:0712/114033.326759:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114033.327835:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2579d201
[1:1:0712/114033.328306:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2579d201
[1:1:0712/114033.329086:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2579d201
[1:1:0712/114033.329689:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.329805:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.329919:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.330018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.330271:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2579d201
[1:1:0712/114033.330420:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8493f7ba
[1:1:0712/114033.330502:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf84936def, 7faf8493f77a, 7faf849410cf
[1:1:0712/114033.332158:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2579d201
[1:1:0712/114033.332339:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2579d201
[1:1:0712/114033.332634:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2579d201
[1:1:0712/114033.333426:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.333546:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.333661:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.333773:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2579d201
[1:1:0712/114033.334274:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2579d201
[1:1:0712/114033.334439:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8493f7ba
[1:1:0712/114033.334522:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf84936def, 7faf8493f77a, 7faf849410cf
[1:1:0712/114033.336983:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114033.337212:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114033.337298:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe70d9c5f8, 0x7ffe70d9c578)
[1:1:0712/114033.343903:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114033.346825:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[6412:6412:0712/114033.762088:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6412:6412:0712/114033.762599:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6412:6435:0712/114033.801286:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/114033.821010:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x172b1298f220
[1:1:0712/114033.821218:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[6412:6423:0712/114033.822295:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[6412:6423:0712/114033.822352:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[6412:6412:0712/114033.822402:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[6412:6412:0712/114033.822446:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[6412:6412:0712/114033.822509:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,6464, 4
[1:7:0712/114033.823255:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114034.143536:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[6412:6423:0712/114034.295413:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/114034.867579:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114034.869299:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[6412:6412:0712/114034.915135:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[6412:6412:0712/114034.915206:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114035.358925:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114035.417175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e545181f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114035.417342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114035.422432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e545181f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/114035.422556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114035.481493:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114035.481642:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114035.665625:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 366, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114035.668145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e545181f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114035.668273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114035.680883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114035.683913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e545181f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/114035.684079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114035.688045:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[6412:6412:0712/114035.688711:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[6412:6412:0712/114035.690994:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0712/114035.690119:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x172b1298de20
[1:1:0712/114035.691402:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[6412:6412:0712/114035.704920:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[6412:6412:0712/114035.705014:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/114035.728690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114036.124093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 432 0x7faf6e5a22e0 0x172b12bb13e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114036.124792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e545181f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/114036.124926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114036.125524:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[6412:6412:0712/114036.152917:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/114036.154208:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x172b1298e820
[1:1:0712/114036.154790:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[6412:6412:0712/114036.155771:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/114036.162635:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/114036.162790:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[6412:6412:0712/114036.165689:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[6412:6412:0712/114036.184009:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6412:6412:0712/114036.185076:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6412:6412:0712/114036.190093:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[6412:6412:0712/114036.190151:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[6412:6412:0712/114036.190216:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,6464, 4
[6412:6423:0712/114036.190620:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[6412:6423:0712/114036.190666:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/114036.192425:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114036.471514:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[6412:6412:0712/114036.519777:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[6412:6440:0712/114036.520066:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/114036.520216:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/114036.520366:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/114036.520587:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/114036.520687:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/114036.522619:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x38730af4, 1
[1:1:0712/114036.522793:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1f3951ee, 0
[1:1:0712/114036.523038:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x218bded6, 3
[1:1:0712/114036.523131:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x14b4deb5, 2
[1:1:0712/114036.523213:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffee51391f fffffff40a7338 ffffffb5ffffffdeffffffb414 ffffffd6ffffffdeffffff8b21 , 10104, 5
[1:1:0712/114036.523960:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[6412:6440:0712/114036.524119:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Q9�
s8�޴�ދ!x�o$
[6412:6440:0712/114036.524161:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Q9�
s8�޴�ދ!��x�o$
[6412:6440:0712/114036.524313:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6505, 5, ee51391f f40a7338 b5deb414 d6de8b21 
[1:1:0712/114036.524214:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf82b790a0, 3
[1:1:0712/114036.524380:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf82d05080, 2
[1:1:0712/114036.524476:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7faf6c9c7d20, -2
[1:1:0712/114036.533582:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/114036.533800:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14b4deb5
[1:1:0712/114036.533943:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14b4deb5
[1:1:0712/114036.534236:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14b4deb5
[1:1:0712/114036.534732:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.534819:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.534945:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.535032:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.535315:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14b4deb5
[1:1:0712/114036.535443:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8493f7ba
[1:1:0712/114036.535516:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf84936def, 7faf8493f77a, 7faf849410cf
[1:1:0712/114036.537200:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 14b4deb5
[1:1:0712/114036.537360:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 14b4deb5
[1:1:0712/114036.537652:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 14b4deb5
[1:1:0712/114036.538418:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.538541:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.538642:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.538740:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 14b4deb5
[1:1:0712/114036.539220:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 14b4deb5
[1:1:0712/114036.539384:INFO:switcher_clone.cc(775)] clone wrapper rip is 7faf8493f7ba
[1:1:0712/114036.539466:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7faf84936def, 7faf8493f77a, 7faf849410cf
[1:1:0712/114036.542075:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/114036.542288:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/114036.542366:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe70d9c5f8, 0x7ffe70d9c578)
[1:1:0712/114036.561310:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/114036.563511:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/114036.657770:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7faf6e5a22e0 0x172b12d3d8e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114036.658396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 38e545181f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/114036.658517:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/114036.658844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/114036.661851:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x172b1295b220
[1:1:0712/114036.662005:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[6412:6412:0712/114036.780419:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[6412:6412:0712/114036.780487:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/114036.792130:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114037.026758:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[6412:6412:0712/114037.242610:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[6412:6412:0712/114037.245355:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[6412:6412:0712/114037.264632:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://yule.iqiyi.com/
[6412:6412:0712/114037.264695:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://yule.iqiyi.com/, https://yule.iqiyi.com/, 1
[6412:6412:0712/114037.264760:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://yule.iqiyi.com/, HTTP/1.1 200 status:200 server:nginx date:Fri, 12 Jul 2019 03:40:37 GMT content-type:text/html; charset=UTF-8 expires:Fri, 12 Jul 2019 03:43:37 GMT cache-control:max-age=180 x-cache:MISS from 124.193.229.68 content-encoding:gzip  ,6505, 5
[6412:6423:0712/114037.278966:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[6412:6423:0712/114037.279035:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/114037.279457:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/114037.297781:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114037.297923:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114037.301453:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://yule.iqiyi.com/
[6412:6412:0712/114037.374840:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://yule.iqiyi.com/, https://yule.iqiyi.com/, 1
[6412:6412:0712/114037.374909:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://yule.iqiyi.com/, https://yule.iqiyi.com
[1:1:0712/114037.386742:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114037.422826:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114037.439124:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114037.461755:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114037.461888:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114037.537985:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114037.567438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 566, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114037.569203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 38e5452b09f8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/114037.569342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/114037.571860:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/114037.667739:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114037.763855:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114037.807422:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7faf6c67a070 0x172b12bba2e0 , "https://yule.iqiyi.com/"
[1:1:0712/114037.808344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , 
    var pageJsMap = window.pageJsMap = {"albumBodan":"albumBodan.1c84c9e1.js","dianshiju":"dianshij
[1:1:0712/114037.808491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "yule.iqiyi.com", 3, 1, , , 0
[1:1:0712/114037.809022:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114037.810187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7faf6c67a070 0x172b12bba2e0 , "https://yule.iqiyi.com/"
[1:1:0712/114037.811348:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7faf6c67a070 0x172b12bba2e0 , "https://yule.iqiyi.com/"
[1:1:0712/114037.828914:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 172 0x7faf6c67a070 0x172b12bba2e0 , "https://yule.iqiyi.com/"
[1:1:0712/114037.965674:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.155942, 605, 1
[1:1:0712/114037.965888:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114038.000064:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114038.219680:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114038.252631:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114038.253149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 220 0x7faf6c67a070 0x172b12c44860 , "https://yule.iqiyi.com/"
[1:1:0712/114038.253979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , 
    function getCookie(name){
          var strcookie = document.cookie;
          var arrcookie = 
[1:1:0712/114038.254112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "yule.iqiyi.com", 3, 1, , , 0
[1:1:0712/114038.256016:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "yule.iqiyi.com", "iqiyi.com"
[1:1:0712/114038.267090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 220 0x7faf6c67a070 0x172b12c44860 , "https://yule.iqiyi.com/"
[1:1:0712/114038.420082:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.167457, 1330, 1
[1:1:0712/114038.420353:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114038.506464:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114038.930225:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114038.930438:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114038.930875:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7faf6c67a070 0x172b124b8ce0 , "https://yule.iqiyi.com/"
[1:1:0712/114038.931371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , 
    window.__qlt = {};
    window.__qlt.statisticsStart = +new Date;
    window.__qlt.cid = "";

[1:1:0712/114038.931472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114038.932763:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 285 0x7faf6c67a070 0x172b124b8ce0 , "https://yule.iqiyi.com/"
[1:1:0712/114038.988971:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114038.994753:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/114039.496365:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114039.496535:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114039.516283:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114039.757265:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114039.757443:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114039.765752:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00828099, 143, 1
[1:1:0712/114039.765919:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114039.975705:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 425 0x7faf6e5a22e0 0x172b12bb1f60 , "https://yule.iqiyi.com/"
[1:1:0712/114039.976319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , try{ updateUserIconCallback({"code":"A00003","data":{"type":"params_error","msg":"userinfoDetail","d
[1:1:0712/114039.976417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114039.977002:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xeb901d829c8, 0x172b127da188
[1:1:0712/114039.977115:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 10
[1:1:0712/114039.977263:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 435
[1:1:0712/114039.977350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 435 0x7faf6c67a070 0x172b12bb6560 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 425 0x7faf6e5a22e0 0x172b12bb1f60 
[1:1:0712/114040.008400:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114040.013253:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114040.021582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7faf6c67a070 0x172b124b5d60 , "https://yule.iqiyi.com/"
[1:1:0712/114040.022213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , 
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
   
[1:1:0712/114040.022375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114040.025944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7faf6c67a070 0x172b124b5d60 , "https://yule.iqiyi.com/"
[1:1:0712/114040.030314:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7faf6c67a070 0x172b124b5d60 , "https://yule.iqiyi.com/"
[1:1:0712/114040.037976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 428 0x7faf6c67a070 0x172b124b5d60 , "https://yule.iqiyi.com/"
[1:1:0712/114040.056521:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/114040.096105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 435, 7faf6efbf881
[1:1:0712/114040.102820:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"425 0x7faf6e5a22e0 0x172b12bb1f60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114040.102990:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"425 0x7faf6e5a22e0 0x172b12bb1f60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114040.103214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114040.103503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , () {
                oHead.removeChild(script);    
            }
[1:1:0712/114040.103622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114040.321137:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 460 0x7faf6e5a22e0 0x172b12ba5be0 , "https://yule.iqiyi.com/"
[1:1:0712/114040.321856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , (function(o,s,f){var t=false,e=/msie/.test(navigator.userAgent.toLowerCase()),r="//iqiyi.irs01.com/i
[1:1:0712/114040.321982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114040.340028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 461 0x7faf6e5a22e0 0x172b12bb0f60 , "https://yule.iqiyi.com/"
[1:1:0712/114040.340593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , function udm_(e,t){var n="comScore=",r=document,i=r.cookie,s="",o="indexOf",u="substring",a="length"
[1:1:0712/114040.340718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114040.346800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://yule.iqiyi.com/"
[1:1:0712/114040.372555:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 463 0x7faf6e5a22e0 0x172b12ba88e0 , "https://yule.iqiyi.com/"
[1:1:0712/114040.374701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , (function(){var h={},mt={},c={id:"53b7374a63c37483e5dd97d78d9bb36e",dm:["iqiyi.com"],js:"tongji.baid
[1:1:0712/114040.374838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114040.399486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da190
[1:1:0712/114040.399655:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114040.399874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 483
[1:1:0712/114040.400006:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 483 0x7faf6c67a070 0x172b127e76e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 463 0x7faf6e5a22e0 0x172b12ba88e0 
[1:1:0712/114041.968855:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[6412:6412:0712/114045.296656:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -356
[3:3:0712/114045.365799:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/114046.446804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/114046.446990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114047.051552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 483, 7faf6efbf881
[1:1:0712/114047.060625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"463 0x7faf6e5a22e0 0x172b12ba88e0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114047.060797:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"463 0x7faf6e5a22e0 0x172b12ba88e0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114047.061016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114047.061295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114047.061421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114047.061758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114047.061864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114047.062031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 580
[1:1:0712/114047.062148:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 580 0x7faf6c67a070 0x172b12c65c60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 483 0x7faf6c67a070 0x172b127e76e0 
[1:1:0712/114047.188005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7faf6e5a22e0 0x172b132766e0 , "https://yule.iqiyi.com/"
[1:1:0712/114047.188511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , MTJXZJZXMY6QUT9K('CLAnatI5Al0pHgsbR1XsgQA')
[1:1:0712/114047.188603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114047.234703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114047.234861:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114047.660504:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://yule.iqiyi.com/"
[1:1:0712/114047.661661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , Je, (t){if(this.count=this.count||0,this.count>=256||Pe>=Ie)return void(window.removeEventListener?windo
[1:1:0712/114047.661762:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114047.934923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://yule.iqiyi.com/"
[1:1:0712/114047.935286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , g.onload, (){g.onload=u;g=window[d]=u;a&&a(b)}
[1:1:0712/114047.935392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114047.990892:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 580, 7faf6efbf881
[1:1:0712/114048.002188:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"483 0x7faf6c67a070 0x172b127e76e0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114048.009271:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"483 0x7faf6c67a070 0x172b127e76e0 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114048.009600:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114048.009924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114048.010059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114048.010410:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114048.010541:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114048.010742:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 627
[1:1:0712/114048.010865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7faf6c67a070 0x172b12588d60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 580 0x7faf6c67a070 0x172b12c65c60 
[1:1:0712/114048.022129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114048.022291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114048.572621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114048.572879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114048.574316:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 627, 7faf6efbf881
[1:1:0712/114048.585150:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"580 0x7faf6c67a070 0x172b12c65c60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114048.585307:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"580 0x7faf6c67a070 0x172b12c65c60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114048.585498:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114048.585760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114048.585858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114048.586143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114048.586236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114048.586423:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 652
[1:1:0712/114048.586526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 652 0x7faf6c67a070 0x172b13256160 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 627 0x7faf6c67a070 0x172b12588d60 
[1:1:0712/114048.825545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114048.825690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114048.846960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 652, 7faf6efbf881
[1:1:0712/114048.856579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"627 0x7faf6c67a070 0x172b12588d60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114048.856746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"627 0x7faf6c67a070 0x172b12588d60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114048.856927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114048.857258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114048.857371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114048.857674:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114048.857757:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114048.857958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 666
[1:1:0712/114048.858115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 666 0x7faf6c67a070 0x172b13d5b460 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 652 0x7faf6c67a070 0x172b13256160 
[1:1:0712/114048.937522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114048.937704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.031245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.031445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.032877:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 666, 7faf6efbf881
[1:1:0712/114049.044239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"652 0x7faf6c67a070 0x172b13256160 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114049.044439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"652 0x7faf6c67a070 0x172b13256160 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114049.044686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114049.044968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114049.045056:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.045352:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114049.045441:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114049.045597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 685
[1:1:0712/114049.045697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 685 0x7faf6c67a070 0x172b131cb760 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 666 0x7faf6c67a070 0x172b13d5b460 
[1:1:0712/114049.112021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.112196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.199410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.199631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.212612:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 685, 7faf6efbf881
[1:1:0712/114049.224501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"666 0x7faf6c67a070 0x172b13d5b460 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114049.224664:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"666 0x7faf6c67a070 0x172b13d5b460 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114049.224846:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114049.225145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114049.225245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.225521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114049.225612:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114049.225768:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 699
[1:1:0712/114049.225869:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 699 0x7faf6c67a070 0x172b1333df60 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 685 0x7faf6c67a070 0x172b131cb760 
[1:1:0712/114049.236217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.236325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.270998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.271162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.295598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.295756:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.329332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.329496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.369441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 699, 7faf6efbf881
[1:1:0712/114049.382513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"685 0x7faf6c67a070 0x172b131cb760 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114049.382715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"685 0x7faf6c67a070 0x172b131cb760 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114049.382925:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114049.383195:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114049.383289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.383558:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114049.383676:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114049.385286:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 714
[1:1:0712/114049.385495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7faf6c67a070 0x172b12bbabe0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 699 0x7faf6c67a070 0x172b1333df60 
[1:1:0712/114049.398896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114049.399112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.453253:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 , "https://yule.iqiyi.com/"
[1:1:0712/114049.477349:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , /*! Built by pcw player group @2019-7-12 09:35:21 */
!function(e,t){"object"==typeof exports&&"objec
[1:1:0712/114049.477547:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114049.507061:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0xeb901d829c8, 0x172b127da1b0
[1:1:0712/114049.507249:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 30000
[1:1:0712/114049.507460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 722
[1:1:0712/114049.507651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 722 0x7faf6c67a070 0x172b124d4ee0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114049.516424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xeb901d829c8, 0x172b127da1b0
[1:1:0712/114049.519881:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/114049.520623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 726
[1:1:0712/114049.520738:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 726 0x7faf6c67a070 0x172b134ea6e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
		remove user.e_b2fe3acf -> 0
[1:1:0712/114049.810075:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xeb901d829c8, 0x172b127da1b0
[1:1:0712/114049.810283:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/114049.810514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 736
[1:1:0712/114049.810678:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7faf6c67a070 0x172b12bb0460 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114050.428458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xeb901d829c8, 0x172b127da1b0
[1:1:0712/114050.428638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/114050.428840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 737
[1:1:0712/114050.428941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 737 0x7faf6c67a070 0x172b1413d9e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114050.431288:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0xeb901d829c8, 0x172b127da1b0
[1:1:0712/114050.431403:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 2000
[1:1:0712/114050.431560:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 738
[1:1:0712/114050.431687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 738 0x7faf6c67a070 0x172b13d5bde0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114050.670604:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 , "https://yule.iqiyi.com/"
[1:1:0712/114050.719182:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 , "https://yule.iqiyi.com/"
[1:1:0712/114050.768948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 , "https://yule.iqiyi.com/"
[1:1:0712/114050.946644:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeb901d829c8, 0x172b127da328
[1:1:0712/114050.946820:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 0
[1:1:0712/114050.947041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 745
[1:1:0712/114050.947164:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7faf6c67a070 0x172b145ec1e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114052.600314:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3600000, 0xeb901d829c8, 0x172b127da328
[1:1:0712/114052.600502:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 3600000
[1:1:0712/114052.600771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 749
[1:1:0712/114052.600866:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 749 0x7faf6c67a070 0x172b156c0ce0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114053.474225:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[6412:6412:0712/114053.943841:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://yule.iqiyi.com/, https://yule.iqiyi.com/, 1
[6412:6412:0712/114053.943918:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://yule.iqiyi.com/, https://yule.iqiyi.com
[1:1:0712/114053.947550:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "iqiyi.com", "iqiyi.com"
[6412:6412:0712/114053.955814:INFO:CONSOLE(1)] "%ciQIYI", source: https://stc.iqiyipic.com/gaze/uniqy/main/js/common.aab3c125.js (1)
[6412:6412:0712/114053.956635:INFO:CONSOLE(1)] "%c一不小心被你发现了:-)
什么都不说了,这里需要喜欢探寻秘密的你!
爱奇艺直聘网址:http://zhaopin.iqiyi.com/", source: https://stc.iqiyipic.com/gaze/uniqy/main/js/common.aab3c125.js (1)
[1:1:0712/114053.992424:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeb901d829c8, 0x172b127da328
[1:1:0712/114053.992592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 0
[1:1:0712/114053.992795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 751
[1:1:0712/114053.992908:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 751 0x7faf6c67a070 0x172b163c7160 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114054.004556:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0xeb901d829c8, 0x172b127da328
[1:1:0712/114054.004684:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 0
[1:1:0712/114054.004842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 752
[1:1:0712/114054.004937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 752 0x7faf6c67a070 0x172b15817fe0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 
[1:1:0712/114054.006023:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 3.3535, 1, 0
[1:1:0712/114054.006167:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/114054.092539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114054.092719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.534736:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/114054.534952:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://yule.iqiyi.com/"
[1:1:0712/114054.537646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 753 0x7faf6c67a070 0x172b15ded5e0 , "https://yule.iqiyi.com/"
[1:1:0712/114054.538546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , 
    (function() { 
        var addedParams = {
            pagec:'7',
            ptp:'2',
        
[1:1:0712/114054.538717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.543103:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 753 0x7faf6c67a070 0x172b15ded5e0 , "https://yule.iqiyi.com/"
[1:1:0712/114054.545802:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://yule.iqiyi.com/"
[1:1:0712/114054.597695:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 714, 7faf6efbf881
[1:1:0712/114054.609380:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"699 0x7faf6c67a070 0x172b1333df60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.609574:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"699 0x7faf6c67a070 0x172b1333df60 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.609824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.610111:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , a, (){clearTimeout(x);var d;r&&(d="visible"==document[r]);y&&(d=!document[y]);m="undefined"==typeof d?t
[1:1:0712/114054.610233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.610517:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114054.610609:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114054.610743:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 799
[1:1:0712/114054.610833:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 799 0x7faf6c67a070 0x172b164f7660 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 714 0x7faf6c67a070 0x172b12bbabe0 
[1:1:0712/114054.611249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 745, 7faf6efbf881
[1:1:0712/114054.623262:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.623466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.623685:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.623974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , (){D.devtools&&et&&et.emit("init",mn)}
[1:1:0712/114054.624307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.624907:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 726, 7faf6efbf881
[1:1:0712/114054.637258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.637436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.637634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.637895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , f, (){s.browser.weixin?s.os.ios?c="02038001010000000000":s.os.android&&(c="02028001010000000000"):s.os.
[1:1:0712/114054.637991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.663113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , document.readyState
[1:1:0712/114054.663277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.664500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 736, 7faf6efbf881
[1:1:0712/114054.677166:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.677346:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.677551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.677848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , P, (){c.browser.weixin?c.os.ios?E="02038001010000000000":c.os.android&&(E="02028001010000000000"):c.os.
[1:1:0712/114054.677962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.678511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 737, 7faf6efbf881
[1:1:0712/114054.689747:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.689881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.690036:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.690316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , S, (){c.browser.weixin?c.os.ios?w="02038001010000000000":c.os.android&&(w="02028001010000000000"):c.os.
[1:1:0712/114054.690454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.691029:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 738, 7faf6efbf881
[1:1:0712/114054.704778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.704951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.705162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.705449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , x, (){c.browser.weixin?c.os.ios?y="02038001010000000000":c.os.android&&(y="02028001010000000000"):c.os.
[1:1:0712/114054.705539:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.732738:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 751, 7faf6efbf881
[1:1:0712/114054.746664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.746868:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.747093:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.747365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , (){navigator.serviceWorker.register("/service-worker.js",{scope:"/"}).then(function(e){}).catch(func
[1:1:0712/114054.747458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.749613:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 752, 7faf6efbf881
[1:1:0712/114054.763670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"16730b782860","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.763866:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://yule.iqiyi.com/","ptid":"711 0x7faf82d05080 0x172b138ce880 1 0 0x172b138ce898 ","rf":"5:3_https://yule.iqiyi.com/"}
[1:1:0712/114054.764092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://yule.iqiyi.com/"
[1:1:0712/114054.764390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://yule.iqiyi.com/, 16730b782860, , , (){(new g).$mount(a.a.appId)}
[1:1:0712/114054.764495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://yule.iqiyi.com/", "iqiyi.com", 3, 1, , , 0
[1:1:0712/114054.782896:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 100
[1:1:0712/114054.783157:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://yule.iqiyi.com/, 802
[1:1:0712/114054.783291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7faf6c67a070 0x172b1613f660 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 752 0x7faf6c67a070 0x172b15817fe0 
[1:1:0712/114054.799927:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0xeb901d829c8, 0x172b127da150
[1:1:0712/114054.800069:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://yule.iqiyi.com/", 800
[1:1:0712/114054.800239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://yule.iqiyi.com/, 803
[1:1:0712/114054.800346:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7faf6c67a070 0x172b160d89e0 , 5:3_https://yule.iqiyi.com/, 1, -5:3_https://yule.iqiyi.com/, 752 0x7faf6c67a070 0x172b15817fe0 
		remove user.f_a4f3caab -> 0
