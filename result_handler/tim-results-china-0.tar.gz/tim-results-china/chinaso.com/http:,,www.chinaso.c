[0712/180629.550412:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/180629.550668:INFO:switcher_clone.cc(787)] backtrace rip is 7f34cca6a891
[0712/180630.103243:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/180630.103505:INFO:switcher_clone.cc(787)] backtrace rip is 7f4414cfd891
[1:1:0712/180630.107867:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/180630.108032:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/180630.110786:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[2992:2992:0712/180630.891029:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/6596fd9c-b5f9-4a77-9082-eeb90f051b20
[0712/180630.937264:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/180630.937505:INFO:switcher_clone.cc(787)] backtrace rip is 7efd9defe891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[3024:3024:0712/180631.084107:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3024
[3037:3037:0712/180631.084454:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=3037
[2992:2992:0712/180631.159556:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[2992:3022:0712/180631.159974:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/180631.160085:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/180631.160244:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/180631.160537:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/180631.160803:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/180631.162513:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2a1e5d47, 1
[1:1:0712/180631.162715:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3ee66ef7, 0
[1:1:0712/180631.162800:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xf17c62f, 3
[1:1:0712/180631.162884:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x319a10c0, 2
[1:1:0712/180631.163012:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff76effffffe63e 475d1e2a ffffffc010ffffff9a31 2fffffffc6170f , 10104, 4
[1:1:0712/180631.163703:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2992:3022:0712/180631.163860:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�n�>G]*��1/��l�
[2992:3022:0712/180631.163899:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �n�>G]*��1/���l�
[1:1:0712/180631.163852:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4412f370a0, 3
[2992:3022:0712/180631.164030:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[2992:3022:0712/180631.164060:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3045, 4, f76ee63e 475d1e2a c0109a31 2fc6170f 
[1:1:0712/180631.164319:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f44130c3080, 2
[1:1:0712/180631.164415:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43fcd85d20, -2
[1:1:0712/180631.172048:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/180631.172500:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 319a10c0
[1:1:0712/180631.172983:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 319a10c0
[1:1:0712/180631.173730:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 319a10c0
[1:1:0712/180631.174328:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.174482:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.174588:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.174686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.174939:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 319a10c0
[1:1:0712/180631.175088:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4414cfd7ba
[1:1:0712/180631.175141:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4414cf4def, 7f4414cfd77a, 7f4414cff0cf
[1:1:0712/180631.176804:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 319a10c0
[1:1:0712/180631.180153:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 319a10c0
[1:1:0712/180631.180478:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 319a10c0
[1:1:0712/180631.181307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.181443:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.181617:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.181722:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 319a10c0
[1:1:0712/180631.182234:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 319a10c0
[1:1:0712/180631.182495:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4414cfd7ba
[1:1:0712/180631.182570:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4414cf4def, 7f4414cfd77a, 7f4414cff0cf
[1:1:0712/180631.185256:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/180631.185546:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/180631.185631:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeb36d4c58, 0x7ffeb36d4bd8)
[1:1:0712/180631.192627:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/180631.195520:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2992:2992:0712/180631.610691:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2992:2992:0712/180631.611176:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2992:3004:0712/180631.619253:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[2992:3004:0712/180631.619319:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[2992:2992:0712/180631.619355:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[2992:2992:0712/180631.619398:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[2992:2992:0712/180631.619466:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,3045, 4
[1:7:0712/180631.620209:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/180631.660863:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x86a041e3220
[1:1:0712/180631.661018:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[2992:3017:0712/180631.680548:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/180631.874479:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/180632.540607:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180632.542209:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2992:2992:0712/180632.542527:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[2992:2992:0712/180632.542578:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/180632.947990:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180632.990912:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/180632.991082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180632.996162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/180632.996322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180633.088138:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180633.088298:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180633.237950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180633.240439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/180633.240569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180633.257009:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180633.259955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/180633.260087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180633.263818:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2992:2992:0712/180633.264451:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/180633.265591:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x86a041e1e20
[1:1:0712/180633.265711:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[2992:2992:0712/180633.266898:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[2992:2992:0712/180633.278236:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[2992:2992:0712/180633.278316:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/180633.297452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180633.595750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f43fe9602e0 0x86a0443f460 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180633.596391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/180633.596514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180633.597075:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2992:2992:0712/180633.621457:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/180633.622567:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x86a041e2820
[1:1:0712/180633.622698:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[2992:2992:0712/180633.623847:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/180633.629427:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/180633.629586:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[2992:2992:0712/180633.630640:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[2992:2992:0712/180633.634605:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2992:2992:0712/180633.635019:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2992:3004:0712/180633.639364:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[2992:3004:0712/180633.639417:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[2992:2992:0712/180633.639443:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[2992:2992:0712/180633.639479:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[2992:2992:0712/180633.639536:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,3045, 4
[1:7:0712/180633.640878:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/180633.891412:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/180634.017392:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7f43fe9602e0 0x86a04533de0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180634.018060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/180634.018236:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180634.018701:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2992:2992:0712/180634.177474:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[2992:2992:0712/180634.177556:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/180634.189812:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/180634.362867:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[2992:2992:0712/180634.537377:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[2992:3022:0712/180634.537653:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/180634.537785:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/180634.537921:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/180634.538111:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/180634.538191:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/180634.540249:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2e759eb4, 1
[1:1:0712/180634.540442:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3c38438f, 0
[1:1:0712/180634.540536:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xe2e6240, 3
[1:1:0712/180634.540623:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x37b19485, 2
[1:1:0712/180634.540699:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8f43383c ffffffb4ffffff9e752e ffffff85ffffff94ffffffb137 40622e0e , 10104, 5
[1:1:0712/180634.541410:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2992:3022:0712/180634.541628:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�C8<��u.���7@b.�l�
[2992:3022:0712/180634.541679:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �C8<��u.���7@b.e�l�
[1:1:0712/180634.541618:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4412f370a0, 3
[2992:3022:0712/180634.541837:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 3088, 5, 8f43383c b49e752e 8594b137 40622e0e 
[1:1:0712/180634.541820:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f44130c3080, 2
[1:1:0712/180634.541933:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f43fcd85d20, -2
[1:1:0712/180634.549655:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180634.549819:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180634.551486:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/180634.551662:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 37b19485
[1:1:0712/180634.551867:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 37b19485
[1:1:0712/180634.552123:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 37b19485
[1:1:0712/180634.552638:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.552763:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.552843:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.552929:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.553215:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 37b19485
[1:1:0712/180634.553413:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4414cfd7ba
[1:1:0712/180634.553479:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4414cf4def, 7f4414cfd77a, 7f4414cff0cf
[1:1:0712/180634.555205:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 37b19485
[1:1:0712/180634.555377:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 37b19485
[1:1:0712/180634.555683:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 37b19485
[1:1:0712/180634.556477:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.556577:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.556660:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.556739:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 37b19485
[1:1:0712/180634.557248:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 37b19485
[1:1:0712/180634.557408:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4414cfd7ba
[1:1:0712/180634.557470:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4414cf4def, 7f4414cfd77a, 7f4414cff0cf
[1:1:0712/180634.560195:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/180634.560422:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/180634.560509:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeb36d4c58, 0x7ffeb36d4bd8)
[1:1:0712/180634.569607:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/180634.571800:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/180634.659595:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x86a041a3220
[1:1:0712/180634.660397:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/180634.749173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180634.750778:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/180634.750970:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180634.753382:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180634.810635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180634.811075:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1dd0a8161f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/180634.811211:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180634.869763:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180634.870554:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/180634.870788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/180634.870953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180634.936747:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180634.937325:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/180634.937454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/180634.937648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.035438:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/180635.200016:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/180635.250972:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/180635.302988:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/180635.337007:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/180635.362521:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/180635.408356:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/180635.444623:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/180635.475418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.475839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.475977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.504071:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.504501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.504627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.524865:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.525341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.525506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.554599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.555026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.555168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.577380:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.577823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.577966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.608141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.608551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.608692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.646533:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.646975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.647123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.667895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.668314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.668450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.706678:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.707086:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.707230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.727854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.728272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.728428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.758522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.758936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.759070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.778249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.778719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.778862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.808617:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.809094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.809282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.849164:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.849634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.849816:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.880357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.880800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/180635.880915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180635.910143:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180635.910615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1dd0a828e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/180635.910776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[2992:2992:0712/180635.990502:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2992:2992:0712/180635.992513:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2992:3004:0712/180636.003655:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[2992:3004:0712/180636.003739:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[2992:2992:0712/180636.003905:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.chinaso.com/
[2992:2992:0712/180636.003947:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.chinaso.com/, http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF, 1
[2992:2992:0712/180636.004007:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.chinaso.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 10:06:36 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Server: nginx Set-Cookie: cookie_name=218.241.135.34.1562925994783181; path=/; max-age=15552000 Expires: Fri, 12 Jul 2019 10:06:34 GMT Cache-Control: no-cache Content-Encoding: gzip X-Cache: MISS from cache.51cdn.com X-Via: 1.1 hbtj81:2 (Cdn Cache Server V2.0), 1.1 hkuan33:4 (Cdn Cache Server V2.0)  ,3088, 5
[1:7:0712/180636.005601:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/180636.018969:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.chinaso.com/
[2992:2992:0712/180636.077830:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.chinaso.com/, http://www.chinaso.com/, 1
[2992:2992:0712/180636.077893:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.chinaso.com/, http://www.chinaso.com
[1:1:0712/180636.086486:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/180636.127404:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.153804:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.158517:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.348033:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180636.476926:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 181 0x7f43fcda0bd0 0x86a0424cfd8 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.480727:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180636.483274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , /*2017-04-25 10:48:19 - static_tmp/base/js/jquery-1.9.1.min.js*/!function(a,b){function c(a){var b=a
[1:1:0712/180636.483457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180636.588160:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 181 0x7f43fcda0bd0 0x86a0424cfd8 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.660492:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0744629, 64, 1
[1:1:0712/180636.660692:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.721591:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.721769:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.724142:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7f43fca38070 0x86a0442f160 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.728986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , /*! Date:Tue May 22 2018 14:35:31 GMT+0800 (中国标准时间), chunkhash:4b2315db1810bee7e5f3 */
!
[1:1:0712/180636.729167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180636.779902:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.058408, 54, 1
[1:1:0712/180636.780681:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.821646:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.821836:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.822467:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 209 0x7f43fca38070 0x86a04434560 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.823455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , 
$(function(){
    var q = '%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA
[1:1:0712/180636.823627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180636.843318:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0213332, 429, 1
[1:1:0712/180636.843478:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.864647:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180636.864797:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.865340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f43fca38070 0x86a0442df60 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180636.865901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , window.q=",视觉中国恢复上线";
[1:1:0712/180636.866027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180636.868142:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f43fca38070 0x86a0442df60 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180637.424241:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x93bde6429c8, 0x86a03cb61d8
[1:1:0712/180637.424450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", 3000
[1:1:0712/180637.424754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 224
[1:1:0712/180637.424892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 224 0x7f43fca38070 0x86a0442ac60 , 5:3_http://www.chinaso.com/, 1, -5:3_http://www.chinaso.com/, 215 0x7f43fca38070 0x86a0442df60 
[1:1:0712/180637.426321:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.561386, 0, 0
[1:1:0712/180637.426498:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180637.469394:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180637.469580:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180637.470212:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 225 0x7f43fca38070 0x86a044ce160 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180637.471143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , 
$(function(){
	function showTimeString(date){
        date = parseInt(date,10)*1000;
		var result =
[1:1:0712/180637.471299:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180637.475894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 225 0x7f43fca38070 0x86a044ce160 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180637.500645:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 225 0x7f43fca38070 0x86a044ce160 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180637.560693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 225 0x7f43fca38070 0x86a044ce160 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180639.835476:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/180649.108628:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/180649.145307:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 11.6756, 44, 0
[1:1:0712/180649.145466:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180649.253888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/180649.254094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180649.374057:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180649.374239:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.375714:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f43fca38070 0x86a042ab360 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.376766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , /*2018-01-31 16:27:37 - dist/base/js/searchbox_channel.js*/!function(a,b){var c=b("#flpage"),d=c.fin
[1:1:0712/180649.376919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180649.382605:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x93bde6429c8, 0x86a03cb61a8
[1:1:0712/180649.382776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", 100
[1:1:0712/180649.383030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 290
[1:1:0712/180649.383173:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 290 0x7f43fca38070 0x86a04537b60 , 5:3_http://www.chinaso.com/, 1, -5:3_http://www.chinaso.com/, 262 0x7f43fca38070 0x86a042ab360 
[1:1:0712/180649.430219:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f43fca38070 0x86a042ab360 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.431569:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f43fca38070 0x86a042ab360 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.440117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f43fca38070 0x86a042ab360 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.443248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 262 0x7f43fca38070 0x86a042ab360 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.484233:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 224, 7f43ff37d881
[1:1:0712/180649.488838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"049e38702860","ptid":"215 0x7f43fca38070 0x86a0442df60 ","rf":"5:3_http://www.chinaso.com/"}
[1:1:0712/180649.488981:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chinaso.com/","ptid":"215 0x7f43fca38070 0x86a0442df60 ","rf":"5:3_http://www.chinaso.com/"}
[1:1:0712/180649.489154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.489528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , e, (){var e=$("div.resultWrapper > table.adTable");var t=$("div.erroResult");var a=$("div.resultWrapper
[1:1:0712/180649.489646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180649.615384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , document.readyState
[1:1:0712/180649.615603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180649.846083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304, "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180649.846841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , var ROOTDM=[".chinaso.com",".emall001.com",".lovelycn.cn",".ecochina.net",".brsn.net"],RECENDM=[],IN
[1:1:0712/180649.846962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.002177:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304, "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.019002:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.076292:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x93bde6429c8, 0x86a03cb6440
[1:1:0712/180650.076495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", 2000
[1:1:0712/180650.076762:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 359
[1:1:0712/180650.076899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 359 0x7f43fca38070 0x86a04bbc0e0 , 5:3_http://www.chinaso.com/, 1, -5:3_http://www.chinaso.com/, 304
[1:1:0712/180650.128595:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x93bde6429c8, 0x86a03cb6440
[1:1:0712/180650.128846:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", 2000
[1:1:0712/180650.129116:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 361
[1:1:0712/180650.129255:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 361 0x7f43fca38070 0x86a042f6ce0 , 5:3_http://www.chinaso.com/, 1, -5:3_http://www.chinaso.com/, 304
[1:1:0712/180650.187794:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 290, 7f43ff37d881
[1:1:0712/180650.193416:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"049e38702860","ptid":"262 0x7f43fca38070 0x86a042ab360 ","rf":"5:3_http://www.chinaso.com/"}
[1:1:0712/180650.193588:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chinaso.com/","ptid":"262 0x7f43fca38070 0x86a042ab360 ","rf":"5:3_http://www.chinaso.com/"}
[1:1:0712/180650.193734:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.194087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , (){d.focus(),g.addClass("searchClick")}
[1:1:0712/180650.194157:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.243085:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , document.readyState
[1:1:0712/180650.243235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.401748:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7f43fe9602e0 0x86a044ce6e0 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.402361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , __setpinyin({"status":0,"msg":"success","data":"{\"pinyin\":\"shijuezhongguohuifushangxian\",\"jianp
[1:1:0712/180650.402474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.404511:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.411400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7f43fe9602e0 0x86a0452be60 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.412027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , /*2018-03-19 16:57:33 - dist/base/js/statistics.js*/!function(){var a="0.1.1",b={sendUrlPath:"/feapi
[1:1:0712/180650.412129:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.542420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.542910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , (){if(P==null){P=setTimeout(function(){w=v();t&&D.put([1,w[0],w[1]]);H();P=null},500)}}
[1:1:0712/180650.543030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.543543:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x93bde6429c8, 0x86a03cb6220
[1:1:0712/180650.543661:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", 500
[1:1:0712/180650.543910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 385
[1:1:0712/180650.544017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 385 0x7f43fca38070 0x86a0452a3e0 , 5:3_http://www.chinaso.com/, 1, -5:3_http://www.chinaso.com/, 350 0x7f440bd49960 0x86a04c279c0 0x86a04c279d0 
[1:1:0712/180650.544186:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.671637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.672169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , d, (a,e){var h,j,k,l;try{if(d&&(e||4===i.readyState))if(d=b,g&&(i.onreadystatechange=ia.noop,Zb&&delete
[1:1:0712/180650.672282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.672929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.674494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.675037:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x187b7ff575f8
[1:1:0712/180650.718615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , document.readyState
[1:1:0712/180650.718771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.849055:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.849565:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , _wdEC, (){}
[1:1:0712/180650.849683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.880302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , document.readyState
[1:1:0712/180650.880455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.901669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 402 0x7f43fe9602e0 0x86a042ae3e0 , "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.902280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , jQuery191028843480508965014_1562925996564({"errNo":0,"list":{"num_results":null},"items":[]})
[1:1:0712/180650.902383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.902873:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.963839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180650.964273:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , d.onload.d.onerror.d.onabort, (){d.onload=d.onerror=d.onabort=null,d=window[e]=null,c&&c(a)}
[1:1:0712/180650.964375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180650.977625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , document.readyState
[1:1:0712/180650.977793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
[1:1:0712/180651.112435:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.chinaso.com/, 385, 7f43ff37d881
[1:1:0712/180651.118815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"049e38702860","ptid":"350 0x7f440bd49960 0x86a04c279c0 0x86a04c279d0 ","rf":"5:3_http://www.chinaso.com/"}
[1:1:0712/180651.118953:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.chinaso.com/","ptid":"350 0x7f440bd49960 0x86a04c279c0 0x86a04c279d0 ","rf":"5:3_http://www.chinaso.com/"}
[1:1:0712/180651.119107:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF"
[1:1:0712/180651.119426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.chinaso.com/, 049e38702860, , , (){w=v();t&&D.put([1,w[0],w[1]]);H();P=null}
[1:1:0712/180651.119533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.chinaso.com/search/pagesearch.htm?q=%2C%E8%A7%86%E8%A7%89%E4%B8%AD%E5%9B%BD%E6%81%A2%E5%A4%8D%E4%B8%8A%E7%BA%BF", "www.chinaso.com", 3, 1, , , 0
