[0712/175736.097780:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/175736.098031:INFO:switcher_clone.cc(787)] backtrace rip is 7f9b6ddbf891
[0712/175736.641118:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/175736.641376:INFO:switcher_clone.cc(787)] backtrace rip is 7fb292447891
[1:1:0712/175736.645183:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/175736.645357:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/175736.648079:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[1257:1257:0712/175737.414075:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/7a95ab7d-9b1f-44ed-8d71-3f596c7cd721
[0712/175737.470457:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/175737.470699:INFO:switcher_clone.cc(787)] backtrace rip is 7f6d620a1891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1290:1290:0712/175737.620055:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1290
[1303:1303:0712/175737.620343:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1303
[1257:1257:0712/175737.660255:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[1257:1288:0712/175737.660651:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/175737.660759:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/175737.660888:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/175737.661184:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/175737.661341:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/175737.663166:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x4aaf38, 1
[1:1:0712/175737.663405:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x103eb639, 0
[1:1:0712/175737.663503:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31c63aa2, 3
[1:1:0712/175737.663595:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a1f6b17, 2
[1:1:0712/175737.663681:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 39ffffffb63e10 38ffffffaf4a00 176b1f2a ffffffa23affffffc631 , 10104, 4
[1:1:0712/175737.664369:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1257:1288:0712/175737.664484:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING9�>8�J
[1:1:0712/175737.664475:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb2906810a0, 3
[1257:1288:0712/175737.664525:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 9�>8�J
[1:1:0712/175737.664539:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb29080d080, 2
[1:1:0712/175737.664605:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb27a4cfd20, -2
[1257:1288:0712/175737.664665:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1257:1288:0712/175737.664692:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1311, 4, 39b63e10 38af4a00 176b1f2a a23ac631 
[1:1:0712/175737.672357:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/175737.672764:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1f6b17
[1:1:0712/175737.673234:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1f6b17
[1:1:0712/175737.673987:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1f6b17
[1:1:0712/175737.674522:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.674637:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.674747:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.674854:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.675108:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1f6b17
[1:1:0712/175737.675252:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb2924477ba
[1:1:0712/175737.675333:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb29243edef, 7fb29244777a, 7fb2924490cf
[1:1:0712/175737.676921:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a1f6b17
[1:1:0712/175737.677120:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a1f6b17
[1:1:0712/175737.677475:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a1f6b17
[1:1:0712/175737.678281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.678393:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.678492:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.678591:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a1f6b17
[1:1:0712/175737.679105:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a1f6b17
[1:1:0712/175737.679640:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb2924477ba
[1:1:0712/175737.679731:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb29243edef, 7fb29244777a, 7fb2924490cf
[1:1:0712/175737.682280:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/175737.682502:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/175737.682615:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd9d626088, 0x7ffd9d626008)
[1:1:0712/175737.689594:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/175737.692306:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1257:1257:0712/175738.104098:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1257:1257:0712/175738.104641:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1257:1257:0712/175738.113346:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[1257:1257:0712/175738.113408:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[1257:1257:0712/175738.113479:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,1311, 4
[1257:1268:0712/175738.115715:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[1257:1268:0712/175738.115773:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/175738.117454:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/175738.166201:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3b0df996c220
[1:1:0712/175738.166398:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1257:1282:0712/175738.178275:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/175738.363242:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/175739.085463:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/175739.086993:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1257:1257:0712/175739.305580:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1257:1257:0712/175739.305698:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/175739.540844:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/175739.626517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/175739.626689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/175739.631615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/175739.631733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/175739.660197:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/175739.660337:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175739.812183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175739.814727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/175739.814859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/175739.826727:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175739.829695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/175739.829823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/175739.833561:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1257:1257:0712/175739.834166:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/175739.835241:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b0df996ae20
[1:1:0712/175739.835343:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1257:1257:0712/175739.836601:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1257:1257:0712/175739.847869:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[1257:1257:0712/175739.847947:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/175739.867431:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175740.173943:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fb27c0aa2e0 0x3b0df9a1c2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175740.174643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/175740.174798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/175740.175378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1257:1257:0712/175740.201221:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1257:1257:0712/175740.203479:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/175740.202420:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3b0df996b820
[1:1:0712/175740.203549:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/175740.210569:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/175740.210725:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[1257:1257:0712/175740.212213:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[1257:1257:0712/175740.216104:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1257:1257:0712/175740.216477:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1257:1268:0712/175740.221334:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[1257:1268:0712/175740.221398:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1257:1257:0712/175740.221411:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[1257:1257:0712/175740.221451:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[1257:1257:0712/175740.221513:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,1311, 4
[1:7:0712/175740.223003:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/175740.490898:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/175740.616013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7fb27c0aa2e0 0x3b0df99ee0e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175740.616618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/175740.616766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/175740.617172:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1257:1257:0712/175740.749946:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[1257:1257:0712/175740.750021:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/175740.761366:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/175740.904741:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1257:1257:0712/175741.050541:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[1257:1288:0712/175741.050811:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/175741.050929:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/175741.051055:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/175741.051232:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/175741.051322:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/175741.053261:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36355cef, 1
[1:1:0712/175741.053468:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x36252aa, 0
[1:1:0712/175741.053559:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1637eb30, 3
[1:1:0712/175741.053719:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x695a59, 2
[1:1:0712/175741.053798:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffaa526203 ffffffef5c3536 595a6900 30ffffffeb3716 , 10104, 5
[1:1:0712/175741.054494:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1257:1288:0712/175741.054709:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Rb�\56YZi
[1257:1288:0712/175741.054762:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Rb�\56YZi
[1:1:0712/175741.054702:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb2906810a0, 3
[1257:1288:0712/175741.054929:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1360, 5, aa526203 ef5c3536 595a6900 30eb3716 
[1:1:0712/175741.054898:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb29080d080, 2
[1:1:0712/175741.055001:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb27a4cfd20, -2
[1:1:0712/175741.064058:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/175741.064250:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 695a59
[1:1:0712/175741.064398:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 695a59
[1:1:0712/175741.064645:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 695a59
[1:1:0712/175741.065142:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.065237:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.065328:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.065424:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.065666:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 695a59
[1:1:0712/175741.065793:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb2924477ba
[1:1:0712/175741.065874:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb29243edef, 7fb29244777a, 7fb2924490cf
[1:1:0712/175741.067548:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 695a59
[1:1:0712/175741.067713:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 695a59
[1:1:0712/175741.068060:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 695a59
[1:1:0712/175741.068878:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.068974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.069077:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.069245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 695a59
[1:1:0712/175741.069793:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 695a59
[1:1:0712/175741.070032:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb2924477ba
[1:1:0712/175741.070133:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb29243edef, 7fb29244777a, 7fb2924490cf
[1:1:0712/175741.072686:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/175741.072904:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/175741.072971:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd9d626088, 0x7ffd9d626008)
[1:1:0712/175741.079133:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/175741.081106:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/175741.089879:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/175741.090060:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/175741.193831:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b0df98fc220
[1:1:0712/175741.194035:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/175741.302196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/175741.303926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1cf24ab8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/175741.304087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/175741.306900:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/175741.366251:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/175741.366643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1cf24aa61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/175741.366770:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1257:1257:0712/175741.385510:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1257:1257:0712/175741.400565:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[1257:1288:0712/175741.400999:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/175741.405172:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/175741.405337:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/175741.405538:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/175741.405625:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/175741.409428:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2af5c9bf, 1
[1:1:0712/175741.409676:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x206e381a, 0
[1:1:0712/175741.409787:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1d1cf9ae, 3
[1:1:0712/175741.409865:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e8f1235, 2
[1:1:0712/175741.409943:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1a386e20 ffffffbfffffffc9fffffff52a 3512ffffff8f1e ffffffaefffffff91c1d , 10104, 6
[1:1:0712/175741.410662:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1257:1288:0712/175741.410798:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING8n ���*5�����
[1257:1288:0712/175741.410840:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 8n ���*5���_��
[1:1:0712/175741.410792:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb2906810a0, 3
[1:1:0712/175741.410905:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb29080d080, 2
[1257:1288:0712/175741.410980:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1372, 6, 1a386e20 bfc9f52a 35128f1e aef91c1d 
[1:1:0712/175741.410986:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fb27a4cfd20, -2
[1257:1257:0712/175741.416176:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/175741.420064:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/175741.420298:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e8f1235
[1:1:0712/175741.420447:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e8f1235
[1:1:0712/175741.420695:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e8f1235
[1:1:0712/175741.421218:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.421336:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.421453:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.421573:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.421837:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e8f1235
[1:1:0712/175741.421987:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb2924477ba
[1:1:0712/175741.422089:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb29243edef, 7fb29244777a, 7fb2924490cf
[1:1:0712/175741.423716:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e8f1235
[1:1:0712/175741.423881:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e8f1235
[1:1:0712/175741.424170:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e8f1235
[1:1:0712/175741.424905:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.424988:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.425082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.425198:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e8f1235
[1:1:0712/175741.425676:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e8f1235
[1:1:0712/175741.425852:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fb2924477ba
[1:1:0712/175741.425946:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fb29243edef, 7fb29244777a, 7fb2924490cf
[1:1:0712/175741.428491:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/175741.428692:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/175741.428785:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd9d626088, 0x7ffd9d626008)
[1257:1268:0712/175741.433443:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[1257:1268:0712/175741.433519:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[1257:1257:0712/175741.434290:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.toutiao.com/
[1257:1257:0712/175741.434340:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.toutiao.com/, https://www.toutiao.com/, 1
[1257:1257:0712/175741.434402:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.toutiao.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=utf-8 date:Fri, 12 Jul 2019 09:57:41 GMT vary:Accept-Encoding vary:Accept-Encoding vary:Accept-Encoding set-cookie:tt_webid=6712713689726813709; Max-Age=7776000 server-timing:inner;dur=0.004, inner; dur=4 content-encoding:gzip x-ss-set-cookie:tt_webid=6712713689726813709; Max-Age=7776000 x-tt-timestamp:1562925461.391 via:cache43.l2cm12-6[8,0], cache5.cn763[12,0] timing-allow-origin:* eagleid:7cc8711915629254613836084e  ,0, 6
[1:1:0712/175741.436089:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[3:3:0712/175741.436669:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/175741.438932:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:7:0712/175741.468020:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/175741.475447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/175741.476244:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/175741.476365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1cf24ab8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/175741.476480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/175741.545048:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b0df9941220
[1:1:0712/175741.545199:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/175741.545456:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/175741.545849:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/175741.545975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1cf24ab8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/175741.546108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/175741.571354:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.toutiao.com/
[1257:1257:0712/175741.699755:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.toutiao.com/, https://www.toutiao.com/, 1
[1257:1257:0712/175741.699827:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.toutiao.com/, https://www.toutiao.com
[1:1:0712/175741.714811:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/175741.763469:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/175741.793529:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/175741.793687:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.toutiao.com/"
[1:1:0712/175741.856553:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/175741.915474:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/175741.995101:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7fb29080d080 0x3b0df9ac32e0 1 0 0x3b0df9ac32f8 , "https://www.toutiao.com/"
[1:1:0712/175741.997523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , !function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==type
[1:1:0712/175741.997665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175742.001501:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/175742.007236:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 156 0x7fb29080d080 0x3b0df9ac32e0 1 0 0x3b0df9ac32f8 , "https://www.toutiao.com/"
[1:1:0712/175742.118602:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/175742.121433:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7fb27a182070 0x3b0df9b366e0 , "https://www.toutiao.com/"
[1:1:0712/175742.122216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , !function(e){function t(a){if(o[a])return o[a].exports;var r=o[a]={exports:{},id:a,loaded:!1};return
[1:1:0712/175742.122344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175742.123564:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7fb27a182070 0x3b0df9b366e0 , "https://www.toutiao.com/"
[1:1:0712/175742.124699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7fb27a182070 0x3b0df9b366e0 , "https://www.toutiao.com/"
[1:1:0712/175742.125830:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7fb27a182070 0x3b0df9b366e0 , "https://www.toutiao.com/"
[1:1:0712/175742.126679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 173 0x7fb27a182070 0x3b0df9b366e0 , "https://www.toutiao.com/"
[1:1:0712/175742.134636:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/175742.155962:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/175742.192992:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/175742.251805:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/175742.274497:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/175742.306247:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/175742.456259:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7fb27a4eabd0 0x3b0df9a29158 , "https://www.toutiao.com/"
[1:1:0712/175742.468300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , webpackJsonp([1,0],[,function(t,e){t.exports=function(t,e,n,r){var o,i=t=t||{},a=typeof t.default;"o
[1:1:0712/175742.468511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175742.501296:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7fb27a4eabd0 0x3b0df9a29158 , "https://www.toutiao.com/"
[1:1:0712/175742.573540:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x17aa91029c8, 0x3b0df97d0fc0
[1:1:0712/175742.573758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 0
[1:1:0712/175742.573990:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 205
[1:1:0712/175742.574159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 205 0x7fb27a182070 0x3b0df9a36be0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 202 0x7fb27a4eabd0 0x3b0df9a29158 
[1:1:0712/175743.125290:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x17aa91029c8, 0x3b0df97d0fc0
[1:1:0712/175743.125516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1
[1:1:0712/175743.125741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 213
[1:1:0712/175743.125907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 213 0x7fb27a182070 0x3b0df9b37160 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 202 0x7fb27a4eabd0 0x3b0df9a29158 
[1:1:0712/175746.331738:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/175754.520501:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175754.529635:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175754.551728:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 360000, 0x17aa91029c8, 0x3b0df97d0fc0
[1:1:0712/175754.551900:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 360000
[1:1:0712/175754.552110:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 238
[1:1:0712/175754.552258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 238 0x7fb27a182070 0x3b0dfd740ae0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 202 0x7fb27a4eabd0 0x3b0df9a29158 
[3:3:0712/175755.021193:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/175755.477569:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175755.480181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 60000
[1:1:0712/175755.480465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.toutiao.com/, 259
[1:1:0712/175755.480610:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 259 0x7fb27a182070 0x3b0dfdf209e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 202 0x7fb27a4eabd0 0x3b0df9a29158 
[1:1:0712/175755.509857:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175755.515794:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175755.520917:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175755.529015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x17aa91029c8, 0x3b0df97d0fc0
[1:1:0712/175755.529209:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 15000
[1:1:0712/175755.529416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 266
[1:1:0712/175755.529535:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 266 0x7fb27a182070 0x3b0dfd85a0e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 202 0x7fb27a4eabd0 0x3b0df9a29158 
[1257:1257:0712/175755.546594:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.toutiao.com/' was loaded over HTTPS, but requested an insecure image 'http://p3.pstatp.com/origin/b76b00091cadfe239a6a'. This content should also be served over HTTPS.", source: https://www.toutiao.com/ (0)
[1:1:0712/175755.696354:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.1996, 0, 1
[1:1:0712/175755.696559:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/175755.719048:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.toutiao.com/"
[1:1:0712/175755.719791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (n){n.source===t&&"string"==typeof n.data&&0===n.data.indexOf(e)&&a(+n.data.slice(e.length))}
[1:1:0712/175755.719928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175755.762545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/175755.762707:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175755.871664:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175755.872117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175755.872251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175755.873318:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175755.875342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175755.877081:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e63b80
[1:1:0712/175756.482555:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/175756.933160:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175756.933604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175756.933771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175756.934342:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175756.935938:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175756.937129:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e63b80
		remove user.f_2af71081 -> 0
[1:1:0712/175757.424949:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.425363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175757.425522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175757.426022:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.427536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.438886:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e63b80
[1:1:0712/175757.877480:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x17aa91029c8, 0x3b0df97d0a10
[1:1:0712/175757.877683:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 200
[1:1:0712/175757.877929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 326
[1:1:0712/175757.878018:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 326 0x7fb27a182070 0x3b0dfd8588e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 271
[1:1:0712/175757.922762:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.923223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175757.923383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175757.923778:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.925004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.934262:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e63b80
[1:1:0712/175757.997447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175757.998160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175757.998291:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175757.998711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175758.000088:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175758.012140:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e63b80
[1:1:0712/175758.610953:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/175758.611105:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.toutiao.com/"
[1:1:0712/175758.612355:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7fb27a182070 0x3b0dfe14a0e0 , "https://www.toutiao.com/"
[1:1:0712/175758.613365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , webpackJsonp([4,0],{0:function(e,t,n){e.exports=n(524)},524:function(e,t){!function(e,t,n){function 
[1:1:0712/175758.613501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175758.615241:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e69758
[1:1:0712/175758.617934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7fb27a182070 0x3b0dfe14a0e0 , "https://www.toutiao.com/"
[1:1:0712/175758.633894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7fb27a182070 0x3b0dfe14a0e0 , "https://www.toutiao.com/"
[1:1:0712/175758.663528:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 281 0x7fb27a182070 0x3b0dfe14a0e0 , "https://www.toutiao.com/"
[1257:1257:0712/175758.714686:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1259612802&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/z_stat.php?id=1259612802&web_id=1259612802 (17)
[1:1:0712/175758.720290:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 205, 7fb27cac7881
[1257:1257:0712/175758.720588:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, https://c.cnzz.com/core.php?web_id=1259612802&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: https://s95.cnzz.com/z_stat.php?id=1259612802&web_id=1259612802 (17)
[1:1:0712/175758.727382:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"202 0x7fb27a4eabd0 0x3b0df9a29158 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175758.727590:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"202 0x7fb27a4eabd0 0x3b0df9a29158 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175758.727786:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175758.728042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , (){_r.devtools&&Dr&&Dr.emit("init",Jt)}
[1:1:0712/175758.728199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175758.735193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 213, 7fb27cac7881
[1:1:0712/175758.741549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"202 0x7fb27a4eabd0 0x3b0df9a29158 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175758.741735:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"202 0x7fb27a4eabd0 0x3b0df9a29158 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175758.741950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175758.742259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , y, (){if(s.isReal()){var t=f.default.getElementsByTagName("video"),e=f.default.getElementsByTagName("au
[1:1:0712/175758.742363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175758.744624:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x17aa91029c8, 0x3b0df97d0950
[1:1:0712/175758.744777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1
[1:1:0712/175758.744997:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 386
[1:1:0712/175758.745131:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 386 0x7fb27a182070 0x3b0dfffb8ae0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 213 0x7fb27a182070 0x3b0df9b37160 
[1:1:0712/175758.757265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , document.readyState
[1:1:0712/175758.757409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175758.788228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , e, (){var i,p;if(f){if(r.length&&!l)for(i=0;i<r.length;i++){if(p=r[i],!p.complete){l=!1;break}l=!0}else
[1:1:0712/175758.788392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175758.969253:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175758.969628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175758.969742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175758.970388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175758.973007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175758.984372:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e63b80
[1:1:0712/175759.067430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2300, 0x17aa91029c8, 0x3b0df97d0a10
[1:1:0712/175759.067626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 2300
[1:1:0712/175759.067843:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 421
[1:1:0712/175759.067994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 421 0x7fb27a182070 0x3b0dffee15e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 298
[1:1:0712/175802.595118:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 326, 7fb27cac7881
[1:1:0712/175802.605045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"271","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175802.605315:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"271","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175802.605592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175802.605972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , s, (){r=Date.now(),n=!1,t.apply(i,a)}
[1:1:0712/175802.606134:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175802.910776:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "https://www.toutiao.com/"
[1:1:0712/175802.912259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/175802.912435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175802.930632:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "https://www.toutiao.com/"
[1:1:0712/175802.938549:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385, "https://www.toutiao.com/"
[1:1:0712/175802.942851:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.toutiao.com/"
[1:1:0712/175802.973149:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 386, 7fb27cac7881
[1:1:0712/175802.984848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"213 0x7fb27a182070 0x3b0df9b37160 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175802.985054:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"213 0x7fb27a182070 0x3b0df9b37160 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175802.985301:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175802.985591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175802.985690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175802.988017:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x17aa91029c8, 0x3b0df97d0950
[1:1:0712/175802.988153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1
[1:1:0712/175802.988354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 736
[1:1:0712/175802.988481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 736 0x7fb27a182070 0x3b0e021179e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 386 0x7fb27a182070 0x3b0dfffb8ae0 
[1:1:0712/175803.001333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , document.readyState
[1:1:0712/175803.001506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175803.261835:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.toutiao.com/"
[1:1:0712/175803.262217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , m, (){var t=i(),n=p(t);if(g=arguments,_=this,x=t,n){if(void 0===T)return c(x);if(O)return T=setTimeout(
[1:1:0712/175803.262332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175803.263713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 150, 0x17aa91029c8, 0x3b0df97d0a20
[1:1:0712/175803.263813:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 150
[1:1:0712/175803.263960:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 768
[1:1:0712/175803.264054:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 768 0x7fb27a182070 0x3b0e01fd1460 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 403 0x7fb289493960 0x3b0dffec4d80 0x3b0dffec4d90 
[1:1:0712/175806.297180:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 421, 7fb27cac7881
[1:1:0712/175806.310141:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"298","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175806.310440:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"298","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175806.310741:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175806.311104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175806.311231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175806.902005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175806.902471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175806.902634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175807.165736:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175807.166157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175807.166295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175808.070333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 736, 7fb27cac7881
[1:1:0712/175808.083644:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"386 0x7fb27a182070 0x3b0dfffb8ae0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175808.083821:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"386 0x7fb27a182070 0x3b0dfffb8ae0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175808.084025:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175808.084296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175808.084404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175808.085353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x17aa91029c8, 0x3b0df97d0950
[1:1:0712/175808.085447:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1
[1:1:0712/175808.085608:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 830
[1:1:0712/175808.085713:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7fb27a182070 0x3b0e025817e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 736 0x7fb27a182070 0x3b0e021179e0 
[1:1:0712/175808.098237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , document.readyState
[1:1:0712/175808.098368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175808.174852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175808.175303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175808.175439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175808.656679:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 768, 7fb27cac7881
[1:1:0712/175808.669341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"403 0x7fb289493960 0x3b0dffec4d80 0x3b0dffec4d90 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175808.669549:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"403 0x7fb289493960 0x3b0dffec4d80 0x3b0dffec4d90 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175808.669800:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175808.670127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175808.670286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175808.763889:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 781 0x7fb27c0aa2e0 0x3b0e021f0260 , "https://www.toutiao.com/"
[1:1:0712/175808.765012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , (function(){
var json={"ads":[{"clktk":["https://max-l.mediav.com/rtb?type=3&ver=1&v=CGQSEDEzNzYzZjI
[1:1:0712/175808.765208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175808.995590:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175808.996015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175808.996174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.023849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.024258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.024394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.064240:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.064600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.064711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.093285:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.093673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.093782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.136672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.137079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.137217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.153327:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.153682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.153822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.184438:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.184811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.184918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.228310:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.228700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.228838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.259023:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.259412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.259551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.303634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.304078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.304217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.335031:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.335411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.335530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.379150:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.379524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.379642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1257:1268:0712/175809.384248:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1257:1268:0712/175809.393632:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/175809.411256:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175809.411654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , r.onload, (){e({naturalHeight:r.naturalHeight,naturalWidth:r.naturalWidth,src:r.src})}
[1:1:0712/175809.411796:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1257:1268:0712/175809.421230:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/175809.500416:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 830, 7fb27cac7881
[1:1:0712/175809.514987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"736 0x7fb27a182070 0x3b0e021179e0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175809.515163:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"736 0x7fb27a182070 0x3b0e021179e0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175809.515378:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175809.515656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175809.515781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175809.516832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x17aa91029c8, 0x3b0df97d0950
[1:1:0712/175809.516929:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1
[1:1:0712/175809.517104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 865
[1:1:0712/175809.517212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7fb27a182070 0x3b0e02630b60 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 830 0x7fb27a182070 0x3b0e025817e0 
[1257:1268:0712/175809.518206:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/175809.531948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , document.readyState
[1:1:0712/175809.532068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175810.086255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 865, 7fb27cac7881
[1:1:0712/175810.100347:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"830 0x7fb27a182070 0x3b0e025817e0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175810.100579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"830 0x7fb27a182070 0x3b0e025817e0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175810.100839:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175810.101156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175810.101307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175810.102267:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x17aa91029c8, 0x3b0df97d0950
[1:1:0712/175810.102411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1
[1:1:0712/175810.102629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 889
[1:1:0712/175810.102750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7fb27a182070 0x3b0e0265ea60 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 865 0x7fb27a182070 0x3b0e02630b60 
[1:1:0712/175810.116058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , document.readyState
[1:1:0712/175810.116222:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175810.404721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175810.405146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , (){l=!0,f=!0,u(n),e()}
[1:1:0712/175810.405278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175810.405875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175810.406877:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x17aa91029c8, 0x3b0df97d09f0
[1:1:0712/175810.407029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1500
[1:1:0712/175810.407271:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 899
[1:1:0712/175810.407445:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 899 0x7fb27a182070 0x3b0e01ef9ae0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 886 0x7fb27a182070 0x3b0dfe05eb60 
[1:1:0712/175810.407686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175810.413418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175810.414235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x17aa91029c8, 0x3b0df97d09f0
[1:1:0712/175810.414343:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 1000
[1:1:0712/175810.414507:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 900
[1:1:0712/175810.414629:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 900 0x7fb27a182070 0x3b0e0056bae0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 886 0x7fb27a182070 0x3b0dfe05eb60 
[1:1:0712/175810.440473:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 889, 7fb27cac7881
[1:1:0712/175810.455996:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"865 0x7fb27a182070 0x3b0e02630b60 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175810.456181:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"865 0x7fb27a182070 0x3b0e02630b60 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175810.456465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175810.456863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175810.456971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175810.473323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , document.readyState
[1:1:0712/175810.473518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175810.684822:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 266, 7fb27cac7881
[1:1:0712/175810.698209:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"202 0x7fb27a4eabd0 0x3b0df9a29158 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175810.698395:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"202 0x7fb27a4eabd0 0x3b0df9a29158 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175810.698592:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175810.698845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , (){s()}
[1:1:0712/175810.698956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175811.086536:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 937 0x7fb27c0aa2e0 0x3b0e0056c960 , "https://www.toutiao.com/"
[1:1:0712/175811.089221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , !function(t){function e(r){if(n[r])return n[r].exports;var o=n[r]={"exports":{},"id":r,"loaded":!1};
[1:1:0712/175811.089395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175811.196228:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175811.218875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175811.220021:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x17aa91029c8, 0x3b0df97d0a10
[1:1:0712/175811.220198:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 0
[1:1:0712/175811.220437:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 950
[1:1:0712/175811.220585:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 950 0x7fb27a182070 0x3b0e024f2560 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 937 0x7fb27c0aa2e0 0x3b0e0056c960 
[1:1:0712/175811.401597:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 950, 7fb27cac7881
[1:1:0712/175811.414561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"937 0x7fb27c0aa2e0 0x3b0e0056c960 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175811.414718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"937 0x7fb27c0aa2e0 0x3b0e0056c960 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175811.414910:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175811.415176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175811.415276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175811.468414:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175811.468773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175811.468890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175811.469494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175811.470846:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175811.480284:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e77888
[1:1:0712/175811.509993:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e77a88
[1:1:0712/175811.541481:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x17aa91029c8, 0x3b0df97d0a10
[1:1:0712/175811.541650:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 100
[1:1:0712/175811.541835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 977
[1:1:0712/175811.541962:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7fb27a182070 0x3b0e01d23660 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 954
[1:1:0712/175811.571474:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e78290
[1:1:0712/175811.594618:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e78598
[1:1:0712/175811.618728:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e788a0
[1:1:0712/175811.826402:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 900, 7fb27cac7881
[1:1:0712/175811.839928:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"886 0x7fb27a182070 0x3b0dfe05eb60 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175811.840145:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"886 0x7fb27a182070 0x3b0dfe05eb60 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175811.840392:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175811.840724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175811.840825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.270595:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 977, 7fb27cac7881
[1:1:0712/175812.284717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"954","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175812.284886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"954","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175812.285098:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175812.285366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175812.285479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.299043:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087d5c360
[1:1:0712/175812.519534:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1008 0x7fb27c0aa2e0 0x3b0e026478e0 , "https://www.toutiao.com/"
[1:1:0712/175812.520141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , (function(){
var json=	[];
window['hia_360'](json);
})();
[1:1:0712/175812.520303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.520781:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175812.525541:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e793f0
[1:1:0712/175812.542183:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1009 0x7fb27c0aa2e0 0x3b0e0233f2e0 , "https://www.toutiao.com/"
[1:1:0712/175812.542875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , (function(w,d){w._tanxlb=w._tanxlb!==void 0?w._tanxlb:0;var o={i:"mm_32479643_3494618_81668314",call
[1:1:0712/175812.543010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.560779:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175812.563065:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 899, 7fb27cac7881
[1:1:0712/175812.580403:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"886 0x7fb27a182070 0x3b0dfe05eb60 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175812.580576:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"886 0x7fb27a182070 0x3b0dfe05eb60 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175812.580797:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175812.581129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175812.581249:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.644903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175812.645328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175812.645456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.858819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175812.859229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175812.859352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.874847:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175812.875178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , f, (t){if(4===this.readyState){var e={ev_type:"ajax",ax_status:this.status,ax_type:this._method};if(200
[1:1:0712/175812.875301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.875653:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175812.876888:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.toutiao.com/"
[1:1:0712/175812.877790:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e77888
[1:1:0712/175812.941729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175812.942105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175812.942232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175812.971215:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175812.971518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175812.971639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175813.014903:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175813.015231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175813.015353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175813.321090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.toutiao.com/"
[1:1:0712/175813.321510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/175813.321642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175813.512823:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1066 0x7fb27c0aa2e0 0x3b0dfffb8c60 , "https://www.toutiao.com/"
[1:1:0712/175813.514803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , /*!2019-06-15 16:18 */function tanxssp_show(a){var b=document;a.i||(a.i=a.pid);var c="tanx-a-"+a.i||
[1:1:0712/175813.514944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175813.566802:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x17aa91029c8, 0x3b0df97d0940
[1:1:0712/175813.566963:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 50
[1:1:0712/175813.567141:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 1076
[1:1:0712/175813.567264:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1076 0x7fb27a182070 0x3b0dfa6882e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 1066 0x7fb27c0aa2e0 0x3b0dfffb8c60 
[1:1:0712/175813.665469:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x17aa91029c8, 0x3b0df97d0940
[1:1:0712/175813.665663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 5000
[1:1:0712/175813.665894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 1084
[1:1:0712/175813.666002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7fb27a182070 0x3b0dfd85a4e0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 1066 0x7fb27c0aa2e0 0x3b0dfffb8c60 
[1:1:0712/175813.687375:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175814.165141:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1099 0x7fb27c0aa2e0 0x3b0e02124ee0 , "https://www.toutiao.com/"
[1:1:0712/175814.165798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , , jsonp_callback_63064({"pid":"mm_32479643_3494618_81668314","acookie":"1","width":"300","height":"250
[1:1:0712/175814.165934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175814.175753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x17aa91029c8, 0x3b0df97d0980
[1:1:0712/175814.175896:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 0
[1:1:0712/175814.176071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 1106
[1:1:0712/175814.176183:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7fb27a182070 0x3b0dfd86fde0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 1099 0x7fb27c0aa2e0 0x3b0e02124ee0 
[1257:1257:0712/175814.180105:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/175814.181265:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3b0e010d1420
[1:1:0712/175814.181455:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1257:1257:0712/175814.182525:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/175814.188929:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/175814.189110:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.toutiao.com
[1257:1257:0712/175814.189781:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://www.toutiao.com/
[1:1:0712/175814.191383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.toutiao.com/"
[1:1:0712/175814.193608:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e69a00
[1:1:0712/175814.211350:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e7c2a8
[1:1:0712/175814.213734:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x228087e7c310
[1257:1257:0712/175814.221248:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1257:1257:0712/175814.221785:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1257:1268:0712/175814.240085:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[1257:1268:0712/175814.240150:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[1257:1257:0712/175814.240169:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://phs.tanx.com/
[1257:1257:0712/175814.240212:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://phs.tanx.com/, https://phs.tanx.com/acbeacon4.html#mm_32479643_3494618_81668314, 4
[1257:1257:0712/175814.240272:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://phs.tanx.com/, HTTP/1.1 200 status:304 date:Fri, 12 Jul 2019 09:58:14 GMT server:Tengine last-modified:Mon, 17 Apr 2017 05:50:10 GMT expires:Fri, 12 Jul 2019 09:58:13 GMT cache-control:no-cache eagleeye-traceid:0b015cc700128122873504816eb610 strict-transport-security:max-age=0 timing-allow-origin:* content-type:text/html; charset=gbk vary:Accept-Encoding content-encoding:gzip  ,1372, 6
[1:7:0712/175814.242583:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/175814.712527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 1106, 7fb27cac7881
[1:1:0712/175814.727458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3ccc17882860","ptid":"1099 0x7fb27c0aa2e0 0x3b0e02124ee0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175814.727623:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.toutiao.com/","ptid":"1099 0x7fb27c0aa2e0 0x3b0e02124ee0 ","rf":"6:3_https://www.toutiao.com/"}
[1:1:0712/175814.727817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.toutiao.com/"
[1:1:0712/175814.728092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.toutiao.com/, 3ccc17882860, , n, (){var n=[],i=arguments.length,o=!e||e&&e.deep!==!1;for(r&&s(r)&&r.apply(this,arguments);i--;)n[i]=o
[1:1:0712/175814.728205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.toutiao.com/", "www.toutiao.com", 3, 1, , , 0
[1:1:0712/175814.730006:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1257:1257:0712/175814.733405:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/175814.734562:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x3b0e01315220
[1:1:0712/175814.734667:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1257:1257:0712/175814.735939:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/175814.741233:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/175814.741394:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.toutiao.com
[1257:1257:0712/175814.741990:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://www.toutiao.com/
[1:1:0712/175814.742911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x17aa91029c8, 0x3b0df97d0950
[1:1:0712/175814.743041:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.toutiao.com/", 0
[1:1:0712/175814.743218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.toutiao.com/, 1159
[1:1:0712/175814.743332:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1159 0x7fb27a182070 0x3b0e0237bce0 , 6:3_https://www.toutiao.com/, 1, -6:3_https://www.toutiao.com/, 1106 0x7fb27a182070 0x3b0dfd86fde0 
[1257:1257:0712/175814.785973:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1257:1257:0712/175814.786570:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1257:1268:0712/175814.802687:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 5
[1257:1268:0712/175814.802749:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 5, HandleIncomingMessage, HandleIncomingMessage
[1257:1257:0712/175814.802781:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://a1.alicdn.com/
[1257:1257:0712/175814.802822:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:5_https://a1.alicdn.com/, https://a1.alicdn.com/creation/html/2018/02/12/creation-3354V76q1GX2xO01-13827984.html#tanxdspv=https%3a%2f%2frdstat.tanx.com%2ftrd%3ff%3d%26k%3da09e279ad7f7a12a%26p%3dmm_32479643_3494618_81668314%26pvid%3d0bb4779200005d2859b5395d00bea634%26s%3d300x250%26d%3d59420271%26t%3d1562925493&pid=mm_32479643_3494618_81668314&tp=3&tsid=0bb4779200005d2859b5395d00bea634&u=https%3A%2F%2Fwww.toutiao.com%2F&r=&tp=3&tsid=0bb4779200005d2859b5395d00bea634&pid=mm_32479643_3494618_81668314, 5
[1257:1257:0712/175814.802887:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:5_https://a1.alicdn.com/, HTTP/1.1 200 status:304 server:Tengine date:Fri, 31 May 2019 07:02:14 GMT cache-control:s-maxage=31197780, max-age=31197780 expires:Tue, 26 May 2020 09:05:14 GMT vary:Accept-Encoding x-oss-request-id:5CF0D176F73A3FC2022DBC8A last-modified:Mon, 12 Feb 2018 06:35:34 GMT x-oss-object-type:Normal x-oss-hash-crc64ecma:6385341098629786898 x-oss-storage-class:Standard x-oss-server-time:23 ali-swift-global-savetime:1559286134 via:cache3.l2cn241[0,200-0,H], cache16.l2cn241[1,0], cache5.cn518[0,304-0,H], cache1.cn518[1,0] age:3639360 x-cache:HIT TCP_IMS_HIT dirn:2:112699492 access-control-allow-origin:* timing-allow-origin:* eagleid:7cc1e21515629254947928528e content-type:text/html content-length:28908 content-md5:rqNlZ+IVAMPT6XdUMvW/Og== content-encoding:gzip x-swift-savetime:Sat, 01 Jun 2019 09:05:14 GMT x-swift-cachetime:31104000  ,1372, 6
[1:7:0712/175814.809734:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/175814.878103:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://phs.tanx.com/
