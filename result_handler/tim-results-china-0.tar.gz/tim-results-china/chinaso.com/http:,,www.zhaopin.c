[0712/180041.866510:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/180041.866767:INFO:switcher_clone.cc(787)] backtrace rip is 7fa621556891
[0712/180042.405292:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/180042.405523:INFO:switcher_clone.cc(787)] backtrace rip is 7ff3401d8891
[1:1:0712/180042.409383:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/180042.409552:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/180042.412260:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[1794:1794:0712/180043.184849:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/c81303bc-1d0f-436b-a3d5-ec9ee7395ce1
[0712/180043.245153:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/180043.245379:INFO:switcher_clone.cc(787)] backtrace rip is 7f99f2fbe891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[1847:1847:0712/180043.391472:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1847
[1872:1872:0712/180043.391774:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1872
[1794:1794:0712/180043.455728:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[1794:1839:0712/180043.456137:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/180043.456277:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/180043.456443:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/180043.456756:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/180043.456841:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/180043.458534:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x31b9cbc9, 1
[1:1:0712/180043.458771:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x7f26ed4, 0
[1:1:0712/180043.458921:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x17773043, 3
[1:1:0712/180043.459051:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xb8e0252, 2
[1:1:0712/180043.459185:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd46efffffff207 ffffffc9ffffffcbffffffb931 5202ffffff8e0b 43307717 , 10104, 4
[1:1:0712/180043.459906:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1794:1839:0712/180043.460075:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�n��˹1R�C0w���(
[1:1:0712/180043.460070:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff33e4120a0, 3
[1794:1839:0712/180043.460123:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �n��˹1R�C0wXF���(
[1:1:0712/180043.460210:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff33e59e080, 2
[1794:1839:0712/180043.460370:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/180043.460356:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff328260d20, -2
[1794:1839:0712/180043.460431:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1880, 4, d46ef207 c9cbb931 52028e0b 43307717 
[1:1:0712/180043.467695:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/180043.468138:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b8e0252
[1:1:0712/180043.468554:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b8e0252
[1:1:0712/180043.469315:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b8e0252
[1:1:0712/180043.469835:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.469954:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.470064:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.470172:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.470429:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b8e0252
[1:1:0712/180043.470582:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3401d87ba
[1:1:0712/180043.470655:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3401cfdef, 7ff3401d877a, 7ff3401da0cf
[1:1:0712/180043.472242:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal b8e0252
[1:1:0712/180043.472383:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal b8e0252
[1:1:0712/180043.472727:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal b8e0252
[1:1:0712/180043.473494:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.473634:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.473766:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.473875:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal b8e0252
[1:1:0712/180043.474460:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal b8e0252
[1:1:0712/180043.474633:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3401d87ba
[1:1:0712/180043.474725:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3401cfdef, 7ff3401d877a, 7ff3401da0cf
[1:1:0712/180043.477374:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/180043.477561:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/180043.477687:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc061d40e8, 0x7ffc061d4068)
[1:1:0712/180043.484021:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/180043.486931:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1794:1794:0712/180043.877408:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1794:1794:0712/180043.877930:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1794:1808:0712/180043.886158:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[1794:1808:0712/180043.886223:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1794:1794:0712/180043.886258:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[1794:1794:0712/180043.886300:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[1794:1794:0712/180043.886367:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,1880, 4
[1:7:0712/180043.889528:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/180043.938776:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3a42635b6220
[1:1:0712/180043.938928:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1794:1822:0712/180043.958483:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/180044.130420:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/180044.834347:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180044.836014:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1794:1794:0712/180045.068617:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[1794:1794:0712/180045.068733:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/180045.293117:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180045.378485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/180045.378673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180045.383621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/180045.383750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180045.421739:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180045.421913:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180045.577298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180045.579817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/180045.579956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180045.597085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180045.600015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/180045.600155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180045.603949:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1794:1794:0712/180045.604617:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/180045.605736:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3a42635b4e20
[1:1:0712/180045.605840:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1794:1794:0712/180045.607080:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1794:1794:0712/180045.618545:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[1794:1794:0712/180045.618625:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/180045.638187:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180045.936844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7ff329e3b2e0 0x3a42637962e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180045.937533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/180045.937675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180045.938257:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1794:1794:0712/180045.963517:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/180045.964620:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3a42635b5820
[1:1:0712/180045.964771:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1794:1794:0712/180045.966084:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/180045.971617:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/180045.972252:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[1794:1794:0712/180045.973741:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[1794:1794:0712/180045.977891:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1794:1794:0712/180045.978293:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1794:1808:0712/180045.982817:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[1794:1808:0712/180045.982872:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1794:1794:0712/180045.982891:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[1794:1794:0712/180045.982929:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[1794:1794:0712/180045.982988:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,1880, 4
[1:7:0712/180045.983602:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/180046.253528:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/180046.396612:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7ff329e3b2e0 0x3a42637f65e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180046.397246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/180046.397468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/180046.397909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1794:1794:0712/180046.526138:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[1794:1794:0712/180046.526213:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/180046.537807:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/180046.697339:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1794:1794:0712/180046.867332:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[1794:1839:0712/180046.867611:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/180046.867745:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/180046.867919:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/180046.868122:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/180046.868206:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/180046.870576:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x26b817e6, 1
[1:1:0712/180046.870784:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2d6d52de, 0
[1:1:0712/180046.870954:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3f9b5d56, 3
[1:1:0712/180046.871111:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3cc61d1e, 2
[1:1:0712/180046.871258:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffde526d2d ffffffe617ffffffb826 1e1dffffffc63c 565dffffff9b3f , 10104, 5
[1:1:0712/180046.872003:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1794:1839:0712/180046.872186:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�Rm-��&�<V]�?՗�(
[1794:1839:0712/180046.872230:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �Rm-��&�<V]�?(+՗�(
[1:1:0712/180046.872178:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff33e4120a0, 3
[1794:1839:0712/180046.872361:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1921, 5, de526d2d e617b826 1e1dc63c 565d9b3f 
[1:1:0712/180046.872359:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff33e59e080, 2
[1:1:0712/180046.872468:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff328260d20, -2
[1:1:0712/180046.881840:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/180046.882039:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3cc61d1e
[1:1:0712/180046.882212:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3cc61d1e
[1:1:0712/180046.882489:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3cc61d1e
[1:1:0712/180046.882989:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.883089:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.883182:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.883275:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.883534:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3cc61d1e
[1:1:0712/180046.883662:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3401d87ba
[1:1:0712/180046.883739:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3401cfdef, 7ff3401d877a, 7ff3401da0cf
[1:1:0712/180046.885464:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3cc61d1e
[1:1:0712/180046.885626:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3cc61d1e
[1:1:0712/180046.885967:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3cc61d1e
[1:1:0712/180046.886754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.886871:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.886980:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.887082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cc61d1e
[1:1:0712/180046.887583:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3cc61d1e
[1:1:0712/180046.887752:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3401d87ba
[1:1:0712/180046.887835:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3401cfdef, 7ff3401d877a, 7ff3401da0cf
[1:1:0712/180046.890458:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/180046.890692:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/180046.890812:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc061d40e8, 0x7ffc061d4068)
[1:1:0712/180046.897081:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/180046.898125:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180046.898259:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180046.899090:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/180046.987153:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3a426354d220
[1:1:0712/180046.987306:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/180047.084391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180047.088303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c7c6eb8e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/180047.088506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180047.091135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180047.147043:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/180047.147487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c7c6ea61f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/180047.147668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1794:1794:0712/180047.203169:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1794:1794:0712/180047.215901:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[1794:1839:0712/180047.216158:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/180047.216295:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/180047.216432:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/180047.216632:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/180047.216749:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/180047.224525:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3fddbe0a, 1
[1:1:0712/180047.224745:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x18f615ba, 0
[1:1:0712/180047.224864:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2678d96a, 3
[1:1:0712/180047.224949:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2a0ddb36, 2
[1:1:0712/180047.225048:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffba15fffffff618 0affffffbeffffffdd3f 36ffffffdb0d2a 6affffffd97826 , 10104, 6
[1:1:0712/180047.225775:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[1794:1839:0712/180047.225904:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��
��?6�*j�x&;��(
[1794:1839:0712/180047.225944:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��
��?6�*j�x&��;��(
[1794:1839:0712/180047.226069:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 1933, 6, ba15f618 0abedd3f 36db0d2a 6ad97826 
[1:1:0712/180047.226245:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff33e4120a0, 3
[1:1:0712/180047.226342:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff33e59e080, 2
[1:1:0712/180047.226437:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff328260d20, -2
[1:1:0712/180047.228743:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1794:1794:0712/180047.229491:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/180047.229547:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/180047.230494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c7c6eb8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/180047.230670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180047.236466:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/180047.236682:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a0ddb36
[1:1:0712/180047.236821:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a0ddb36
[1:1:0712/180047.237091:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a0ddb36
[1:1:0712/180047.237604:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.237753:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.237869:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.237983:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.238251:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a0ddb36
[1:1:0712/180047.238377:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3401d87ba
[1:1:0712/180047.238475:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3401cfdef, 7ff3401d877a, 7ff3401da0cf
[1:1:0712/180047.240122:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2a0ddb36
[1:1:0712/180047.240291:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2a0ddb36
[1:1:0712/180047.240606:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2a0ddb36
[1:1:0712/180047.241458:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.241589:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.241709:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.241826:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2a0ddb36
[1:1:0712/180047.242343:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2a0ddb36
[1:1:0712/180047.242497:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff3401d87ba
[1:1:0712/180047.242561:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff3401cfdef, 7ff3401d877a, 7ff3401da0cf
[1:1:0712/180047.245161:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/180047.245387:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/180047.245502:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc061d40e8, 0x7ffc061d4068)
[1794:1808:0712/180047.249358:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[1794:1808:0712/180047.249421:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[1794:1794:0712/180047.250536:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.zhaopin.com/
[1794:1794:0712/180047.250588:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.zhaopin.com/, https://www.zhaopin.com/, 1
[1794:1794:0712/180047.250656:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.zhaopin.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 10:00:47 GMT content-type:text/html; charset=utf-8 server:Tengine vary:Accept-Encoding x-zp-request-id:277575dcb1934713864897f60b52ec28 content-encoding:br expires:Fri, 12 Jul 2019 10:05:47 GMT cache-control:max-age=300 x-proxy-cache:HIT  ,0, 6
[1:1:0712/180047.251555:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/180047.253727:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/180047.255231:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:7:0712/180047.299903:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/180047.301869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/180047.302312:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/180047.302596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c7c6eb8e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/180047.302740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/180047.360506:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3a4263577220
[1:1:0712/180047.360658:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/180047.390187:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.zhaopin.com/
[1794:1794:0712/180047.507104:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.zhaopin.com/, https://www.zhaopin.com/, 1
[1794:1794:0712/180047.507223:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.zhaopin.com/, https://www.zhaopin.com
[1:1:0712/180047.514039:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/180047.568767:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180047.589589:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/180047.616878:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180047.617026:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zhaopin.com/"
[1:1:0712/180047.869773:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/180047.905545:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/180047.931575:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/180047.956550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 167 0x7ff327f13070 0x3a42636d8360 , "https://www.zhaopin.com/"
[1:1:0712/180047.957445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , var zpPageRequestId = "e4219a18ebb74eff93046ccc2abcb653-" + (new Date()).valueOf() + "-" + parseInt(
[1:1:0712/180047.957569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180047.970574:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/180047.998865:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/180048.038042:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/180048.065184:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/180048.130593:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/180048.134236:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.175629, 4058, 1
[1:1:0712/180048.134372:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180048.509860:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180048.510037:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zhaopin.com/"
[1:1:0712/180048.510447:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7ff327f13070 0x3a42637c6860 , "https://www.zhaopin.com/"
[1:1:0712/180048.510891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , window.IS_HOME_PAGE_NEW = true;
[1:1:0712/180048.511022:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180048.511842:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7ff327f13070 0x3a42637c6860 , "https://www.zhaopin.com/"
[1:1:0712/180048.513769:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180048.522339:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7ff327f13070 0x3a42637c6860 , "https://www.zhaopin.com/"
[1:1:0712/180048.526317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7ff327f13070 0x3a42637c6860 , "https://www.zhaopin.com/"
[1:1:0712/180048.612184:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180049.034276:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7ff32827bbd0 0x3a4263570058 , "https://www.zhaopin.com/"
[1:1:0712/180049.037740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , /*!
* zp-passport-widget@1.0.0-beta.9
* (c) 2018-2019 zhaopin.com
*/
var zpPassportWidget=function()
[1:1:0712/180049.037878:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180049.199872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7ff32827bbd0 0x3a4263570058 , "https://www.zhaopin.com/"
[1:1:0712/180049.202033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 309 0x7ff32827bbd0 0x3a4263570058 , "https://www.zhaopin.com/"
[1:1:0712/180052.105487:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/180100.276361:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/180100.312459:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 11.1177, 0, 0
[1:1:0712/180100.317239:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180101.029173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/180101.029394:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180101.220486:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180101.220640:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zhaopin.com/"
[1:1:0712/180101.222047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7ff327f13070 0x3a4263d07460 , "https://www.zhaopin.com/"
[1:1:0712/180101.223143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , /*!
* @zpfe/widget-sdk-web@1.0.0
* (c) 2018-2019 zhaopin.com
*/
!function(e,t){"object"==typeof expo
[1:1:0712/180101.223248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180101.672709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 483 0x7ff329e3b2e0 0x3a42637cb0e0 , "https://www.zhaopin.com/"
[1:1:0712/180101.674403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , /* initGeetest 1.0.0
 * 用于加载id对应的验证码库，并支持宕机模式
 * 暴露 initGe
[1:1:0712/180101.674516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180101.677558:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180101.694588:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 484 0x7ff329e3b2e0 0x3a426373ca60 , "https://www.zhaopin.com/"
[1:1:0712/180101.697316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (function(f){function n(a){this.name=a;this.counter=0;this.profile={};this.loginFlag=!1;this.head={m
[1:1:0712/180101.697435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180102.251236:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180102.251422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180103.701995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180103.702187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180103.725579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7ff32827bbd0 0x3a4263662a58 , "https://www.zhaopin.com/"
[1:1:0712/180103.728669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , !function(){var e=function(e){var t={};function n(r){if(t[r])return t[r].exports;var i=t[r]={i:r,l:!
[1:1:0712/180103.728812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180103.769589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x235df9d029c8, 0x3a42633a9160
[1:1:0712/180103.769773:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 0
[1:1:0712/180103.769991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 611
[1:1:0712/180103.770126:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 611 0x7ff327f13070 0x3a42636542e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 555 0x7ff32827bbd0 0x3a4263662a58 
[1:1:0712/180103.808553:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7ff32827bbd0 0x3a4263662a58 , "https://www.zhaopin.com/"
[1:1:0712/180103.812949:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7ff32827bbd0 0x3a4263662a58 , "https://www.zhaopin.com/"
[1:1:0712/180103.834284:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 555 0x7ff32827bbd0 0x3a4263662a58 , "https://www.zhaopin.com/"
[1:1:0712/180103.959564:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x235df9d029c8, 0x3a42633a9bd0
[1:1:0712/180103.959786:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 0
[1:1:0712/180103.960012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 619
[1:1:0712/180103.960156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 619 0x7ff327f13070 0x3a4262eb3de0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 555 0x7ff32827bbd0 0x3a4263662a58 
[1794:1794:0712/180104.414346:INFO:CONSOLE(1)] "您好， 我们是【智联大前端​】。
我们帮助芸芸众生找到更好的工作，当然也不愿错过走在前端之巅的您。
我们在 zpfe@group.zhaopin.com.cn 恭候您的简历。", source: https://fecdn1.zhaopin.cn/www/index.web.16d9fa.js (1)
[1794:1794:0712/180104.415630:INFO:CONSOLE(1)] "%c            ___         ___      ___      ___           
           /  /\       /  /\    /  /\    /  /\          
          /  /::|     /  /::\  /  /:/   /  /:/          
         /  /:/:|    /  /:/\:\/  /:/ /\/  /:/ /\        
        /  /:/|:|__ /  /:/ /:/  /:/ /:/  /:/ /:/_       
       /__/:/ |:| //__/:/ /:/__/:/ /:/__/:/ /:/ /\      
       \__\/  |:|/:\  \:\/:/\  \:\/:/\  \:\/:/ /:/      
           |  |:/:/ \  \::/  \  \::/  \  \::/ /:/       
           |  |::/   \  \:\   \  \:\   \  \:\/:/        
           |  |:/     \  \:\   \  \:\   \  \::/         
           |__|/       \__\/    \__\/    \__\/          
 ", source: https://fecdn1.zhaopin.cn/www/index.web.16d9fa.js (1)
[1:1:0712/180104.904563:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x2cb5783b9e50
[1:1:0712/180107.915134:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 3000
[1:1:0712/180107.915398:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 631
[1:1:0712/180107.915550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7ff327f13070 0x3a4267252060 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 555 0x7ff32827bbd0 0x3a4263662a58 
		remove user.e_f31b725b -> 0
[1794:1794:0712/180108.817018:INFO:CONSOLE(1)] "adv：请求开始", source: https://fecdn1.zhaopin.cn/www/index.web.16d9fa.js (1)
[1:1:0712/180108.838035:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x235df9d029c8, 0x3a42633a9bc8
[1:1:0712/180108.838236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 2000
[1:1:0712/180108.838465:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 646
[1:1:0712/180108.838620:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 646 0x7ff327f13070 0x3a42677b3ce0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 555 0x7ff32827bbd0 0x3a4263662a58 
[1:1:0712/180108.947797:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 5.13982, 0, 0
[1:1:0712/180108.947999:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180110.636892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180110.637112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180110.650059:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.zhaopin.com/"
[1:1:0712/180110.650731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , s, (t){t.source===e&&"string"==typeof t.data&&0===t.data.indexOf(a)&&v(+t.data.slice(a.length))}
[1:1:0712/180110.650825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180111.220331:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180111.220495:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zhaopin.com/"
[1:1:0712/180111.221945:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7ff327f13070 0x3a42677b6fe0 , "https://www.zhaopin.com/"
[1:1:0712/180111.223009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , //seo统计从搜索引擎直接访问简历、投递统计
(function(){
    var referrer = docume
[1:1:0712/180111.223182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180111.235061:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7ff327f13070 0x3a42677b6fe0 , "https://www.zhaopin.com/"
[1:1:0712/180111.341453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7ff327f13070 0x3a42677b6fe0 , "https://www.zhaopin.com/"
[1:1:0712/180111.344982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7ff327f13070 0x3a42677b6fe0 , "https://www.zhaopin.com/"
[1:1:0712/180111.353512:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7ff327f13070 0x3a42677b6fe0 , "https://www.zhaopin.com/"
[1:1:0712/180111.496186:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 654 0x7ff327f13070 0x3a42677b6fe0 , "https://www.zhaopin.com/"
[1:1:0712/180111.562111:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 4000
[1:1:0712/180111.562422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 713
[1:1:0712/180111.562595:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 713 0x7ff327f13070 0x3a4263586160 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 654 0x7ff327f13070 0x3a42677b6fe0 
[1:1:0712/180111.569577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 4000
[1:1:0712/180111.569894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 714
[1:1:0712/180111.570085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 714 0x7ff327f13070 0x3a4263b4ffe0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 654 0x7ff327f13070 0x3a42677b6fe0 
[1:1:0712/180111.575710:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 4000
[1:1:0712/180111.575905:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 715
[1:1:0712/180111.576010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 715 0x7ff327f13070 0x3a42637773e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 654 0x7ff327f13070 0x3a42677b6fe0 
[1:1:0712/180111.581259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 4000
[1:1:0712/180111.581563:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 716
[1:1:0712/180111.581740:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 716 0x7ff327f13070 0x3a4263d212e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 654 0x7ff327f13070 0x3a42677b6fe0 
[1:1:0712/180112.045588:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180112.246674:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.02615, 0, 1
[1:1:0712/180112.246865:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/180112.261236:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 611, 7ff32a858881
[1:1:0712/180112.272767:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180112.272981:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180112.273213:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180112.273489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){B.devtools&&oe&&oe.emit("init",Cn)}
[1:1:0712/180112.273599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180112.285661:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 619, 7ff32a858881
[1:1:0712/180112.297162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180112.297361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180112.297575:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180112.297862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){H.devtools&&oe&&oe.emit("init",xn)}
[1:1:0712/180112.297977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180112.324181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zhaopin.com/"
[1:1:0712/180112.324583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0712/180112.324705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180112.325272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zhaopin.com/"
[1:1:0712/180112.326738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zhaopin.com/"
[1794:1794:0712/180112.335173:INFO:CONSOLE(1)] "adv：数据更新成功，耗时：3515ms", source: https://fecdn1.zhaopin.cn/www/index.web.16d9fa.js (1)
[1794:1794:0712/180112.335967:INFO:CONSOLE(1)] "adv：请求返回数据，用时 3518ms", source: https://fecdn1.zhaopin.cn/www/index.web.16d9fa.js (1)
		remove user.f_3f284ae5 -> 0
[1:1:0712/180112.595938:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x235df9d029c8, 0x3a42633a9210
[1:1:0712/180112.596144:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 1000
[1:1:0712/180112.596342:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 740
[1:1:0712/180112.596493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7ff327f13070 0x3a4263b24ae0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 662
[1:1:0712/180113.096665:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){Ti(e)}
[1:1:0712/180113.096858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180113.220331:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180113.220564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180113.248401:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 686 0x7ff329e3b2e0 0x3a4264824a60 , "https://www.zhaopin.com/"
[1:1:0712/180113.250469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , !function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():t()}(this,functi
[1:1:0712/180113.250611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180113.485533:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x235df9d029c8, 0x3a42633a9148
[1:1:0712/180113.485724:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 200
[1:1:0712/180113.485920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 775
[1:1:0712/180113.486090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7ff327f13070 0x3a42677b5160 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 686 0x7ff329e3b2e0 0x3a4264824a60 
[1:1:0712/180114.132590:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 687 0x7ff329e3b2e0 0x3a42677b5d60 , "https://www.zhaopin.com/"
[1:1:0712/180114.133257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , jQuery112101745867411156683_1562925649152({"code":200,"data":{"validateId":"e84ed6f5bcb14a249016ada0
[1:1:0712/180114.133414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180114.133988:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180114.192937:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 646, 7ff32a858881
[1:1:0712/180114.205237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180114.205452:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180114.205670:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180114.205959:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){n(new Error("timeout"))}
[1:1:0712/180114.206077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180114.271129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 631, 7ff32a8588db
[1:1:0712/180114.284518:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180114.284731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"555 0x7ff32827bbd0 0x3a4263662a58 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180114.284991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 809
[1:1:0712/180114.285124:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7ff327f13070 0x3a42637cc160 , 6:3_https://www.zhaopin.com/, 0, , 631 0x7ff327f13070 0x3a4267252060 
[1:1:0712/180114.285276:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180114.285564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.showKey++,t.showKey=t.showKey>t.bannerData.length-1?0:t.showKey}
[1:1:0712/180114.285694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180114.652220:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/180114.652465:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.zhaopin.com/"
[1:1:0712/180114.653969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7ff327f13070 0x3a4263a26260 , "https://www.zhaopin.com/"
[1:1:0712/180114.656056:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , //-- Zhaopin Web Analytics Module 2006.12.19

//cookieValue= 1234567890123  . 123456  .  123456789
[1:1:0712/180114.656218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180114.661196:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7ff327f13070 0x3a4263a26260 , "https://www.zhaopin.com/"
[1:1:0712/180114.675022:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7ff327f13070 0x3a4263a26260 , "https://www.zhaopin.com/"
[1:1:0712/180114.677781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 719 0x7ff327f13070 0x3a4263a26260 , "https://www.zhaopin.com/"
[1:1:0712/180114.683490:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.zhaopin.com/"
[1:1:0712/180114.719508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.zhaopin.com/"
[1:1:0712/180114.960996:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.zhaopin.com/"
[1794:1794:0712/180115.069335:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: https://www.zhaopin.com/ (0)
[1794:1808:0712/180115.135430:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1794:1808:0712/180115.152608:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/180115.515707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){Mi(n,S),R.cancelled||(ji(n,E),F||(Bi(L)?setTimeout(R,L):Ii(n,s,R)))}
[1:1:0712/180115.515901:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180115.663813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180115.664012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180116.483567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 740, 7ff32a858881
[1:1:0712/180116.498192:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"662","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180116.498425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"662","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180116.498683:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180116.498992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , 
[1:1:0712/180116.499147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180116.500317:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 775, 7ff32a858881
[1:1:0712/180116.514563:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"686 0x7ff329e3b2e0 0x3a4264824a60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180116.514764:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"686 0x7ff329e3b2e0 0x3a4264824a60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180116.515011:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180116.515345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){e.isEnd(!0)}
[1:1:0712/180116.515459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180116.516490:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2800, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180116.516608:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 2800
[1:1:0712/180116.516785:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 879
[1:1:0712/180116.516887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 879 0x7ff327f13070 0x3a42697fe0e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 775 0x7ff327f13070 0x3a42677b5160 
[1:1:0712/180116.517149:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180116.517240:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180116.517383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 880
[1:1:0712/180116.517484:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 880 0x7ff327f13070 0x3a4263a3e260 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 775 0x7ff327f13070 0x3a42677b5160 
[1:1:0712/180117.047327:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.zhaopin.com/"
[1:1:0712/180117.047758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , c.onload.c.onerror, (){c.onload=null;c.onerror=null;d()}
[1:1:0712/180117.047874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180117.108114:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 716, 7ff32a8588db
[1:1:0712/180117.121889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"654 0x7ff327f13070 0x3a42677b6fe0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180117.122070:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"654 0x7ff327f13070 0x3a42677b6fe0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180117.122308:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 909
[1:1:0712/180117.122449:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7ff327f13070 0x3a42649d16e0 , 6:3_https://www.zhaopin.com/, 0, , 716 0x7ff327f13070 0x3a4263d212e0 
[1:1:0712/180117.122598:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180117.122902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , () {
                            t += 1;
                            t >= k && (t = 0);
         
[1:1:0712/180117.123064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180117.337935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180117.338140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180117.870156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180117.870601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , sd.para.ignore_oom.img.onload, (){this.onload=null,this.onerror=null,this.onabort=null,e.isEnd()}
[1:1:0712/180117.870752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180117.916795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 885 0x7ff329e3b2e0 0x3a42639a2660 , "https://www.zhaopin.com/"
[1:1:0712/180117.917438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , geetest_1562925680275({"status": "success", "data": {"voice": "/static/js/voice.1.2.0.js", "pencil":
[1:1:0712/180117.917544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180117.921010:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180117.921563:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x235df9d029c8, 0x3a42633a9210
[1:1:0712/180117.921662:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 0
[1:1:0712/180117.921824:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 921
[1:1:0712/180117.921971:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7ff327f13070 0x3a42697fb860 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 885 0x7ff329e3b2e0 0x3a42639a2660 
[1:1:0712/180117.939879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 886 0x7ff329e3b2e0 0x3a42698b8660 , "https://www.zhaopin.com/"
[1:1:0712/180117.945708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , var _dywe=Object({c:"length",lb:"4.3.18",m:"cookie",b:void 0,cb:function(b,c){this.zb=b;this.Nb=c},r
[1:1:0712/180117.945894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180118.169811:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 880, 7ff32a858881
[1:1:0712/180118.186491:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"775 0x7ff327f13070 0x3a42677b5160 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180118.186785:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"775 0x7ff327f13070 0x3a42677b5160 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180118.187060:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180118.187376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.close()}
[1:1:0712/180118.187512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180118.189279:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180118.189450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 200
[1:1:0712/180118.189677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 946
[1:1:0712/180118.189830:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7ff327f13070 0x3a4267cbf9e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 880 0x7ff327f13070 0x3a4263a3e260 
[1:1:0712/180118.240345:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 890 0x7ff329e3b2e0 0x3a4263fdeb60 , "https://www.zhaopin.com/"
[1:1:0712/180118.243862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (function(){var h={},mt={},c={id:"38ba284938d5eddca645bb5e02a02006",dm:["zhaopin.com"],js:"tongji.ba
[1:1:0712/180118.244031:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180118.258589:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9148
[1:1:0712/180118.258762:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180118.258945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 953
[1:1:0712/180118.259058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 953 0x7ff327f13070 0x3a426766f9e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 890 0x7ff329e3b2e0 0x3a4263fdeb60 
[1:1:0712/180118.304950:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 600000
[1:1:0712/180118.305231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 968
[1:1:0712/180118.305393:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 968 0x7ff327f13070 0x3a4269fe4460 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 890 0x7ff329e3b2e0 0x3a4263fdeb60 
[1:1:0712/180118.305850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 5000
[1:1:0712/180118.306002:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 969
[1:1:0712/180118.306110:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 969 0x7ff327f13070 0x3a4269fb9060 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 890 0x7ff329e3b2e0 0x3a4263fdeb60 
[1:1:0712/180118.344062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 891 0x7ff329e3b2e0 0x3a4263121660 , "https://www.zhaopin.com/"
[1:1:0712/180118.347303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (function(){var E;var g=window,m=document,p=function(a){var b=g._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a
[1:1:0712/180118.347512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180118.815760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 809, 7ff32a8588db
[1:1:0712/180118.832709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"631 0x7ff327f13070 0x3a4267252060 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180118.832900:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"631 0x7ff327f13070 0x3a4267252060 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180118.833162:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1013
[1:1:0712/180118.833323:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1013 0x7ff327f13070 0x3a42631e9960 , 6:3_https://www.zhaopin.com/, 0, , 809 0x7ff327f13070 0x3a42637cc160 
[1:1:0712/180118.833594:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180118.833918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.showKey++,t.showKey=t.showKey>t.bannerData.length-1?0:t.showKey}
[1:1:0712/180118.834028:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180119.101326:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180119.101548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180119.161343:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 921, 7ff32a858881
[1:1:0712/180119.179526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"885 0x7ff329e3b2e0 0x3a42639a2660 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180119.179743:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"885 0x7ff329e3b2e0 0x3a42639a2660 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180119.179985:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180119.180265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , () {
                    cb(false);
                }
[1:1:0712/180119.180413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180120.831649:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 953, 7ff32a858881
[1:1:0712/180120.848675:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"890 0x7ff329e3b2e0 0x3a4263fdeb60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180120.848845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"890 0x7ff329e3b2e0 0x3a4263fdeb60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180120.849027:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180120.849342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/180120.849439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180120.849780:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180120.849875:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180120.850035:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1057
[1:1:0712/180120.850141:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1057 0x7ff327f13070 0x3a42635a71e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 953 0x7ff327f13070 0x3a426766f9e0 
[1:1:0712/180120.867674:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 946, 7ff32a858881
[1:1:0712/180120.885284:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"880 0x7ff327f13070 0x3a4263a3e260 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180120.885481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"880 0x7ff327f13070 0x3a4263a3e260 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180120.885699:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180120.885973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){e.isEnd(!0)}
[1:1:0712/180120.886096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180120.886522:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2800, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180120.886632:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 2800
[1:1:0712/180120.886802:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1058
[1:1:0712/180120.886909:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7ff327f13070 0x3a426317b160 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 946 0x7ff327f13070 0x3a4267cbf9e0 
[1:1:0712/180120.887208:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180120.887301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180120.887443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1059
[1:1:0712/180120.887546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1059 0x7ff327f13070 0x3a4263126ae0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 946 0x7ff327f13070 0x3a4267cbf9e0 
[1:1:0712/180121.190289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180121.190473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180121.261924:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1029 0x7ff329e3b2e0 0x3a4269812060 , "https://www.zhaopin.com/"
[1:1:0712/180121.262448:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , jsonp_360283({"status":"1","info":"OK","infocode":"10000","province":"北京市","city":"北京市",
[1:1:0712/180121.262552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180121.527273:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 879, 7ff32a858881
[1:1:0712/180121.544678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"775 0x7ff327f13070 0x3a42677b5160 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180121.544893:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"775 0x7ff327f13070 0x3a42677b5160 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180121.545139:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180121.545463:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){e.lastClear&&e.lastClear()}
[1:1:0712/180121.545617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180121.721146:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 909, 7ff32a8588db
[1:1:0712/180121.738218:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"716 0x7ff327f13070 0x3a4263d212e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180121.738399:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"716 0x7ff327f13070 0x3a4263d212e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180121.738680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1083
[1:1:0712/180121.738843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1083 0x7ff327f13070 0x3a4266270c60 , 6:3_https://www.zhaopin.com/, 0, , 909 0x7ff327f13070 0x3a42649d16e0 
[1:1:0712/180121.739067:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180121.739342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , () {
                            t += 1;
                            t >= k && (t = 0);
         
[1:1:0712/180121.739458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180121.821307:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180121.821773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , sd.para.ignore_oom.img.onload, (){this.onload=null,this.onerror=null,this.onabort=null,e.isEnd()}
[1:1:0712/180121.821902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180121.822607:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1013, 7ff32a8588db
[1:1:0712/180121.840444:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"809 0x7ff327f13070 0x3a42637cc160 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180121.840617:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"809 0x7ff327f13070 0x3a42637cc160 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180121.840839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1084
[1:1:0712/180121.840932:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1084 0x7ff327f13070 0x3a4263978760 , 6:3_https://www.zhaopin.com/, 0, , 1013 0x7ff327f13070 0x3a42631e9960 
[1:1:0712/180121.841154:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180121.841407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.showKey++,t.showKey=t.showKey>t.bannerData.length-1?0:t.showKey}
[1:1:0712/180121.841514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180121.962561:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180121.962953:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , r.onload, (){}
[1:1:0712/180121.963055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.052001:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180122.052430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , g.onload, (){g.onload=w;g=window[d]=w;a&&a(b)}
[1:1:0712/180122.052572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.091729:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180122.092100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , d.onload, (){d.onload=null;d.onerror=null;b()}
[1:1:0712/180122.092201:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.149598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1057, 7ff32a858881
[1:1:0712/180122.167331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"953 0x7ff327f13070 0x3a426766f9e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180122.167577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"953 0x7ff327f13070 0x3a426766f9e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180122.167830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180122.168118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/180122.168223:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.168536:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180122.168643:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180122.168813:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1096
[1:1:0712/180122.168915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1096 0x7ff327f13070 0x3a426397aa60 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1057 0x7ff327f13070 0x3a42635a71e0 
[1:1:0712/180122.169441:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1059, 7ff32a858881
[1:1:0712/180122.186638:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"946 0x7ff327f13070 0x3a4267cbf9e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180122.186818:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"946 0x7ff327f13070 0x3a4267cbf9e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180122.187019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180122.187277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.close()}
[1:1:0712/180122.187373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.188512:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180122.188630:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 200
[1:1:0712/180122.188796:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1097
[1:1:0712/180122.188898:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1097 0x7ff327f13070 0x3a426a3bf3e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1059 0x7ff327f13070 0x3a4263126ae0 
[1:1:0712/180122.327877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180122.328088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.526980:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zhaopin.com/"
[1:1:0712/180122.527369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0712/180122.527496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180122.527749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zhaopin.com/"
[1:1:0712/180122.529244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://www.zhaopin.com/"
[1:1:0712/180123.947265:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1094 0x7ff329e3b2e0 0x3a4263e77360 , "https://www.zhaopin.com/"
[1:1:0712/180123.951245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeo
[1:1:0712/180123.951447:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180124.014183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180124.118750:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){Si(e)}
[1:1:0712/180124.118964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180124.207367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1096, 7ff32a858881
[1:1:0712/180124.226968:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1057 0x7ff327f13070 0x3a42635a71e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180124.227216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1057 0x7ff327f13070 0x3a42635a71e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180124.227473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180124.227825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/180124.227947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180124.228262:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180124.228383:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180124.228589:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1169
[1:1:0712/180124.228732:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1169 0x7ff327f13070 0x3a426955f960 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1096 0x7ff327f13070 0x3a426397aa60 
[1:1:0712/180124.325232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180124.325429:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180124.402500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1097, 7ff32a858881
[1:1:0712/180124.420957:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1059 0x7ff327f13070 0x3a4263126ae0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180124.421160:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1059 0x7ff327f13070 0x3a4263126ae0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180124.421353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180124.421637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){e.isEnd(!0)}
[1:1:0712/180124.421759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180124.422125:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2800, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180124.422226:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 2800
[1:1:0712/180124.422377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1172
[1:1:0712/180124.422463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7ff327f13070 0x3a4263121ae0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1097 0x7ff327f13070 0x3a426a3bf3e0 
[1:1:0712/180124.422792:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180124.423130:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180124.423332:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1173
[1:1:0712/180124.423452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7ff327f13070 0x3a426955fde0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1097 0x7ff327f13070 0x3a426a3bf3e0 
[1:1:0712/180125.071647:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1084, 7ff32a8588db
[1:1:0712/180125.090035:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1013 0x7ff327f13070 0x3a42631e9960 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.090212:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1013 0x7ff327f13070 0x3a42631e9960 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.090442:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1177
[1:1:0712/180125.090564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1177 0x7ff327f13070 0x3a42699711e0 , 6:3_https://www.zhaopin.com/, 0, , 1084 0x7ff327f13070 0x3a4263978760 
[1:1:0712/180125.090763:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180125.091115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.showKey++,t.showKey=t.showKey>t.bannerData.length-1?0:t.showKey}
[1:1:0712/180125.091305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.160335:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 969, 7ff32a8588db
[1:1:0712/180125.180643:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"890 0x7ff329e3b2e0 0x3a4263fdeb60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.180843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"890 0x7ff329e3b2e0 0x3a4263fdeb60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.181102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1180
[1:1:0712/180125.181229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1180 0x7ff327f13070 0x3a4269563f60 , 6:3_https://www.zhaopin.com/, 0, , 969 0x7ff327f13070 0x3a4269fb9060 
[1:1:0712/180125.181415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180125.181682:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , Wb, (){var a=d.O()+d.I();0<a-h.b.c.vl&&(h.b.c.vl=a)}
[1:1:0712/180125.181782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.193169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1083, 7ff32a8588db
[1:1:0712/180125.213265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"909 0x7ff327f13070 0x3a42649d16e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.213446:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"909 0x7ff327f13070 0x3a42649d16e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.213685:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1181
[1:1:0712/180125.213806:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1181 0x7ff327f13070 0x3a4269a4f860 , 6:3_https://www.zhaopin.com/, 0, , 1083 0x7ff327f13070 0x3a4266270c60 
[1:1:0712/180125.214005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180125.214281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , () {
                            t += 1;
                            t >= k && (t = 0);
         
[1:1:0712/180125.214397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.280370:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1058, 7ff32a858881
[1:1:0712/180125.299432:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"946 0x7ff327f13070 0x3a4267cbf9e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.299650:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"946 0x7ff327f13070 0x3a4267cbf9e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.299878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180125.300190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){e.lastClear&&e.lastClear()}
[1:1:0712/180125.300345:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.575116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180125.575621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , sd.para.ignore_oom.img.onload, (){this.onload=null,this.onerror=null,this.onabort=null,e.isEnd()}
[1:1:0712/180125.575782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.596355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){ji(n,u),w.cancelled||(Ii(n,l),b||(Hi($)?setTimeout(w,$):Ni(n,s,w)))}
[1:1:0712/180125.596525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.890252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180125.890491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.891833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1169, 7ff32a858881
[1:1:0712/180125.911614:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1096 0x7ff327f13070 0x3a426397aa60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.911845:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1096 0x7ff327f13070 0x3a426397aa60 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.912092:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180125.912407:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/180125.912551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.912875:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180125.912984:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180125.913156:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1197
[1:1:0712/180125.913279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1197 0x7ff327f13070 0x3a42677b4de0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1169 0x7ff327f13070 0x3a426955f960 
[1:1:0712/180125.933710:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1173, 7ff32a858881
[1:1:0712/180125.953374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1097 0x7ff327f13070 0x3a426a3bf3e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.953563:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1097 0x7ff327f13070 0x3a426a3bf3e0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180125.953766:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180125.954027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.close()}
[1:1:0712/180125.954126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180125.955217:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180125.955322:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 200
[1:1:0712/180125.955475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1199
[1:1:0712/180125.955569:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1199 0x7ff327f13070 0x3a426b16d260 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1173 0x7ff327f13070 0x3a426955fde0 
[1:1:0712/180126.125569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){Si(e)}
[1:1:0712/180126.125755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180126.291135:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1195 0x7ff329e3b2e0 0x3a426397abe0 , "https://www.zhaopin.com/"
[1:1:0712/180126.315667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , $_At.$_B_=function(){var $_DDDFt=2;for(;$_DDDFt!==1;){switch($_DDDFt){case 2:return{$_DDDGD:function
[1:1:0712/180126.315884:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180126.791711:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180126.791971:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/180126.792496:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:17:0712/180126.794660:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/180126.834323:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.zhaopin.com/"
[1:1:0712/180126.834782:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x235df9d029c8, 0x3a42633a9210
[1:1:0712/180126.834886:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 0
[1:1:0712/180126.835059:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1222
[1:1:0712/180126.835170:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1222 0x7ff327f13070 0x3a426b16a760 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1195 0x7ff329e3b2e0 0x3a426397abe0 
[1:1:0712/180126.859334:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , document.readyState
[1:1:0712/180126.859510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180126.860850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1177, 7ff32a8588db
[1:1:0712/180126.882506:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1084 0x7ff327f13070 0x3a4263978760 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180126.882733:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1084 0x7ff327f13070 0x3a4263978760 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180126.883008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.zhaopin.com/, 1227
[1:1:0712/180126.883167:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1227 0x7ff327f13070 0x3a426b16b5e0 , 6:3_https://www.zhaopin.com/, 0, , 1177 0x7ff327f13070 0x3a42699711e0 
[1:1:0712/180126.883366:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180126.883644:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){t.showKey++,t.showKey=t.showKey>t.bannerData.length-1?0:t.showKey}
[1:1:0712/180126.883765:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180127.099082:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1204 0x7ff329e3b2e0 0x3a426a56dce0 , "https://www.zhaopin.com/"
[1:1:0712/180127.099695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , 
[1:1:0712/180127.099849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180127.119787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1197, 7ff32a858881
[1:1:0712/180127.140311:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1169 0x7ff327f13070 0x3a426955f960 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180127.140535:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1169 0x7ff327f13070 0x3a426955f960 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180127.140742:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180127.141058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);y&&(b=!document[y]);n="undefined"==typeof b?v
[1:1:0712/180127.141170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180127.141471:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180127.141567:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180127.141734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1233
[1:1:0712/180127.141843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1233 0x7ff327f13070 0x3a426b16d660 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1197 0x7ff327f13070 0x3a42677b4de0 
[1:1:0712/180127.201784:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){ji(n,T),R.cancelled||(Ii(n,E),P||(Hi(M)?setTimeout(R,M):Ni(n,s,R)))}
[1:1:0712/180127.201987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180127.251480:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1199, 7ff32a858881
[1:1:0712/180127.274140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1173 0x7ff327f13070 0x3a426955fde0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180127.274372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1173 0x7ff327f13070 0x3a426955fde0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180127.274640:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180127.274984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (){e.isEnd(!0)}
[1:1:0712/180127.275104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180127.275491:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2800, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180127.275746:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 2800
[1:1:0712/180127.275925:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1241
[1:1:0712/180127.276020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1241 0x7ff327f13070 0x3a426b1ad0e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1199 0x7ff327f13070 0x3a426b16d260 
[1:1:0712/180127.276310:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x235df9d029c8, 0x3a42633a9150
[1:1:0712/180127.276525:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.zhaopin.com/", 100
[1:1:0712/180127.276916:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1242
[1:1:0712/180127.277058:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1242 0x7ff327f13070 0x3a426b9d67e0 , 6:3_https://www.zhaopin.com/, 1, -6:3_https://www.zhaopin.com/, 1199 0x7ff327f13070 0x3a426b16d260 
[1:1:0712/180127.505377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , (e){var $_CAIBf=$_At.$_Dj,$_CAIAF=['$_CAIEl'].concat($_CAIBf),$_CAICi=$_CAIAF[1];$_CAIAF.shift();var
[1:1:0712/180127.505566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
[1:1:0712/180127.633596:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.zhaopin.com/, 1222, 7ff32a858881
[1:1:0712/180127.656040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2cb5782e2860","ptid":"1195 0x7ff329e3b2e0 0x3a426397abe0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180127.656303:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.zhaopin.com/","ptid":"1195 0x7ff329e3b2e0 0x3a426397abe0 ","rf":"6:3_https://www.zhaopin.com/"}
[1:1:0712/180127.656559:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.zhaopin.com/"
[1:1:0712/180127.656876:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.zhaopin.com/, 2cb5782e2860, , , () {
                    cb(false);
                }
[1:1:0712/180127.656987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.zhaopin.com/", "www.zhaopin.com", 3, 1, , , 0
		remove user.10_406aa04b -> 0
		remove user.11_f5c70387 -> 0
		remove user.12_b2f363a1 -> 0
		remove user.13_f5312aa5 -> 0
		remove user.14_ca577fb2 -> 0
[1:19:0712/180128.821305:WARNING:paced_sender.cc(261)] Elapsed time (2003 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180129.321705:WARNING:paced_sender.cc(261)] Elapsed time (2504 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180129.822091:WARNING:paced_sender.cc(261)] Elapsed time (3004 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180130.322443:WARNING:paced_sender.cc(261)] Elapsed time (3504 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180130.822622:WARNING:paced_sender.cc(261)] Elapsed time (4005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180131.322851:WARNING:paced_sender.cc(261)] Elapsed time (4505 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180131.823294:WARNING:paced_sender.cc(261)] Elapsed time (5005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180132.323636:WARNING:paced_sender.cc(261)] Elapsed time (5506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180132.823277:WARNING:paced_sender.cc(261)] Elapsed time (6005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180133.323573:WARNING:paced_sender.cc(261)] Elapsed time (6506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180133.823924:WARNING:paced_sender.cc(261)] Elapsed time (7006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180134.323516:WARNING:paced_sender.cc(261)] Elapsed time (7505 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180134.823900:WARNING:paced_sender.cc(261)] Elapsed time (8006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180135.324275:WARNING:paced_sender.cc(261)] Elapsed time (8506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180135.824817:WARNING:paced_sender.cc(261)] Elapsed time (9007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180136.324218:WARNING:paced_sender.cc(261)] Elapsed time (9506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180136.824639:WARNING:paced_sender.cc(261)] Elapsed time (10007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180137.324960:WARNING:paced_sender.cc(261)] Elapsed time (10507 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180137.825292:WARNING:paced_sender.cc(261)] Elapsed time (11007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180138.325667:WARNING:paced_sender.cc(261)] Elapsed time (11508 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180138.826041:WARNING:paced_sender.cc(261)] Elapsed time (12008 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180139.326688:WARNING:paced_sender.cc(261)] Elapsed time (12509 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180139.827134:WARNING:paced_sender.cc(261)] Elapsed time (13009 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180140.327443:WARNING:paced_sender.cc(261)] Elapsed time (13509 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180140.827735:WARNING:paced_sender.cc(261)] Elapsed time (14010 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180141.328045:WARNING:paced_sender.cc(261)] Elapsed time (14510 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180141.828290:WARNING:paced_sender.cc(261)] Elapsed time (15010 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180142.328669:WARNING:paced_sender.cc(261)] Elapsed time (15511 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180142.829129:WARNING:paced_sender.cc(261)] Elapsed time (16011 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180143.329397:WARNING:paced_sender.cc(261)] Elapsed time (16511 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180143.829782:WARNING:paced_sender.cc(261)] Elapsed time (17012 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180144.329224:WARNING:paced_sender.cc(261)] Elapsed time (17511 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180144.829316:WARNING:paced_sender.cc(261)] Elapsed time (18011 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180145.329646:WARNING:paced_sender.cc(261)] Elapsed time (18512 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180145.830023:WARNING:paced_sender.cc(261)] Elapsed time (19012 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180146.330422:WARNING:paced_sender.cc(261)] Elapsed time (19512 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180146.830785:WARNING:paced_sender.cc(261)] Elapsed time (20013 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180147.330214:WARNING:paced_sender.cc(261)] Elapsed time (20512 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180147.830514:WARNING:paced_sender.cc(261)] Elapsed time (21012 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180148.330766:WARNING:paced_sender.cc(261)] Elapsed time (21513 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180148.831151:WARNING:paced_sender.cc(261)] Elapsed time (22013 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180149.331547:WARNING:paced_sender.cc(261)] Elapsed time (22513 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180149.831234:WARNING:paced_sender.cc(261)] Elapsed time (23013 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180150.331274:WARNING:paced_sender.cc(261)] Elapsed time (23513 ms) longer than expected, limiting to 2000 ms
[1:19:0712/180150.831633:WARNING:paced_sender.cc(261)] Elapsed time (24014 ms) longer than expected, limiting to 2000 ms
[1:19:0100/000000.333000:WARNING:paced_sender.cc(261)] Elapsed time (24515 ms) longer than expected, limiting to 2000 ms
