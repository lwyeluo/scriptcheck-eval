[0713/024726.083095:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/024726.083338:INFO:switcher_clone.cc(787)] backtrace rip is 7fd1b1a2f891
[0713/024726.612501:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/024726.612754:INFO:switcher_clone.cc(787)] backtrace rip is 7f1bca95d891
[1:1:0713/024726.616566:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/024726.616731:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/024726.619530:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/024727.448406:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/024727.448684:INFO:switcher_clone.cc(787)] backtrace rip is 7fc0d77d0891
[21004:21004:0713/024727.520272:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/bf077aec-e917-4960-8c6e-053d6125036d
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[21035:21035:0713/024727.599947:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=21035
[21048:21048:0713/024727.600267:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=21048
[21004:21004:0713/024727.770168:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[21004:21033:0713/024727.770621:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/024727.770756:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/024727.770912:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/024727.771219:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/024727.771341:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/024727.773010:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x1d1a1a37, 1
[1:1:0713/024727.773235:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1be43db0, 0
[1:1:0713/024727.773339:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x277b8837, 3
[1:1:0713/024727.773443:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15ac94d2, 2
[1:1:0713/024727.773568:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb03dffffffe41b 371a1a1d ffffffd2ffffff94ffffffac15 37ffffff887b27 , 10104, 4
[1:1:0713/024727.774227:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[21004:21033:0713/024727.774369:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�=�7Ҕ�7�{'��-
[21004:21033:0713/024727.774407:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �=�7Ҕ�7�{'�w��-
[1:1:0713/024727.774360:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1bc8b970a0, 3
[21004:21033:0713/024727.774540:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[21004:21033:0713/024727.774575:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21056, 4, b03de41b 371a1a1d d294ac15 37887b27 
[1:1:0713/024727.774853:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1bc8d23080, 2
[1:1:0713/024727.774966:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1bb29e5d20, -2
[1:1:0713/024727.782766:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/024727.783252:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15ac94d2
[1:1:0713/024727.783705:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15ac94d2
[1:1:0713/024727.784483:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15ac94d2
[1:1:0713/024727.785051:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.785154:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.785249:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.785345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.785592:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15ac94d2
[1:1:0713/024727.785737:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1bca95d7ba
[1:1:0713/024727.785814:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1bca954def, 7f1bca95d77a, 7f1bca95f0cf
[1:1:0713/024727.787494:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15ac94d2
[1:1:0713/024727.787666:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15ac94d2
[1:1:0713/024727.787943:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15ac94d2
[1:1:0713/024727.788686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.788771:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.788845:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.788917:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15ac94d2
[1:1:0713/024727.789393:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15ac94d2
[1:1:0713/024727.789565:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1bca95d7ba
[1:1:0713/024727.789648:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1bca954def, 7f1bca95d77a, 7f1bca95f0cf
[1:1:0713/024727.792188:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/024727.792377:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/024727.792445:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcef9759d8, 0x7ffcef975958)
[1:1:0713/024727.799140:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/024727.802548:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[21004:21004:0713/024728.232108:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21004:21004:0713/024728.232586:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21004:21004:0713/024728.240809:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[21004:21004:0713/024728.240862:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[21004:21004:0713/024728.240926:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,21056, 4
[21004:21015:0713/024728.243290:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[21004:21015:0713/024728.243348:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/024728.243765:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/024728.289879:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x39bc39e77220
[1:1:0713/024728.290038:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[21004:21027:0713/024728.370838:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/024728.504610:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/024729.174026:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024729.175561:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[21004:21004:0713/024729.354259:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[21004:21004:0713/024729.354336:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/024729.592117:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024729.673499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/024729.673689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024729.678741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/024729.678869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024729.721916:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024729.722068:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024729.873280:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024729.875917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/024729.876052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024729.888155:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024729.891243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/024729.891379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024729.895149:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[21004:21004:0713/024729.895829:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/024729.896874:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x39bc39e75e20
[1:1:0713/024729.897000:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[21004:21004:0713/024729.898336:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[21004:21004:0713/024729.909599:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[21004:21004:0713/024729.909688:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/024729.929224:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024730.228187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f1bb45c02e0 0x39bc39fb3e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024730.228866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/024730.228997:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024730.229547:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[21004:21004:0713/024730.254852:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/024730.255838:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x39bc39e76820
[1:1:0713/024730.255973:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[21004:21004:0713/024730.257361:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/024730.262792:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/024730.262967:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[21004:21004:0713/024730.264021:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[21004:21004:0713/024730.268044:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21004:21004:0713/024730.268451:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21004:21015:0713/024730.272948:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[21004:21015:0713/024730.273003:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[21004:21004:0713/024730.273047:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[21004:21004:0713/024730.273099:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[21004:21004:0713/024730.273159:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,21056, 4
[1:7:0713/024730.274768:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/024730.523991:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/024730.707499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f1bb45c02e0 0x39bc39e283e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024730.708089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/024730.708269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024730.708622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[21004:21004:0713/024730.778026:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[21004:21004:0713/024730.778097:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/024730.789824:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/024730.951375:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[21004:21004:0713/024731.021722:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[21004:21033:0713/024731.021997:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/024731.022131:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/024731.022287:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/024731.022471:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/024731.022547:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/024731.024962:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2c00aab, 1
[1:1:0713/024731.025213:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2b3611e, 0
[1:1:0713/024731.025307:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x33f27d11, 3
[1:1:0713/024731.025468:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3cd9fb88, 2
[1:1:0713/024731.025618:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 1e61ffffffb302 ffffffab0affffffc002 ffffff88fffffffbffffffd93c 117dfffffff233 , 10104, 5
[1:1:0713/024731.026378:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[21004:21033:0713/024731.026612:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGa��
����<}�3��-
[21004:21033:0713/024731.026656:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is a��
����<}�3�`��-
[1:1:0713/024731.026602:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1bc8b970a0, 3
[1:1:0713/024731.026704:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1bc8d23080, 2
[21004:21033:0713/024731.026803:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 21099, 5, 1e61b302 ab0ac002 88fbd93c 117df233 
[1:1:0713/024731.026798:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f1bb29e5d20, -2
[1:1:0713/024731.036402:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/024731.036735:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3cd9fb88
[1:1:0713/024731.036904:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3cd9fb88
[1:1:0713/024731.037190:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3cd9fb88
[1:1:0713/024731.037697:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.037801:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.037894:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.037998:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.038252:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3cd9fb88
[1:1:0713/024731.038399:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1bca95d7ba
[1:1:0713/024731.038478:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1bca954def, 7f1bca95d77a, 7f1bca95f0cf
[1:1:0713/024731.040192:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3cd9fb88
[1:1:0713/024731.040370:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3cd9fb88
[1:1:0713/024731.040676:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3cd9fb88
[1:1:0713/024731.041510:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.041629:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.041727:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.041823:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3cd9fb88
[1:1:0713/024731.042319:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3cd9fb88
[1:1:0713/024731.042485:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f1bca95d7ba
[1:1:0713/024731.042568:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f1bca954def, 7f1bca95d77a, 7f1bca95f0cf
[1:1:0713/024731.045156:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/024731.045391:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/024731.045501:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcef9759d8, 0x7ffcef975958)
[1:1:0713/024731.051533:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/024731.053730:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/024731.147803:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x39bc39e1b220
[1:1:0713/024731.148039:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/024731.163662:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024731.163869:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[21004:21004:0713/024731.314365:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21004:21004:0713/024731.317116:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21004:21015:0713/024731.337862:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[21004:21015:0713/024731.337929:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[21004:21004:0713/024731.342628:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://s.takungpao.com/
[21004:21004:0713/024731.342686:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://s.takungpao.com/, http://s.takungpao.com/paper/bz.html, 1
[21004:21004:0713/024731.342753:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://s.takungpao.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 18:38:58 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Keep-Alive: timeout=15 Vary: Accept-Encoding Content-Encoding: gzip  ,21099, 5
[1:7:0713/024731.344267:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/024731.353569:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://s.takungpao.com/
[1:1:0713/024731.369479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 538, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/024731.383100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 021fccd2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/024731.383280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/024731.385650:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[21004:21004:0713/024731.414714:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://s.takungpao.com/, http://s.takungpao.com/, 1
[21004:21004:0713/024731.414775:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://s.takungpao.com/, http://s.takungpao.com
[1:1:0713/024731.422504:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/024731.459944:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024731.486778:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024731.486979:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://s.takungpao.com/paper/bz.html"
[1:1:0713/024731.538744:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/024731.539147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 021fccc01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/024731.539286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/024731.643504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 157 0x7f1bb2698070 0x39bc39f38d60 , "http://s.takungpao.com/paper/bz.html"
[1:1:0713/024731.644591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://s.takungpao.com/, 2d3f5ac62860, , , 
	location.href="http://www.takungpao.com/paper/index.html";
	(function(){
		var date = new Date();

[1:1:0713/024731.644776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://s.takungpao.com/paper/bz.html", "s.takungpao.com", 3, 1, , , 0
[1:1:0713/024731.680827:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/024731.680964:INFO:render_frame_impl.cc(7019)] 	 [url] = http://s.takungpao.com
[1:1:0713/024736.448349:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/024751.816491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://s.takungpao.com/, 2d3f5ac62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/024751.816728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://s.takungpao.com/paper/bz.html", "s.takungpao.com", 3, 1, , , 0
[1:1:0713/024751.817178:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[21004:21004:0713/024751.972790:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://s.takungpao.com/
[3:3:0713/024751.999420:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[21004:21015:0713/024752.181130:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[21004:21004:0713/024752.682684:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[21004:21004:0713/024752.683364:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[21004:21015:0713/024752.699290:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[21004:21015:0713/024752.699357:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[21004:21004:0713/024752.699373:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.takungpao.com/
[21004:21004:0713/024752.699415:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.takungpao.com/, http://www.takungpao.com/paper/index.html, 1
[21004:21004:0713/024752.699476:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.takungpao.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 18:47:52 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Server: nginx X-Frame-Options: SAMEORIGIN Content-Encoding: gzip X-Via: 1.1 PS-WUX-01Bhf232:6 (Cdn Cache Server V2.0), 1.1 hkuan176:1 (Cdn Cache Server V2.0)  ,21099, 5
[1:7:0713/024752.700700:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/024752.720653:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.takungpao.com/
[1:1:0713/024752.783972:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[21004:21004:0713/024752.786508:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.takungpao.com/, http://www.takungpao.com/, 1
[21004:21004:0713/024752.786575:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.takungpao.com/, http://www.takungpao.com
[1:1:0713/024752.865913:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024752.881072:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/024752.957060:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024752.957279:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.takungpao.com/paper/index.html"
[1:1:0713/024752.977740:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0204849, 56, 1
[1:1:0713/024752.978011:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024753.011020:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/024753.144752:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024753.144923:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.takungpao.com/paper/index.html"
[1:1:0713/024753.235565:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/024754.546591:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7f1bb2698070 0x39bc3a054a60 , "http://www.takungpao.com/paper/index.html"
[1:1:0713/024754.547475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.takungpao.com/, 2d3f5ac62860, , , 
$(function(){
	            //用户信息
            var tkpu=tkp.ui();
            if(tkpu.status
[1:1:0713/024754.547654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.takungpao.com/paper/index.html", "www.takungpao.com", 3, 1, , , 0
[1:1:0713/024754.549760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7f1bb2698070 0x39bc3a054a60 , "http://www.takungpao.com/paper/index.html"
[21004:21004:0713/024754.549990:INFO:CONSOLE(59)] "Uncaught ReferenceError: $ is not defined", source: http://www.takungpao.com/paper/index.html (59)
[21004:21004:0713/024754.551420:INFO:CONSOLE(71)] "Uncaught ReferenceError: write_ad is not defined", source: http://www.takungpao.com/paper/index.html (71)
[1:1:0713/024754.612367:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.06322, 1153, 1
[1:1:0713/024754.612553:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/024756.547427:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/024756.547639:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.takungpao.com/paper/index.html"
[1:1:0713/024756.550541:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7f1bb2698070 0x39bc3a3471e0 , "http://www.takungpao.com/paper/index.html"
[1:1:0713/024756.553995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.takungpao.com/, 2d3f5ac62860, , , /*! jQuery v1.9.1 | (c) 2005, 2012 jQuery Foundation, Inc. | jquery.org/license
//@ sourceMappingURL
[1:1:0713/024756.554197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.takungpao.com/paper/index.html", "www.takungpao.com", 3, 1, , , 0
		remove user.d_9f1853ae -> 0
[1:1:0713/024756.648848:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7f1bb2698070 0x39bc3a3471e0 , "http://www.takungpao.com/paper/index.html"
