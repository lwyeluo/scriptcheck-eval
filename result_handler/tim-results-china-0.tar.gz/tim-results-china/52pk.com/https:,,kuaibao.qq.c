[0712/212326.434205:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/212326.434470:INFO:switcher_clone.cc(787)] backtrace rip is 7f776f2bd891
[0712/212327.001796:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/212327.002049:INFO:switcher_clone.cc(787)] backtrace rip is 7f7d9fb5f891
[1:1:0712/212327.005886:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/212327.006051:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/212327.008792:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/212327.951207:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/212327.951505:INFO:switcher_clone.cc(787)] backtrace rip is 7f50b5418891
[2087:2087:0712/212327.955601:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3c0c8d0e-6a84-410a-b0fe-3a978af5619a
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[2151:2151:0712/212328.170586:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2151
[2169:2169:0712/212328.170885:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=2169
[2087:2087:0712/212328.245716:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[2087:2145:0712/212328.246164:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/212328.246284:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/212328.246432:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/212328.246707:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/212328.246801:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/212328.248455:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b6c2046, 1
[1:1:0712/212328.248674:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3679ea13, 0
[1:1:0712/212328.248747:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3f4d84d2, 3
[1:1:0712/212328.248810:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3f9e057, 2
[1:1:0712/212328.248879:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 13ffffffea7936 46206c3b 57ffffffe0fffffff903 ffffffd2ffffff844d3f , 10104, 4
[1:1:0712/212328.249608:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2087:2145:0712/212328.249761:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�y6F l;W��҄M?;J�,
[2087:2145:0712/212328.249803:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �y6F l;W��҄M?xe;J�,
[1:1:0712/212328.249753:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7d9dd990a0, 3
[1:1:0712/212328.249854:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7d9df25080, 2
[2087:2145:0712/212328.249954:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/212328.249948:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7d87be7d20, -2
[2087:2145:0712/212328.249987:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2185, 4, 13ea7936 46206c3b 57e0f903 d2844d3f 
[1:1:0712/212328.257945:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/212328.258439:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f9e057
[1:1:0712/212328.258915:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f9e057
[1:1:0712/212328.259711:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f9e057
[1:1:0712/212328.260277:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.260375:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.260470:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.260561:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.260817:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f9e057
[1:1:0712/212328.260964:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7d9fb5f7ba
[1:1:0712/212328.261046:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7d9fb56def, 7f7d9fb5f77a, 7f7d9fb610cf
[1:1:0712/212328.262734:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3f9e057
[1:1:0712/212328.262897:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3f9e057
[1:1:0712/212328.263198:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3f9e057
[1:1:0712/212328.263987:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.264090:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.264185:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.264284:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3f9e057
[1:1:0712/212328.264782:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3f9e057
[1:1:0712/212328.264945:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7d9fb5f7ba
[1:1:0712/212328.265022:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7d9fb56def, 7f7d9fb5f77a, 7f7d9fb610cf
[1:1:0712/212328.267653:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/212328.267993:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/212328.268083:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffec4a4e648, 0x7ffec4a4e5c8)
[1:1:0712/212328.274910:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/212328.277685:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[2087:2087:0712/212328.810967:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2087:2087:0712/212328.811469:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2087:2087:0712/212328.819838:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[2087:2087:0712/212328.819891:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[2087:2087:0712/212328.819965:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,2185, 4
[2087:2109:0712/212328.821595:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[2087:2109:0712/212328.821672:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/212328.826780:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/212328.851404:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x360a84945220
[1:1:0712/212328.851562:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[2087:2138:0712/212328.913021:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/212329.158288:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/212329.958414:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212329.959913:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2087:2087:0712/212330.239662:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[2087:2087:0712/212330.239775:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/212330.453461:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212330.559139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04597f8a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/212330.559356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212330.565753:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04597f8a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/212330.565971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212330.593042:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212330.593229:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212330.753460:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212330.757392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04597f8a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/212330.757619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212330.771237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212330.774971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04597f8a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/212330.775180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212330.779735:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[2087:2087:0712/212330.780582:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/212330.781711:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x360a84943e20
[1:1:0712/212330.782209:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[2087:2087:0712/212330.782998:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[2087:2087:0712/212330.795116:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[2087:2087:0712/212330.795198:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/212330.815451:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212331.178946:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f7d897c22e0 0x360a84af5d60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212331.179642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04597f8a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/212331.179798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212331.180357:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2087:2087:0712/212331.211523:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[2087:2087:0712/212331.213763:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/212331.213906:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x360a84944820
[1:1:0712/212331.214038:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/212331.220959:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/212331.221169:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[2087:2087:0712/212331.226656:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[2087:2087:0712/212331.232730:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2087:2087:0712/212331.233842:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2087:2087:0712/212331.238934:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[2087:2087:0712/212331.238995:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[2087:2087:0712/212331.239064:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,2185, 4
[2087:2109:0712/212331.241019:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[2087:2109:0712/212331.241120:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/212331.242169:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[2087:2087:0712/212331.273857:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[2087:2145:0712/212331.276820:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/212331.276956:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/212331.277340:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/212331.277916:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/212331.277998:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/212331.285574:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2775a8d6, 1
[1:1:0712/212331.285816:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2bb6f84f, 0
[1:1:0712/212331.285913:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x23b0f99e, 3
[1:1:0712/212331.285995:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x23274efe, 2
[1:1:0712/212331.286075:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4ffffffff8ffffffb62b ffffffd6ffffffa87527 fffffffe4e2723 ffffff9efffffff9ffffffb023 , 10104, 5
[1:1:0712/212331.286813:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[2087:2145:0712/212331.287022:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGO��+֨u'�N'#���#N�,
[2087:2145:0712/212331.287065:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is O��+֨u'�N'#���#(�N�,
[1:1:0712/212331.287021:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7d9dd990a0, 3
[1:1:0712/212331.287120:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7d9df25080, 2
[2087:2145:0712/212331.287199:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 2262, 5, 4ff8b62b d6a87527 fe4e2723 9ef9b023 
[1:1:0712/212331.287214:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7d87be7d20, -2
[1:1:0712/212331.296413:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/212331.296621:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 23274efe
[1:1:0712/212331.296776:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 23274efe
[1:1:0712/212331.297046:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 23274efe
[1:1:0712/212331.297549:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.297646:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.297744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.297842:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.298099:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 23274efe
[1:1:0712/212331.298242:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7d9fb5f7ba
[1:1:0712/212331.298389:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7d9fb56def, 7f7d9fb5f77a, 7f7d9fb610cf
[1:1:0712/212331.300130:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 23274efe
[1:1:0712/212331.300331:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 23274efe
[1:1:0712/212331.300658:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 23274efe
[1:1:0712/212331.301483:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.301604:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.301703:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.301802:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 23274efe
[1:1:0712/212331.302305:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 23274efe
[1:1:0712/212331.302483:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7d9fb5f7ba
[1:1:0712/212331.302651:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7d9fb56def, 7f7d9fb5f77a, 7f7d9fb610cf
[1:1:0712/212331.305392:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/212331.305716:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/212331.305832:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffec4a4e648, 0x7ffec4a4e5c8)
[1:1:0712/212331.311684:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/212331.313958:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/212331.412580:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x360a84903220
[1:1:0712/212331.412738:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/212331.547940:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/212331.734522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 478 0x7f7d897c22e0 0x360a84b791e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/212331.735157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04597f8a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/212331.735287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/212331.735615:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[2087:2087:0712/212331.843698:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[2087:2087:0712/212331.846248:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[2087:2109:0712/212331.866862:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[2087:2109:0712/212331.866926:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[2087:2087:0712/212331.872155:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://kuaibao.qq.com/
[2087:2087:0712/212331.872212:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kuaibao.qq.com/, https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704, 1
[2087:2087:0712/212331.872275:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://kuaibao.qq.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 13:23:32 GMT content-type:text/html; charset=utf-8 server:openresty x-powered-by:HHVM/3.7.3-dev content-encoding:gzip vary:Accept-Encoding x-location:/ x-client-ip:218.241.135.34 x-server-ip:182.254.50.110 nginx-cache:MISS  ,2262, 5
[1:7:0712/212331.875101:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/212331.886134:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://kuaibao.qq.com/
[2087:2087:0712/212331.902126:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[2087:2087:0712/212331.902194:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/212331.900807:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/212331.959827:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[2087:2087:0712/212331.969083:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://kuaibao.qq.com/, https://kuaibao.qq.com/, 1
[2087:2087:0712/212331.969147:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://kuaibao.qq.com/, https://kuaibao.qq.com
[1:1:0712/212331.991166:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212332.026063:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/212332.026264:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212332.048374:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 132 0x7f7d8789a070 0x360a849d7260 , "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212332.049458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , , 
        var newWxSchemeOpen = 0;
                newWxSchemeOpen = 1;
                var _ua = nav
[1:1:0712/212332.049622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212332.051523:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212332.237990:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212332.239829:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/212332.259930:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175 0x7f7d87c02bd0 0x360a8451b1d8 , "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212332.261813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , , function FastClick(t){var e,n=this;if(this.trackingClick=!1,this.trackingClickStart=0,this.targetEle
[1:1:0712/212332.261999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212332.380045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 181 0x7f7d87c02bd0 0x360a849e8358 , "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212332.393969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , , !function(e){function o(e){delete installedChunks[e]}function t(e){var o=document.getElementsByTagNa
[1:1:0712/212332.394315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212337.006869:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/212348.868406:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/212349.804183:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/212350.559960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212350.632377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/212350.632578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212350.823453:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , , document.readyState
[1:1:0712/212350.823673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212351.140939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/212351.141143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212351.149297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/212351.149510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[2087:2087:0712/212351.621087:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://inews.gtimg.com/newsapp_ls/0/130070243_100100/0'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.622964:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://mat1.gtimg.com/www/images/newsapp/cyshare/detail_icon_qiehao.png'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.678314:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://inews.gtimg.com/newsapp_ls/0/9396224580_580300/0'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.682052:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://inews.gtimg.com/newsapp_ls/0/9543873350_354264/0'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.684813:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://qqpublic.qpic.cn/qq_public_cover/0/0-1562837752-F844B6698FE15A2DABB837C2B98DDC62_kbacover_321_234/0?fmt=jpg&size=36&h=397&w=640&ppv=1'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.691303:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://qqpublic.qpic.cn/qq_public_cover/0/0-1562837752-BAF0F3614E56AAC3F7496E85116C3B8B_kbacover_321_234/0?fmt=jpg&size=71&h=360&w=640&ppv=1'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.693931:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://qqpublic.qpic.cn/qq_public_cover/0/0-1562837752-8449C85CC33D552592D98D44D31A28B1_kbacover_321_234/0?fmt=jpg&size=29&h=385&w=640&ppv=1'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[2087:2087:0712/212351.703029:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704' was loaded over HTTPS, but requested an insecure image 'http://img1.gtimg.com/www/pics/hv1/210/85/2207/143532060.png'. This content should also be served over HTTPS.", source: https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704 (0)
[1:1:0712/212352.259574:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212352.260054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , dispatchEvent, (e,o){if(h._enabled){var t=s.getPooled(e,o);try{p.batchedUpdates(r,t)}finally{s.release(t)}}}
[1:1:0712/212352.260192:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
[1:1:0712/212352.291349:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704"
[1:1:0712/212352.291748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://kuaibao.qq.com/, 37c7758a2860, , dispatchEvent, (e,o){if(h._enabled){var t=s.getPooled(e,o);try{p.batchedUpdates(r,t)}finally{s.release(t)}}}
[1:1:0712/212352.291876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://kuaibao.qq.com/s/MEDIANEWSLIST?chlid=5034704", "kuaibao.qq.com", 3, 1, , , 0
