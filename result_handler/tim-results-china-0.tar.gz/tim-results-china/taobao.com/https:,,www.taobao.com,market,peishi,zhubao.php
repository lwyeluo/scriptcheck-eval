[0711/162527.885459:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/162527.885744:INFO:switcher_clone.cc(787)] backtrace rip is 7f7f40746891
[0711/162528.430165:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/162528.430438:INFO:switcher_clone.cc(787)] backtrace rip is 7fc2482ad891
[1:1:0711/162528.434256:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/162528.434434:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/162528.437286:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[14932:14932:0711/162529.010360:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/dfdff142-fc1f-4507-b06a-9c5608c7ba24
[14932:14932:0711/162529.268318:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[14932:14964:0711/162529.268811:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/162529.268949:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/162529.269132:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/162529.269463:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/162529.269619:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/162529.271364:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33fe126e, 1
[1:1:0711/162529.271579:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xb1819cc, 0
[1:1:0711/162529.271683:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xffc4417, 3
[1:1:0711/162529.271782:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2990cd0f, 2
[1:1:0711/162529.271858:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffcc19180b 6e12fffffffe33 0fffffffcdffffff9029 1744fffffffc0f , 10104, 4
[1:1:0711/162529.272561:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14932:14964:0711/162529.272661:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�n�3͐)D��
[14932:14964:0711/162529.272709:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �n�3͐)D�(�
[1:1:0711/162529.272657:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2464e70a0, 3
[1:1:0711/162529.272776:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc246673080, 2
[14932:14964:0711/162529.272860:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[14932:14964:0711/162529.272897:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 14981, 4, cc19180b 6e12fe33 0fcd9029 1744fc0f 
[1:1:0711/162529.272865:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc230335d20, -2
[1:1:0711/162529.280522:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/162529.280967:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2990cd0f
[1:1:0711/162529.281431:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2990cd0f
[0711/162529.281822:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/162529.282147:INFO:switcher_clone.cc(787)] backtrace rip is 7ff9f87a7891
[1:1:0711/162529.282267:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2990cd0f
[1:1:0711/162529.282845:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.282982:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.283126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.283215:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.283444:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2990cd0f
[1:1:0711/162529.283571:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2482ad7ba
[1:1:0711/162529.283656:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2482a4def, 7fc2482ad77a, 7fc2482af0cf
[1:1:0711/162529.285411:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2990cd0f
[1:1:0711/162529.285653:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2990cd0f
[1:1:0711/162529.286016:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2990cd0f
[1:1:0711/162529.286832:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.286949:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.287051:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.287133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2990cd0f
[1:1:0711/162529.287622:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2990cd0f
[1:1:0711/162529.287770:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2482ad7ba
[1:1:0711/162529.287886:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2482a4def, 7fc2482ad77a, 7fc2482af0cf
[1:1:0711/162529.290719:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/162529.290946:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/162529.291023:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffed9e78e08, 0x7ffed9e78d88)
[1:1:0711/162529.297757:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/162529.300615:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[14966:14966:0711/162529.453371:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=14966
[15002:15002:0711/162529.453675:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=15002
[14932:14932:0711/162529.575878:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14932:14932:0711/162529.576454:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14932:14932:0711/162529.585496:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[14932:14932:0711/162529.585565:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[14932:14932:0711/162529.585656:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,14981, 4
[14932:14946:0711/162529.667575:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[14932:14946:0711/162529.667646:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/162529.672415:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/162529.751826:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x2ef46ac51220
[1:1:0711/162529.752009:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[14932:14957:0711/162529.871657:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/162529.939482:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[14932:14932:0711/162530.597110:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[14932:14932:0711/162530.597215:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/162530.614357:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/162530.616000:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/162531.037465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/162531.037660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162531.042879:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/162531.043017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162531.071618:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162531.180710:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162531.180868:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162531.311146:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162531.313664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/162531.313826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162531.325884:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162531.328812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/162531.328936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162531.332848:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[14932:14932:0711/162531.333486:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/162531.334639:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ef46ac4fe20
[1:1:0711/162531.334759:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[14932:14932:0711/162531.336030:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[14932:14932:0711/162531.347504:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[14932:14932:0711/162531.347617:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/162531.367329:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162531.668410:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7fc231f102e0 0x2ef46ac15160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162531.669114:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0711/162531.669264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162531.669850:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[14932:14932:0711/162531.695637:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/162531.696763:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ef46ac50820
[1:1:0711/162531.696901:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[14932:14932:0711/162531.698181:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/162531.703956:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/162531.704104:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[14932:14932:0711/162531.705076:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[14932:14932:0711/162531.709012:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14932:14932:0711/162531.709518:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14932:14946:0711/162531.713965:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[14932:14946:0711/162531.714031:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[14932:14932:0711/162531.714062:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[14932:14932:0711/162531.714113:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[14932:14932:0711/162531.714203:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,14981, 4
[1:7:0711/162531.715778:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/162531.969581:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/162532.155765:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7fc231f102e0 0x2ef46af42960 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162532.156362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/162532.156514:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162532.156849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[14932:14932:0711/162532.236583:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[14932:14932:0711/162532.236671:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/162532.246890:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/162532.384178:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162532.569313:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162532.569518:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162532.716938:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162532.718613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/162532.718823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162532.721381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[14932:14932:0711/162532.769286:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[14932:14964:0711/162532.769579:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/162532.769738:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/162532.769885:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/162532.770091:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/162532.770181:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/162532.772768:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x36cf95f2, 1
[1:1:0711/162532.772990:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e52733b, 0
[1:1:0711/162532.773109:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x397f9e1d, 3
[1:1:0711/162532.773217:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x33e7a01, 2
[1:1:0711/162532.773310:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3b73522e fffffff2ffffff95ffffffcf36 017a3e03 1dffffff9e7f39 , 10104, 5
[1:1:0711/162532.774041:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[14932:14964:0711/162532.774164:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING;sR.��6z>�9��
[14932:14964:0711/162532.774212:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ;sR.��6z>�9����
[14932:14964:0711/162532.774379:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 15038, 5, 3b73522e f295cf36 017a3e03 1d9e7f39 
[1:1:0711/162532.774163:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc2464e70a0, 3
[1:1:0711/162532.774665:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc246673080, 2
[1:1:0711/162532.774782:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fc230335d20, -2
[1:1:0711/162532.783990:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/162532.784372:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33e7a01
[1:1:0711/162532.784541:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33e7a01
[1:1:0711/162532.784818:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33e7a01
[1:1:0711/162532.785348:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.785488:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.785592:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.785691:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.785951:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33e7a01
[1:1:0711/162532.786099:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2482ad7ba
[1:1:0711/162532.786179:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2482a4def, 7fc2482ad77a, 7fc2482af0cf
[1:1:0711/162532.787891:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 33e7a01
[1:1:0711/162532.788044:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 33e7a01
[1:1:0711/162532.788327:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 33e7a01
[1:1:0711/162532.789136:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.789273:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.789409:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.789545:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 33e7a01
[1:1:0711/162532.790031:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 33e7a01
[1:1:0711/162532.790177:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fc2482ad7ba
[1:1:0711/162532.790232:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fc2482a4def, 7fc2482ad77a, 7fc2482af0cf
[1:1:0711/162532.792874:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/162532.793090:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/162532.793165:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffed9e78e08, 0x7ffed9e78d88)
[1:1:0711/162532.799397:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/162532.801355:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/162532.803849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/162532.804268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 364d174c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/162532.804420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/162532.889238:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x2ef46abae220
[1:1:0711/162532.889630:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/162532.907852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162532.908859:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/162532.908999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/162532.909175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162532.976569:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162532.977026:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/162532.977164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/162532.977307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162533.243335:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[14932:14932:0711/162533.351154:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14932:14932:0711/162533.354572:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14932:14946:0711/162533.364663:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[14932:14946:0711/162533.364752:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[14932:14932:0711/162533.364865:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.taobao.com/
[14932:14932:0711/162533.364926:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taobao.com/, https://www.taobao.com/market/peishi/zhubao.php, 1
[14932:14932:0711/162533.365002:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.taobao.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=GB2312 date:Thu, 11 Jul 2019 08:25:33 GMT vary:Accept-Encoding expires:Thu, 11 Jul 2019 09:25:33 GMT cache-control:max-age=3600 strict-transport-security:max-age=31536000 content-encoding:gzip via:cache10.cn764[12,0] timing-allow-origin:* eagleid:7cc8715d15628335331296958e  ,15038, 5
[1:7:0711/162533.368904:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/162533.386871:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.taobao.com/
[1:1:0711/162533.388981:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[14932:14932:0711/162533.442396:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taobao.com/, https://www.taobao.com/, 1
[14932:14932:0711/162533.442483:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.taobao.com/, https://www.taobao.com
[1:1:0711/162533.457498:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/162533.464107:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0711/162533.500503:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0711/162533.501921:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162533.516971:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/162533.527261:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0711/162533.535449:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162533.535611:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162533.566352:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0711/162533.594605:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0711/162533.634097:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0711/162533.746085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162533.746575:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/162533.746864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162533.770452:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162533.770904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/162533.771071:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162533.803597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162533.804045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/162533.804220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162533.824669:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162533.825544:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/162533.827931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*
Copyright 2014, KISSY v1.42
MIT Licensed
build time: Feb 25 16:01
*/
var KISSY=function(a){functi
[1:1:0711/162533.828080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162533.919028:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162533.919508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/162533.919640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162533.954956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/162533.955390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 364d175ee5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/162533.955558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/162534.094301:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162534.117975:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29f3ebfc29c8, 0x2ef46a5761a8
[1:1:0711/162534.118156:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 0
[1:1:0711/162534.118367:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 204
[1:1:0711/162534.118509:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 204 0x7fc22ffe8070 0x2ef46ad448e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 
[1:1:0711/162534.134935:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162534.138679:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162534.149937:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162534.286445:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.194741, 460, 1
[1:1:0711/162534.286677:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162534.410661:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162534.411430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , c.port1.onmessage, (){i=g;c.port1.onmessage=
f;f()}
[1:1:0711/162534.411624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162534.412076:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0xb0fc440ed30
[1:1:0711/162535.032843:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162535.033678:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162535.035814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fc22ffe8070 0x2ef46b15e160 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162535.036535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , KISSY.add("nav/tpl",function(S){return function(obj){obj||(obj={});var __t,__p="",__e=function(str){
[1:1:0711/162535.036656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162535.042321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7fc22ffe8070 0x2ef46b15e160 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162535.053810:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.020026, 91, 1
[1:1:0711/162535.053995:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162535.060017:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 204, 7fc23292d881
[1:1:0711/162535.065278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162535.065463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"184 0x7fc246673080 0x2ef46ad1ce20 1 0 0x2ef46ad1ce38 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162535.065693:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162535.066017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162535.066146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162535.158337:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/162535.204262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7fc231f102e0 0x2ef46b03cbe0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162535.207123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , !function e(t,n,r){function a(i,u){if(!n[i]){if(!t[i]){var s="function"==typeof require&&require;if(
[1:1:0711/162535.207282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[3:3:0711/162535.933557:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/162536.067651:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 289 0x7fc231f102e0 0x2ef46b03cbe0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.277633:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576778
[1:1:0711/162536.277851:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162536.278129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 347
[1:1:0711/162536.278303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 347 0x7fc22ffe8070 0x2ef46b6a7160 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 289 0x7fc231f102e0 0x2ef46b03cbe0 
[1:1:0711/162536.342751:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576778
[1:1:0711/162536.342957:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162536.343239:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 356
[1:1:0711/162536.343409:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 356 0x7fc22ffe8070 0x2ef46ab85ce0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 289 0x7fc231f102e0 0x2ef46b03cbe0 
[1:1:0711/162536.362840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576778
[1:1:0711/162536.363037:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162536.363327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 357
[1:1:0711/162536.363483:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 357 0x7fc22ffe8070 0x2ef46acd4760 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 289 0x7fc231f102e0 0x2ef46b03cbe0 
[1:1:0711/162536.365461:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x29f3ebfc29c8, 0x2ef46a576778
[1:1:0711/162536.365591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 10
[1:1:0711/162536.365801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 358
[1:1:0711/162536.365935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 358 0x7fc22ffe8070 0x2ef46b076060 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 289 0x7fc231f102e0 0x2ef46b03cbe0 
[1:1:0711/162536.379167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 290 0x7fc231f102e0 0x2ef46b0ebee0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.381559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , !function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={exports:{},id:r,loaded:!1};return
[1:1:0711/162536.381701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162536.417816:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.430573:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 293 0x7fc231f102e0 0x2ef46acd6c60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.431084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , jsonp0({"TCART_234_67ee04042047c691725150187b3a65ac_q":-1});
[1:1:0711/162536.431214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162536.436102:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.485420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.485822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162536.485950:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162536.528529:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162536.528682:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.533221:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.004457, 67, 1
[1:1:0711/162536.533364:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162536.565712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 311 0x7fc231f102e0 0x2ef46b494b60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.566294:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*! datalazyload - v1.0.1 - 2013-10-30 7:56:43 PM
* Copyright (c) 2013 kissy-team; Licensed  */
KISS
[1:1:0711/162536.566426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162536.567922:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.601308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/162536.601488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162536.904993:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 358, 7fc23292d881
[1:1:0711/162536.910198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162536.910572:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162536.910755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.911063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0711/162536.911200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162536.984406:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162536.984548:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162536.989502:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00487685, 79, 1
[1:1:0711/162536.989615:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162537.010633:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 377 0x7fc231f102e0 0x2ef46b643160 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162537.012012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:17
*/
KISSY.add("node/base",["dom",
[1:1:0711/162537.012146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162537.079383:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162538.395268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162538.405051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162538.441882:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "open", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162538.442309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , s.onopen, (){e.status="active";var t=e.getMsgQueue();t.length>0&&e.proessMsgQueue(t);var n="connTime="+((new D
[1:1:0711/162538.442440:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162538.450694:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 347, 7fc23292d881
[1:1:0711/162538.458116:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162538.458301:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162538.458469:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162538.458769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162538.458859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162538.459560:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162538.459644:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162538.459846:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 448
[1:1:0711/162538.459964:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 448 0x7fc22ffe8070 0x2ef46c5278e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 347 0x7fc22ffe8070 0x2ef46b6a7160 
[1:1:0711/162538.502525:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162538.502899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , n.onload, (){i()}
[1:1:0711/162538.503002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162538.559592:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162538.559778:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162538.564689:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00484586, 78, 1
[1:1:0711/162538.564824:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162538.579299:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162538.579714:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162538.579850:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.124895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162539.125098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.238721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 450 0x7fc231f102e0 0x2ef46c74cf60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.239935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0711/162539.240044:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.256954:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 451 0x7fc231f102e0 0x2ef46c3c5f60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.257689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:16
*/
KISSY.add("event",["event/dom
[1:1:0711/162539.257808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.269635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.417565:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162539.417727:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.422580:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00476384, 78, 1
[1:1:0711/162539.422685:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162539.559593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 448, 7fc23292d881
[1:1:0711/162539.567777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"347 0x7fc22ffe8070 0x2ef46b6a7160 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162539.567952:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"347 0x7fc22ffe8070 0x2ef46b6a7160 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162539.568117:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.568399:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162539.568491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.569239:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162539.569332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162539.569541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 498
[1:1:0711/162539.569640:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7fc22ffe8070 0x2ef46c3bd660 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 448 0x7fc22ffe8070 0x2ef46c5278e0 
[1:1:0711/162539.584328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162539.584458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.756428:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.756883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162539.756983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.907190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 357, 7fc23292d881
[1:1:0711/162539.916714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162539.916910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162539.917185:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.917517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0711/162539.917640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162539.982213:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162539.982364:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162539.987156:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00476003, 78, 1
[1:1:0711/162539.987293:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162540.004780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162540.004948:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.080285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7fc231f102e0 0x2ef46c3bcbe0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162540.084815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0711/162540.084946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.168864:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/162540.169105:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/162540.169764:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:16:0711/162540.172566:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0711/162540.180071:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576190
[1:1:0711/162540.181133:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162540.181382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 542
[1:1:0711/162540.181520:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 542 0x7fc22ffe8070 0x2ef46b9b8fe0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 509 0x7fc231f102e0 0x2ef46c3bcbe0 
[1:1:0711/162540.422856:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162540.423033:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162540.442478:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.019388, 339, 1
[1:1:0711/162540.442670:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162540.452911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162540.453110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.454283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 498, 7fc23292d881
[1:1:0711/162540.463282:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"448 0x7fc22ffe8070 0x2ef46c5278e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162540.463439:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"448 0x7fc22ffe8070 0x2ef46c5278e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162540.463630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162540.463888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162540.463976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.464800:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162540.464889:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162540.465057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 582
[1:1:0711/162540.465156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 582 0x7fc22ffe8070 0x2ef46c8d1ce0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 498 0x7fc22ffe8070 0x2ef46c3bd660 
[1:1:0711/162540.546587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){G=n}
[1:1:0711/162540.546749:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.640169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){a.setLocalDescription(n,function(){},function(){})}
[1:1:0711/162540.640309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.788376:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 561 0x7fc231f102e0 0x2ef46acd7ce0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162540.789198:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 9 22:41
*/
KISSY.add("io/form-serializer
[1:1:0711/162540.789551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162540.808044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162541.084522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 562 0x7fc231f102e0 0x2ef46c0a1fe0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162541.098116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , !function(){function e(e,a){for(var r=3;void 0!==r;){var s=-1&r,c=r>>-(1/0),b=-1&c;switch(s){case 0:
[1:1:0711/162541.098280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:18:0711/162542.202002:WARNING:paced_sender.cc(261)] Elapsed time (2005 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162542.702322:WARNING:paced_sender.cc(261)] Elapsed time (2505 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162542.707905:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576190
[1:1:0711/162542.708118:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162542.708371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 609
[1:1:0711/162542.708496:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7fc22ffe8070 0x2ef46c3d2860 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 562 0x7fc231f102e0 0x2ef46c0a1fe0 
[1:18:0711/162543.202614:WARNING:paced_sender.cc(261)] Elapsed time (3006 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162543.219706:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:18:0711/162543.702320:WARNING:paced_sender.cc(261)] Elapsed time (3505 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162544.202681:WARNING:paced_sender.cc(261)] Elapsed time (4006 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162544.702786:WARNING:paced_sender.cc(261)] Elapsed time (4506 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162544.728372:WARNING:paced_sender.cc(261)] Elapsed time (2005 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162545.203161:WARNING:paced_sender.cc(261)] Elapsed time (5006 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162545.228719:WARNING:paced_sender.cc(261)] Elapsed time (2505 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162545.703564:WARNING:paced_sender.cc(261)] Elapsed time (5507 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162545.728260:WARNING:paced_sender.cc(261)] Elapsed time (3004 ms) longer than expected, limiting to 2000 ms
		remove user.f_ffd67b08 -> 0
		remove user.10_d2251216 -> 0
		remove user.12_103afde -> 0
		remove user.11_af4a65c0 -> 0
		remove user.13_77903d59 -> 0
[1:18:0711/162546.203849:WARNING:paced_sender.cc(261)] Elapsed time (6007 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162546.228873:WARNING:paced_sender.cc(261)] Elapsed time (3505 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162546.704306:WARNING:paced_sender.cc(261)] Elapsed time (6507 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162546.729231:WARNING:paced_sender.cc(261)] Elapsed time (4005 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162547.204811:WARNING:paced_sender.cc(261)] Elapsed time (7008 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162547.229481:WARNING:paced_sender.cc(261)] Elapsed time (4506 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162547.704951:WARNING:paced_sender.cc(261)] Elapsed time (7508 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162547.729832:WARNING:paced_sender.cc(261)] Elapsed time (5006 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162548.205386:WARNING:paced_sender.cc(261)] Elapsed time (8008 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162548.231155:WARNING:paced_sender.cc(261)] Elapsed time (5507 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162548.705218:WARNING:paced_sender.cc(261)] Elapsed time (8508 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162548.731509:WARNING:paced_sender.cc(261)] Elapsed time (6008 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162549.205634:WARNING:paced_sender.cc(261)] Elapsed time (9009 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162549.231959:WARNING:paced_sender.cc(261)] Elapsed time (6508 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162549.705868:WARNING:paced_sender.cc(261)] Elapsed time (9509 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162549.732566:WARNING:paced_sender.cc(261)] Elapsed time (7009 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162550.206301:WARNING:paced_sender.cc(261)] Elapsed time (10009 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162550.232893:WARNING:paced_sender.cc(261)] Elapsed time (7509 ms) longer than expected, limiting to 2000 ms
[1:18:0711/162550.706678:WARNING:paced_sender.cc(261)] Elapsed time (10510 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162550.734054:WARNING:paced_sender.cc(261)] Elapsed time (8010 ms) longer than expected, limiting to 2000 ms
[14932:14932:0711/162550.953949:INFO:CONSOLE(3)] "", source: https://g.alicdn.com/secdev/nsv/1.0.63/ns_c_74_3_f.js (3)
[1:18:0711/162551.206900:WARNING:paced_sender.cc(261)] Elapsed time (11010 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162551.234447:WARNING:paced_sender.cc(261)] Elapsed time (8511 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162551.343975:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162551.344127:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162551.345549:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7fc22ffe8070 0x2ef46cfb2b60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162551.346036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , KISSY.add("sm-margin",function(a){function b(d,c){}return b},{requires:[]});KISSY.add("sm-bannerLeft
[1:1:0711/162551.346141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162551.356817:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7fc22ffe8070 0x2ef46cfb2b60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162551.361289:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162551.422929:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162551.486877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162551.487078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:16:0711/162551.587871:WARNING:stunport.cc(403)] Port[0x2ef470c5b420:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:1:0711/162551.600239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){}
[1:1:0711/162551.600464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:16:0711/162551.679699:WARNING:p2ptransportchannel.cc(714)] Port[0x2ef46c7d68a0:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:16:0711/162551.680172:WARNING:p2ptransportchannel.cc(714)] Port[0x2ef46acb1420:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:1:0711/162551.681696:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162551.682026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162551.682126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:18:0711/162551.708160:WARNING:paced_sender.cc(261)] Elapsed time (11511 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162551.734717:WARNING:paced_sender.cc(261)] Elapsed time (9011 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162551.903298:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162551.903504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 50
[1:1:0711/162551.903731:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 668
[1:1:0711/162551.903888:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 668 0x7fc22ffe8070 0x2ef470b692e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:18:0711/162552.208477:WARNING:paced_sender.cc(261)] Elapsed time (12012 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162552.235029:WARNING:paced_sender.cc(261)] Elapsed time (9511 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162552.248430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.248604:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.248862:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 676
[1:1:0711/162552.248968:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 676 0x7fc22ffe8070 0x2ef46c3e2060 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:1:0711/162552.290496:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.290647:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.290840:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 677
[1:1:0711/162552.290945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 677 0x7fc22ffe8070 0x2ef470b62ee0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:1:0711/162552.319507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.319670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.319856:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 678
[1:1:0711/162552.319965:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7fc22ffe8070 0x2ef471271b60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:1:0711/162552.348223:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.348359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.348551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 679
[1:1:0711/162552.348644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7fc22ffe8070 0x2ef46df17c60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:1:0711/162552.376439:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.376652:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.376901:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 680
[1:1:0711/162552.377008:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7fc22ffe8070 0x2ef471339460 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:1:0711/162552.404760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.404909:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.405195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 681
[1:1:0711/162552.405301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 681 0x7fc22ffe8070 0x2ef471339de0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:1:0711/162552.434372:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162552.434510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 100
[1:1:0711/162552.434699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 682
[1:1:0711/162552.434802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 682 0x7fc22ffe8070 0x2ef46acdcce0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 
[1:18:0711/162552.709067:WARNING:paced_sender.cc(261)] Elapsed time (12512 ms) longer than expected, limiting to 2000 ms
[1:20:0711/162552.735229:WARNING:paced_sender.cc(261)] Elapsed time (10011 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162553.100619:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 582, 7fc23292d881
[1:1:0711/162553.110888:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"498 0x7fc22ffe8070 0x2ef46c3bd660 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.111037:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"498 0x7fc22ffe8070 0x2ef46c3bd660 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.111236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162553.111519:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162553.111612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162553.112421:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162553.112501:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162553.112651:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 694
[1:1:0711/162553.112744:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 694 0x7fc22ffe8070 0x2ef46cfb0f60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 582 0x7fc22ffe8070 0x2ef46c8d1ce0 
[1:18:0711/162553.209275:WARNING:paced_sender.cc(261)] Elapsed time (13012 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162553.210373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , S, (e){var a="se";a&&(a+="tLo"),a+="calDes",a+="cript",a+="io",a+="n",$a[a](e)}
[1:1:0711/162553.210530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:20:0711/162553.235728:WARNING:paced_sender.cc(261)] Elapsed time (10512 ms) longer than expected, limiting to 2000 ms
[1:1:0711/162553.319654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 356, 7fc23292d881
[1:1:0711/162553.330865:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.331038:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"289 0x7fc231f102e0 0x2ef46b03cbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.331271:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162553.331560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/162553.331648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162553.336928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 542, 7fc23292d881
[1:1:0711/162553.348941:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"509 0x7fc231f102e0 0x2ef46c3bcbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.349194:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"509 0x7fc231f102e0 0x2ef46c3bcbe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.349413:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162553.349695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){try{a.close()}catch(t){}}
[1:1:0711/162553.349795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162553.365255:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 609, 7fc23292d881
[1:1:0711/162553.376691:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"562 0x7fc231f102e0 0x2ef46c0a1fe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.376913:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"562 0x7fc231f102e0 0x2ef46c0a1fe0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162553.377157:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162553.377541:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , Y, (e){try{for(var a="\u0441\u044a\u044d\u0451\u0443",r="",s=0;s<a.length;s++){var c=a.charCodeAt(s)-99
[1:1:0711/162553.377677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162553.766295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162553.766564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.115329:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162554.115867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , D, (n){cn=n.gamma,en||(en=s(function(n){removeEventListener("deviceorientation",D),s(A,470)},30))}
[1:1:0711/162554.115971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.116400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x29f3ebfc29c8, 0x2ef46a576238
[1:1:0711/162554.116495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 30
[1:1:0711/162554.116669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 757
[1:1:0711/162554.116761:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7fc22ffe8070 0x2ef46d17bd60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 666 0x7fc2485483d0 0x2ef46cfe0060 
[1:1:0711/162554.116943:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162554.216588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 668, 7fc23292d881
[1:1:0711/162554.228995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162554.229214:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162554.229426:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162554.229701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){getInitialHlEl()}
[1:1:0711/162554.229800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.232485:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162554.232582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 50
[1:1:0711/162554.232777:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 761
[1:1:0711/162554.232907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 761 0x7fc22ffe8070 0x2ef4717cafe0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 668 0x7fc22ffe8070 0x2ef470b692e0 
[1:1:0711/162554.233392:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 682, 7fc23292d881
[1:1:0711/162554.245934:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162554.246100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"598 0x7fc246673080 0x2ef46cdeeba0 1 0 0x2ef46cdeebb8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162554.246283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162554.246543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){m.apply(c,b)}
[1:1:0711/162554.246639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.775333:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 694, 7fc23292d881
[1:1:0711/162554.788716:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"582 0x7fc22ffe8070 0x2ef46c8d1ce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162554.788909:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"582 0x7fc22ffe8070 0x2ef46c8d1ce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162554.789163:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162554.789495:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162554.789605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.790006:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162554.790112:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162554.790306:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 774
[1:1:0711/162554.790416:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7fc22ffe8070 0x2ef46ad1ee60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 694 0x7fc22ffe8070 0x2ef46cfb0f60 
[1:1:0711/162554.919465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162554.919657:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.944653:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 734 0x7fc231f102e0 0x2ef46c3b39e0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162554.945433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*! umpp 2015-08-03 */
KISSY.add("tbc/umpp/1.5.4/mods/messenger",function(a,b,c,d){function e(a,b){r
[1:1:0711/162554.945565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162554.955874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.074194:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 180000, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162555.074412:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 180000
[1:1:0711/162555.074700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 778
[1:1:0711/162555.074892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 778 0x7fc22ffe8070 0x2ef4715c47e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 734 0x7fc231f102e0 0x2ef46c3b39e0 
[1:1:0711/162555.102325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 735 0x7fc231f102e0 0x2ef46cfb2260 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.103102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , define("tbc/search-suggest/1.5.0/index",["combobox","base","json","cookie","event","node","dom"],fun
[1:1:0711/162555.103244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.105160:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.130692:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.131055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , j, (){var a=o.readyState;if(!a||"loaded"===a||"complete"===a)o.onreadystatechange=o.onload=null,v(0)}
[1:1:0711/162555.131162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.438192:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 739 0x7fc231f102e0 0x2ef46c4f2160 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.438852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , 
	    window.tce_79618&&tce_79618(
		{"79618":{"value":{"moduleinfo":{"data_count":[{"count":1,"cou
[1:1:0711/162555.439013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.439956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.457829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 740 0x7fc231f102e0 0x2ef46ec16360 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.458365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*! market 2015-08-24 */
KISSY.add("tbc/market/1.3.24/json",function(S){var JSONA={};return function
[1:1:0711/162555.458466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.461449:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.488478:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 743 0x7fc231f102e0 0x2ef470b680e0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.489362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:19
*/
KISSY.add("xtemplate",["xtemp
[1:1:0711/162555.489466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.498477:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.714822:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 757, 7fc23292d881
[1:1:0711/162555.727469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"666 0x7fc2485483d0 0x2ef46cfe0060 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162555.727642:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"666 0x7fc2485483d0 0x2ef46cfe0060 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162555.727835:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.728105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/162555.728200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.728693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162555.728774:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 470
[1:1:0711/162555.728924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 791
[1:1:0711/162555.729004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 791 0x7fc22ffe8070 0x2ef46acd5b60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 757 0x7fc22ffe8070 0x2ef46d17bd60 
[1:1:0711/162555.741222:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.741532:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162555.741628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.807413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 761, 7fc23292d881
[1:1:0711/162555.820657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"668 0x7fc22ffe8070 0x2ef470b692e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162555.820830:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"668 0x7fc22ffe8070 0x2ef470b692e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162555.821020:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162555.821410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){getInitialHlEl()}
[1:1:0711/162555.821506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162555.980978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162555.981179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162556.035721:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 774, 7fc23292d881
[1:1:0711/162556.047825:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"694 0x7fc22ffe8070 0x2ef46cfb0f60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162556.048035:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"694 0x7fc22ffe8070 0x2ef46cfb0f60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162556.048259:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162556.048602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162556.048720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162556.049607:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162556.049734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162556.049932:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 800
[1:1:0711/162556.050087:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 800 0x7fc22ffe8070 0x2ef46ad1eb60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 774 0x7fc22ffe8070 0x2ef46ad1ee60 
[1:1:0711/162556.250301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162556.250468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162556.327118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 805 0x7fc231f102e0 0x2ef46bccfbe0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162556.328492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:04
*/
KISSY.add("combobox/combobox-
[1:1:0711/162556.328658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162556.373718:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162556.955656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 806 0x7fc231f102e0 0x2ef47190fe60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162556.956372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*! market 2015-06-09 */
KISSY.add("tms/api",function(a,b){"use strict";var c={},d={add:function(a,d
[1:1:0711/162556.956544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162556.957973:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162557.054601:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 809 0x7fc231f102e0 0x2ef46cfda260 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162557.055361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*!build time : 2014-03-27 6:09:53 PM*/
KISSY.add("gallery/slide/1.3/slide-util",function(a){"use st
[1:1:0711/162557.055515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162557.061751:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162557.228035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 791, 7fc23292d881
[1:1:0711/162557.240165:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"757 0x7fc22ffe8070 0x2ef46d17bd60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162557.240398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"757 0x7fc22ffe8070 0x2ef46d17bd60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162557.240660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162557.241012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/162557.241190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162557.269107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162557.269318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162557.285564:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162557.285982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162557.286111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162557.965453:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162557.965639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162557.965893:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 845
[1:1:0711/162557.966056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7fc22ffe8070 0x2ef47329fce0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 822 0x7fc246673080 0x2ef4729d3560 1 0 0x2ef4729d3578 
[1:1:0711/162558.137579:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 800, 7fc23292d881
[1:1:0711/162558.151040:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"774 0x7fc22ffe8070 0x2ef46ad1ee60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162558.151294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"774 0x7fc22ffe8070 0x2ef46ad1ee60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162558.151584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162558.151927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162558.152080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162558.152993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162558.153193:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162558.153466:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 852
[1:1:0711/162558.153641:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7fc22ffe8070 0x2ef4732e9360 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 800 0x7fc22ffe8070 0x2ef46ad1eb60 
[1:1:0711/162558.365772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162558.366015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162558.661542:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 867 0x7fc231f102e0 0x2ef47349da60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162558.662119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /*! market 2015-08-24 */
KISSY.add("tbc/market/1.3.24/getHelper",function(a,b,c){"use strict";functi
[1:1:0711/162558.662256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162558.663691:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162559.767898:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162559.768113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162559.824831:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162559.825259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162559.825387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162601.454550:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162601.454758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162601.455025:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 891
[1:1:0711/162601.455187:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7fc22ffe8070 0x2ef46b375b60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 876 0x7fc246673080 0x2ef473de1100 1 0 0x2ef473de1118 
[1:1:0711/162601.478216:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162601.478418:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162601.478688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 892
[1:1:0711/162601.478848:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7fc22ffe8070 0x2ef4734a0960 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 876 0x7fc246673080 0x2ef473de1100 1 0 0x2ef473de1118 
[1:1:0711/162601.570032:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 852, 7fc23292d881
[1:1:0711/162601.583407:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"800 0x7fc22ffe8070 0x2ef46ad1eb60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162601.583613:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"800 0x7fc22ffe8070 0x2ef46ad1eb60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162601.583823:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162601.584103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162601.584231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162601.585117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162601.585219:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162601.585411:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 903
[1:1:0711/162601.585524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7fc22ffe8070 0x2ef47231a660 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 852 0x7fc22ffe8070 0x2ef4732e9360 
[1:1:0711/162601.670347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162601.670533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162601.799420:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162601.801219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0711/162601.801333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162601.900205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162601.900699:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x29f3ebfc29c8, 0x2ef46a5761f0
[1:1:0711/162601.900781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 30
[1:1:0711/162601.900945:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 916
[1:1:0711/162601.901066:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 916 0x7fc22ffe8070 0x2ef474015160 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 887 0x7fc2485483d0 0x2ef47393a360 
[1:1:0711/162601.931268:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 845, 7fc23292d881
[1:1:0711/162601.943727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"822 0x7fc246673080 0x2ef4729d3560 1 0 0x2ef4729d3578 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162601.943869:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"822 0x7fc246673080 0x2ef4729d3560 1 0 0x2ef4729d3578 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162601.944054:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162601.944325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){a.next().play()}
[1:1:0711/162601.944413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.020910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162602.021119:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 15
[1:1:0711/162602.021339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 921
[1:1:0711/162602.021453:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7fc22ffe8070 0x2ef47321cc60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 845 0x7fc22ffe8070 0x2ef47329fce0 
[1:1:0711/162602.021799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162602.021878:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 300
[1:1:0711/162602.022055:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 922
[1:1:0711/162602.022140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7fc22ffe8070 0x2ef4735d5960 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 845 0x7fc22ffe8070 0x2ef47329fce0 
[1:1:0711/162602.047912:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162602.048065:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162602.048274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 924
[1:1:0711/162602.048383:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 924 0x7fc22ffe8070 0x2ef47494d760 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 845 0x7fc22ffe8070 0x2ef47329fce0 
[1:1:0711/162602.127486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162602.127650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.216375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 916, 7fc23292d881
[1:1:0711/162602.231134:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"887 0x7fc2485483d0 0x2ef47393a360 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.231314:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"887 0x7fc2485483d0 0x2ef47393a360 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.231520:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.231822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/162602.231927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.232295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162602.232375:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 470
[1:1:0711/162602.232568:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 937
[1:1:0711/162602.232675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 937 0x7fc22ffe8070 0x2ef473ba6560 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 916 0x7fc22ffe8070 0x2ef474015160 
[1:1:0711/162602.292519:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 921, 7fc23292d881
[1:1:0711/162602.309076:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"845 0x7fc22ffe8070 0x2ef47329fce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.309267:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"845 0x7fc22ffe8070 0x2ef47329fce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.309474:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.309755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , l, (){b.runFrames()?
b.stopTimer():b.timer=h(l)}
[1:1:0711/162602.309841:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.384435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7fc231f102e0 0x2ef4734a0860 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.385191:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , KISSY.add("sd/data_sufei/sufei",function(u){"use strict";function e(u,e){return function(){return e.
[1:1:0711/162602.385298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.386631:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.426517:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 903, 7fc23292d881
[1:1:0711/162602.441579:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"852 0x7fc22ffe8070 0x2ef4732e9360 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.441792:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"852 0x7fc22ffe8070 0x2ef4732e9360 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.442038:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.442390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162602.442483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.443458:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162602.443605:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 500
[1:1:0711/162602.443772:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 950
[1:1:0711/162602.443954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 950 0x7fc22ffe8070 0x2ef471a1cce0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 903 0x7fc22ffe8070 0x2ef47231a660 
[1:1:0711/162602.487646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162602.487847:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.586275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 922, 7fc23292d881
[1:1:0711/162602.603787:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"845 0x7fc22ffe8070 0x2ef47329fce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.603986:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"845 0x7fc22ffe8070 0x2ef47329fce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162602.604244:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.604583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){f()}
[1:1:0711/162602.604727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162602.639249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162602.639699:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162602.639848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
		remove user.14_bdf6a4ac -> 0
		remove user.15_c585e5e1 -> 0
		remove user.16_f45e7222 -> 0
[1:1:0711/162605.180408:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162605.180615:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 0
[1:1:0711/162605.180871:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 982
[1:1:0711/162605.181009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7fc22ffe8070 0x2ef47349aee0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 945 0x7fc246673080 0x2ef4736191a0 1 0 0x2ef4736191b8 
[1:1:0711/162605.204159:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162605.204358:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 0
[1:1:0711/162605.204547:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 984
[1:1:0711/162605.204717:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7fc22ffe8070 0x2ef475f7e8e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 945 0x7fc246673080 0x2ef4736191a0 1 0 0x2ef4736191b8 
[1:1:0711/162607.375692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162607.375886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162608.036628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 937, 7fc23292d881
[1:1:0711/162608.052381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"916 0x7fc22ffe8070 0x2ef474015160 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.052587:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"916 0x7fc22ffe8070 0x2ef474015160 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.052814:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162608.053138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/162608.053264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162608.053960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 950, 7fc23292d881
[1:1:0711/162608.070154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"903 0x7fc22ffe8070 0x2ef47231a660 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.070369:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"903 0x7fc22ffe8070 0x2ef47231a660 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.070646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162608.071005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162608.071117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162608.072024:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162608.072151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162608.072371:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1009
[1:1:0711/162608.072517:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7fc22ffe8070 0x2ef4776ac5e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 950 0x7fc22ffe8070 0x2ef471a1cce0 
[1:1:0711/162608.073102:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 891, 7fc23292d881
[1:1:0711/162608.090461:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"876 0x7fc246673080 0x2ef473de1100 1 0 0x2ef473de1118 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.090673:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"876 0x7fc246673080 0x2ef473de1100 1 0 0x2ef473de1118 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.090867:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162608.091245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){n=!0,e.log(j,"\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u02b1\ufffd\ufffd\ufffd\ufffd\ufffd\xf1\ufffd\
[1:1:0711/162608.091380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162608.156245:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162608.156430:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162608.156647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1015
[1:1:0711/162608.156817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1015 0x7fc22ffe8070 0x2ef475889c60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 891 0x7fc22ffe8070 0x2ef46b375b60 
[1:1:0711/162608.646721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162608.646947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162608.667135:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 892, 7fc23292d881
[1:1:0711/162608.687149:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"876 0x7fc246673080 0x2ef473de1100 1 0 0x2ef473de1118 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.687389:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"876 0x7fc246673080 0x2ef473de1100 1 0 0x2ef473de1118 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162608.687672:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162608.688229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){n=!0,e.log(j,"\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u02b1\ufffd\ufffd\ufffd\ufffd\ufffd\xf1\ufffd\
[1:1:0711/162608.688362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162608.844516:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162608.844720:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162608.844946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1054
[1:1:0711/162608.845121:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1054 0x7fc22ffe8070 0x2ef475f7e560 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 892 0x7fc22ffe8070 0x2ef4734a0960 
[1:1:0711/162609.295084:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 924, 7fc23292d881
[1:1:0711/162609.314952:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"845 0x7fc22ffe8070 0x2ef47329fce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162609.315143:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"845 0x7fc22ffe8070 0x2ef47329fce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162609.315402:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162609.315749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){a.next().play()}
[1:1:0711/162609.315851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162609.420517:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162609.420697:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162609.420913:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1075
[1:1:0711/162609.421002:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7fc22ffe8070 0x2ef478067e60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 924 0x7fc22ffe8070 0x2ef47494d760 
[1:1:0711/162609.467294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162609.467446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 15
[1:1:0711/162609.467642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1076
[1:1:0711/162609.467749:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1076 0x7fc22ffe8070 0x2ef478068de0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 924 0x7fc22ffe8070 0x2ef47494d760 
[1:1:0711/162609.468062:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162609.468152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 300
[1:1:0711/162609.468322:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1077
[1:1:0711/162609.468429:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1077 0x7fc22ffe8070 0x2ef478064be0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 924 0x7fc22ffe8070 0x2ef47494d760 
[1:1:0711/162609.478225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162609.478380:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162609.478615:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1078
[1:1:0711/162609.478708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1078 0x7fc22ffe8070 0x2ef47805f260 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 924 0x7fc22ffe8070 0x2ef47494d760 
[1:1:0711/162609.479411:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 982, 7fc23292d881
[1:1:0711/162609.496383:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"945 0x7fc246673080 0x2ef4736191a0 1 0 0x2ef4736191b8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162609.496548:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"945 0x7fc246673080 0x2ef4736191a0 1 0 0x2ef4736191b8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162609.496733:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162609.497002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , ve, (e){B=0;var r=d(8,0),s="l",c=s.split("").reverse().join(""),b="/",k=b.split("").reverse().join("");a
[1:1:0711/162609.497107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162611.001401:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "webkitTransitionEnd", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162611.002158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , j.handle, (a){var b=a.type,c=d.currentTarget;if(!(k.triggeredEvent===b||typeof KISSY==="undefined"))if(b=k.get
[1:1:0711/162611.002265:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162611.099079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 984, 7fc23292d881
[1:1:0711/162611.116950:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"945 0x7fc246673080 0x2ef4736191a0 1 0 0x2ef4736191b8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162611.117192:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"945 0x7fc246673080 0x2ef4736191a0 1 0 0x2ef4736191b8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162611.117445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162611.117779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , e, (){D=null;var n=M.ra(!1,null);z.s(n),p.k(g,n)}
[1:1:0711/162611.117934:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162611.983368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162611.983589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162612.693385:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1076, 7fc23292d881
[1:1:0711/162612.711702:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"924 0x7fc22ffe8070 0x2ef47494d760 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162612.711950:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"924 0x7fc22ffe8070 0x2ef47494d760 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162612.712214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162612.712585:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , l, (){b.runFrames()?
b.stopTimer():b.timer=h(l)}
[1:1:0711/162612.712773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162612.721848:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1077, 7fc23292d881
[1:1:0711/162612.739045:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"924 0x7fc22ffe8070 0x2ef47494d760 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162612.739321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"924 0x7fc22ffe8070 0x2ef47494d760 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162612.739565:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162612.739902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){f()}
[1:1:0711/162612.740017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162612.850234:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1009, 7fc23292d881
[1:1:0711/162612.870796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"950 0x7fc22ffe8070 0x2ef471a1cce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162612.871004:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"950 0x7fc22ffe8070 0x2ef471a1cce0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162612.871251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162612.871564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162612.871692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162612.872752:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162612.872843:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162612.872999:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1152
[1:1:0711/162612.873116:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1152 0x7fc22ffe8070 0x2ef4735c7460 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1009 0x7fc22ffe8070 0x2ef4776ac5e0 
[1:1:0711/162613.077018:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1099 0x7fc231f102e0 0x2ef46c3ecae0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162613.078085:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162613.078471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , window.onerror, (){try{a&&a.apply(window,arguments);var e=r.apply(window,arguments);window.JSTracker2.push(e)}catch(
[1:1:0711/162613.078575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162613.084440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[14932:14932:0711/162613.085439:INFO:CONSOLE(6)] "Uncaught SyntaxError: Unexpected token <", source: https://login.taobao.com/member/login.jhtml?redirectURL=http%3A%2F%2Fs.taobao.com%2Fsearch%3Fcallback%3Djsonp755%26app%3Dstditemapi%26m%3Dstditem%26_input_charset%3Dutf-8%26page_size%3D24%26rand_size%3D100%26oeid%3D5278000%26originurl%3D%26count%3D24 (6)
[1:1:0711/162613.087342:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162613.087444:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 0
[1:1:0711/162613.087635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1170
[1:1:0711/162613.087729:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7fc22ffe8070 0x2ef47367b360 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1099 0x7fc231f102e0 0x2ef46c3ecae0 
[1:1:0711/162613.126496:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162613.126682:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162613.126910:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1178
[1:1:0711/162613.127099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7fc22ffe8070 0x2ef475aafae0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1099 0x7fc231f102e0 0x2ef46c3ecae0 
[1:1:0711/162613.160660:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1100 0x7fc231f102e0 0x2ef46c3c57e0 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162613.161325:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162613.161719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , window.onerror, (){try{a&&a.apply(window,arguments);var e=r.apply(window,arguments);window.JSTracker2.push(e)}catch(
[1:1:0711/162613.161927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162613.165724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[14932:14932:0711/162613.166823:INFO:CONSOLE(6)] "Uncaught SyntaxError: Unexpected token <", source: https://login.taobao.com/member/login.jhtml?redirectURL=http%3A%2F%2Fs.taobao.com%2Fsearch%3Fcallback%3Djsonp756%26app%3Dstditemapi%26m%3Dstditem%26_input_charset%3Dutf-8%26page_size%3D24%26rand_size%3D100%26oeid%3D5279000%26originurl%3D%26count%3D24 (6)
[1:1:0711/162613.168305:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162613.168452:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 0
[1:1:0711/162613.168677:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1186
[1:1:0711/162613.168855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1186 0x7fc22ffe8070 0x2ef4734ac7e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1100 0x7fc231f102e0 0x2ef46c3c57e0 
[1:1:0711/162613.206270:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x29f3ebfc29c8, 0x2ef46a576210
[1:1:0711/162613.206463:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 5000
[1:1:0711/162613.206696:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1196
[1:1:0711/162613.206842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1196 0x7fc22ffe8070 0x2ef4735d5660 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1100 0x7fc231f102e0 0x2ef46c3c57e0 
[1:1:0711/162613.590794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162613.591003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162613.704849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162613.705299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , n.onload, (){i()}
[1:1:0711/162613.705748:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162613.799235:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1078, 7fc23292d881
[1:1:0711/162613.818003:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"924 0x7fc22ffe8070 0x2ef47494d760 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162613.818190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"924 0x7fc22ffe8070 0x2ef47494d760 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162613.818396:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162613.818671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){a.next().play()}
[1:1:0711/162613.818771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162613.850314:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162613.850511:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162613.850781:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1208
[1:1:0711/162613.850906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1208 0x7fc22ffe8070 0x2ef475b1cd60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1078 0x7fc22ffe8070 0x2ef47805f260 
[1:1:0711/162613.904241:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162613.904434:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 15
[1:1:0711/162613.904641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1209
[1:1:0711/162613.904779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1209 0x7fc22ffe8070 0x2ef478073fe0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1078 0x7fc22ffe8070 0x2ef47805f260 
[1:1:0711/162613.905128:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162613.905232:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 300
[1:1:0711/162613.905399:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1210
[1:1:0711/162613.905558:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1210 0x7fc22ffe8070 0x2ef478067a60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1078 0x7fc22ffe8070 0x2ef47805f260 
[1:1:0711/162613.919608:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162613.919754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162613.919951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1211
[1:1:0711/162613.920055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1211 0x7fc22ffe8070 0x2ef473152de0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1078 0x7fc22ffe8070 0x2ef47805f260 
[1:1:0711/162614.251823:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162614.252247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , n.onload, (){i()}
[1:1:0711/162614.252348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162614.988806:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162614.989246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/162614.989357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162614.991475:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1170, 7fc23292d881
[1:1:0711/162615.011058:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1099 0x7fc231f102e0 0x2ef46c3ecae0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.011266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1099 0x7fc231f102e0 0x2ef46c3ecae0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.011499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.011800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){throw e;}
[1:1:0711/162615.011880:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.012397:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/zhubao.php"
[14932:14932:0711/162615.016391:INFO:CONSOLE(40)] "Uncaught TypeError: Cannot read property '0' of undefined", source: https://g.alicdn.com/kissy/k/1.4.2/??io-min.js,cookie-min.js (40)
[1:1:0711/162615.301345:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1015, 7fc23292d881
[1:1:0711/162615.320666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"891 0x7fc22ffe8070 0x2ef46b375b60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.320844:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"891 0x7fc22ffe8070 0x2ef46b375b60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.321087:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.321373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/162615.321473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.325437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1186, 7fc23292d881
[1:1:0711/162615.344739:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1100 0x7fc231f102e0 0x2ef46c3c57e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.344949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1100 0x7fc231f102e0 0x2ef46c3c57e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.345191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.345545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){throw e;}
[1:1:0711/162615.345702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.346148:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/zhubao.php"
[14932:14932:0711/162615.350299:INFO:CONSOLE(40)] "Uncaught TypeError: Cannot read property '0' of undefined", source: https://g.alicdn.com/kissy/k/1.4.2/??io-min.js,cookie-min.js (40)
[1:1:0711/162615.430510:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.432174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0711/162615.432276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.496893:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.497346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x29f3ebfc29c8, 0x2ef46a5761f0
[1:1:0711/162615.497468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 30
[1:1:0711/162615.497690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1231
[1:1:0711/162615.497827:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1231 0x7fc22ffe8070 0x2ef46a8a2ee0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1202 0x7fc2485483d0 0x2ef4777b8960 
[1:1:0711/162615.556956:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162615.557163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.558406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1054, 7fc23292d881
[1:1:0711/162615.578324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"892 0x7fc22ffe8070 0x2ef4734a0960 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.578529:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"892 0x7fc22ffe8070 0x2ef4734a0960 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.578728:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.579001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/162615.579090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.582249:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1209, 7fc23292d881
[1:1:0711/162615.601514:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1078 0x7fc22ffe8070 0x2ef47805f260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.601688:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1078 0x7fc22ffe8070 0x2ef47805f260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.601890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.602166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , l, (){b.runFrames()?
b.stopTimer():b.timer=h(l)}
[1:1:0711/162615.602263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.611513:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1210, 7fc23292d881
[1:1:0711/162615.630114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1078 0x7fc22ffe8070 0x2ef47805f260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.630279:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1078 0x7fc22ffe8070 0x2ef47805f260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162615.630475:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.630744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){f()}
[1:1:0711/162615.630846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.670774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "webkitTransitionEnd", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.671238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , j.handle, (a){var b=a.type,c=d.currentTarget;if(!(k.triggeredEvent===b||typeof KISSY==="undefined"))if(b=k.get
[1:1:0711/162615.671499:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.876058:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.876554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , n.onload, (){i()}
[1:1:0711/162615.876656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.934080:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.934490:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , n.onload, (){i()}
[1:1:0711/162615.934613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162615.935624:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.935984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.936247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162615.996126:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1231, 7fc23292d881
[1:1:0711/162616.013926:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1202 0x7fc2485483d0 0x2ef4777b8960 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162616.014083:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1202 0x7fc2485483d0 0x2ef4777b8960 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162616.014275:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162616.014572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/162616.014670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162616.015010:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162616.015079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 470
[1:1:0711/162616.015302:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1248
[1:1:0711/162616.015405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1248 0x7fc22ffe8070 0x2ef478f5af60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1231 0x7fc22ffe8070 0x2ef46a8a2ee0 
[1:1:0711/162616.033642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , document.readyState
[1:1:0711/162616.033774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162616.115348:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1152, 7fc23292d881
[1:1:0711/162616.132570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1009 0x7fc22ffe8070 0x2ef4776ac5e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162616.132722:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1009 0x7fc22ffe8070 0x2ef4776ac5e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162616.132904:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162616.133222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/162616.133320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162616.134321:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162616.134411:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162616.134599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1255
[1:1:0711/162616.134701:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1255 0x7fc22ffe8070 0x2ef4774b1de0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1152 0x7fc22ffe8070 0x2ef4735c7460 
[1:1:0711/162616.433202:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1258 0x7fc231f102e0 0x2ef46c50ec60 , "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162616.434092:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , /* 2018-10-09 14:12:23 */
!function(e,n){function i(e){var i=n.createElement("iframe");return i.styl
[1:1:0711/162616.434219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[14932:14932:0711/162616.440334:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/162616.441532:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x2ef477bbe220
[1:1:0711/162616.442349:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[14932:14932:0711/162616.442705:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0711/162616.449187:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/162616.449381:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.taobao.com
[14932:14932:0711/162616.450030:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.taobao.com/
[14932:14932:0711/162616.458158:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[14932:14932:0711/162616.458758:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[14932:14946:0711/162616.468878:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[14932:14932:0711/162616.468956:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://g.alicdn.com/
[14932:14946:0711/162616.468954:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[14932:14932:0711/162616.469000:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://g.alicdn.com/, https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid=, 4
[14932:14932:0711/162616.469077:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://g.alicdn.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html content-length:5224 date:Tue, 09 Jul 2019 11:04:16 GMT vary:Accept-Encoding x-oss-request-id:5D2474B0B13C7D2C22800191 x-oss-object-type:Normal x-oss-hash-crc64ecma:5664768117394609694 x-oss-storage-class:Standard content-md5:3tLMJLZn4GHBah7HDU9pog== x-oss-server-time:2 cache-control:max-age=2592000,s-maxage=3600 access-control-allow-origin:* x-source-scheme:https content-encoding:gzip ali-swift-global-savetime:1562670256 via:cache3.l2cn241[66,200-0,M], cache8.l2cn241[68,0], cache4.cn310[0,200-0,H], cache7.cn310[1,0] age:740 x-cache:HIT TCP_MEM_HIT dirn:-2:-2 x-swift-savetime:Tue, 09 Jul 2019 11:04:16 GMT x-swift-cachetime:3600 timing-allow-origin:* eagleid:7cc1ebcf15626709962575610e  ,15038, 5
[1:7:0711/162616.473739:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/162616.927857:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://g.alicdn.com/
[1:1:0711/162616.932151:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1248, 7fc23292d881
[1:1:0711/162616.950777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1231 0x7fc22ffe8070 0x2ef46a8a2ee0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162616.950973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1231 0x7fc22ffe8070 0x2ef46a8a2ee0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162616.951253:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162616.951588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/162616.951711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[14932:14932:0711/162617.160940:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://g.alicdn.com/, https://g.alicdn.com/, 4
[14932:14932:0711/162617.161009:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://g.alicdn.com/, https://g.alicdn.com
[1:1:0711/162617.161281:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/162617.163270:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1211, 7fc23292d881
[1:1:0711/162617.183991:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1078 0x7fc22ffe8070 0x2ef47805f260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162617.184156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1078 0x7fc22ffe8070 0x2ef47805f260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162617.184353:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162617.184610:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){a.next().play()}
[1:1:0711/162617.184698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162617.215202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162617.215355:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162617.215565:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1319
[1:1:0711/162617.215671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1319 0x7fc22ffe8070 0x2ef476bfee60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1211 0x7fc22ffe8070 0x2ef473152de0 
[1:1:0711/162617.255494:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162617.255665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 15
[1:1:0711/162617.255890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1320
[1:1:0711/162617.256017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1320 0x7fc22ffe8070 0x2ef478eb5360 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1211 0x7fc22ffe8070 0x2ef473152de0 
[1:1:0711/162617.256345:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162617.256442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 300
[1:1:0711/162617.256598:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1321
[1:1:0711/162617.256694:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7fc22ffe8070 0x2ef478f83760 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1211 0x7fc22ffe8070 0x2ef473152de0 
[1:1:0711/162617.265577:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162617.265709:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 3000
[1:1:0711/162617.265917:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1322
[1:1:0711/162617.266040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1322 0x7fc22ffe8070 0x2ef478065660 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1211 0x7fc22ffe8070 0x2ef473152de0 
[1:1:0711/162617.525044:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/162617.682199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1320, 7fc23292d881
[1:1:0711/162617.699992:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1211 0x7fc22ffe8070 0x2ef473152de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162617.700182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1211 0x7fc22ffe8070 0x2ef473152de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162617.700405:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162617.700709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , l, (){b.runFrames()?
b.stopTimer():b.timer=h(l)}
[1:1:0711/162617.700826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162617.985275:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/162617.985438:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
[1:1:0711/162617.987107:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1343 0x7fc22ffe8070 0x2ef478e82c60 , "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
[1:1:0711/162618.002063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://g.alicdn.com/, 1e7d87665028, , , !function e(t,n,o){function i(r,s){if(!n[r]){if(!t[r]){var c="function"==typeof require&&require;if(
[1:1:0711/162618.002257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid=", "g.alicdn.com", 4, 1, https://www.taobao.com, www.taobao.com, 3
[1:1:0711/162618.069221:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1321, 7fc23292d881
[1:1:0711/162618.091219:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1211 0x7fc22ffe8070 0x2ef473152de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162618.091468:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1211 0x7fc22ffe8070 0x2ef473152de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162618.091757:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162618.092171:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){f()}
[1:1:0711/162618.092328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162618.241964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162618.243816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0711/162618.244034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162618.357762:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162618.358310:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x29f3ebfc29c8, 0x2ef46a5761f0
[1:1:0711/162618.358442:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 30
[1:1:0711/162618.358675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://g.alicdn.com/, 1408
[1:1:0711/162618.358912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1408 0x7fc22ffe8070 0x2ef4790f56e0 , 5:4_https://g.alicdn.com/, 1, -5:3_https://www.taobao.com/, 1349 0x7fc2485483d0 0x2ef478e94d60 
[1:1:0711/162618.993009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1178, 7fc23292d881
[1:1:0711/162619.012025:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1099 0x7fc231f102e0 0x2ef46c3ecae0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162619.012216:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1099 0x7fc231f102e0 0x2ef46c3ecae0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162619.012437:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162619.012739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/162619.012830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162619.131464:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1196, 7fc23292d881
[1:1:0711/162619.150700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1100 0x7fc231f102e0 0x2ef46c3c57e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162619.150858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1100 0x7fc231f102e0 0x2ef46c3c57e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/162619.151075:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162619.151376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/162619.151497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162619.581412:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://g.alicdn.com/, 1408, 7fc23292d881
[1:1:0711/162619.600498:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1e7d875c2860","ptid":"1349 0x7fc2485483d0 0x2ef478e94d60 ","rf":"5:4_https://g.alicdn.com/"}
[1:1:0711/162619.600687:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1349 0x7fc2485483d0 0x2ef478e94d60 ","rf":"5:4_https://g.alicdn.com/"}
[1:1:0711/162619.600887:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/zhubao.php"
[1:1:0711/162619.601170:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 1e7d875c2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/162619.601289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/zhubao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/162619.601628:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x29f3ebfc29c8, 0x2ef46a576150
[1:1:0711/162619.601744:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/zhubao.php", 470
[1:1:0711/162619.601909:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:4_https://g.alicdn.com/, 1437
[1:1:0711/162619.601988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1437 0x7fc22ffe8070 0x2ef46d920460 , 5:4_https://g.alicdn.com/, 1, -5:3_https://www.taobao.com/, 1408 0x7fc22ffe8070 0x2ef4790f56e0 
[1:1:0711/162619.797592:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1425 0x7fc231f102e0 0x2ef46ac83960 , "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
[1:1:0711/162619.798885:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://g.alicdn.com/, 1e7d87665028, , , /* 2017-09-20 15:53:08 */
!function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={exports
[1:1:0711/162619.799042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid=", "g.alicdn.com", 4, 1, https://www.taobao.com, www.taobao.com, 3
[1:1:0711/162619.816526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
