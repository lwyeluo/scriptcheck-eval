[0711/161422.278855:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/161422.279136:INFO:switcher_clone.cc(787)] backtrace rip is 7fbc296ae891
[0711/161422.815690:INFO:switcher_clone.cc(818)] ### setup!!!
[0711/161422.815967:INFO:switcher_clone.cc(787)] backtrace rip is 7ff638f65891
[1:1:0711/161422.819840:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0711/161422.820021:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0711/161422.822880:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[11908:11908:0711/161423.368423:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/a888e2eb-7114-4f8c-b373-48cc2b0c7408
[11908:11908:0711/161423.637720:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[11908:11942:0711/161423.638185:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0711/161423.638319:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/161423.638471:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/161423.638785:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/161423.638908:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0711/161423.640777:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x442db91, 1
[1:1:0711/161423.643903:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xc4bf391, 0
[1:1:0711/161423.648492:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2377e3d9, 3
[1:1:0711/161423.648629:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x11328349, 2
[1:1:0711/161423.648744:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff91fffffff34b0c ffffff91ffffffdb4204 49ffffff833211 ffffffd9ffffffe37723 , 10104, 4
[1:1:0711/161423.649517:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11908:11942:0711/161423.649648:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��K��BI�2��w#��+4
[1:1:0711/161423.649646:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff63719f0a0, 3
[11908:11942:0711/161423.649722:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��K��BI�2��w#����+4
[1:1:0711/161423.649739:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff63732b080, 2
[1:1:0711/161423.649823:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff620fedd20, -2
[11908:11942:0711/161423.649913:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[11908:11942:0711/161423.649954:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 11958, 4, 91f34b0c 91db4204 49833211 d9e37723 
[1:1:0711/161423.658192:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/161423.658646:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 11328349
[1:1:0711/161423.659120:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 11328349
[1:1:0711/161423.659876:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 11328349
[1:1:0711/161423.660438:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.660538:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.660633:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.660724:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.660966:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 11328349
[1:1:0711/161423.661125:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff638f657ba
[1:1:0711/161423.661201:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff638f5cdef, 7ff638f6577a, 7ff638f670cf
[1:1:0711/161423.663091:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 11328349
[1:1:0711/161423.663407:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 11328349
[1:1:0711/161423.663712:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 11328349
[1:1:0711/161423.664555:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.664673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.664781:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[1:1:0711/161423.664885:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 11328349
[0711/161423.665376:INFO:switcher_clone.cc(818)] ### setup!!!
[1:1:0711/161423.665478:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 11328349
[0711/161423.665640:INFO:switcher_clone.cc(787)] backtrace rip is 7f1aee887891
[1:1:0711/161423.665715:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff638f657ba
[1:1:0711/161423.665794:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff638f5cdef, 7ff638f6577a, 7ff638f670cf
[1:1:0711/161423.668882:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/161423.669091:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/161423.669195:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8b5b8a58, 0x7fff8b5b89d8)
[1:1:0711/161423.680142:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/161423.683361:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[11944:11944:0711/161423.828478:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11944
[11980:11980:0711/161423.828785:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=11980
[11908:11908:0711/161423.931136:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11908:11908:0711/161423.931642:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11908:11908:0711/161423.939537:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[11908:11908:0711/161423.939585:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[11908:11908:0711/161423.939644:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,11958, 4
[11908:11923:0711/161424.024664:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[11908:11923:0711/161424.024740:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0711/161424.032844:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/161424.077783:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xf1e38934220
[1:1:0711/161424.077962:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[11908:11934:0711/161424.155601:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0711/161424.260239:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[11908:11908:0711/161424.913908:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[11908:11908:0711/161424.913992:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/161424.929457:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/161424.931060:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/161425.344746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/161425.344930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/161425.349908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0711/161425.350021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/161425.375639:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161425.491558:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161425.491715:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161425.623835:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161425.626357:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/161425.626478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/161425.638359:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161425.641333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0711/161425.641472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/161425.645214:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[11908:11908:0711/161425.645922:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/161425.647005:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf1e38932e20
[1:1:0711/161425.647115:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[11908:11908:0711/161425.648403:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[11908:11908:0711/161425.659824:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[11908:11908:0711/161425.659933:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0711/161425.679084:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161425.972861:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7ff622bc82e0 0xf1e38bb8e60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161425.973564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0711/161425.973702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/161425.974289:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11908:11908:0711/161425.998890:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/161425.999986:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xf1e38933820
[11908:11908:0711/161426.001214:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0711/161426.000844:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0711/161426.010708:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/161426.010890:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[11908:11908:0711/161426.011584:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[11908:11908:0711/161426.015666:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11908:11908:0711/161426.016092:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11908:11923:0711/161426.021139:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[11908:11923:0711/161426.021218:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[11908:11908:0711/161426.021252:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[11908:11908:0711/161426.021306:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[11908:11908:0711/161426.021397:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,11958, 4
[1:7:0711/161426.023042:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/161426.282395:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0711/161426.412537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 465 0x7ff622bc82e0 0xf1e38ba8360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161426.413202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0711/161426.413383:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0711/161426.413812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[11908:11908:0711/161426.534018:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[11908:11908:0711/161426.534128:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0711/161426.545376:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/161426.658533:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161426.848813:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161426.848985:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161426.975142:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161426.976818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0711/161426.976979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161426.979332:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.062989:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0711/161427.063365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 39614ed21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0711/161427.063492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[11908:11908:0711/161427.108720:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[11908:11942:0711/161427.109004:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0711/161427.109182:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0711/161427.109316:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0711/161427.109508:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0711/161427.109590:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0711/161427.111954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.112204:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3bb14982, 1
[1:1:0711/161427.112405:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1ab2efef, 0
[1:1:0711/161427.112575:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2485f4e6, 3
[1:1:0711/161427.112722:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3897b9ae, 2
[1:1:0711/161427.112818:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffefffffffefffffffb21a ffffff8249ffffffb13b ffffffaeffffffb9ffffff9738 ffffffe6fffffff4ffffff8524 , 10104, 5
[1:1:0711/161427.112890:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/161427.112983:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/161427.113108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161427.113564:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[11908:11942:0711/161427.113742:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���I�;���8��$f�+4
[11908:11942:0711/161427.113783:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���I�;���8��$h"f�+4
[11908:11942:0711/161427.113920:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 12015, 5, efefb21a 8249b13b aeb99738 e6f48524 
[1:1:0711/161427.114118:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff63719f0a0, 3
[1:1:0711/161427.114212:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff63732b080, 2
[1:1:0711/161427.114455:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7ff620fedd20, -2
[1:1:0711/161427.123409:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0711/161427.123594:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3897b9ae
[1:1:0711/161427.123739:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3897b9ae
[1:1:0711/161427.123978:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3897b9ae
[1:1:0711/161427.124460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.124622:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.124715:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.124805:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.125074:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3897b9ae
[1:1:0711/161427.125247:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff638f657ba
[1:1:0711/161427.125324:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff638f5cdef, 7ff638f6577a, 7ff638f670cf
[1:1:0711/161427.126999:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3897b9ae
[1:1:0711/161427.127203:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3897b9ae
[1:1:0711/161427.127607:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3897b9ae
[1:1:0711/161427.128381:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.128518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.128630:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.128707:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3897b9ae
[1:1:0711/161427.129210:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3897b9ae
[1:1:0711/161427.129358:INFO:switcher_clone.cc(775)] clone wrapper rip is 7ff638f657ba
[1:1:0711/161427.129432:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7ff638f5cdef, 7ff638f6577a, 7ff638f670cf
[1:1:0711/161427.132053:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0711/161427.132327:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0711/161427.132401:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff8b5b8a58, 0x7fff8b5b89d8)
[1:1:0711/161427.138471:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0711/161427.140425:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0711/161427.178211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.178677:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0711/161427.178777:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0711/161427.178895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161427.251317:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf1e38901220
[1:1:0711/161427.255444:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0711/161427.347539:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0711/161427.455955:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0711/161427.570480:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0711/161427.597541:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[11908:11908:0711/161427.618586:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11908:11908:0711/161427.621791:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11908:11923:0711/161427.631838:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[11908:11923:0711/161427.631916:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[11908:11908:0711/161427.632663:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.taobao.com/
[11908:11908:0711/161427.632727:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taobao.com/, https://www.taobao.com/market/peishi/shoubiao.php, 1
[11908:11908:0711/161427.632801:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://www.taobao.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html; charset=GB2312 date:Thu, 11 Jul 2019 08:14:27 GMT vary:Accept-Encoding expires:Thu, 11 Jul 2019 09:14:27 GMT cache-control:max-age=3600 strict-transport-security:max-age=31536000 content-encoding:gzip via:cache1.cn764[13,0] timing-allow-origin:* eagleid:7cc8715415628328676566303e  ,12015, 5
[1:7:0711/161427.636592:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/161427.648599:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://www.taobao.com/
[1:1:0711/161427.648707:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0711/161427.696907:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[11908:11908:0711/161427.709488:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://www.taobao.com/, https://www.taobao.com/, 1
[11908:11908:0711/161427.709573:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.taobao.com/, https://www.taobao.com
[1:1:0711/161427.715191:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/161427.724894:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0711/161427.757455:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161427.762259:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0711/161427.772222:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/161427.785355:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.785827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/161427.785995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161427.789969:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161427.790110:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161427.880126:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.880634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/161427.880769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161427.904838:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.905322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/161427.905502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161427.939411:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.939882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/161427.940063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161427.965374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161427.971866:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/161427.972035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.008374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.008843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/161428.009010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.034864:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.035343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/161428.035505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.130083:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161428.130031:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.130514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/161428.130654:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.143830:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/161428.146607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*
Copyright 2014, KISSY v1.42
MIT Licensed
build time: Feb 25 16:01
*/
var KISSY=function(a){functi
[1:1:0711/161428.146803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161428.155109:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.155543:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/161428.155723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.268249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.268715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/161428.268879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.321856:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.322290:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0711/161428.322468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.354090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0711/161428.354538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 39614ee4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0711/161428.354706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0711/161428.415138:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161428.438309:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x130c2de429c8, 0xf1e385259a8
[1:1:0711/161428.438489:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 0
[1:1:0711/161428.438704:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 213
[1:1:0711/161428.438842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 213 0x7ff620ca0070 0xf1e38df6ee0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 
[1:1:0711/161428.454474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161428.459330:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161428.470920:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161428.629093:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.217381, 460, 1
[1:1:0711/161428.629326:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161428.774358:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161428.775169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , c.port1.onmessage, (){i=g;c.port1.onmessage=
f;f()}
[1:1:0711/161428.775320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161428.775716:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x3561ab4ced30
[1:1:0711/161429.440524:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161429.440735:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161429.442858:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7ff620ca0070 0xf1e38ef88e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161429.445804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , KISSY.add("nav/tpl",function(S){return function(obj){obj||(obj={});var __t,__p="",__e=function(str){
[1:1:0711/161429.446003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161429.451977:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 284 0x7ff620ca0070 0xf1e38ef88e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161429.462514:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.021697, 83, 1
[1:1:0711/161429.462683:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161429.468658:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 213, 7ff6235e5881
[1:1:0711/161429.473787:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161429.474001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"189 0x7ff63732b080 0xf1e38953c40 1 0 0xf1e38953c58 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161429.474229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161429.474583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161429.474738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161429.569366:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/161429.617976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7ff622bc82e0 0xf1e38ef73e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161429.620666:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , !function e(t,n,r){function a(i,u){if(!n[i]){if(!t[i]){var s="function"==typeof require&&require;if(
[1:1:0711/161429.620812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[3:3:0711/161430.246075:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0711/161430.417771:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 305 0x7ff622bc82e0 0xf1e38acf7e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.420634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , !function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={exports:{},id:r,loaded:!1};return
[1:1:0711/161430.420808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161430.497195:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.514655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 308 0x7ff622bc82e0 0xf1e38d6ff60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.515224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , jsonp0({"TCART_234_67ee04042047c691725150187b3a65ac_q":-1});
[1:1:0711/161430.515380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161430.520296:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.565189:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.565587:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161430.565713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161430.600308:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161430.600456:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.604788:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00426078, 67, 1
[1:1:0711/161430.604940:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161430.636362:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 326 0x7ff622bc82e0 0xf1e39383e60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.637847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*! datalazyload - v1.0.1 - 2013-10-30 7:56:43 PM
* Copyright (c) 2013 kissy-team; Licensed  */
KISS
[1:1:0711/161430.637983:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161430.639595:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.678739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0711/161430.678921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161430.884691:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161430.884876:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.889593:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00469112, 79, 1
[1:1:0711/161430.889762:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161430.903463:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 367 0x7ff622bc82e0 0xf1e3932e360 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161430.906025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:17
*/
KISSY.add("node/base",["dom",
[1:1:0711/161430.906182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161430.975878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161431.772150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0711/161431.772321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161431.780600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0711/161431.780798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161431.852412:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161431.852583:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161431.856987:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00432706, 78, 1
[1:1:0711/161431.857117:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161432.429211:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161432.429637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161432.439855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161432.440283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161432.440438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161432.570605:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161432.570800:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161432.575415:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0045681, 78, 1
[1:1:0711/161432.575645:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161433.097011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161433.097180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161433.199870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 441 0x7ff622bc82e0 0xf1e39f87860 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161433.202197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:16
*/
KISSY.add("event",["event/dom
[1:1:0711/161433.202305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161433.212278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161433.389983:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161433.390134:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161433.394881:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00471807, 78, 1
[1:1:0711/161433.395060:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161433.496253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161433.496462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161433.552010:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161433.552423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161433.552548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161433.733589:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (e){t(e)}
[1:1:0711/161433.733771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161433.736209:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 470 0x7ff6341ffbb0 0xf1e3a104f00 0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161433.917162:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x130c2de429c8, 0xf1e38525e50
[1:1:0711/161433.917378:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 1000
[1:1:0711/161433.917658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 498
[1:1:0711/161433.917814:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 498 0x7ff620ca0070 0xf1e3a9ba0e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 470 0x7ff6341ffbb0 0xf1e3a104f00 0 
[1:1:0711/161433.983600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525e50
[1:1:0711/161433.983781:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161433.983992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 502
[1:1:0711/161433.984133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 502 0x7ff620ca0070 0xf1e3a9c5de0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 470 0x7ff6341ffbb0 0xf1e3a104f00 0 
[1:1:0711/161434.085955:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525e50
[1:1:0711/161434.086158:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161434.086436:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 514
[1:1:0711/161434.086624:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 514 0x7ff620ca0070 0xf1e3ab6d860 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 470 0x7ff6341ffbb0 0xf1e3a104f00 0 
[1:1:0711/161434.108850:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x130c2de429c8, 0xf1e38525e50
[1:1:0711/161434.109016:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 3000
[1:1:0711/161434.109266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 515
[1:1:0711/161434.109407:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 515 0x7ff620ca0070 0xf1e38dd9460 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 470 0x7ff6341ffbb0 0xf1e3a104f00 0 
[1:1:0711/161434.111382:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x130c2de429c8, 0xf1e38525e50
[1:1:0711/161434.111523:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 10
[1:1:0711/161434.111744:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 516
[1:1:0711/161434.112230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 516 0x7ff620ca0070 0xf1e3ab556e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 470 0x7ff6341ffbb0 0xf1e3a104f00 0 
[1:1:0711/161434.252587:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161434.252795:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161434.272324:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0194418, 339, 1
[1:1:0711/161434.272490:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161434.309949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161434.310120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161434.628553:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 516, 7ff6235e5881
[1:1:0711/161434.637351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161434.637506:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161434.637695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161434.637972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0711/161434.638069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161434.708916:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "open", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161434.709384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , s.onopen, (){e.status="active";var t=e.getMsgQueue();t.length>0&&e.proessMsgQueue(t);var n="connTime="+((new D
[1:1:0711/161434.709538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.164581:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161435.164734:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.166207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7ff620ca0070 0xf1e3ab972e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.167316:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , KISSY.add("sm-margin",function(a){function b(d,c){}return b},{requires:[]});KISSY.add("sm-bannerLeft
[1:1:0711/161435.167422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.176688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7ff620ca0070 0xf1e3ab972e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.180398:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 546 0x7ff620ca0070 0xf1e3ab972e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.189405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.253622:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.308265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161435.308470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.357225:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 554 0x7ff622bc82e0 0xf1e3ae56d60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.359999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 9 22:41
*/
KISSY.add("io/form-serializer
[1:1:0711/161435.360107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.378193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.692598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 502, 7ff6235e5881
[1:1:0711/161435.702051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161435.702272:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161435.702541:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.702874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161435.703042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.703487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161435.703569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161435.703729:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 604
[1:1:0711/161435.703819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 604 0x7ff620ca0070 0xf1e3ae7b5e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 502 0x7ff620ca0070 0xf1e3a9c5de0 
[1:1:0711/161435.783704:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 498, 7ff6235e5881
[1:1:0711/161435.792513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161435.792741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161435.792965:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.793350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0711/161435.793513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.881363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161435.881812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161435.881965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161435.987605:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/161436.140212:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.140376:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 50
[1:1:0711/161436.140595:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 623
[1:1:0711/161436.140705:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7ff620ca0070 0xf1e3b5874e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.369867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.370088:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.370366:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 625
[1:1:0711/161436.370549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 625 0x7ff620ca0070 0xf1e3b77a460 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.410624:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.410807:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.411057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 626
[1:1:0711/161436.411210:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 626 0x7ff620ca0070 0xf1e3b83dd60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.438340:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.438476:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.438669:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 627
[1:1:0711/161436.438778:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 627 0x7ff620ca0070 0xf1e3b89c960 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.466434:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.466604:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.466806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 628
[1:1:0711/161436.466914:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 628 0x7ff620ca0070 0xf1e3b8f3360 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.495030:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.495268:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.495541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 629
[1:1:0711/161436.495669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 629 0x7ff620ca0070 0xf1e3b951c60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.522709:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.522883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.523149:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 630
[1:1:0711/161436.523287:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 630 0x7ff620ca0070 0xf1e3b9a62e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161436.551409:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161436.551559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 100
[1:1:0711/161436.551746:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 631
[1:1:0711/161436.551881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 631 0x7ff620ca0070 0xf1e3b9f6c60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 
[1:1:0711/161437.030210:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.030656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , n.onload, (){i()}
[1:1:0711/161437.030806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.062113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161437.062321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.094877:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 607 0x7ff622bc82e0 0xf1e3b041460 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.096205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0711/161437.096385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.531898:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 623, 7ff6235e5881
[1:1:0711/161437.543139:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.543406:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.543694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.544011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){getInitialHlEl()}
[1:1:0711/161437.544091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.547192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161437.547388:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 50
[1:1:0711/161437.547666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 689
[1:1:0711/161437.547773:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 689 0x7ff620ca0070 0xf1e3aa47760 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 623 0x7ff620ca0070 0xf1e3b5874e0 
[1:1:0711/161437.559748:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 604, 7ff6235e5881
[1:1:0711/161437.571330:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"502 0x7ff620ca0070 0xf1e3a9c5de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.571565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"502 0x7ff620ca0070 0xf1e3a9c5de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.571808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.572173:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161437.572305:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.573220:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161437.573386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161437.573625:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 692
[1:1:0711/161437.573786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 692 0x7ff620ca0070 0xf1e3ac935e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 604 0x7ff620ca0070 0xf1e3ae7b5e0 
[1:1:0711/161437.584829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 631, 7ff6235e5881
[1:1:0711/161437.595164:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.595363:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"577 0x7ff63732b080 0xf1e3acb79c0 1 0 0xf1e3acb79d8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.595602:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.595929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){m.apply(c,b)}
[1:1:0711/161437.596075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.805116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161437.805353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.838772:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 515, 7ff6235e5881
[1:1:0711/161437.848625:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.848822:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161437.849024:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.849422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0711/161437.849580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.916576:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 662 0x7ff622bc82e0 0xf1e3ae89f60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.917284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="x72HFb6WgX0CAXlFE14b37jj";goldlog.stag=1;
[1:1:0711/161437.917387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.917711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.931085:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 663 0x7ff622bc82e0 0xf1e3bcd4960 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161437.933579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*! umpp 2015-08-03 */
KISSY.add("tbc/umpp/1.5.4/mods/messenger",function(a,b,c,d){function e(a,b){r
[1:1:0711/161437.933739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161437.944196:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.061417:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 180000, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161438.061574:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 180000
[1:1:0711/161438.061791:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 706
[1:1:0711/161438.061917:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 706 0x7ff620ca0070 0xf1e3bfbb460 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 663 0x7ff622bc82e0 0xf1e3bcd4960 
[1:1:0711/161438.145154:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 671 0x7ff622bc82e0 0xf1e3ae7b060 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.145825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , 
	    window.tce_79618&&tce_79618(
		{"79618":{"value":{"moduleinfo":{"data_count":[{"count":1,"cou
[1:1:0711/161438.145973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161438.146821:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.173300:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 672 0x7ff622bc82e0 0xf1e3bcf5960 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.176860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , define("tbc/search-suggest/1.5.0/index",["combobox","base","json","cookie","event","node","dom"],fun
[1:1:0711/161438.177014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161438.178833:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.203472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 674 0x7ff622bc82e0 0xf1e3bb19be0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.205138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*! market 2015-08-24 */
KISSY.add("tbc/market/1.3.24/json",function(S){var JSONA={};return function
[1:1:0711/161438.205324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161438.208606:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.222317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 675 0x7ff622bc82e0 0xf1e3bc2c060 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.223452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:19
*/
KISSY.add("xtemplate",["xtemp
[1:1:0711/161438.223600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161438.232703:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.332984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.333547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , j, (){var a=o.readyState;if(!a||"loaded"===a||"complete"===a)o.onreadystatechange=o.onload=null,v(0)}
[1:1:0711/161438.333731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161438.620298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7ff622bc82e0 0xf1e3bcda3e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161438.624713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0711/161438.624874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161438.878618:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/161438.879433:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0711/161438.887444:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:17:0711/161439.027286:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0711/161439.223688:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525990
[1:1:0711/161439.223869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161439.224065:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 735
[1:1:0711/161439.224203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 735 0x7ff620ca0070 0xf1e3a6238e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 679 0x7ff622bc82e0 0xf1e3bcda3e0 
[1:1:0711/161439.453637:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161439.454123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161439.454268:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161439.526019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 689, 7ff6235e5881
[1:1:0711/161439.537580:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"623 0x7ff620ca0070 0xf1e3b5874e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161439.537789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"623 0x7ff620ca0070 0xf1e3b5874e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161439.537996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161439.538333:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){getInitialHlEl()}
[1:1:0711/161439.538437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161439.562558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161439.562731:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161439.712933:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 692, 7ff6235e5881
[1:1:0711/161439.724258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"604 0x7ff620ca0070 0xf1e3ae7b5e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161439.724468:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"604 0x7ff620ca0070 0xf1e3ae7b5e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161439.724692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161439.725010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161439.725133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161439.726195:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161439.726317:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161439.726559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 750
[1:1:0711/161439.726680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 750 0x7ff620ca0070 0xf1e3bca30e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 692 0x7ff620ca0070 0xf1e3ac935e0 
[1:1:0711/161439.957057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (n){G=n}
[1:1:0711/161439.957283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161440.139058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (n){a.setLocalDescription(n,function(){},function(){})}
[1:1:0711/161440.139245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161440.154710:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 514, 7ff6235e5881
[1:1:0711/161440.166489:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161440.166719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"470 0x7ff6341ffbb0 0xf1e3a104f00 0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161440.167061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161440.167440:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/161440.167570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161440.271742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161440.272032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161440.348291:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 756 0x7ff622bc82e0 0xf1e3c696b60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161440.349749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*! market 2015-06-09 */
KISSY.add("tms/api",function(a,b){"use strict";var c={},d={add:function(a,d
[1:1:0711/161440.349898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161440.351370:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161440.407921:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 757 0x7ff622bc82e0 0xf1e3bec4360 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161440.409804:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*
Copyright 2013, KISSY v1.42
MIT Licensed
build time: Dec 4 22:04
*/
KISSY.add("combobox/combobox-
[1:1:0711/161440.409939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161440.458097:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161441.074904:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 762 0x7ff622bc82e0 0xf1e3c714560 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161441.078485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*!build time : 2014-03-27 6:09:53 PM*/
KISSY.add("gallery/slide/1.3/slide-util",function(a){"use st
[1:1:0711/161441.078660:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161441.085181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:19:0711/161441.125675:WARNING:paced_sender.cc(261)] Elapsed time (2002 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161441.202306:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 763 0x7ff622bc82e0 0xf1e3c6e0860 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161441.215540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , !function(){function e(e,a){for(var r=3;void 0!==r;){var s=-1&r,c=r>>-(1/0),b=-1&c;switch(s){case 0:
[1:1:0711/161441.215738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:19:0711/161441.625898:WARNING:paced_sender.cc(261)] Elapsed time (2503 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161442.127199:WARNING:paced_sender.cc(261)] Elapsed time (3004 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161442.627735:WARNING:paced_sender.cc(261)] Elapsed time (3504 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161442.828845:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525990
[1:1:0711/161442.829002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161442.829314:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 812
[1:1:0711/161442.829501:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 812 0x7ff620ca0070 0xf1e3dbb44e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 763 0x7ff622bc82e0 0xf1e3c6e0860 
[1:19:0711/161443.128144:WARNING:paced_sender.cc(261)] Elapsed time (4005 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161443.628518:WARNING:paced_sender.cc(261)] Elapsed time (4505 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161444.128721:WARNING:paced_sender.cc(261)] Elapsed time (5005 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161444.628967:WARNING:paced_sender.cc(261)] Elapsed time (5506 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161444.850197:WARNING:paced_sender.cc(261)] Elapsed time (2004 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161445.129416:WARNING:paced_sender.cc(261)] Elapsed time (6006 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161445.350211:WARNING:paced_sender.cc(261)] Elapsed time (2504 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161445.629833:WARNING:paced_sender.cc(261)] Elapsed time (6506 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161445.850355:WARNING:paced_sender.cc(261)] Elapsed time (3004 ms) longer than expected, limiting to 2000 ms
		remove user.e_22bc4baf -> 0
		remove user.f_9d13e6fd -> 0
		remove user.10_30504a43 -> 0
		remove user.11_f1b5b8ba -> 0
		remove user.12_f61b1cec -> 0
		remove user.13_e0aad627 -> 0
		remove user.14_d92d96b7 -> 0
[1:19:0711/161446.130219:WARNING:paced_sender.cc(261)] Elapsed time (7007 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161446.350539:WARNING:paced_sender.cc(261)] Elapsed time (3504 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161446.630015:WARNING:paced_sender.cc(261)] Elapsed time (7507 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161446.850557:WARNING:paced_sender.cc(261)] Elapsed time (4004 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161447.130369:WARNING:paced_sender.cc(261)] Elapsed time (8007 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161447.350643:WARNING:paced_sender.cc(261)] Elapsed time (4504 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161447.630735:WARNING:paced_sender.cc(261)] Elapsed time (8507 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161447.850729:WARNING:paced_sender.cc(261)] Elapsed time (5004 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161448.130969:WARNING:paced_sender.cc(261)] Elapsed time (9008 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161448.350922:WARNING:paced_sender.cc(261)] Elapsed time (5505 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161448.632129:WARNING:paced_sender.cc(261)] Elapsed time (9509 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161448.852094:WARNING:paced_sender.cc(261)] Elapsed time (6006 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161449.133150:WARNING:paced_sender.cc(261)] Elapsed time (10010 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161449.352351:WARNING:paced_sender.cc(261)] Elapsed time (6506 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161449.633464:WARNING:paced_sender.cc(261)] Elapsed time (10510 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161449.852491:WARNING:paced_sender.cc(261)] Elapsed time (7006 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161450.133609:WARNING:paced_sender.cc(261)] Elapsed time (11010 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161450.352635:WARNING:paced_sender.cc(261)] Elapsed time (7506 ms) longer than expected, limiting to 2000 ms
[1:19:0711/161450.633943:WARNING:paced_sender.cc(261)] Elapsed time (11511 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161450.852743:WARNING:paced_sender.cc(261)] Elapsed time (8006 ms) longer than expected, limiting to 2000 ms
[11908:11908:0711/161450.977632:INFO:CONSOLE(3)] "", source: https://g.alicdn.com/secdev/nsv/1.0.63/ns_c_74_3_f.js (3)
[1:19:0711/161451.134621:WARNING:paced_sender.cc(261)] Elapsed time (12011 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161451.187730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){}
[1:17:0711/161451.188000:WARNING:stunport.cc(403)] Port[0xf1e3a348220:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:1:0711/161451.188146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:17:0711/161451.264005:WARNING:p2ptransportchannel.cc(714)] Port[0xf1e3d6a74a0:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:17:0711/161451.264469:WARNING:p2ptransportchannel.cc(714)] Port[0xf1e3c7fcda0:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:1:0711/161451.269090:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 750, 7ff6235e5881
[1:1:0711/161451.282241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"692 0x7ff620ca0070 0xf1e3ac935e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161451.282460:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"692 0x7ff620ca0070 0xf1e3ac935e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161451.282750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161451.283083:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161451.283252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161451.284073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161451.284153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161451.284363:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 840
[1:1:0711/161451.284525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 840 0x7ff620ca0070 0xf1e409350e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 750 0x7ff620ca0070 0xf1e3bca30e0 
[1:1:0711/161451.298814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161451.298992:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:21:0711/161451.352904:WARNING:paced_sender.cc(261)] Elapsed time (8507 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161451.454489:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161451.454923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161451.455032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:19:0711/161451.634905:WARNING:paced_sender.cc(261)] Elapsed time (12512 ms) longer than expected, limiting to 2000 ms
[1:21:0711/161451.853976:WARNING:paced_sender.cc(261)] Elapsed time (9008 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161452.122772:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.124315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , j.handle, (a){var b=a.type,c=d.currentTarget;if(!(k.triggeredEvent===b||typeof KISSY==="undefined"))if(b=k.get
[1:1:0711/161452.124482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:19:0711/161452.135772:WARNING:paced_sender.cc(261)] Elapsed time (13012 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161452.146904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseover", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.160282:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.160960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mousemove", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.263889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseout", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.302830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161452.303029:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 50
[1:1:0711/161452.303293:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 864
[1:1:0711/161452.303463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 864 0x7ff620ca0070 0xf1e410a7460 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 856 0x7ff6341cafa0 0xf1e402fd1e0 
[1:1:0711/161452.303894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "mouseout", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:21:0711/161452.354758:WARNING:paced_sender.cc(261)] Elapsed time (9508 ms) longer than expected, limiting to 2000 ms
[1:1:0711/161452.478018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , S, (e){var a="se";a&&(a+="tLo"),a+="calDes",a+="cript",a+="io",a+="n",$a[a](e)}
[1:1:0711/161452.478194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161452.587558:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 735, 7ff6235e5881
[1:1:0711/161452.600714:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"679 0x7ff622bc82e0 0xf1e3bcda3e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161452.600885:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"679 0x7ff622bc82e0 0xf1e3bcda3e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161452.601104:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.601429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (n){try{a.close()}catch(t){}}
[1:1:0711/161452.601561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161452.640820:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 812, 7ff6235e5881
[1:1:0711/161452.656532:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"763 0x7ff622bc82e0 0xf1e3c6e0860 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161452.656757:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"763 0x7ff622bc82e0 0xf1e3c6e0860 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161452.657015:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.657438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , Y, (e){try{for(var a="\u0441\u044a\u044d\u0451\u0443",r="",s=0;s<a.length;s++){var c=a.charCodeAt(s)-99
[1:1:0711/161452.657543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161452.737023:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.737572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , D, (n){cn=n.gamma,en||(en=s(function(n){removeEventListener("deviceorientation",D),s(A,470)},30))}
[1:1:0711/161452.737741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161452.738300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x130c2de429c8, 0xf1e38525a38
[1:1:0711/161452.738471:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 30
[1:1:0711/161452.738699:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 889
[1:1:0711/161452.738808:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 889 0x7ff620ca0070 0xf1e40231260 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 832 0x7ff6392003d0 0xf1e407865e0 
[1:1:0711/161452.738972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.902676:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161452.902886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161452.996047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 848 0x7ff622bc82e0 0xf1e40ad4560 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161452.997958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /*! market 2015-08-24 */
KISSY.add("tbc/market/1.3.24/getHelper",function(a,b,c){"use strict";functi
[1:1:0711/161452.998100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161452.999917:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161454.196442:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 840, 7ff6235e5881
[1:1:0711/161454.211292:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"750 0x7ff620ca0070 0xf1e3bca30e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161454.211499:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"750 0x7ff620ca0070 0xf1e3bca30e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161454.211793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161454.212174:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161454.212326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161454.213339:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161454.213470:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161454.213646:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 906
[1:1:0711/161454.213750:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 906 0x7ff620ca0070 0xf1e41de5be0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 840 0x7ff620ca0070 0xf1e409350e0 
[1:1:0711/161454.318938:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 864, 7ff6235e5881
[1:1:0711/161454.333840:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"856 0x7ff6341cafa0 0xf1e402fd1e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161454.334003:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"856 0x7ff6341cafa0 0xf1e402fd1e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161454.334204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161454.334517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){theNav.navEl.one(".sm-cat-list").removeClass("hover");theNav.navEl.one(".list-index").removeClass
[1:1:0711/161454.334615:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161454.794759:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 889, 7ff6235e5881
[1:1:0711/161454.809728:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"832 0x7ff6392003d0 0xf1e407865e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161454.809943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"832 0x7ff6392003d0 0xf1e407865e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161454.810189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161454.811132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/161454.811231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161454.812740:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161454.812857:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 470
[1:1:0711/161454.813013:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 919
[1:1:0711/161454.813155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7ff620ca0070 0xf1e41d50560 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 889 0x7ff620ca0070 0xf1e40231260 
[1:1:0711/161454.829341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161454.829519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161454.847312:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161454.847717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161454.847824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
		remove user.15_a1ca9569 -> 0
		remove user.16_e063281d -> 0
[1:1:0711/161456.368452:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161456.368668:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 3000
[1:1:0711/161456.368908:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 922
[1:1:0711/161456.369025:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 922 0x7ff620ca0070 0xf1e430a94e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 895 0x7ff63732b080 0xf1e3dafd600 1 0 0xf1e3dafd618 
[1:1:0711/161456.391304:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161456.391507:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 3000
[1:1:0711/161456.391750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 923
[1:1:0711/161456.391886:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7ff620ca0070 0xf1e43140160 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 895 0x7ff63732b080 0xf1e3dafd600 1 0 0xf1e3dafd618 
[1:1:0711/161456.748023:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 906, 7ff6235e5881
[1:1:0711/161456.763420:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"840 0x7ff620ca0070 0xf1e409350e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161456.763647:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"840 0x7ff620ca0070 0xf1e409350e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161456.763899:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161456.764234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161456.764374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161456.765387:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161456.765486:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161456.765666:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 936
[1:1:0711/161456.765767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 936 0x7ff620ca0070 0xf1e4318dd60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 906 0x7ff620ca0070 0xf1e41de5be0 
[1:1:0711/161456.782058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161456.782246:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161456.830038:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 919, 7ff6235e5881
[1:1:0711/161456.845041:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"889 0x7ff620ca0070 0xf1e40231260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161456.845275:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"889 0x7ff620ca0070 0xf1e40231260 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161456.845533:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161456.845928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/161456.846055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161457.007113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161457.007284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161457.067762:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7ff622bc82e0 0xf1e43214a60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161457.068452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , KISSY.add("sd/data_sufei/sufei",function(u){"use strict";function e(u,e){return function(){return e.
[1:1:0711/161457.068559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161457.069958:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161457.177581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161457.177767:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161457.242366:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161457.242790:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161457.242917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161459.859068:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161459.859293:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 0
[1:1:0711/161459.859629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 966
[1:1:0711/161459.859816:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7ff620ca0070 0xf1e442a3160 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 950 0x7ff63732b080 0xf1e3f18c2e0 1 0 0xf1e3f18c2f8 
[1:1:0711/161459.884276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161459.884491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 0
[1:1:0711/161459.884741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 968
[1:1:0711/161459.884908:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 968 0x7ff620ca0070 0xf1e442be260 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 950 0x7ff63732b080 0xf1e3f18c2e0 1 0 0xf1e3f18c2f8 
[1:1:0711/161502.002451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161502.002666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161502.301306:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 936, 7ff6235e5881
[1:1:0711/161502.316297:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"906 0x7ff620ca0070 0xf1e41de5be0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161502.316527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"906 0x7ff620ca0070 0xf1e41de5be0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161502.316777:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161502.317535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161502.317666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161502.319120:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161502.319256:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161502.319494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1001
[1:1:0711/161502.319650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7ff620ca0070 0xf1e3d9be660 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 936 0x7ff620ca0070 0xf1e4318dd60 
[1:1:0711/161502.320216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 922, 7ff6235e5881
[1:1:0711/161502.334886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"895 0x7ff63732b080 0xf1e3dafd600 1 0 0xf1e3dafd618 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161502.335076:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"895 0x7ff63732b080 0xf1e3dafd600 1 0 0xf1e3dafd618 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161502.335308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161502.335613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){n=!0,e.log(j,"\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u02b1\ufffd\ufffd\ufffd\ufffd\ufffd\xf1\ufffd\
[1:1:0711/161502.335734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161502.394998:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161502.395203:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161502.395444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1007
[1:1:0711/161502.395592:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1007 0x7ff620ca0070 0xf1e450c4f60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 922 0x7ff620ca0070 0xf1e430a94e0 
[1:1:0711/161502.903944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 923, 7ff6235e5881
[1:1:0711/161502.922083:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"895 0x7ff63732b080 0xf1e3dafd600 1 0 0xf1e3dafd618 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161502.922298:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"895 0x7ff63732b080 0xf1e3dafd600 1 0 0xf1e3dafd618 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161502.922540:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161502.922871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){n=!0,e.log(j,"\ufffd\ufffd\ufffd\ufffd\ufffd\ufffd\u02b1\ufffd\ufffd\ufffd\ufffd\ufffd\xf1\ufffd\
[1:1:0711/161502.922990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161503.062864:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161503.063072:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161503.063323:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1045
[1:1:0711/161503.063474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7ff620ca0070 0xf1e456c32e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 923 0x7ff620ca0070 0xf1e43140160 
[1:1:0711/161503.539117:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161503.539295:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161503.540695:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 966, 7ff6235e5881
[1:1:0711/161503.558843:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"950 0x7ff63732b080 0xf1e3f18c2e0 1 0 0xf1e3f18c2f8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161503.559048:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"950 0x7ff63732b080 0xf1e3f18c2e0 1 0 0xf1e3f18c2f8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161503.559305:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161503.559671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , ve, (e){B=0;var r=d(8,0),s="l",c=s.split("").reverse().join(""),b="/",k=b.split("").reverse().join("");a
[1:1:0711/161503.559821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161505.034630:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 968, 7ff6235e5881
[1:1:0711/161505.051393:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"950 0x7ff63732b080 0xf1e3f18c2e0 1 0 0xf1e3f18c2f8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161505.051631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"950 0x7ff63732b080 0xf1e3f18c2e0 1 0 0xf1e3f18c2f8 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161505.051905:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161505.052243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , e, (){D=null;var n=M.ra(!1,null);z.s(n),p.k(g,n)}
[1:1:0711/161505.052379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161505.216972:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161505.218827:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0711/161505.218979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161505.285752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161505.286192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x130c2de429c8, 0xf1e385259f0
[1:1:0711/161505.286288:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 30
[1:1:0711/161505.286494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1078
[1:1:0711/161505.286603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1078 0x7ff620ca0070 0xf1e46571c60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 992 0x7ff6392003d0 0xf1e431fd2e0 
[1:1:0711/161505.970631:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1001, 7ff6235e5881
[1:1:0711/161505.989443:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"936 0x7ff620ca0070 0xf1e4318dd60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161505.989626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"936 0x7ff620ca0070 0xf1e4318dd60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161505.989851:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161505.990168:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161505.990274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161505.991332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161505.991432:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161505.991632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1099
[1:1:0711/161505.991730:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1099 0x7ff620ca0070 0xf1e3df356e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1001 0x7ff620ca0070 0xf1e3d9be660 
[1:1:0711/161506.690744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161506.690987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161507.092193:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1078, 7ff6235e5881
[1:1:0711/161507.110415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"992 0x7ff6392003d0 0xf1e431fd2e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161507.110626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"992 0x7ff6392003d0 0xf1e431fd2e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161507.110874:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161507.111228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/161507.111372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161507.111829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161507.111949:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 470
[1:1:0711/161507.112178:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1146
[1:1:0711/161507.112313:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1146 0x7ff620ca0070 0xf1e4654d8e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1078 0x7ff620ca0070 0xf1e46571c60 
[1:1:0711/161507.151045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1087 0x7ff622bc82e0 0xf1e465bea60 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161507.152151:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161507.152559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , window.onerror, (){try{a&&a.apply(window,arguments);var e=r.apply(window,arguments);window.JSTracker2.push(e)}catch(
[1:1:0711/161507.152701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161507.157723:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[11908:11908:0711/161507.158661:INFO:CONSOLE(6)] "Uncaught SyntaxError: Unexpected token <", source: https://login.taobao.com/member/login.jhtml?redirectURL=http%3A%2F%2Fs.taobao.com%2Fsearch%3Fcallback%3Djsonp751%26app%3Dstditemapi%26m%3Dstditem%26_input_charset%3Dutf-8%26page_size%3D24%26rand_size%3D100%26oeid%3D5287000%26originurl%3D%26count%3D24 (6)
[1:1:0711/161507.160526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161507.160665:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 0
[1:1:0711/161507.160875:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1147
[1:1:0711/161507.160980:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1147 0x7ff620ca0070 0xf1e46781ce0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1087 0x7ff622bc82e0 0xf1e465bea60 
[1:1:0711/161507.196939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161507.197151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161507.197546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1153
[1:1:0711/161507.197696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1153 0x7ff620ca0070 0xf1e46779ee0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1087 0x7ff622bc82e0 0xf1e465bea60 
[1:1:0711/161507.248634:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1088 0x7ff622bc82e0 0xf1e465e23e0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161507.249261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161507.249627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , window.onerror, (){try{a&&a.apply(window,arguments);var e=r.apply(window,arguments);window.JSTracker2.push(e)}catch(
[1:1:0711/161507.249801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161507.253523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[11908:11908:0711/161507.255081:INFO:CONSOLE(6)] "Uncaught SyntaxError: Unexpected token <", source: https://login.taobao.com/member/login.jhtml?redirectURL=http%3A%2F%2Fs.taobao.com%2Fsearch%3Fcallback%3Djsonp752%26app%3Dstditemapi%26m%3Dstditem%26_input_charset%3Dutf-8%26page_size%3D24%26rand_size%3D100%26oeid%3D5288000%26originurl%3D%26count%3D24 (6)
[1:1:0711/161507.256143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161507.256292:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 0
[1:1:0711/161507.256501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1160
[1:1:0711/161507.256636:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1160 0x7ff620ca0070 0xf1e431a0f60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1088 0x7ff622bc82e0 0xf1e465e23e0 
[1:1:0711/161507.290817:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x130c2de429c8, 0xf1e38525a10
[1:1:0711/161507.291043:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 5000
[1:1:0711/161507.291299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1166
[1:1:0711/161507.291405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1166 0x7ff620ca0070 0xf1e4630ee60 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1088 0x7ff622bc82e0 0xf1e465e23e0 
[1:1:0711/161508.004981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.005517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , n.onload, (){i()}
[1:1:0711/161508.005960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.006715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1099, 7ff6235e5881
[1:1:0711/161508.024554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1001 0x7ff620ca0070 0xf1e3d9be660 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.024804:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1001 0x7ff620ca0070 0xf1e3d9be660 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.025051:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.025441:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161508.025618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.026046:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161508.026208:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 500
[1:1:0711/161508.026432:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1184
[1:1:0711/161508.026525:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1184 0x7ff620ca0070 0xf1e45ae4160 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1099 0x7ff620ca0070 0xf1e3df356e0 
[1:1:0711/161508.044501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161508.044670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.454673:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.455119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , n.onload, (){i()}
[1:1:0711/161508.455259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.668235:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.668646:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , f, (){for(var a=0,b;b=h[a++];)try{b()}catch(d){d.stack||d,"error",setTimeout(function(){throw d;},0)}1<
[1:1:0711/161508.668750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.707826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1147, 7ff6235e5881
[1:1:0711/161508.725285:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1087 0x7ff622bc82e0 0xf1e465bea60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.725460:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1087 0x7ff622bc82e0 0xf1e465bea60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.725688:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.726019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){throw e;}
[1:1:0711/161508.726148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.726702:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/shoubiao.php"
[11908:11908:0711/161508.730978:INFO:CONSOLE(40)] "Uncaught TypeError: Cannot read property '0' of undefined", source: https://g.alicdn.com/kissy/k/1.4.2/??io-min.js,cookie-min.js (40)
[1:1:0711/161508.861546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1160, 7ff6235e5881
[1:1:0711/161508.879023:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1088 0x7ff622bc82e0 0xf1e465e23e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.879252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1088 0x7ff622bc82e0 0xf1e465e23e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.879501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.879822:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){throw e;}
[1:1:0711/161508.879952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161508.880327:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.taobao.com/market/peishi/shoubiao.php"
[11908:11908:0711/161508.884465:INFO:CONSOLE(40)] "Uncaught TypeError: Cannot read property '0' of undefined", source: https://g.alicdn.com/kissy/k/1.4.2/??io-min.js,cookie-min.js (40)
[1:1:0711/161508.942588:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1007, 7ff6235e5881
[1:1:0711/161508.960771:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"922 0x7ff620ca0070 0xf1e430a94e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.960951:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"922 0x7ff620ca0070 0xf1e430a94e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161508.961179:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161508.961523:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/161508.961638:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.127178:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1146, 7ff6235e5881
[1:1:0711/161509.144760:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1078 0x7ff620ca0070 0xf1e46571c60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161509.144946:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1078 0x7ff620ca0070 0xf1e46571c60 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161509.145182:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.145525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/161509.145635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.166479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161509.166656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.188055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1045, 7ff6235e5881
[1:1:0711/161509.206980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"923 0x7ff620ca0070 0xf1e43140160 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161509.207176:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"923 0x7ff620ca0070 0xf1e43140160 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161509.207398:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.207695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0711/161509.207800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.211064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1184, 7ff6235e5881
[1:1:0711/161509.231197:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1099 0x7ff620ca0070 0xf1e3df356e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161509.231400:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1099 0x7ff620ca0070 0xf1e3df356e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161509.231654:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.231986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0711/161509.232109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.232505:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161509.232619:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 3000
[1:1:0711/161509.232837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1199
[1:1:0711/161509.232930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1199 0x7ff620ca0070 0xf1e468196e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1184 0x7ff620ca0070 0xf1e45ae4160 
[1:1:0711/161509.344655:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.345115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , n.onload, (){i()}
[1:1:0711/161509.345210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.399297:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.399711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , n.onload, (){i()}
[1:1:0711/161509.399892:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.401008:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.401468:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.401800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.462015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , document.readyState
[1:1:0711/161509.462205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.803230:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1220 0x7ff622bc82e0 0xf1e46873de0 , "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.804070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , /* 2018-10-09 14:12:23 */
!function(e,n){function i(e){var i=n.createElement("iframe");return i.styl
[1:1:0711/161509.804197:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[11908:11908:0711/161509.810045:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0711/161509.811159:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xf1e4568be20
[1:1:0711/161509.811307:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[11908:11908:0711/161509.812248:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0711/161509.818237:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0711/161509.818432:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.taobao.com
[11908:11908:0711/161509.819105:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://www.taobao.com/
[11908:11908:0711/161509.840110:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[11908:11908:0711/161509.840716:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[11908:11923:0711/161509.850681:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[11908:11908:0711/161509.850769:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://g.alicdn.com/
[11908:11923:0711/161509.850767:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[11908:11908:0711/161509.850816:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://g.alicdn.com/, https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid=, 4
[11908:11908:0711/161509.850881:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://g.alicdn.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html content-length:5224 date:Tue, 09 Jul 2019 11:04:16 GMT vary:Accept-Encoding x-oss-request-id:5D2474B0B13C7D2C22800191 x-oss-object-type:Normal x-oss-hash-crc64ecma:5664768117394609694 x-oss-storage-class:Standard content-md5:3tLMJLZn4GHBah7HDU9pog== x-oss-server-time:2 cache-control:max-age=2592000,s-maxage=3600 access-control-allow-origin:* x-source-scheme:https content-encoding:gzip ali-swift-global-savetime:1562670256 via:cache3.l2cn241[66,200-0,M], cache8.l2cn241[68,0], cache4.cn310[0,200-0,H], cache7.cn310[1,0] age:740 x-cache:HIT TCP_MEM_HIT dirn:-2:-2 x-swift-savetime:Tue, 09 Jul 2019 11:04:16 GMT x-swift-cachetime:3600 timing-allow-origin:* eagleid:7cc1ebcf15626709962575610e  ,12015, 5
[1:7:0711/161509.861407:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0711/161509.924712:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.926422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , d, (e,c,b,k,C){var j,S,E,z,L,W,U,J,Q,X,q,F,G,H,$,K,V,Z,Y,ee,ae,re,se,ce,be,ke,oe,te,ie,ne,he,ve,de,ue,p
[1:1:0711/161509.926566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161509.988708:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161509.989144:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x130c2de429c8, 0xf1e385259f0
[1:1:0711/161509.989261:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 30
[1:1:0711/161509.989500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1252
[1:1:0711/161509.989628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1252 0x7ff620ca0070 0xf1e469c2de0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1226 0x7ff6392003d0 0xf1e455e13e0 
[1:1:0711/161510.319584:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://g.alicdn.com/
[1:1:0711/161510.444528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1252, 7ff6235e5881
[1:1:0711/161510.460662:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1226 0x7ff6392003d0 0xf1e455e13e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161510.460836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1226 0x7ff6392003d0 0xf1e455e13e0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161510.461025:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161510.461360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0711/161510.461480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161510.461845:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x130c2de429c8, 0xf1e38525950
[1:1:0711/161510.461939:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.taobao.com/market/peishi/shoubiao.php", 470
[1:1:0711/161510.462132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1266
[1:1:0711/161510.462211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1266 0x7ff620ca0070 0xf1e4695c9e0 , 5:3_https://www.taobao.com/, 1, -5:3_https://www.taobao.com/, 1252 0x7ff620ca0070 0xf1e469c2de0 
[11908:11908:0711/161510.550568:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://g.alicdn.com/, https://g.alicdn.com/, 4
[11908:11908:0711/161510.550639:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://g.alicdn.com/, https://g.alicdn.com
[1:1:0711/161510.550833:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0711/161510.736276:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0711/161510.985185:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0711/161510.985346:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
[1:1:0711/161510.987110:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1289 0x7ff620ca0070 0xf1e38f3fb60 , "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
[1:1:0711/161511.000769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://g.alicdn.com/, 33f82204c330, , , !function e(t,n,o){function i(r,s){if(!n[r]){if(!t[r]){var c="function"==typeof require&&require;if(
[1:1:0711/161511.000942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid=", "g.alicdn.com", 4, 1, https://www.taobao.com, www.taobao.com, 3
[1:1:0711/161511.114664:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://www.taobao.com/, 1266, 7ff6235e5881
[1:1:0711/161511.132585:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"33f821fa2860","ptid":"1252 0x7ff620ca0070 0xf1e469c2de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161511.132777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://www.taobao.com/","ptid":"1252 0x7ff620ca0070 0xf1e469c2de0 ","rf":"5:3_https://www.taobao.com/"}
[1:1:0711/161511.132982:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.taobao.com/market/peishi/shoubiao.php"
[1:1:0711/161511.133297:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://www.taobao.com/, 33f821fa2860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0711/161511.133424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.taobao.com/market/peishi/shoubiao.php", "www.taobao.com", 3, 1, , , 0
[1:1:0711/161511.906657:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1336 0x7ff622bc82e0 0xf1e46876a60 , "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
[1:1:0711/161511.908124:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://g.alicdn.com/, 33f82204c330, , , /* 2017-09-20 15:53:08 */
!function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={exports
[1:1:0711/161511.908284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid=", "g.alicdn.com", 4, 1, https://www.taobao.com, www.taobao.com, 3
[1:1:0711/161511.931884:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://g.alicdn.com/alilog/oneplus/blk.html#coid=x72HFb6WgX0CAXlFE14b37jj&noid="
