[0712/142836.925024:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/142836.925307:INFO:switcher_clone.cc(787)] backtrace rip is 7f2ba5335891
[0712/142837.461882:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/142837.462129:INFO:switcher_clone.cc(787)] backtrace rip is 7fef4ca4c891
[1:1:0712/142837.465944:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/142837.466105:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/142837.468823:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[4239:4239:0712/142838.226240:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/b4d94a4d-1dc0-407e-99f7-3bfd926e33c4
[0712/142838.316465:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/142838.316731:INFO:switcher_clone.cc(787)] backtrace rip is 7fb1fb97e891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[4270:4270:0712/142838.469784:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4270
[4283:4283:0712/142838.470381:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=4283
[4239:4239:0712/142838.483236:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[4239:4268:0712/142838.483660:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/142838.483783:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/142838.483937:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/142838.484286:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/142838.484397:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/142838.486317:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xf01a89e, 1
[1:1:0712/142838.486497:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8d35d93, 0
[1:1:0712/142838.487453:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b25612f, 3
[1:1:0712/142838.487535:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3388512b, 2
[1:1:0712/142838.487607:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff935dffffffd308 ffffff9effffffa8010f 2b51ffffff8833 2f61253b , 10104, 4
[1:1:0712/142838.488318:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4239:4268:0712/142838.488435:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�]���+Q�3/a%;v!�1
[4239:4268:0712/142838.488474:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �]���+Q�3/a%;8v!�1
[4239:4268:0712/142838.488617:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[4239:4268:0712/142838.488648:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4291, 4, 935dd308 9ea8010f 2b518833 2f61253b 
[1:1:0712/142838.488529:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef4ac860a0, 3
[1:1:0712/142838.488920:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef4ae12080, 2
[1:1:0712/142838.489061:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef34ad4d20, -2
[1:1:0712/142838.497279:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/142838.497717:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3388512b
[1:1:0712/142838.498168:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3388512b
[1:1:0712/142838.498909:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3388512b
[1:1:0712/142838.499481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.499582:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.499679:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.499767:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.499999:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3388512b
[1:1:0712/142838.500124:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef4ca4c7ba
[1:1:0712/142838.500178:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef4ca43def, 7fef4ca4c77a, 7fef4ca4e0cf
[1:1:0712/142838.501844:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3388512b
[1:1:0712/142838.501990:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3388512b
[1:1:0712/142838.502264:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3388512b
[1:1:0712/142838.503014:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.503095:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.503171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.503245:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3388512b
[1:1:0712/142838.503713:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3388512b
[1:1:0712/142838.503851:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef4ca4c7ba
[1:1:0712/142838.503902:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef4ca43def, 7fef4ca4c77a, 7fef4ca4e0cf
[1:1:0712/142838.506404:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/142838.506602:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/142838.506688:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc38ce2d48, 0x7ffc38ce2cc8)
[1:1:0712/142838.513821:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/142838.516490:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[4239:4239:0712/142838.945255:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4239:4239:0712/142838.945743:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4239:4250:0712/142838.953980:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[4239:4250:0712/142838.954044:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[4239:4239:0712/142838.954084:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[4239:4239:0712/142838.954137:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[4239:4239:0712/142838.954208:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,4291, 4
[1:7:0712/142838.955021:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/142838.955748:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1298db989220
[1:1:0712/142838.956724:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[4239:4263:0712/142839.023980:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/142839.204668:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[4239:4239:0712/142839.837604:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[4239:4239:0712/142839.837691:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/142839.848375:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/142839.849993:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/142840.273026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20e505141f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/142840.273267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/142840.279215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20e505141f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/142840.279347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/142840.307314:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/142840.410767:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/142840.410927:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/142840.529469:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/142840.531925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20e505141f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/142840.532061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/142840.543886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 362, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/142840.546841:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20e505141f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/142840.546972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/142840.550692:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[4239:4239:0712/142840.551346:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/142840.552444:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1298db987e20
[1:1:0712/142840.552546:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[4239:4239:0712/142840.553900:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[4239:4239:0712/142840.565192:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[4239:4239:0712/142840.565272:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/142840.584752:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/142840.877676:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 421 0x7fef366af2e0 0x1298dbc611e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/142840.878338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20e505141f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/142840.878473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/142840.879011:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4239:4239:0712/142840.903871:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/142840.904990:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1298db988820
[1:1:0712/142840.905159:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[4239:4239:0712/142840.906448:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/142840.912170:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/142840.912364:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[4239:4239:0712/142840.913403:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[4239:4239:0712/142840.917303:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4239:4239:0712/142840.917690:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4239:4250:0712/142840.921925:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[4239:4250:0712/142840.921975:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[4239:4239:0712/142840.921995:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[4239:4239:0712/142840.922031:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[4239:4239:0712/142840.922089:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,4291, 4
[1:7:0712/142840.923441:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/142841.186293:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/142841.305985:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fef366af2e0 0x1298dbb7dce0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/142841.306534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 20e505141f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/142841.306694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/142841.307135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[4239:4239:0712/142841.454622:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[4239:4239:0712/142841.454700:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/142841.468221:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/142841.581541:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/142841.781265:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/142841.781453:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4239:4239:0712/142841.808256:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[4239:4268:0712/142841.808513:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/142841.808641:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/142841.808812:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/142841.808997:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/142841.809085:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/142841.811362:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa1cbe7, 1
[1:1:0712/142841.811620:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x8e48467, 0
[1:1:0712/142841.811773:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x337f1509, 3
[1:1:0712/142841.811897:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xc580c1b, 2
[1:1:0712/142841.812025:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 67ffffff84ffffffe408 ffffffe7ffffffcbffffffa100 1b0c580c 09157f33 , 10104, 5
[1:1:0712/142841.812758:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[4239:4268:0712/142841.812936:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGg���ˡ
[1:1:0712/142841.812928:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef4ac860a0, 3
[4239:4268:0712/142841.812983:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is g���ˡ
[1:1:0712/142841.813015:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef4ae12080, 2
[1:1:0712/142841.813129:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fef34ad4d20, -2
[4239:4268:0712/142841.814807:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 4335, 5, 6784e408 e7cba100 1b0c580c 09157f33 
[1:1:0712/142841.824504:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/142841.824699:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c580c1b
[1:1:0712/142841.824858:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c580c1b
[1:1:0712/142841.825122:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c580c1b
[1:1:0712/142841.825630:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.825721:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.825814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.825946:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.826191:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c580c1b
[1:1:0712/142841.826298:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef4ca4c7ba
[1:1:0712/142841.826362:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef4ca43def, 7fef4ca4c77a, 7fef4ca4e0cf
[1:1:0712/142841.827973:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal c580c1b
[1:1:0712/142841.828134:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal c580c1b
[1:1:0712/142841.828427:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal c580c1b
[1:1:0712/142841.829220:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.829347:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.829474:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.829585:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal c580c1b
[1:1:0712/142841.830105:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal c580c1b
[1:1:0712/142841.830276:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fef4ca4c7ba
[1:1:0712/142841.830357:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fef4ca43def, 7fef4ca4c77a, 7fef4ca4e0cf
[1:1:0712/142841.832942:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/142841.833200:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/142841.833310:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc38ce2d48, 0x7ffc38ce2cc8)
[1:1:0712/142841.839903:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/142841.841918:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/142841.928068:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 534, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/142841.929774:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1298db956220
[1:1:0712/142841.929915:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/142841.929942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 20e50526e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/142841.930079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/142841.932563:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[4239:4239:0712/142842.092897:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4239:4239:0712/142842.094987:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4239:4250:0712/142842.114143:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[4239:4250:0712/142842.114206:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[4239:4239:0712/142842.114338:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.eastday.com/
[4239:4239:0712/142842.114381:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.eastday.com/, http://www.eastday.com/eastday/shouye/07index/enews/index.html, 1
[4239:4239:0712/142842.114446:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.eastday.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:28:42 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Server: nginx Last-Modified: Thu, 27 Jun 2019 01:41:27 GMT ETag: W/"a98dea6f892cd51:0" X-Powered-By: ASP.NET Content-Encoding: gzip X-Via: 1.1 PS-WUX-01VS3230:10 (Cdn Cache Server V2.0), 1.1 bj17:0 (Cdn Cache Server V2.0)  ,4335, 5
[1:7:0712/142842.115413:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/142842.130119:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.eastday.com/
[4239:4239:0712/142842.184958:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.eastday.com/, http://www.eastday.com/, 1
[4239:4239:0712/142842.185021:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.eastday.com/, http://www.eastday.com
[1:1:0712/142842.196565:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/142842.237098:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/142842.263997:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/142842.264181:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.eastday.com/eastday/shouye/07index/enews/index.html"
[1:1:0712/142842.276823:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/142842.285137:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1298db954420
[1:1:0712/142842.285280:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/142842.293549:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/142842.293712:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.eastday.com
[1:1:0712/142842.299671:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/142842.301637:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1298db953a20
[1:1:0712/142842.302103:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/142842.308491:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/142842.308651:INFO:render_frame_impl.cc(7019)] 	 [url] = http://www.eastday.com
[1:1:0712/142847.098310:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/142851.168477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/142851.168700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142851.170237:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[4239:4239:0712/142851.286432:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[4239:4239:0712/142851.288541:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: head, 4, 4, 
[4239:4239:0712/142851.292136:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.eastday.com/
[4239:4239:0712/142851.295509:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[4239:4239:0712/142851.297673:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: riframe, 5, 5, 
[4239:4239:0712/142851.300847:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://www.eastday.com/
[3:3:0712/142851.333333:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[4239:4239:0712/142851.367134:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4239:4239:0712/142851.368856:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4239:4250:0712/142851.384100:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[4239:4250:0712/142851.384168:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[4239:4239:0712/142851.384188:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://ej.eastday.com/
[4239:4239:0712/142851.384229:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://ej.eastday.com/, http://ej.eastday.com/eastday/shouye/iframe/dh/index.html, 4
[4239:4239:0712/142851.384291:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://ej.eastday.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:28:51 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Server: nginx Last-Modified: Tue, 29 Oct 2013 07:34:09 GMT ETag: W/"f291474179d4ce1:0" X-Powered-By: ASP.NET Content-Encoding: gzip X-Via: 1.1 PS-WUX-01VS3230:6 (Cdn Cache Server V2.0), 1.1 bj19:7 (Cdn Cache Server V2.0)  ,4335, 5
[1:7:0712/142851.386826:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[4239:4239:0712/142851.397209:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[4239:4239:0712/142851.399749:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[4239:4250:0712/142851.426069:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[4239:4250:0712/142851.426137:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[4239:4239:0712/142851.426167:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://ej.eastday.com/
[4239:4239:0712/142851.426210:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://ej.eastday.com/, http://ej.eastday.com/eastday/shouye/iframe/rightiframe/index.html, 5
[4239:4239:0712/142851.426281:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://ej.eastday.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 06:28:51 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Server: nginx Last-Modified: Sun, 05 May 2019 02:08:58 GMT ETag: W/"6ef7e17fe72d51:0" X-Powered-By: ASP.NET Content-Encoding: gzip X-Via: 1.1 hkuan152:5 (Cdn Cache Server V2.0), 1.1 bj17:6 (Cdn Cache Server V2.0)  ,4335, 5
[1:7:0712/142851.429677:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/142851.629265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142851.629448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142851.696762:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://ej.eastday.com/
[1:1:0712/142851.731532:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://ej.eastday.com/
[1:1:0712/142851.856369:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/142851.878175:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/142851.938310:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/142851.974523:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/142852.024263:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/142852.024395:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[4239:4239:0712/142852.045761:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://ej.eastday.com/, http://ej.eastday.com/, 4
[4239:4239:0712/142852.045819:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://ej.eastday.com/, http://ej.eastday.com
[1:1:0712/142852.052753:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/142852.052894:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://ej.eastday.com/eastday/shouye/iframe/rightiframe/index.html"
[4239:4239:0712/142852.054176:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://ej.eastday.com/, http://ej.eastday.com/, 5
[4239:4239:0712/142852.054219:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://ej.eastday.com/, http://ej.eastday.com
[1:1:0712/142852.359817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142852.359963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142852.880105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142852.880288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142852.912683:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 379 0x7fef4ae12080 0x1298dc1eb880 1 0 0x1298dc1eb898 , "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[1:1:0712/142852.924720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://ej.eastday.com/, 39be3cd22450, , , /*! jQuery v1.11.0 | (c) 2005, 2014 jQuery Foundation, Inc. | jquery.org/license */
!function(a,b){"
[1:1:0712/142852.924906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html", "ej.eastday.com", 4, 1, http://www.eastday.com, www.eastday.com, 3
		remove user.d_5b4d6fb1 -> 0
[1:1:0712/142853.048953:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 379 0x7fef4ae12080 0x1298dc1eb880 1 0 0x1298dc1eb898 , "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[1:1:0712/142853.379503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142853.379779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142853.592287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142853.592510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142853.672040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142853.672599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142853.751486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fef34787070 0x1298dc41ff60 , "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[1:1:0712/142853.752372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://ej.eastday.com/, 39be3cd22450, , , 
<!--
function qbcheckform(theForm){
if(theForm.title.value==""){
		window.alert("关键字不能为
[1:1:0712/142853.752533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html", "ej.eastday.com", 4, 1, http://www.eastday.com, www.eastday.com, 3
[1:1:0712/142853.753455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fef34787070 0x1298dc41ff60 , "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[1:1:0712/142853.754544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fef34787070 0x1298dc41ff60 , "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[1:1:0712/142853.762232:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://ej.eastday.com/eastday/shouye/iframe/dh/index.html"
[4239:4239:0712/142853.904176:INFO:CONSOLE(0)] "[DOM] Password field is not contained in a form: (More info: https://goo.gl/9p2vKq) %o", source: http://ej.eastday.com/eastday/shouye/iframe/dh/index.html (0)
[1:1:0712/142853.975821:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142853.975974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
[1:1:0712/142854.412516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.eastday.com/, 39be3cc02860, , , document.readyState
[1:1:0712/142854.412663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.eastday.com/eastday/shouye/07index/enews/index.html", "www.eastday.com", 3, 1, , , 0
