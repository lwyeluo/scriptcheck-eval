[0712/191717.855071:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/191717.855324:INFO:switcher_clone.cc(787)] backtrace rip is 7f5c3bda3891
[0712/191718.402211:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/191718.402464:INFO:switcher_clone.cc(787)] backtrace rip is 7f6deb6c8891
[1:1:0712/191718.406333:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/191718.406483:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/191718.409380:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[15566:15566:0712/191719.216332:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/191719.249093:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/191719.249377:INFO:switcher_clone.cc(787)] backtrace rip is 7f55f4347891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2d3b1ead-70c8-48fd-837e-bc279f2c4c5f
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[15597:15597:0712/191719.410580:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=15597
[15610:15610:0712/191719.410891:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=15610
[15566:15566:0712/191719.485605:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[15566:15595:0712/191719.486028:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/191719.486153:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/191719.486311:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/191719.486627:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/191719.486747:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/191719.488443:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x186cca7f, 1
[1:1:0712/191719.488624:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x29b36463, 0
[1:1:0712/191719.488717:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x200415f1, 3
[1:1:0712/191719.488809:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2dd876e6, 2
[1:1:0712/191719.488899:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 6364ffffffb329 7fffffffca6c18 ffffffe676ffffffd82d fffffff1150420 , 10104, 4
[1:1:0712/191719.489621:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[15566:15595:0712/191719.490102:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGcd�)�l�v�-� X�E
[15566:15595:0712/191719.490140:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is cd�)�l�v�-� �,X�E
[15566:15595:0712/191719.490292:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[15566:15595:0712/191719.490332:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 15618, 4, 6364b329 7fca6c18 e676d82d f1150420 
[1:1:0712/191719.490571:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6de99020a0, 3
[1:1:0712/191719.490681:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6de9a8e080, 2
[1:1:0712/191719.490766:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6dd3750d20, -2
[1:1:0712/191719.498724:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/191719.499191:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2dd876e6
[1:1:0712/191719.499650:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2dd876e6
[1:1:0712/191719.500413:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2dd876e6
[1:1:0712/191719.500999:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.501104:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.501225:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.501325:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.501573:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2dd876e6
[1:1:0712/191719.501724:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6deb6c87ba
[1:1:0712/191719.501807:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6deb6bfdef, 7f6deb6c877a, 7f6deb6ca0cf
[1:1:0712/191719.503514:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2dd876e6
[1:1:0712/191719.503667:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2dd876e6
[1:1:0712/191719.503947:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2dd876e6
[1:1:0712/191719.504805:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.504898:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.504974:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.505082:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2dd876e6
[1:1:0712/191719.505604:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2dd876e6
[1:1:0712/191719.505809:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6deb6c87ba
[1:1:0712/191719.505886:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6deb6bfdef, 7f6deb6c877a, 7f6deb6ca0cf
[1:1:0712/191719.508569:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/191719.508765:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/191719.508834:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2dbe1f28, 0x7fff2dbe1ea8)
[1:1:0712/191719.515758:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/191719.518539:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[15566:15566:0712/191719.933253:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15566:15566:0712/191719.933727:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[15566:15577:0712/191719.942057:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[15566:15577:0712/191719.942125:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[15566:15566:0712/191719.942148:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[15566:15566:0712/191719.942192:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[15566:15566:0712/191719.942265:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,15618, 4
[1:7:0712/191719.943021:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/191719.981643:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x11bd03fec220
[1:1:0712/191719.981798:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[15566:15588:0712/191720.072072:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/191720.175915:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/191720.848992:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/191720.850609:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[15566:15566:0712/191720.921378:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[15566:15566:0712/191720.921441:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/191721.282282:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191721.357621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/191721.357804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191721.363031:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/191721.363181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191721.420767:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191721.420920:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191721.567033:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191721.569517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/191721.569652:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191721.581374:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191721.584255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/191721.584387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191721.588128:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[15566:15566:0712/191721.588773:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/191721.589885:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x11bd03feae20
[1:1:0712/191721.590006:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[15566:15566:0712/191721.591351:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[15566:15566:0712/191721.602589:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[15566:15566:0712/191721.602710:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/191721.621810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191721.908317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f6dd532b2e0 0x11bd042c5560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191721.909004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/191721.909194:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191721.909738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[15566:15566:0712/191721.935775:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/191721.936427:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x11bd03feb820
[1:1:0712/191721.936580:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[15566:15566:0712/191721.938008:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/191721.943740:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/191721.944127:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[15566:15566:0712/191721.951643:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[15566:15566:0712/191721.955506:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15566:15566:0712/191721.955925:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[15566:15577:0712/191721.960358:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[15566:15577:0712/191721.960411:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[15566:15566:0712/191721.960429:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[15566:15566:0712/191721.960468:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[15566:15566:0712/191721.960529:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,15618, 4
[1:7:0712/191721.961958:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/191722.228478:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/191722.357814:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7f6dd532b2e0 0x11bd04350860 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191722.358431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/191722.358586:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191722.358946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[15566:15566:0712/191722.503037:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[15566:15566:0712/191722.503123:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/191722.514347:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/191722.646883:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[15566:15566:0712/191722.815352:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[15566:15595:0712/191722.815622:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/191722.815753:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/191722.815882:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/191722.816063:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/191722.816138:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/191722.818245:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3c81d112, 1
[1:1:0712/191722.818508:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x5a775e0, 0
[1:1:0712/191722.818670:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15151a91, 3
[1:1:0712/191722.818817:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x20fe0eb8, 2
[1:1:0712/191722.818938:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe075ffffffa705 12ffffffd1ffffff813c ffffffb80efffffffe20 ffffff911a1515 , 10104, 5
[1:1:0712/191722.819716:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[15566:15595:0712/191722.819903:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�u�с<�� ��E
[15566:15595:0712/191722.819949:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �u�с<�� �h�E
[1:1:0712/191722.819895:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6de99020a0, 3
[15566:15595:0712/191722.820085:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 15659, 5, e075a705 12d1813c b80efe20 911a1515 
[1:1:0712/191722.820081:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6de9a8e080, 2
[1:1:0712/191722.820180:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6dd3750d20, -2
[1:1:0712/191722.829296:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/191722.829489:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20fe0eb8
[1:1:0712/191722.829639:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20fe0eb8
[1:1:0712/191722.829893:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20fe0eb8
[1:1:0712/191722.830382:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.830474:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.830565:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.830655:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.830937:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20fe0eb8
[1:1:0712/191722.831083:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6deb6c87ba
[1:1:0712/191722.831160:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6deb6bfdef, 7f6deb6c877a, 7f6deb6ca0cf
[1:1:0712/191722.832854:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 20fe0eb8
[1:1:0712/191722.833023:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 20fe0eb8
[1:1:0712/191722.833344:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 20fe0eb8
[1:1:0712/191722.834113:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.834252:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.834359:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.834461:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 20fe0eb8
[1:1:0712/191722.834953:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 20fe0eb8
[1:1:0712/191722.835105:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6deb6c87ba
[1:1:0712/191722.835190:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6deb6bfdef, 7f6deb6c877a, 7f6deb6ca0cf
[1:1:0712/191722.837797:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/191722.838033:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/191722.838145:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2dbe1f28, 0x7fff2dbe1ea8)
[1:1:0712/191722.843975:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/191722.846198:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191722.846308:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191722.846162:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/191722.959308:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x11bd03fba220
[1:1:0712/191722.959504:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[15566:15577:0712/191723.031158:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/191723.060273:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191723.062016:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/191723.062167:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191723.064533:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191723.154479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/191723.154889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 36584ad21f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/191723.154999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/191723.232578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191723.233385:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/191723.233486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/191723.233614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191723.308787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191723.317612:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/191723.317756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/191723.317925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[15566:15566:0712/191723.427056:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15566:15566:0712/191723.439355:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 6
[15566:15595:0712/191723.439595:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/191723.439726:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/191723.439848:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/191723.440033:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/191723.440115:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/191723.442490:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3b0f9e50, 1
[1:1:0712/191723.442716:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x34c0d147, 0
[1:1:0712/191723.442809:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xfdbfce0, 3
[1:1:0712/191723.442889:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e892034, 2
[1:1:0712/191723.442968:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 47ffffffd1ffffffc034 50ffffff9e0f3b 3420ffffff893e ffffffe0fffffffcffffffdb0f , 10104, 6
[1:1:0712/191723.443664:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[15566:15595:0712/191723.443788:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGG��4P�;4 �>���E�E
[15566:15595:0712/191723.443827:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is G��4P�;4 �>�����E�E
[15566:15595:0712/191723.443952:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 15672, 6, 47d1c034 509e0f3b 3420893e e0fcdb0f 
[1:1:0712/191723.444183:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6de99020a0, 3
[1:1:0712/191723.444284:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6de9a8e080, 2
[1:1:0712/191723.444376:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f6dd3750d20, -2
[1:1:0712/191723.453648:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/191723.456251:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e892034
[1:1:0712/191723.456386:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e892034
[1:1:0712/191723.456620:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e892034
[1:1:0712/191723.457133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.457246:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.457339:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.457429:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.457680:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e892034
[1:1:0712/191723.457806:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6deb6c87ba
[1:1:0712/191723.457878:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6deb6bfdef, 7f6deb6c877a, 7f6deb6ca0cf
[15566:15566:0712/191723.458232:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/191723.459576:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e892034
[1:1:0712/191723.459749:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e892034
[1:1:0712/191723.460052:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e892034
[1:1:0712/191723.460829:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.460935:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.461040:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.461136:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e892034
[1:1:0712/191723.461633:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e892034
[1:1:0712/191723.461799:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f6deb6c87ba
[1:1:0712/191723.461874:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f6deb6bfdef, 7f6deb6c877a, 7f6deb6ca0cf
[1:1:0712/191723.464577:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/191723.464818:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/191723.464902:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff2dbe1f28, 0x7fff2dbe1ea8)
[1:1:0712/191723.473197:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[15566:15566:0712/191723.475772:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.alibaba.com/
[15566:15566:0712/191723.475826:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.alibaba.com/, https://www.alibaba.com/, 1
[15566:15566:0712/191723.475889:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:3_https://www.alibaba.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 11:17:23 GMT content-type:text/html;charset=UTF-8 vary:Accept-Encoding server:Apache-Coyote/1.1 set-cookie:JSESSIONID=10910538B808B59B65127D492783F007; Path=/; HttpOnly set-cookie:ali_apache_track=; Domain=.alibaba.com; Expires=Wed, 30-Jul-2087 14:31:30 GMT; Path=/ set-cookie:ali_apache_tracktmp=; Domain=.alibaba.com; Path=/ set-cookie:xman_us_f=x_locale=en_US&x_l=1; Domain=.alibaba.com; Expires=Wed, 30-Jul-2087 14:31:30 GMT; Path=/ set-cookie:intl_locale=en_US; Domain=.alibaba.com; Path=/ set-cookie:sc_g_cfg_f=sc_b_locale=en_US; Domain=.alibaba.com; Expires=Wed, 30-Jul-2087 14:31:30 GMT; Path=/ set-cookie:intl_common_forever=X3ONtuM4HgKY2VGXvBse8aGQCDFrqrPZOcsiWZ2E+1hu5vJx2CclRQ==; Domain=.alibaba.com; Expires=Wed, 30-Jul-2087 14:31:30 GMT; Path=/; HttpOnly p3p:CP="CAO PSA OUR" cache-control:s-maxage=3600 resin-trace:ali_resin_trace=aisn_homepage_version=null|septemberPromotion=black content-language:de-DE strict-transport-security:max-age=31536000 strict-transport-security:max-age=31536000 content-encoding:gzip timing-allow-origin:* eagleid:0b09865515629302432514395ea920  ,0, 6
[15566:15577:0712/191723.477174:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 3
[15566:15577:0712/191723.477238:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 3, HandleIncomingMessage, HandleIncomingMessage
[1:1:0712/191723.475314:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[3:3:0712/191723.478868:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/191723.489956:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:7:0712/191723.504209:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/191723.587645:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x11bd03fdf220
[1:1:0712/191723.587834:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/191723.614343:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:3_https://www.alibaba.com/
[1:1:0712/191723.659885:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[15566:15566:0712/191723.725334:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:3_https://www.alibaba.com/, https://www.alibaba.com/, 1
[15566:15566:0712/191723.725396:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.alibaba.com/, https://www.alibaba.com
[1:1:0712/191723.729254:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/191723.776217:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/191723.777973:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191723.794506:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/191723.817184:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191723.817381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191723.821246:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 108 0x7f6dd3403070 0x11bd040e0ae0 , "https://www.alibaba.com/"
[1:1:0712/191723.822014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , 
    var homeTimePage1 = +new Date();

[1:1:0712/191723.822154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "www.alibaba.com", 3, 1, , , 0
[1:1:0712/191723.827346:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/191723.835841:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0183029, 58, 1
[1:1:0712/191723.836029:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191723.855315:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/191723.905582:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/191723.934303:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/191723.973466:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/191724.035420:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191724.035606:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191724.036016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.036533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , 
    //pc
	try { document.domain = 'alibaba.com'; } catch(e) { }

[1:1:0712/191724.036666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "www.alibaba.com", 3, 1, , , 0
[1:1:0712/191724.037227:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "www.alibaba.com", "alibaba.com"
[1:1:0712/191724.038317:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.039442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.054872:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.059279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.060346:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/191724.066795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.071744:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.079302:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.082821:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7f6dd3403070 0x11bd04128960 , "https://www.alibaba.com/"
[1:1:0712/191724.083911:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191724.084322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/191724.084476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191724.107242:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.07162, 151, 1
[1:1:0712/191724.107412:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191724.220818:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191724.221327:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/191724.221455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191724.247272:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191724.247723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/191724.247888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191724.301624:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191724.302064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/191724.302224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191724.307441:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191724.307576:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191724.308006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 213 0x7f6dd3403070 0x11bd04187b60 , "https://www.alibaba.com/"
[1:1:0712/191724.308989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(){try{if(localStorage){var b=localStorage.getItem("sc-header-login"),c=document.cookie.mat
[1:1:0712/191724.309146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191724.338372:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/191724.338812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 36584ae4e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/191724.338979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/191728.146358:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/191737.295916:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[15566:15566:0712/191737.375755:INFO:CONSOLE(455)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://s.alicdn.com/@g/sc/header-footer/0.0.14/sc-header-footer/$node_modules/@alife/alpha-icon/src/iconfont.woff", source: https://www.alibaba.com/ (455)
[1:1:0712/191737.552989:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.2454, 0, 0
[1:1:0712/191737.553200:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191737.708845:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/191737.709087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191737.872077:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191737.872263:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191737.875404:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00310707, 71, 1
[1:1:0712/191737.875571:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191737.960628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 287 0x7f6dd532b2e0 0x11bd041414e0 , "https://www.alibaba.com/"
[1:1:0712/191737.964974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , ,  !function(){function e(t,n,r){function i(o,s){if(!n[o]){if(!t[o]){var c="function"==typeof require&
[1:1:0712/191737.965147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191738.028125:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 288 0x7f6dd532b2e0 0x11bd041ac460 , "https://www.alibaba.com/"
[1:1:0712/191738.032017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , /*! 2019-03-20 10:16:09 v0.0.27 */
!(function (e) { function n (t) { if (o[t]) return o[t].exports; 
[1:1:0712/191738.032188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191738.265449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191738.265677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191738.338189:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191738.338399:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191738.339153:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/191738.339286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191738.351886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.370854:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.384279:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.398165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.411868:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.426372:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.440550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.441528:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x137233629c8, 0x11bd03e4d1b0
[1:1:0712/191738.441634:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 2000
[1:1:0712/191738.441806:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 362
[1:1:0712/191738.441937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 362 0x7f6dd3403070 0x11bd041b0be0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 304 0x7f6dd3403070 0x11bd041e8a60 
[1:1:0712/191738.470844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.506296:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.550221:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.567535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.604330:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 304 0x7f6dd3403070 0x11bd041e8a60 , "https://www.alibaba.com/"
[1:1:0712/191738.616677:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.27822, 90, 1
[1:1:0712/191738.616833:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191738.812445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/191738.812606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191738.820758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/191738.820927:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191738.839256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191738.839424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.011841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.alibaba.com/"
[1:1:0712/191739.012721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){b()}
[1:1:0712/191739.012833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.225200:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191739.225581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , () {
                                if(performance && performance.getEntriesByName) {
             
[1:1:0712/191739.225681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.365269:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191739.365439:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191739.366151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/191739.366269:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.389795:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f6dd3403070 0x11bd0418a760 , "https://www.alibaba.com/"
[1:1:0712/191739.412504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f6dd3403070 0x11bd0418a760 , "https://www.alibaba.com/"
[1:1:0712/191739.420299:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f6dd3403070 0x11bd0418a760 , "https://www.alibaba.com/"
[1:1:0712/191739.427072:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f6dd3403070 0x11bd0418a760 , "https://www.alibaba.com/"
[1:1:0712/191739.434965:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 390 0x7f6dd3403070 0x11bd0418a760 , "https://www.alibaba.com/"
[1:1:0712/191739.445925:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0805218, 97, 1
[1:1:0712/191739.446142:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191739.572974:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 395 0x7f6dd532b2e0 0x11bd045c26e0 , "https://www.alibaba.com/"
[1:1:0712/191739.574522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , !function(t,a){var r=1e4,g_moduleConfig={uabModule:{stable:["AWSC/uab/117.js"],grey:["AWSC/uab/118.j
[1:1:0712/191739.574669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.577990:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191739.580122:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191739.580259:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191739.580479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 440
[1:1:0712/191739.580604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 440 0x7f6dd3403070 0x11bd03c3f060 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 395 0x7f6dd532b2e0 0x11bd045c26e0 
[1:1:0712/191739.621801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 396 0x7f6dd532b2e0 0x11bd0432a5e0 , "https://www.alibaba.com/"
[1:1:0712/191739.624113:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(){var e=function(){var e={},t={exports:e};var n=0;function r(){}function i(e,t,i){if("func
[1:1:0712/191739.624220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.668130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191739.669886:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191739.670066:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/191739.670283:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 450
[1:1:0712/191739.670463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f6dd3403070 0x11bd040cc760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 396 0x7f6dd532b2e0 0x11bd0432a5e0 
[1:1:0712/191739.696643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191739.696794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.825340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , startMeasureFMP, (){var metaNodes=Array.prototype.filter.call(document.getElementsByName("data-spm"),function(node){r
[1:1:0712/191739.825525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191739.863580:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f6dd532b2e0 0x11bd04a33460 , "https://www.alibaba.com/"
[1:1:0712/191739.864084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , topBannerCallback({"code":500,"message":"no data "});
[1:1:0712/191739.864185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191740.034784:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191740.034951:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191740.035612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/191740.035718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191740.061417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.089567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.120357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.152466:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.181624:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.212978:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.243863:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.271379:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.296917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.308332:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 436 0x7f6dd3403070 0x11bd04189260 , "https://www.alibaba.com/"
[1:1:0712/191740.345572:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.310667, 353, 1
[1:1:0712/191740.345793:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191740.581203:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 450, 7f6dd5d48881
[1:1:0712/191740.589344:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"396 0x7f6dd532b2e0 0x11bd0432a5e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191740.589570:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"396 0x7f6dd532b2e0 0x11bd0432a5e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191740.589793:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191740.590120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var t=e.modNames.join("^");try{e.callback()}catch(n){o({gmkey:"EXP",gokey:"pos=useCallbackError&c
[1:1:0712/191740.590273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191740.690128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191740.690322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191740.717242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , rFACallBack, (){var hes=document.querySelectorAll(selector);if(hes.length>=config.minCount){var runTime=performan
[1:1:0712/191740.717435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191740.720708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d168
[1:1:0712/191740.720864:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191740.721015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 522
[1:1:0712/191740.721143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 522 0x7f6dd3403070 0x11bd0466e760 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 459 0x7f6de2714960 0x11bd046bba60 0x11bd046bba70 
[1:1:0712/191741.184665:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191741.184849:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191741.185549:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/191741.185659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[15566:15566:0712/191741.318586:INFO:CONSOLE(1)] "Slow network is detected. See https://www.chromestatus.com/feature/5636954674692096 for more details. Fallback font will be used while loading: https://s.alicdn.com/@g/sc/aisn/0.0.7/sc-aisn/$node_modules/@alife/alpha-icon/src/iconfont.woff", source: https://retcode.alicdn.com/retcode/bl.js (1)
[1:1:0712/191741.437343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.441641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d1a0
[1:1:0712/191741.441840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191741.442071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 554
[1:1:0712/191741.442243:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7f6dd3403070 0x11bd051b4360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 496 0x7f6dd3403070 0x11bd0454c960 
[1:1:0712/191741.463326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.475013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.486128:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.518240:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.529608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.545550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7f6dd3403070 0x11bd0454c960 , "https://www.alibaba.com/"
[1:1:0712/191741.791184:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191741.794141:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.60929, 0, 0
[1:1:0712/191741.794318:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/191741.812202:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 362, 7f6dd5d48881
[1:1:0712/191741.822327:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"304 0x7f6dd3403070 0x11bd041e8a60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191741.822489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"304 0x7f6dd3403070 0x11bd041e8a60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191741.822641:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191741.822904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , () {
            if(!window.TOP_BANNER_DATA) {
                window.topBannerCallback({});
       
[1:1:0712/191741.822991:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191742.042551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (e){t(e)}
[1:1:0712/191742.042752:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191742.045818:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 519 0x7f6de6962bb0 0x11bd04734960 0 , "https://www.alibaba.com/"
[1:1:0712/191742.267247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.267456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191742.267676:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 596
[1:1:0712/191742.267839:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 596 0x7f6dd3403070 0x11bd04142fe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.355330:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.355533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191742.355766:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 608
[1:1:0712/191742.355932:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7f6dd3403070 0x11bd04247560 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.364593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.364772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191742.364987:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 609
[1:1:0712/191742.365134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f6dd3403070 0x11bd03c3b360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.375952:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.376129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191742.376338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 610
[1:1:0712/191742.376479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 610 0x7f6dd3403070 0x11bd049d99e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.453295:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.453491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191742.453710:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 620
[1:1:0712/191742.453878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 620 0x7f6dd3403070 0x11bd04fb2b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.473713:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.473856:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191742.474028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 621
[1:1:0712/191742.474134:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 621 0x7f6dd3403070 0x11bd049d93e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.475816:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x137233629c8, 0x11bd03e4d678
[1:1:0712/191742.475911:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 10
[1:1:0712/191742.476043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 622
[1:1:0712/191742.476152:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 622 0x7f6dd3403070 0x11bd04326360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 519 0x7f6de6962bb0 0x11bd04734960 0 
[1:1:0712/191742.532364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191742.532597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191743.181106:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191743.181614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , imgLarge.onload, () {
            firstImage.src = imgLarge.src;
        }
[1:1:0712/191743.181780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191743.203632:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/191743.203772:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.alibaba.com/"
[1:1:0712/191743.204501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){!function(e){var t=Date.now()-e,r=n.querySelector("body");if(r){var i=0;i+=a(r,1,!1),c.push({scor
[1:1:0712/191743.204627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191743.361522:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7f6dd3403070 0x11bd03e2d960 , "https://www.alibaba.com/"
[1:1:0712/191743.374740:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 522, 7f6dd5d48881
[1:1:0712/191743.385345:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"459 0x7f6de2714960 0x11bd046bba60 0x11bd046bba70 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191743.385602:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"459 0x7f6de2714960 0x11bd046bba60 0x11bd046bba70 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191743.385805:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191743.386089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){trace(type,action)}
[1:1:0712/191743.386221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191743.386706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191743.386827:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191743.387000:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 661
[1:1:0712/191743.387122:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 661 0x7f6dd3403070 0x11bd041dd5e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 522 0x7f6dd3403070 0x11bd0466e760 
[1:1:0712/191743.410590:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/191743.445686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 , "https://www.alibaba.com/"
[1:1:0712/191743.484964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(){var r=function(){var r={},n={exports:r};return n.exports}()})();(function(){var hashArra
[1:1:0712/191743.485176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191743.729488:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 , "https://www.alibaba.com/"
[1:1:0712/191744.126193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 , "https://www.alibaba.com/"
		remove user.e_e7a2dbe7 -> 0
[1:1:0712/191744.135119:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191744.167736:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 , "https://www.alibaba.com/"
[1:1:0712/191744.179400:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 , "https://www.alibaba.com/"
[1:1:0712/191744.181640:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/191744.223733:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191744.223933:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191744.224137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 678
[1:1:0712/191744.224298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 678 0x7f6dd3403070 0x11bd061807e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 
[1:1:0712/191744.229664:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191744.229873:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191744.230190:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 679
[1:1:0712/191744.230350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 679 0x7f6dd3403070 0x11bd061802e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 
[1:1:0712/191744.232222:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/191744.232799:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x137233629c8, 0x11bd03e4d1e0
[1:1:0712/191744.232895:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191744.233102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 680
[1:1:0712/191744.233241:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f6dd3403070 0x11bd06247160 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 
[1:1:0712/191744.233449:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/191744.250294:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/191744.251413:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/191744.272018:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.alibaba.com/"
[1:1:0712/191744.705070:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "open", "https://www.alibaba.com/"
[1:1:0712/191744.705476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , s.onopen, (){e.status="active";var t=e.getMsgQueue();t.length>0&&e.proessMsgQueue(t);var n="connTime="+((new D
[1:1:0712/191744.705580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191744.749548:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 622, 7f6dd5d48881
[1:1:0712/191744.760204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191744.760365:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191744.760542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191744.760800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0712/191744.760888:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191744.822225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191744.822387:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.069206:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 610, 7f6dd5d48881
[1:1:0712/191745.081719:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.081929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.082162:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191745.082524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/191745.082614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.083346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191745.083428:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191745.083572:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 728
[1:1:0712/191745.083657:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 728 0x7f6dd3403070 0x11bd03bf86e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 610 0x7f6dd3403070 0x11bd049d99e0 
[1:1:0712/191745.133505:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 648 0x7f6dd532b2e0 0x11bd051af8e0 , "https://www.alibaba.com/"
[1:1:0712/191745.134180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(){var e=function(){var e={},t={exports:e};(function(){var e=document.getElementsByTagName(
[1:1:0712/191745.134302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.147905:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191745.221579:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191745.222012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , () {
                                if(performance && performance.getEntriesByName) {
             
[1:1:0712/191745.222140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.223009:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 596, 7f6dd5d48881
[1:1:0712/191745.234654:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.234858:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.235061:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191745.235352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0712/191745.235505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.686037:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 661, 7f6dd5d48881
[1:1:0712/191745.698683:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"522 0x7f6dd3403070 0x11bd0466e760 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.698933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"522 0x7f6dd3403070 0x11bd0466e760 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.699198:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191745.699538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){trace(type,action)}
[1:1:0712/191745.699704:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.700053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191745.700213:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191745.700431:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 755
[1:1:0712/191745.700532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f6dd3403070 0x11bd0604d560 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 661 0x7f6dd3403070 0x11bd041dd5e0 
[1:1:0712/191745.829850:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 554, 7f6dd5d48881
[1:1:0712/191745.842184:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"496 0x7f6dd3403070 0x11bd0454c960 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.842355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"496 0x7f6dd3403070 0x11bd0454c960 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.842553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191745.842863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){
        useScript('//s.alicdn.com/@g/sc/footer/0.0.3/sc-footer/dist/footer-sync.js');
      }
[1:1:0712/191745.842965:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.903719:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 440, 7f6dd5d48881
[1:1:0712/191745.916414:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"395 0x7f6dd532b2e0 0x11bd045c26e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.916591:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"395 0x7f6dd532b2e0 0x11bd045c26e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191745.916779:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191745.917057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){S.state=b,x(S,r&&r.throwExceptionInCallback)}
[1:1:0712/191745.917180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191745.954076:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191745.954275:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191745.954496:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 771
[1:1:0712/191745.954661:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 771 0x7f6dd3403070 0x11bd062fef60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 440 0x7f6dd3403070 0x11bd03c3f060 
[1:1:0712/191746.019158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191746.019396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191746.046955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191746.047341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , n.onload, (){i()}
[1:1:0712/191746.047495:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191746.100416:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191746.100772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , n.onload, (){i()}
[1:1:0712/191746.100864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191746.333087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 680, 7f6dd5d48881
[1:1:0712/191746.345878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191746.346067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191746.346273:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191746.346544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , () {
                window.SCHD_COMS.use(['globalTopBanner'], function () {
                    try
[1:1:0712/191746.346641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191746.347665:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191746.347761:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/191746.347912:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 789
[1:1:0712/191746.348004:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f6dd3403070 0x11bd062d8460 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 680 0x7f6dd3403070 0x11bd06247160 
[1:1:0712/191746.393012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 740 0x7f6dd532b2e0 0x11bd03bfbf60 , "https://www.alibaba.com/"
[1:1:0712/191746.396217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , define("sc-global/node_modules/@alife/alpha-security/security.js",[],function(require,e,t){var n={};
[1:1:0712/191746.396368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191746.426445:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191747.493876:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.494075:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191747.494307:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 819
[1:1:0712/191747.494470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 819 0x7f6dd3403070 0x11bd06de3360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.696486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.696692:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/191747.696903:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 820
[1:1:0712/191747.697015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 820 0x7f6dd3403070 0x11bd06e879e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.721169:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.721356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/191747.721578:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 824
[1:1:0712/191747.721735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 824 0x7f6dd3403070 0x11bd070937e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.743167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.743382:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/191747.743629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 828
[1:1:0712/191747.743797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 828 0x7f6dd3403070 0x11bd070cb3e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.756752:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.756946:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.757315:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 830
[1:1:0712/191747.757493:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 830 0x7f6dd3403070 0x11bd0709c2e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.766591:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.766791:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.767027:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 833
[1:1:0712/191747.767196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 833 0x7f6dd3403070 0x11bd07101a60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.775352:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.775544:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.775767:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 835
[1:1:0712/191747.775924:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 835 0x7f6dd3403070 0x11bd0712b960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.783725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.783908:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.784071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 837
[1:1:0712/191747.784169:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 837 0x7f6dd3403070 0x11bd07138de0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.794023:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.794181:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.794365:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 839
[1:1:0712/191747.794489:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 839 0x7f6dd3403070 0x11bd071417e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.810032:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.810180:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191747.810354:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 842
[1:1:0712/191747.810463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 842 0x7f6dd3403070 0x11bd071012e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.818987:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.819151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.819327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 843
[1:1:0712/191747.819463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7f6dd3403070 0x11bd07152ce0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191747.826564:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191747.826725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191747.826958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 845
[1:1:0712/191747.827071:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7f6dd3403070 0x11bd07181b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191748.012733:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191748.013015:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 851
[1:1:0712/191748.013156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 851 0x7f6dd3403070 0x11bd0709c4e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191748.657125:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191748.657345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191748.657590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 860
[1:1:0712/191748.657728:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 860 0x7f6dd3403070 0x11bd0773eee0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191748.715071:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191748.715267:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 60000
[1:1:0712/191748.715475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 862
[1:1:0712/191748.715614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 862 0x7f6dd3403070 0x11bd078cdb60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191748.974090:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/191751.636019:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191751.636303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 897
[1:1:0712/191751.636479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7f6dd3403070 0x11bd097e93e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191751.783478:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191751.783681:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 20000
[1:1:0712/191751.783938:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 903
[1:1:0712/191751.784050:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7f6dd3403070 0x11bd096b6160 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 740 0x7f6dd532b2e0 0x11bd03bfbf60 
[1:1:0712/191751.850167:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 741 0x7f6dd532b2e0 0x11bd05a39060 , "https://www.alibaba.com/"
[1:1:0712/191751.850928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , jsonpCallback({"code":200,"data":{"nicheVoList":[{"materialVoList":[{"clickParam":"click_cid-3852#cl
[1:1:0712/191751.851081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191751.889083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 609, 7f6dd5d48881
[1:1:0712/191751.904637:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191751.904821:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191751.905058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191751.905376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/191751.905516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191751.974008:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 621, 7f6dd5d48881
[1:1:0712/191751.989525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191751.989712:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191751.989915:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191751.990223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/191751.990320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.069320:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191752.069715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , n.onload, (){i()}
[1:1:0712/191752.069837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.070577:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 728, 7f6dd5d48881
[1:1:0712/191752.085658:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"610 0x7f6dd3403070 0x11bd049d99e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191752.085832:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"610 0x7f6dd3403070 0x11bd049d99e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191752.086032:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191752.086296:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/191752.086396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.087203:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191752.087298:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191752.087460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 932
[1:1:0712/191752.087571:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 932 0x7f6dd3403070 0x11bd059f4260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 728 0x7f6dd3403070 0x11bd03bf86e0 
[1:1:0712/191752.178550:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 758 0x7f6dd532b2e0 0x11bd05a18f60 , "https://www.alibaba.com/"
[1:1:0712/191752.179871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0712/191752.180001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.237766:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 759 0x7f6dd532b2e0 0x11bd06193d60 , "https://www.alibaba.com/"
[1:1:0712/191752.241303:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , !function(t){function e(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};return t[r].
[1:1:0712/191752.241450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.253981:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191752.261619:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191752.261812:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191752.262007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 939
[1:1:0712/191752.262147:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 939 0x7f6dd3403070 0x11bd058fdfe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 759 0x7f6dd532b2e0 0x11bd06193d60 
[1:1:0712/191752.539773:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 776 0x7f6dd532b2e0 0x11bd05fb84e0 , "https://www.alibaba.com/"
[1:1:0712/191752.540445:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="x72HFb6WgX0CAXlFE14b37jj";goldlog.stag=1;
[1:1:0712/191752.540591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.540909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191752.574200:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 777 0x7f6dd532b2e0 0x11bd041e8b60 , "https://www.alibaba.com/"
[1:1:0712/191752.578341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(){var e=function(){var e={},t={exports:e};var n={};var r={};var i;o();function o(){var e=d
[1:1:0712/191752.578528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.909188:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191752.910258:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191752.910427:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1
[1:1:0712/191752.910679:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 954
[1:1:0712/191752.911020:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 954 0x7f6dd3403070 0x11bd05a182e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 777 0x7f6dd532b2e0 0x11bd041e8b60 
[1:1:0712/191752.952053:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191752.952351:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191752.952601:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 960
[1:1:0712/191752.952767:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 960 0x7f6dd3403070 0x11bd04c387e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 777 0x7f6dd532b2e0 0x11bd041e8b60 
[1:1:0712/191752.997455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191752.997669:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191752.999155:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 755, 7f6dd5d48881
[1:1:0712/191753.015421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"661 0x7f6dd3403070 0x11bd041dd5e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191753.015653:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"661 0x7f6dd3403070 0x11bd041dd5e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191753.015880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191753.016181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){trace(type,action)}
[1:1:0712/191753.016278:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191753.016645:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191753.016776:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191753.016939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 971
[1:1:0712/191753.017079:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7f6dd3403070 0x11bd065076e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 755 0x7f6dd3403070 0x11bd0604d560 
[1:1:0712/191753.123997:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 787 0x7f6dd532b2e0 0x11bd05a1b660 , "https://www.alibaba.com/"
[1:1:0712/191753.124707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (function(){var e=function(){var e={},o={exports:e};window.jsonpFooterCallback=function(e){if(e&&e.c
[1:1:0712/191753.124812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191753.145980:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191753.168596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 788 0x7f6dd532b2e0 0x11bd05bb2ee0 , "https://www.alibaba.com/"
[1:1:0712/191753.198004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , !function(){function e(b,k,o,t,n){var h,d,p,v,u,f,l,C,g,w,m,S,j,A,x,y,E,_,R,O,T,D,P,M,I,B,L,N,V,W,z,
[1:1:0712/191753.198174:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191757.070758:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/191757.071040:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/191757.071548:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:17:0712/191757.074095:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/191757.106130:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x137233629c8, 0x11bd03e4d190
[1:1:0712/191757.106329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/191757.106555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 988
[1:1:0712/191757.106669:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 988 0x7f6dd3403070 0x11bd0a15f560 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 788 0x7f6dd532b2e0 0x11bd05bb2ee0 
[1:19:0712/191759.102405:WARNING:paced_sender.cc(261)] Elapsed time (2002 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191759.602840:WARNING:paced_sender.cc(261)] Elapsed time (2502 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191800.103291:WARNING:paced_sender.cc(261)] Elapsed time (3003 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191800.603687:WARNING:paced_sender.cc(261)] Elapsed time (3503 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191801.104128:WARNING:paced_sender.cc(261)] Elapsed time (4003 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191801.604570:WARNING:paced_sender.cc(261)] Elapsed time (4504 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191802.104846:WARNING:paced_sender.cc(261)] Elapsed time (5004 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191802.605326:WARNING:paced_sender.cc(261)] Elapsed time (5505 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191803.105697:WARNING:paced_sender.cc(261)] Elapsed time (6005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191803.606163:WARNING:paced_sender.cc(261)] Elapsed time (6506 ms) longer than expected, limiting to 2000 ms
		remove user.f_e3b14879 -> 0
[1:19:0712/191804.106621:WARNING:paced_sender.cc(261)] Elapsed time (7006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191804.607051:WARNING:paced_sender.cc(261)] Elapsed time (7506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191805.107502:WARNING:paced_sender.cc(261)] Elapsed time (8007 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191805.607927:WARNING:paced_sender.cc(261)] Elapsed time (8507 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191806.108335:WARNING:paced_sender.cc(261)] Elapsed time (9008 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191806.608660:WARNING:paced_sender.cc(261)] Elapsed time (9508 ms) longer than expected, limiting to 2000 ms
[15566:15566:0712/191807.027966:INFO:CONSOLE(1)] "", source: https://aeis.alicdn.com/AWSC/WebUMID/1.73.2/um.js?d=12 (1)
[1:1:0712/191807.059495:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 789, 7f6dd5d48881
[1:1:0712/191807.074597:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"680 0x7f6dd3403070 0x11bd06247160 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191807.074842:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"680 0x7f6dd3403070 0x11bd06247160 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191807.075135:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191807.075461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){n();o({gmkey:"EXP",gokey:"pos=loadSuccess&val=2&c_name="+g})}
[1:1:0712/191807.075618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191807.078957:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191807.079098:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 2000
[1:1:0712/191807.079252:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1003
[1:1:0712/191807.079336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f6dd3403070 0x11bd0b857b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 789 0x7f6dd3403070 0x11bd062d8460 
[1:19:0712/191807.109071:WARNING:paced_sender.cc(261)] Elapsed time (10008 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191807.117935:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191807.118145:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191807.118384:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1010
[1:1:0712/191807.118542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1010 0x7f6dd3403070 0x11bd09943fe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 789 0x7f6dd3403070 0x11bd062d8460 
[1:1:0712/191807.195693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 792 0x7f6dd532b2e0 0x11bd05a152e0 , "https://www.alibaba.com/"
[1:1:0712/191807.196925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , !function(e){function t(n){if(o[n])return o[n].exports;var i=o[n]={i:n,l:!1,exports:{}};return e[n].
[1:1:0712/191807.197092:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191807.221270:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191807.242699:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 793 0x7f6dd532b2e0 0x11bd03bf9ee0 , "https://www.alibaba.com/"
[1:1:0712/191807.259461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , !function(){var t="client/index.js",e=new Function("return this")();!function(t){var e={};function n
[1:1:0712/191807.259658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191807.458664:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x137233629c8, 0x11bd03e4d1a8
[1:1:0712/191807.458826:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/191807.459012:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1022
[1:1:0712/191807.459132:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7f6dd3403070 0x11bd0b6a7860 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 793 0x7f6dd532b2e0 0x11bd03bf9ee0 
[1:1:0712/191807.476351:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x12977fac1e8
[1:1:0712/191807.476765:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 50, 0x137233629c8, 0x11bd03e4d1a8
[1:1:0712/191807.476861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/191807.477056:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1023
[1:1:0712/191807.477196:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f6dd3403070 0x11bd0b4da8e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 793 0x7f6dd532b2e0 0x11bd03bf9ee0 
[1:1:0712/191807.521914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191807.524008:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191807.524152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191807.524345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1027
[1:1:0712/191807.524460:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1027 0x7f6dd3403070 0x11bd0b411be0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 793 0x7f6dd532b2e0 0x11bd03bf9ee0 
[1:1:0712/191807.524817:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191807.524901:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191807.525025:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1028
[1:1:0712/191807.525178:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7f6dd3403070 0x11bd0b50e0e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 793 0x7f6dd532b2e0 0x11bd03bf9ee0 
[1:1:0712/191807.525524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191807.525592:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191807.525740:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1029
[1:1:0712/191807.525822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f6dd3403070 0x11bd0b4d3460 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 793 0x7f6dd532b2e0 0x11bd03bf9ee0 
[1:1:0712/191807.526129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191807.526195:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191807.526330:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1030
[1:1:0712/191807.526423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1030 0x7f6dd3403070 0x11bd0b5ef6e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 793 0x7f6dd532b2e0 0x11bd03bf9ee0 
[1:19:0712/191807.609335:WARNING:paced_sender.cc(261)] Elapsed time (10509 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191808.109296:WARNING:paced_sender.cc(261)] Elapsed time (11009 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191808.609691:WARNING:paced_sender.cc(261)] Elapsed time (11509 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191809.110123:WARNING:paced_sender.cc(261)] Elapsed time (12009 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191809.380474:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191809.380874:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , t.onload, (){try{localStorage.setItem(e,"available")}catch(t){}}
[1:1:0712/191809.380981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191809.610488:WARNING:paced_sender.cc(261)] Elapsed time (12510 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191809.629321:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 679, 7f6dd5d48881
[1:1:0712/191809.647807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.647988:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.648199:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191809.648466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var n=t.wsHandler.getMsgQueue();if(t.dataInArray(n,e)){t.doSetRetryTimes(),t.changeToHttpRequest(
[1:1:0712/191809.648565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191809.666138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 608, 7f6dd5d48881
[1:1:0712/191809.684902:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.685128:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.685434:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191809.685791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/191809.685895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191809.691788:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 620, 7f6dd5d48881
[1:1:0712/191809.710749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.710975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"519 0x7f6de6962bb0 0x11bd04734960 0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.711194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191809.711472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/191809.711576:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191809.733606:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 842, 7f6dd5d48881
[1:1:0712/191809.752066:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.752246:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191809.752494:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191809.752759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){if(this.scrollTimer){clearTimeout(this.scrollTimer)}this._calculator();this._dot()}
[1:1:0712/191809.752860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191810.110877:WARNING:paced_sender.cc(261)] Elapsed time (13010 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191810.205331:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d110
[1:1:0712/191810.205548:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191810.205781:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1101
[1:1:0712/191810.205945:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1101 0x7f6dd3403070 0x11bd06391a60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 842 0x7f6dd3403070 0x11bd071012e0 
[1:1:0712/191810.232649:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191810.233093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , d.onload, (){dotBanner(a,b,c)}
[1:1:0712/191810.233256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191810.275988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191810.276227:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191810.276447:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1110
[1:1:0712/191810.276583:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1110 0x7f6dd3403070 0x11bd097f40e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 925 0x7f6dd3403070 0x11bd0429f260 
[1:1:0712/191810.284468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 678, 7f6dd5d48881
[1:1:0712/191810.303659:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.303863:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"587 0x7f6de9a8e080 0x11bd041deec0 1 0 0x11bd041deed8 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.304088:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191810.304368:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/191810.304461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191810.308082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 819, 7f6dd5d48881
[1:1:0712/191810.325956:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.326125:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.326331:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191810.326612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){if(n){window.clearTimeout(n)}if(!t){a.get();t=true}}
[1:1:0712/191810.326706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191810.335301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 50
[1:1:0712/191810.335545:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1114
[1:1:0712/191810.335714:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1114 0x7f6dd3403070 0x11bd0ad8d3e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 819 0x7f6dd3403070 0x11bd06de3360 
[15566:15566:0712/191810.344039:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/191810.345270:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x11bd045f0e20
[1:1:0712/191810.345569:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[15566:15566:0712/191810.346380:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/191810.353515:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/191810.353706:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.alibaba.com
[15566:15566:0712/191810.354531:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 6:3_https://www.alibaba.com/
[15566:15566:0712/191810.372728:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[15566:15566:0712/191810.375731:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[15566:15577:0712/191810.391616:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 6, 4
[15566:15577:0712/191810.391685:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 6, 4, HandleIncomingMessage, HandleIncomingMessage
[15566:15566:0712/191810.391712:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://i.alicdn.com/
[15566:15566:0712/191810.391754:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 6, 6:4_https://i.alicdn.com/, https://i.alicdn.com/g/sc/global-components/1.0.0/store-proxy.html?iframe_delete=true, 4
[15566:15566:0712/191810.391816:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 6:4_https://i.alicdn.com/, HTTP/1.1 200 status:200 server:Tengine content-type:text/html content-length:3298 date:Fri, 12 Jul 2019 11:12:11 GMT vary:Accept-Encoding vary:Accept-Encoding x-oss-request-id:5D285F9EA748743E9C04E9A2 x-oss-object-type:Normal x-oss-hash-crc64ecma:439327456095308131 x-oss-storage-class:Standard content-md5:maTxakUtjO2GgUl8aX1OqQ== x-oss-server-time:19 cache-control:max-age=2592000,s-maxage=3600 x-source-scheme:https ali-swift-global-savetime:1562927006 via:cache3.l2cm12-1[93,200-0,M], cache8.l2cm12-1[95,0], cache2.cn396[0,200-0,H], cache3.cn396[1,0], cache6.l2cn241[86,200-0,M], cache3.l2cn241[89,0], cache10.cn310[0,200-0,H], cache1.cn310[2,0] timing-allow-origin:* timing-allow-origin:*, * eagleid:7cc1ebcb15629299313866720e eagleid:7cc1ebcb15629299313866720e, 7cc1ebc915629302904341819e access-control-allow-origin:* content-encoding:gzip strict-transport-security:max-age=0 age:359 x-cache:HIT TCP_MEM_HIT dirn:-2:-2 x-swift-savetime:Fri, 12 Jul 2019 11:12:11 GMT x-swift-cachetime:3600 access-control-expose-headers:Via   ,15672, 6
[1:1:0712/191810.393651:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 771, 7f6dd5d48881
[1:7:0712/191810.394580:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/191810.412723:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"440 0x7f6dd3403070 0x11bd03c3f060 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.412921:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"440 0x7f6dd3403070 0x11bd03c3f060 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.413177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191810.413455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/191810.413559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191810.444223:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 820, 7f6dd5d48881
[1:1:0712/191810.462071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.462294:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.462566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191810.462882:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){f();if(a)a(new Error("Timeout"),null,e)}
[1:1:0712/191810.463026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191810.466548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[1:1:0712/191810.483795:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[15566:15566:0712/191810.495067:INFO:CONSOLE(4)] "Uncaught TypeError: Cannot read property 'map' of undefined", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (4)
[1:1:0712/191810.508929:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 824, 7f6dd5d48881
[1:1:0712/191810.528180:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.528476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.528735:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191810.529099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){f();if(a)a(new Error("Timeout"),null,e)}
[1:1:0712/191810.529245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191810.564638:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 828, 7f6dd5d48881
[1:1:0712/191810.581861:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.582057:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191810.582277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191810.582561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){f();if(a)a(new Error("Timeout"),null,e)}
[1:1:0712/191810.582685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191810.611261:WARNING:paced_sender.cc(261)] Elapsed time (13511 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191810.767166:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 930 0x7f6dd532b2e0 0x11bd097f1460 , "https://www.alibaba.com/"
[1:1:0712/191810.768313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74283({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":13,"data":{
[1:1:0712/191810.768460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[15566:15566:0712/191810.771266:INFO:CONSOLE(3)] "jsonp timeout", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (3)
[1:1:0712/191810.788613:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 931 0x7f6dd532b2e0 0x11bd040dcf60 , "https://www.alibaba.com/"
[1:1:0712/191810.789165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74284({"code":500,"message":"no data "});
[1:1:0712/191810.789270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[15566:15566:0712/191810.790733:INFO:CONSOLE(3)] "jsonp timeout", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (3)
[1:1:0712/191811.073493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , n.observe.entryTypes, (t){if("function"==typeof t.getEntries){for(var n=t.getEntries(),r=0;r<n.length;r++){var o=n[r]||{},
[1:1:0712/191811.073646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191811.111678:WARNING:paced_sender.cc(261)] Elapsed time (14011 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191811.127786:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.127965:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.128160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1174
[1:1:0712/191811.128299:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f6dd3403070 0x11bd03c3c3e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.181202:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.181379:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.181602:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1182
[1:1:0712/191811.181759:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1182 0x7f6dd3403070 0x11bd05751d60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.233216:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.233415:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.233632:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1190
[1:1:0712/191811.233783:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1190 0x7f6dd3403070 0x11bd04aa6860 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.286535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.286725:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.286941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1198
[1:1:0712/191811.287107:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1198 0x7f6dd3403070 0x11bd059f35e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.338910:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.339091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.339287:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1206
[1:1:0712/191811.339426:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1206 0x7f6dd3403070 0x11bd045c2560 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.390898:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.391112:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.391346:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1214
[1:1:0712/191811.391511:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1214 0x7f6dd3403070 0x11bd03d20de0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.442842:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.443036:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.443250:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1222
[1:1:0712/191811.443403:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1222 0x7f6dd3403070 0x11bd0b529f60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.499450:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.499699:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.499951:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1230
[1:1:0712/191811.500161:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1230 0x7f6dd3403070 0x11bd0b4114e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.554518:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.554701:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.554911:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1238
[1:1:0712/191811.555064:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1238 0x7f6dd3403070 0x11bd0cbf4660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.606794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.606997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.607224:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1246
[1:1:0712/191811.607375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1246 0x7f6dd3403070 0x11bd071814e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:19:0712/191811.611235:WARNING:paced_sender.cc(261)] Elapsed time (14511 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191811.659776:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.659971:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.660194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1254
[1:1:0712/191811.660357:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1254 0x7f6dd3403070 0x11bd07036ce0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.711433:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.711615:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.711826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1262
[1:1:0712/191811.711921:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1262 0x7f6dd3403070 0x11bd0bcbab60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.765409:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d278
[1:1:0712/191811.765602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.765827:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1270
[1:1:0712/191811.765974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1270 0x7f6dd3403070 0x11bd0b958460 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 943 0x7f6dd3403070 0x11bd03b3f760 
[1:1:0712/191811.847513:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 944 0x7f6dd532b2e0 0x11bd097f4e60 , "https://www.alibaba.com/"
[1:1:0712/191811.848263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74285({"code":200,"data":{"nicheVoList":[{"materialVoList":[{"extendMap":{"tracelog":"20190712_I
[1:1:0712/191811.848415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[15566:15566:0712/191811.853370:INFO:CONSOLE(3)] "jsonp timeout", source: https://s.alicdn.com/@g/sc/aisn/0.0.7/??sc-aisn/hashmap.js,sc-aisn/home2019/common.js,sc-aisn/home2019/home.js (3)
[1:1:0712/191811.872069:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 945 0x7f6dd532b2e0 0x11bd058fd060 , "https://www.alibaba.com/"
[1:1:0712/191811.872783:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74286({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"OK","code":200,"time":63,"data":{
[1:1:0712/191811.872889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191811.940805:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191811.940975:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191811.941201:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1305
[1:1:0712/191811.941354:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1305 0x7f6dd3403070 0x11bd0712be60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:1:0712/191811.958908:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191811.959107:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3000
[1:1:0712/191811.959350:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1306
[1:1:0712/191811.959463:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7f6dd3403070 0x11bd056865e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:1:0712/191811.970590:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3500, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191811.970763:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 3500
[1:1:0712/191811.970965:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1307
[1:1:0712/191811.971100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1307 0x7f6dd3403070 0x11bd0a377660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:1:0712/191811.981654:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4000, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191811.981815:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4000
[1:1:0712/191811.981986:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1308
[1:1:0712/191811.982097:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1308 0x7f6dd3403070 0x11bd05516be0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:1:0712/191811.992407:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4500, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191811.992551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 4500
[1:1:0712/191811.992706:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1309
[1:1:0712/191811.992803:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1309 0x7f6dd3403070 0x11bd098ced60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:1:0712/191812.003153:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191812.003319:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191812.003501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1310
[1:1:0712/191812.003628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1310 0x7f6dd3403070 0x11bd098d10e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:1:0712/191812.014039:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5500, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191812.014201:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5500
[1:1:0712/191812.014375:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1311
[1:1:0712/191812.014487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1311 0x7f6dd3403070 0x11bd049d93e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:19:0712/191812.111707:WARNING:paced_sender.cc(261)] Elapsed time (15011 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191812.438088:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191812.438358:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1314
[1:1:0712/191812.438512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7f6dd3403070 0x11bd0d695fe0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
[1:19:0712/191812.612135:WARNING:paced_sender.cc(261)] Elapsed time (15511 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191812.666197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d180
[1:1:0712/191812.666404:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191812.666640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1321
[1:1:0712/191812.666802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1321 0x7f6dd3403070 0x11bd03c3c4e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 945 0x7f6dd532b2e0 0x11bd058fd060 
		remove user.10_af873479 -> 0
		remove user.11_1e479e14 -> 0
		remove user.12_bb8f7e3e -> 0
		remove user.13_edf60695 -> 0
		remove user.14_6deeb538 -> 0
[1:19:0712/191813.112541:WARNING:paced_sender.cc(261)] Elapsed time (16012 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191813.120467:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 932, 7f6dd5d48881
[1:1:0712/191813.140458:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"728 0x7f6dd3403070 0x11bd03bf86e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.140656:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"728 0x7f6dd3403070 0x11bd03bf86e0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.140850:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191813.141135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/191813.141281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191813.142397:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191813.142551:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191813.142793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1331
[1:1:0712/191813.142935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1331 0x7f6dd3403070 0x11bd071410e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 932 0x7f6dd3403070 0x11bd059f4260 
[1:1:0712/191813.143587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 897, 7f6dd5d488db
[1:1:0712/191813.164750:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.164978:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.165235:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1332
[1:1:0712/191813.165378:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1332 0x7f6dd3403070 0x11bd0d69b3e0 , 6:3_https://www.alibaba.com/, 0, , 897 0x7f6dd3403070 0x11bd097e93e0 
[1:1:0712/191813.165555:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191813.165817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var e=i("[data-goldexpokey]");e.each(function(e,t){var n=i(t),a=n.data("goldexpokey"),r=n.data("g
[1:1:0712/191813.165921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191813.208454:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191813.208636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191813.208829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1338
[1:1:0712/191813.208927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7f6dd3403070 0x11bd03bf8b60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 897 0x7f6dd3403070 0x11bd097e93e0 
[1:1:0712/191813.258637:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191813.258844:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191813.259077:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1345
[1:1:0712/191813.259205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7f6dd3403070 0x11bd097ed660 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 897 0x7f6dd3403070 0x11bd097e93e0 
[1:1:0712/191813.270194:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 954, 7f6dd5d48881
[1:1:0712/191813.293060:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"777 0x7f6dd532b2e0 0x11bd041e8b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.293258:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"777 0x7f6dd532b2e0 0x11bd041e8b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.293459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191813.293724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){var t=e.modNames.join("^");try{e.callback()}catch(n){o({gmkey:"EXP",gokey:"pos=useCallbackError&c
[1:1:0712/191813.293823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191813.496971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , document.readyState
[1:1:0712/191813.497204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191813.498548:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 851, 7f6dd5d488db
[1:1:0712/191813.520154:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.520386:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"740 0x7f6dd532b2e0 0x11bd03bfbf60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191813.520675:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1364
[1:1:0712/191813.520817:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1364 0x7f6dd3403070 0x11bd097e36e0 , 6:3_https://www.alibaba.com/, 0, , 851 0x7f6dd3403070 0x11bd0709c4e0 
[1:1:0712/191813.520993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191813.521271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){if(o.paused)return;o.next()}
[1:1:0712/191813.521425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191813.590176:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 974 0x7f6dd532b2e0 0x11bd041e8b60 , "https://www.alibaba.com/"
[1:1:0712/191813.590752:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74290({"code":200,"message":"success"});
[1:1:0712/191813.590874:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191813.612780:WARNING:paced_sender.cc(261)] Elapsed time (16512 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191813.632417:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 975 0x7f6dd532b2e0 0x11bd09943f60 , "https://www.alibaba.com/"
[1:1:0712/191813.633221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74292({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":148,"data":
[1:1:0712/191813.633621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191813.675409:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 976 0x7f6dd532b2e0 0x11bd05686d60 , "https://www.alibaba.com/"
[1:1:0712/191813.677270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74291({"code":200,"data":{"nicheVoList":[{"nicheCode":"ICBU_PC_THEME_BRAND_ZONE","subNicheVoList
[1:1:0712/191813.677487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191814.113135:WARNING:paced_sender.cc(261)] Elapsed time (17012 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191814.444604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , Ma, (a){e(28,Qs,a)}
[1:1:0712/191814.444769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191814.613496:WARNING:paced_sender.cc(261)] Elapsed time (17513 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191815.113893:WARNING:paced_sender.cc(261)] Elapsed time (18013 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191815.615167:WARNING:paced_sender.cc(261)] Elapsed time (18515 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191816.115551:WARNING:paced_sender.cc(261)] Elapsed time (19015 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191816.615940:WARNING:paced_sender.cc(261)] Elapsed time (19515 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191817.116416:WARNING:paced_sender.cc(261)] Elapsed time (20016 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191817.260681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 939, 7f6dd5d48881
[1:1:0712/191817.282640:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"759 0x7f6dd532b2e0 0x11bd06193d60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191817.282881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"759 0x7f6dd532b2e0 0x11bd06193d60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191817.283140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191817.283455:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){r(t,e,n)}
[1:1:0712/191817.283602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191817.291468:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191817.291638:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 1000
[1:1:0712/191817.291829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1440
[1:1:0712/191817.291954:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1440 0x7f6dd3403070 0x11bd0b4d3360 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 939 0x7f6dd3403070 0x11bd058fdfe0 
[1:1:0712/191817.315259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 971, 7f6dd5d48881
[1:1:0712/191817.336646:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"755 0x7f6dd3403070 0x11bd0604d560 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191817.336881:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"755 0x7f6dd3403070 0x11bd0604d560 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191817.337121:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191817.337439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){trace(type,action)}
[1:1:0712/191817.337556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191817.337898:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191817.338010:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 500
[1:1:0712/191817.338181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1441
[1:1:0712/191817.338266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7f6dd3403070 0x11bd0dbc5260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 971 0x7f6dd3403070 0x11bd065076e0 
[1:1:0712/191817.338780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 988, 7f6dd5d48881
[1:1:0712/191817.361398:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"788 0x7f6dd532b2e0 0x11bd05bb2ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191817.361609:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"788 0x7f6dd532b2e0 0x11bd05bb2ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191817.361878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191817.362158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , Ke, (){e(9)}
[1:1:0712/191817.362284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191817.616889:WARNING:paced_sender.cc(261)] Elapsed time (20516 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191818.117213:WARNING:paced_sender.cc(261)] Elapsed time (21017 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191818.617635:WARNING:paced_sender.cc(261)] Elapsed time (21517 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191819.117331:WARNING:paced_sender.cc(261)] Elapsed time (22017 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191819.617668:WARNING:paced_sender.cc(261)] Elapsed time (22517 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191820.060405:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 960, 7f6dd5d48881
[1:1:0712/191820.082258:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"777 0x7f6dd532b2e0 0x11bd041e8b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.082464:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"777 0x7f6dd532b2e0 0x11bd041e8b60 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.082717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191820.083036:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/191820.083199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191820.117978:WARNING:paced_sender.cc(261)] Elapsed time (23017 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191820.618598:WARNING:paced_sender.cc(261)] Elapsed time (23518 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191820.643270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/191820.643426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191820.648566:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/191820.648723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191820.665514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1022, 7f6dd5d48881
[1:1:0712/191820.688286:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.688489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.688695:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191820.688957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){r.default.init()}
[1:1:0712/191820.689098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191820.689868:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 8000, 0x137233629c8, 0x11bd03e4d150
[1:1:0712/191820.689981:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 8000
[1:1:0712/191820.690161:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1466
[1:1:0712/191820.690285:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1466 0x7f6dd3403070 0x11bd0b4d3260 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1022 0x7f6dd3403070 0x11bd0b6a7860 
[1:1:0712/191820.712682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1023, 7f6dd5d48881
[1:1:0712/191820.735454:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.735668:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.735944:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191820.736295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){a.reportTrace()}
[1:1:0712/191820.736473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191820.875227:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1027, 7f6dd5d48881
[1:1:0712/191820.897176:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.897478:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191820.897808:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191820.898121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){a()(window.__icbu_globaljs_config__["l-d-abkey"],window.__icbu_globaljs_config__["l-d-percent"])?
[1:1:0712/191820.898214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191820.981582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1043 0x7f6dd532b2e0 0x11bd0ab12be0 , "https://www.alibaba.com/"
[1:1:0712/191820.982347:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74289({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"成功执行命令","code":200,"d
[1:1:0712/191820.982519:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191821.059130:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1044 0x7f6dd532b2e0 0x11bd0acc06e0 , "https://www.alibaba.com/"
[1:1:0712/191821.059975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74288({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"成功执行命令","code":200,"d
[1:1:0712/191821.060132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191821.119075:WARNING:paced_sender.cc(261)] Elapsed time (24018 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191821.153323:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1046 0x7f6dd532b2e0 0x11bd0bbfd4e0 , "https://www.alibaba.com/"
[1:1:0712/191821.154047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74287({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"成功执行命令","code":200,"d
[1:1:0712/191821.154175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191821.244097:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1047 0x7f6dd532b2e0 0x11bd07a4b360 , "https://www.alibaba.com/"
[1:1:0712/191821.244692:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74294({"encode":"UTF-8","ret":["SUCCESS::CALL SUCCESS"],"msg":"OK","code":200,"time":4,"data":{}
[1:1:0712/191821.244804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191821.313161:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1049 0x7f6dd532b2e0 0x11bd0709c0e0 , "https://www.alibaba.com/"
[1:1:0712/191821.315258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp74293({"ret":["SUCCESS::CALL SUCCESS"],"encode":"UTF-8","msg":"OK","code":200,"time":177,"data":
[1:1:0712/191821.315423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191821.619389:WARNING:paced_sender.cc(261)] Elapsed time (24519 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191822.004885:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x137233629c8, 0x11bd03e4d138
[1:1:0712/191822.005089:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 100
[1:1:0712/191822.005340:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1492
[1:1:0712/191822.005491:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1492 0x7f6dd3403070 0x11bd0dbc19e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1049 0x7f6dd532b2e0 0x11bd0709c0e0 
[1:1:0712/191822.007719:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x137233629c8, 0x11bd03e4d138
[1:1:0712/191822.007857:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 100
[1:1:0712/191822.008043:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1493
[1:1:0712/191822.008168:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1493 0x7f6dd3403070 0x11bd0de71960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1049 0x7f6dd532b2e0 0x11bd0709c0e0 
[1:1:0712/191822.009166:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x137233629c8, 0x11bd03e4d138
[1:1:0712/191822.009286:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 100
[1:1:0712/191822.009457:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1494
[1:1:0712/191822.009559:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1494 0x7f6dd3403070 0x11bd03c497e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1049 0x7f6dd532b2e0 0x11bd0709c0e0 
[1:1:0712/191822.069134:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1050 0x7f6dd532b2e0 0x11bd055fde60 , "https://www.alibaba.com/"
[1:1:0712/191822.069744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , ,  mtopjsonp1({"api":"mtop.alibaba.intl.localization.getmullangquantityunits","data":{},"ret":["FAIL_S
[1:1:0712/191822.069848:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191822.119713:WARNING:paced_sender.cc(261)] Elapsed time (25019 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191822.197789:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 20000, 0x137233629c8, 0x11bd03e4d178
[1:1:0712/191822.197978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 20000
[1:1:0712/191822.198223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1517
[1:1:0712/191822.198402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1517 0x7f6dd3403070 0x11bd043f2ae0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1050 0x7f6dd532b2e0 0x11bd055fde60 
[1:1:0712/191822.347706:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1052 0x7f6dd532b2e0 0x11bd0aaf97e0 , "https://www.alibaba.com/"
[1:1:0712/191822.352895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0712/191822.353090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191822.453575:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d188
[1:1:0712/191822.453765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191822.453992:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1539
[1:1:0712/191822.454139:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1539 0x7f6dd3403070 0x11bd09769c60 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1052 0x7f6dd532b2e0 0x11bd0aaf97e0 
[1:1:0712/191822.504530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1053 0x7f6dd532b2e0 0x11bd0aca66e0 , "https://www.alibaba.com/"
[1:1:0712/191822.505209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , 



jsonpFooterCallback({"cityName":"beijing","countryCode":"CN","countryName":"CHINA (MAINLAND)
[1:1:0712/191822.505339:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191822.507304:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191822.579925:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1055 0x7f6dd532b2e0 0x11bd07093d60 , "https://www.alibaba.com/"
[1:1:0712/191822.580678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , __jp0({"code":200,"data":{"nicheVoList":[{"materialVoList":[{"extendMap":{"tracelog":"20190712_ICBU_
[1:1:0712/191822.580825:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191822.619216:WARNING:paced_sender.cc(261)] Elapsed time (25519 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191822.753232:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d188
[1:1:0712/191822.753438:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191822.753647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1555
[1:1:0712/191822.753758:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1555 0x7f6dd3403070 0x11bd0dbc1960 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1055 0x7f6dd532b2e0 0x11bd07093d60 
[1:1:0712/191822.878012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1056 0x7f6dd532b2e0 0x11bd070cbd60 , "https://www.alibaba.com/"
[1:1:0712/191822.878584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , /**/GDPR_NOTICE_GET_INFO_FUN_1562930287200({"code":200,"data":{"needShow":false,"gdprNotice":"We use
[1:1:0712/191822.878729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191823.119573:WARNING:paced_sender.cc(261)] Elapsed time (26019 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191823.159288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1028, 7f6dd5d48881
[1:1:0712/191823.181989:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191823.182182:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191823.182424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191823.182711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){a()(window.__icbu_globaljs_config__["l-d-abkey"],window.__icbu_globaljs_config__["l-d-percent"])?
[1:1:0712/191823.182830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:19:0712/191823.620000:WARNING:paced_sender.cc(261)] Elapsed time (26519 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191824.120450:WARNING:paced_sender.cc(261)] Elapsed time (27020 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191824.620745:WARNING:paced_sender.cc(261)] Elapsed time (27520 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191824.833978:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1114, 7f6dd5d488db
[1:1:0712/191824.857909:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"819 0x7f6dd3403070 0x11bd06de3360 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191824.858203:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"819 0x7f6dd3403070 0x11bd06de3360 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191824.858537:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 6:3_https://www.alibaba.com/, 1595
[1:1:0712/191824.858663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1595 0x7f6dd3403070 0x11bd0b9599e0 , 6:3_https://www.alibaba.com/, 0, , 1114 0x7f6dd3403070 0x11bd0ad8d3e0 
[1:1:0712/191824.858920:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191824.859215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){if(n[0]&&n[0].contentWindow&&n[0].Messenger){for(var e=0,t=l.length;e<t;e++){l[e](n)}l.length=0;w
[1:1:0712/191824.859351:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191824.966138:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 6:4_https://i.alicdn.com/
[1:21:0712/191824.970131:WARNING:paced_sender.cc(261)] Elapsed time (2500 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191825.001350:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://www.alibaba.com/"
[1:1:0712/191825.001722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , n.onerror, (){o.do_tracker_jserror({message:"loadError",error:"",filename:"sendImg"}),i()}
[1:1:0712/191825.001824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191825.077890:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.alibaba.com/"
[1:1:0712/191825.078365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , d.onload, (){dotBanner(a,b,c)}
[1:1:0712/191825.078468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191825.115237:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x137233629c8, 0x11bd03e4d210
[1:1:0712/191825.115449:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.alibaba.com/", 5000
[1:1:0712/191825.115708:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1605
[1:1:0712/191825.115865:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1605 0x7f6dd3403070 0x11bd04e979e0 , 6:3_https://www.alibaba.com/, 1, -6:3_https://www.alibaba.com/, 1134 0x7f6dd3403070 0x11bd0586d560 
[1:19:0712/191825.121086:WARNING:paced_sender.cc(261)] Elapsed time (28020 ms) longer than expected, limiting to 2000 ms
[1:1:0712/191825.272874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 6:3_https://www.alibaba.com/, 1029, 7f6dd5d48881
[1:1:0712/191825.296886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"183e99c42860","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191825.297173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-6:3_https://www.alibaba.com/","ptid":"793 0x7f6dd532b2e0 0x11bd03bf9ee0 ","rf":"6:3_https://www.alibaba.com/"}
[1:1:0712/191825.297455:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.alibaba.com/"
[1:1:0712/191825.297766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -6:3_https://www.alibaba.com/, 183e99c42860, , , (){a()(window.__icbu_globaljs_config__["l-d-abkey"],window.__icbu_globaljs_config__["l-d-percent"])?
[1:1:0712/191825.297905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.alibaba.com/", "alibaba.com", 3, 1, , , 0
[1:1:0712/191825.458856:ERROR:resource_dispatcher.cc(373)] unknown request
[15566:15566:0712/191825.461605:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://www.alibaba.com/' was loaded over HTTPS, but requested an insecure Beacon endpoint 'http://err.taobao.com/error1.html'. This request has been blocked; the content must be served over HTTPS.", source: https://www.alibaba.com/ (0)
[1:21:0712/191825.470486:WARNING:paced_sender.cc(261)] Elapsed time (3001 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191825.621419:WARNING:paced_sender.cc(261)] Elapsed time (28521 ms) longer than expected, limiting to 2000 ms
[1:21:0712/191825.970940:WARNING:paced_sender.cc(261)] Elapsed time (3501 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191826.121815:WARNING:paced_sender.cc(261)] Elapsed time (29021 ms) longer than expected, limiting to 2000 ms
[1:21:0712/191826.471327:WARNING:paced_sender.cc(261)] Elapsed time (4002 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191826.622211:WARNING:paced_sender.cc(261)] Elapsed time (29522 ms) longer than expected, limiting to 2000 ms
[1:21:0712/191826.971501:WARNING:paced_sender.cc(261)] Elapsed time (4502 ms) longer than expected, limiting to 2000 ms
[1:19:0712/191827.122698:WARNING:paced_sender.cc(261)] Elapsed time (30022 ms) longer than expected, limiting to 2000 ms
