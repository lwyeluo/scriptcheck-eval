[0712/124422.338051:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124422.338306:INFO:switcher_clone.cc(787)] backtrace rip is 7f184cb31891
[0712/124422.884155:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124422.884400:INFO:switcher_clone.cc(787)] backtrace rip is 7f21044a5891
[1:1:0712/124422.888217:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/124422.888380:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/124422.891075:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[17932:17932:0712/124423.601590:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/378edcc7-6eb1-4d0e-8271-c85728736def
[0712/124423.714359:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/124423.714619:INFO:switcher_clone.cc(787)] backtrace rip is 7fae93e13891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[17932:17932:0712/124423.848990:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[17932:17962:0712/124423.849395:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/124423.849522:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124423.849669:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124423.849970:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124423.850079:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/124423.854079:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xfe8f5d3, 1
[1:1:0712/124423.854282:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xa578d91, 0
[1:1:0712/124423.854376:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2896ea34, 3
[1:1:0712/124423.854459:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1f2021ac, 2
[1:1:0712/124423.854552:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff91ffffff8d570a ffffffd3fffffff5ffffffe80f ffffffac21201f 34ffffffeaffffff9628 , 10104, 4
[1:1:0712/124423.855263:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[17932:17962:0712/124423.855374:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��W
����! 4�(yn�:
[17932:17962:0712/124423.855409:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��W
����! 4�(��yn�:
[17932:17962:0712/124423.855561:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[17932:17962:0712/124423.855590:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 17978, 4, 918d570a d3f5e80f ac21201f 34ea9628 
[1:1:0712/124423.855477:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21026df0a0, 3
[1:1:0712/124423.855841:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f210286b080, 2
[1:1:0712/124423.855929:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f20ec52dd20, -2
[17964:17964:0712/124423.861686:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=17964
[17979:17979:0712/124423.862983:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=17979
[1:1:0712/124423.863480:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124423.863917:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f2021ac
[1:1:0712/124423.864386:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f2021ac
[1:1:0712/124423.865144:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f2021ac
[1:1:0712/124423.865681:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.865814:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.866015:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.866105:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.866355:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f2021ac
[1:1:0712/124423.866493:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21044a57ba
[1:1:0712/124423.866565:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f210449cdef, 7f21044a577a, 7f21044a70cf
[1:1:0712/124423.868241:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1f2021ac
[1:1:0712/124423.868401:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1f2021ac
[1:1:0712/124423.868699:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1f2021ac
[1:1:0712/124423.869487:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.869590:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.869683:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.869777:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1f2021ac
[1:1:0712/124423.870269:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1f2021ac
[1:1:0712/124423.870442:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21044a57ba
[1:1:0712/124423.870521:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f210449cdef, 7f21044a577a, 7f21044a70cf
[1:1:0712/124423.873113:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124423.873296:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124423.873373:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff80413218, 0x7fff80413198)
[1:1:0712/124423.879785:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124423.882499:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[17932:17932:0712/124424.295148:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17932:17932:0712/124424.295622:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/124424.297259:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xfeeb26c6220
[1:1:0712/124424.297397:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[17932:17944:0712/124424.303784:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[17932:17944:0712/124424.303848:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[17932:17932:0712/124424.303861:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[17932:17932:0712/124424.303905:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[17932:17932:0712/124424.303969:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,17978, 4
[1:7:0712/124424.304887:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[17932:17956:0712/124424.341576:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/124424.547576:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[17932:17932:0712/124425.172054:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[17932:17932:0712/124425.172141:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/124425.188185:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124425.189842:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124425.605574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/124425.605759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124425.611193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/124425.611347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124425.641117:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124425.746602:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124425.746762:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124425.867455:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124425.870069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/124425.870213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124425.882325:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124425.885299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/124425.885437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124425.889297:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17932:17932:0712/124425.889945:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/124425.891028:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xfeeb26c4e20
[1:1:0712/124425.891128:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[17932:17932:0712/124425.892464:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[17932:17932:0712/124425.903935:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[17932:17932:0712/124425.904025:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/124425.923928:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124426.231354:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f20ee1082e0 0xfeeb28ac5e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124426.232013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/124426.232153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124426.232721:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[17932:17932:0712/124426.258126:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/124426.259261:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xfeeb26c5820
[1:1:0712/124426.259435:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[17932:17932:0712/124426.260671:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/124426.266462:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/124426.266593:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[17932:17932:0712/124426.267660:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[17932:17932:0712/124426.271721:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17932:17932:0712/124426.272120:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17932:17944:0712/124426.276612:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[17932:17944:0712/124426.276663:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[17932:17932:0712/124426.276684:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[17932:17932:0712/124426.276724:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[17932:17932:0712/124426.276784:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,17978, 4
[1:7:0712/124426.278206:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124426.536831:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/124426.653112:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 468 0x7f20ee1082e0 0xfeeb297f6e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124426.653734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/124426.653914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124426.654331:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[17932:17932:0712/124426.816563:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[17932:17932:0712/124426.816649:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/124426.828162:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124426.972186:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[17932:17932:0712/124427.158856:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[17932:17962:0712/124427.159125:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/124427.159253:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/124427.159384:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/124427.159580:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/124427.159659:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/124427.161823:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2eedfffb, 1
[1:1:0712/124427.162018:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2ed389cc, 0
[1:1:0712/124427.162113:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x25b2b41b, 3
[1:1:0712/124427.162209:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2d06fa11, 2
[1:1:0712/124427.162287:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffccffffff89ffffffd32e fffffffbffffffffffffffed2e 11fffffffa062d 1bffffffb4ffffffb225 , 10104, 5
[1:1:0712/124427.162993:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[17932:17962:0712/124427.163206:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING̉�.���.�-��%
p�:
[17932:17962:0712/124427.163247:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ̉�.���.�-��%x�
p�:
[1:1:0712/124427.163203:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f21026df0a0, 3
[17932:17962:0712/124427.163383:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18027, 5, cc89d32e fbffed2e 11fa062d 1bb4b225 
[1:1:0712/124427.163396:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f210286b080, 2
[1:1:0712/124427.163492:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f20ec52dd20, -2
[1:1:0712/124427.171161:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124427.171547:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124427.172968:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/124427.173204:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d06fa11
[1:1:0712/124427.173629:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d06fa11
[1:1:0712/124427.173902:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d06fa11
[1:1:0712/124427.174416:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.174515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.174615:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.174708:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.174957:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d06fa11
[1:1:0712/124427.175086:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21044a57ba
[1:1:0712/124427.175161:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f210449cdef, 7f21044a577a, 7f21044a70cf
[1:1:0712/124427.176884:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2d06fa11
[1:1:0712/124427.177098:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2d06fa11
[1:1:0712/124427.177418:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2d06fa11
[1:1:0712/124427.178231:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.178350:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.178448:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.178556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2d06fa11
[1:1:0712/124427.179072:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2d06fa11
[1:1:0712/124427.179241:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f21044a57ba
[1:1:0712/124427.179322:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f210449cdef, 7f21044a577a, 7f21044a70cf
[1:1:0712/124427.182140:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/124427.182347:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/124427.182434:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff80413218, 0x7fff80413198)
[1:1:0712/124427.191258:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/124427.193338:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/124427.285831:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xfeeb269b220
[1:1:0712/124427.285986:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/124427.368500:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124427.370140:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2880ee28e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/124427.370310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/124427.372681:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124427.426993:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/124427.427621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2880ee161f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/124427.427742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/124427.508045:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124427.508943:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/124427.509090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2880ee28e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/124427.509257:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/124427.574205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/124427.574632:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/124427.574722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2880ee28e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/124427.574827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[17932:17932:0712/124427.645286:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17932:17932:0712/124427.648506:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17932:17944:0712/124427.664913:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[17932:17944:0712/124427.664996:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[17932:17932:0712/124427.665597:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://light.1688.com/
[17932:17932:0712/124427.665870:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://light.1688.com/, https://light.1688.com/, 1
[17932:17932:0712/124427.665939:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://light.1688.com/, HTTP/1.1 200 status:200 date:Fri, 12 Jul 2019 04:44:27 GMT content-type:text/html vary:Accept-Encoding content-language:cn age:1301 x-cache:HIT from cm10-static-010 content-encoding:gzip server:Tengine/Aserver eagleeye-traceid:0bfa263215629066676034815ec9c1 strict-transport-security:max-age=31536000 timing-allow-origin:*  ,18027, 5
[1:7:0712/124427.668563:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/124427.683959:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://light.1688.com/
[17932:17932:0712/124427.742556:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://light.1688.com/, https://light.1688.com/, 1
[17932:17932:0712/124427.742619:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://light.1688.com/, https://light.1688.com
[1:1:0712/124427.752050:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/124427.799682:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124427.836433:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124427.836620:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://light.1688.com/"
[1:1:0712/124428.006346:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/124428.046971:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/124428.075055:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/124428.124809:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/124428.152525:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/124428.204439:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/124428.242844:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/124428.269661:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/124428.374492:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f20ec1e0070 0xfeeb29e81e0 , "https://light.1688.com/"
[1:1:0712/124428.375522:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , /* Disable minification (remove `.min` from URL path) for more info */

(function(undefined) {!funct
[1:1:0712/124428.375693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124428.378615:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124428.382828:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f20ec1e0070 0xfeeb29e81e0 , "https://light.1688.com/"
[1:1:0712/124428.404028:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f20ec1e0070 0xfeeb29e81e0 , "https://light.1688.com/"
[1:1:0712/124428.407479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 215 0x7f20ec1e0070 0xfeeb29e81e0 , "https://light.1688.com/"
[1:1:0712/124429.009498:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f20ec1e0070 0xfeeb2874160 , "https://light.1688.com/"
[1:1:0712/124429.010192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , 
with(document)with(body)with(insertBefore(createElement("script"),firstChild))setAttribute("exparam
[1:1:0712/124429.010377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124429.019948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f20ec1e0070 0xfeeb2874160 , "https://light.1688.com/"
[1:1:0712/124429.494502:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.481057, 447, 1
[1:1:0712/124429.494689:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124429.600617:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124429.600815:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://light.1688.com/"
[1:1:0712/124429.601571:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 300 0x7f20ec1e0070 0xfeeb29e4560 , "https://light.1688.com/"
[1:1:0712/124429.602190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , 
          window.__get_croco_version_map__ = function(){
            return {"@alife/ocms-fusion-16
[1:1:0712/124429.602356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124429.609694:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00883102, 70, 1
[1:1:0712/124429.609836:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124429.635090:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 305 0x7f20ee1082e0 0xfeeb2af68e0 , "https://light.1688.com/"
[1:1:0712/124429.636473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , /*! 2018-09-12 16:37:31 v0.1.0 */
!function(t){function n(o){if(e[o])return e[o].exports;var u=e[o]=
[1:1:0712/124429.636625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124432.442863:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[3:3:0712/124435.493544:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/124435.703167:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124435.703381:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://light.1688.com/"
[1:1:0712/124435.711887:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 320 0x7f20ec1e0070 0xfeeb2762ee0 , "https://light.1688.com/"
[1:1:0712/124435.760470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , __def("react/15.x/index",["require","module","exports"],function(e,t,n){!function(e){if("object"==ty
[1:1:0712/124435.760649:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124435.883145:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124435.899857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/124435.900078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124436.053997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/124436.054357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124436.063014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/124436.063193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124436.671018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124436.671184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.098375:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124437.099058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.292184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124437.292538:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.309362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (e){t(e)}
[1:1:0712/124437.309509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.311583:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f20ff73fbb0 0xfeeb271a600 0 , "https://light.1688.com/"
[1:1:0712/124437.461261:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124437.499549:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205ded0
[1:1:0712/124437.499711:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124437.499920:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 440
[1:1:0712/124437.500075:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 440 0x7f20ec1e0070 0xfeeb23ccf60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 424 0x7f20ff73fbb0 0xfeeb271a600 0 
[1:1:0712/124437.532911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205ded0
[1:1:0712/124437.533122:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124437.533382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 442
[1:1:0712/124437.533536:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 442 0x7f20ec1e0070 0xfeeb2afaae0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 424 0x7f20ff73fbb0 0xfeeb271a600 0 
[1:1:0712/124437.600188:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205ded0
[1:1:0712/124437.600383:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124437.600600:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 452
[1:1:0712/124437.600742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 452 0x7f20ec1e0070 0xfeeb2f053e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 424 0x7f20ff73fbb0 0xfeeb271a600 0 
[1:1:0712/124437.608861:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x199524c029c8, 0xfeeb205ded0
[1:1:0712/124437.609012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 10
[1:1:0712/124437.609208:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 453
[1:1:0712/124437.609321:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 453 0x7f20ec1e0070 0xfeeb2343be0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 424 0x7f20ff73fbb0 0xfeeb271a600 0 
[1:1:0712/124437.730847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124437.731016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.789078:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , highWaterMark =>
new BuiltInCountQueuingStrategy(highWaterMark)
[1:1:0712/124437.789318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.794284:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , SetUpReadableStreamDefaultController.thenPromise, () => {
controller[_readableStreamDefaultControllerBits] |= STARTED;
ReadableStreamDefaultController
[1:1:0712/124437.794474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124437.957272:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205d8b0
[1:1:0712/124437.957456:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124437.957648:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 486
[1:1:0712/124437.957765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7f20ec1e0070 0xfeeb2f00460 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 441
[1:1:0712/124438.189107:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 453, 7f20eeb25881
[1:1:0712/124438.196268:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124438.196436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124438.196637:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124438.196941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){n&&"script"==n.tagName.toLowerCase()||r.addScript(p,"","aplus-sufei")}
[1:1:0712/124438.197024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.233989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124438.234143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.518969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 442, 7f20eeb25881
[1:1:0712/124438.527204:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124438.527367:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124438.527559:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124438.527816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124438.527912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.528441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124438.528519:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124438.528665:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 518
[1:1:0712/124438.528754:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 518 0x7f20ec1e0070 0xfeeb2340760 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 442 0x7f20ec1e0070 0xfeeb2afaae0 
[1:1:0712/124438.589116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124438.589272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.614607:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124438.615415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , n.onload, (){i()}
[1:1:0712/124438.615525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.655468:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 511 0x7f20ee1082e0 0xfeeb3fb2fe0 , "https://light.1688.com/"
[1:1:0712/124438.659989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , /*! 2019-07-08 18:00:36 v8.12.0 */
!function(e){function t(o){if(n[o])return n[o].exports;var r=n[o]
[1:1:0712/124438.660117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.674975:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205da50
[1:1:0712/124438.675129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124438.675302:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 528
[1:1:0712/124438.675410:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7f20ec1e0070 0xfeeb23c8360 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 511 0x7f20ee1082e0 0xfeeb3fb2fe0 
[1:1:0712/124438.949829:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 512 0x7f20ee1082e0 0xfeeb40542e0 , "https://light.1688.com/"
[1:1:0712/124438.954213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , /*! 2019-07-08 18:00:35 v8.12.0 */
!function(t){function e(r){if(n[r])return n[r].exports;var o=n[r]
[1:1:0712/124438.954356:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124438.966710:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124438.966851:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124438.967017:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 534
[1:1:0712/124438.967119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 534 0x7f20ec1e0070 0xfeeb2af62e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 512 0x7f20ee1082e0 0xfeeb40542e0 
[1:1:0712/124439.132031:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 514 0x7f20ee1082e0 0xfeeb405d760 , "https://light.1688.com/"
[1:1:0712/124439.132796:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (function(a,e,t,i,o){var n=i.userAgent;var r=e.getElementsByTagName("head")[0];function c(a){var t=e
[1:1:0712/124439.132947:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.170211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 440, 7f20eeb25881
[1:1:0712/124439.179822:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124439.180016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124439.180258:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124439.180584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){var e=r.getUrl(t.options.context.etag||{});a.loadScript(e,function(e){e&&"error"!==e.type&&o.setL
[1:1:0712/124439.180682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.204273:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124439.204696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , n.onload, (){i()}
[1:1:0712/124439.204799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.287412:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124439.287772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.326160:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 518, 7f20eeb25881
[1:1:0712/124439.333849:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"442 0x7f20ec1e0070 0xfeeb2afaae0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124439.334029:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"442 0x7f20ec1e0070 0xfeeb2afaae0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124439.334256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124439.334583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124439.334755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.335310:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124439.335445:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124439.335690:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 561
[1:1:0712/124439.335842:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 561 0x7f20ec1e0070 0xfeeb3fc43e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 518 0x7f20ec1e0070 0xfeeb2340760 
[1:1:0712/124439.447351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124439.447516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.457516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (e){l(e,function(e){e.intersectionRatio>0&&r(e)})}
[1:1:0712/124439.457675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.473596:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x199524c029c8, 0xfeeb205dbe0
[1:1:0712/124439.473741:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 300
[1:1:0712/124439.473906:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 573
[1:1:0712/124439.474010:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 573 0x7f20ec1e0070 0xfeeb34cd560 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 554 0x7f20ee1082e0 0xfeeb3fb3060 
[1:1:0712/124439.483171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x199524c029c8, 0xfeeb205dbe0
[1:1:0712/124439.483272:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 300
[1:1:0712/124439.483415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 574
[1:1:0712/124439.483513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 574 0x7f20ec1e0070 0xfeeb37084e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 554 0x7f20ee1082e0 0xfeeb3fb3060 
[1:1:0712/124439.491657:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x199524c029c8, 0xfeeb205dbe0
[1:1:0712/124439.491835:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 300
[1:1:0712/124439.492030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 575
[1:1:0712/124439.492140:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 575 0x7f20ec1e0070 0xfeeb2f00860 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 554 0x7f20ee1082e0 0xfeeb3fb3060 
[1:1:0712/124439.576958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 564 0x7f20ee1082e0 0xfeeb2efdee0 , "https://light.1688.com/"
[1:1:0712/124439.577997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , !function(n,t,i,r,a,o,e,c,u,f,s,l,m,h,v){var p,d=374,g="isg",y=c,b=!!y.addEventListener,w=u.getEleme
[1:1:0712/124439.578107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.659794:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124439.660083:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/124439.660814:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:17:0712/124439.663010:ERROR:adm_helpers.cc(73)] Failed to query stereo recording.
[1:1:0712/124439.670920:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205d990
[1:1:0712/124439.671079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124439.671261:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 592
[1:1:0712/124439.671368:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 592 0x7f20ec1e0070 0xfeeb29e96e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 564 0x7f20ee1082e0 0xfeeb2efdee0 
[1:1:0712/124439.709426:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 565 0x7f20ee1082e0 0xfeeb2343be0 , "https://light.1688.com/"
[1:1:0712/124439.709981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , window.goldlog=(window.goldlog||{});goldlog.Etag="x72HFb6WgX0CAXlFE14b37jj";goldlog.stag=1;
[1:1:0712/124439.710128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124439.710442:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124439.745463:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 569 0x7f20ee1082e0 0xfeeb4531a60 , "https://light.1688.com/"
[1:1:0712/124439.748229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , !function(){function e(e,a){for(var r=1;void 0!==r;){var s=-1&r,c=r>>-(1/0),b=-1&c;switch(s){case 0:
[1:1:0712/124439.748371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124441.019662:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205d990
[1:1:0712/124441.019833:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124441.020069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 609
[1:1:0712/124441.020239:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 609 0x7f20ec1e0070 0xfeeb277bee0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 569 0x7f20ee1082e0 0xfeeb4531a60 
[1:19:0712/124441.690517:WARNING:paced_sender.cc(261)] Elapsed time (2003 ms) longer than expected, limiting to 2000 ms
[1:19:0712/124442.190964:WARNING:paced_sender.cc(261)] Elapsed time (2504 ms) longer than expected, limiting to 2000 ms
[1:19:0712/124442.692191:WARNING:paced_sender.cc(261)] Elapsed time (3005 ms) longer than expected, limiting to 2000 ms
[1:21:0712/124443.039486:WARNING:paced_sender.cc(261)] Elapsed time (2004 ms) longer than expected, limiting to 2000 ms
[1:19:0712/124443.192508:WARNING:paced_sender.cc(261)] Elapsed time (3505 ms) longer than expected, limiting to 2000 ms
[1:21:0712/124443.539824:WARNING:paced_sender.cc(261)] Elapsed time (2504 ms) longer than expected, limiting to 2000 ms
		remove user.e_e417b55e -> 0
		remove user.f_e23a7c7c -> 0
		remove user.10_93970731 -> 0
		remove user.11_1072b13 -> 0
		remove user.12_4bd95985 -> 0
		remove user.13_755fdd66 -> 0
		remove user.14_90a482d9 -> 0
[1:19:0712/124443.692699:WARNING:paced_sender.cc(261)] Elapsed time (4006 ms) longer than expected, limiting to 2000 ms
[1:21:0712/124444.041152:WARNING:paced_sender.cc(261)] Elapsed time (3005 ms) longer than expected, limiting to 2000 ms
[1:19:0712/124444.192196:WARNING:paced_sender.cc(261)] Elapsed time (4505 ms) longer than expected, limiting to 2000 ms
[1:21:0712/124444.541504:WARNING:paced_sender.cc(261)] Elapsed time (3506 ms) longer than expected, limiting to 2000 ms
[1:19:0712/124444.692417:WARNING:paced_sender.cc(261)] Elapsed time (5005 ms) longer than expected, limiting to 2000 ms
[1:21:0712/124445.041858:WARNING:paced_sender.cc(261)] Elapsed time (4006 ms) longer than expected, limiting to 2000 ms
[1:19:0712/124445.192985:WARNING:paced_sender.cc(261)] Elapsed time (5506 ms) longer than expected, limiting to 2000 ms
[17932:17932:0712/124445.500395:INFO:CONSOLE(4)] "", source: https://g.alicdn.com/secdev/nsv/1.0.60/ns_b_71_3_f.js (4)
[1:21:0712/124445.543170:WARNING:paced_sender.cc(261)] Elapsed time (4507 ms) longer than expected, limiting to 2000 ms
[1:1:0712/124445.556032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124445.556242:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124445.652217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (n){G=n}
[1:1:0712/124445.652422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:19:0712/124445.694045:WARNING:paced_sender.cc(261)] Elapsed time (6007 ms) longer than expected, limiting to 2000 ms
[1:1:0712/124445.750337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (n){a.setLocalDescription(n,function(){},function(){})}
[1:1:0712/124445.750525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124445.937321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , W, (e){var a="set";a+="Loca",a&&(a+="lDesc"),a+="ription",Ha[a](e)}
[1:1:0712/124445.937525:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124445.977401:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 573, 7f20eeb25881
[1:1:0712/124445.986501:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"554 0x7f20ee1082e0 0xfeeb3fb3060 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124445.986826:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"554 0x7f20ee1082e0 0xfeeb3fb3060 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124445.987112:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124445.987425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i=p.filterEndExposureSize(a,r),i>0&&goldlog.aplus_pubsub.publish(n,{size:i,eventType:r})}
[1:1:0712/124445.987572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:21:0712/124446.043354:WARNING:paced_sender.cc(261)] Elapsed time (5008 ms) longer than expected, limiting to 2000 ms
[1:1:0712/124446.045884:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 574, 7f20eeb25881
[1:1:0712/124446.057668:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"554 0x7f20ee1082e0 0xfeeb3fb3060 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.057891:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"554 0x7f20ee1082e0 0xfeeb3fb3060 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.058138:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.058462:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i=p.filterEndExposureSize(a,r),i>0&&goldlog.aplus_pubsub.publish(n,{size:i,eventType:r})}
[1:1:0712/124446.058566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.106928:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 575, 7f20eeb25881
[1:1:0712/124446.118098:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"554 0x7f20ee1082e0 0xfeeb3fb3060 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.118333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"554 0x7f20ee1082e0 0xfeeb3fb3060 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.118591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.118860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i=p.filterEndExposureSize(a,r),i>0&&goldlog.aplus_pubsub.publish(n,{size:i,eventType:r})}
[1:1:0712/124446.118981:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.186967:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 561, 7f20eeb25881
[1:19:0712/124446.194366:WARNING:paced_sender.cc(261)] Elapsed time (6507 ms) longer than expected, limiting to 2000 ms
[1:1:0712/124446.197511:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"518 0x7f20ec1e0070 0xfeeb2340760 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.197680:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"518 0x7f20ec1e0070 0xfeeb2340760 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.197950:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.198254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124446.198425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.198846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124446.198974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124446.199177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 680
[1:1:0712/124446.199289:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 680 0x7f20ec1e0070 0xfeeb44f06e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 561 0x7f20ec1e0070 0xfeeb3fc43e0 
[1:1:0712/124446.199723:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 452, 7f20eeb25881
[1:1:0712/124446.210374:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.210542:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"424 0x7f20ff73fbb0 0xfeeb271a600 0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.210727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.210981:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/124446.211100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.216744:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 486, 7f20eeb25881
[1:1:0712/124446.226709:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"441","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.226904:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"441","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.227141:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.227689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/124446.227814:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.251032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124446.251179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.252297:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 528, 7f20eeb25881
[1:1:0712/124446.263135:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"511 0x7f20ee1082e0 0xfeeb3fb2fe0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.263318:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"511 0x7f20ee1082e0 0xfeeb3fb2fe0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.263537:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.263814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){l||a.logger({msg:"aplus_auto_exp_init failed! please check whether aplusJs is loaded correctly!"}
[1:1:0712/124446.263925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.264537:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 534, 7f20eeb25881
[1:1:0712/124446.275017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"512 0x7f20ee1082e0 0xfeeb40542e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.275179:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"512 0x7f20ee1082e0 0xfeeb40542e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.275378:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.275631:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){l||o.logger({msg:"aplus_ac_init failed! please check whether aplusJs is loaded correctly!"})}
[1:1:0712/124446.275727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.276277:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 592, 7f20eeb25881
[1:1:0712/124446.285353:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"564 0x7f20ee1082e0 0xfeeb2efdee0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.285475:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"564 0x7f20ee1082e0 0xfeeb2efdee0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.285642:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.285865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (n){try{a.close()}catch(t){}}
[1:1:0712/124446.285959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:17:0712/124446.462956:WARNING:stunport.cc(403)] Port[0xfeeb3903c20:data:1:0:local:Net[any:::/0:Unknown]]: StunPort: stun host lookup received error 0
[1:21:0712/124446.543501:WARNING:paced_sender.cc(261)] Elapsed time (5508 ms) longer than expected, limiting to 2000 ms
[1:17:0712/124446.558923:WARNING:p2ptransportchannel.cc(714)] Port[0xfeeb36f2920:data:1:0:local:Net[any:0.0.0.0/0:Unknown]]: SetOption(5, 0) failed: 0
[1:17:0712/124446.559368:WARNING:p2ptransportchannel.cc(714)] Port[0xfeeb45db020:data:1:0:local:Net[any:::/0:Unknown]]: SetOption(5, 0) failed: 0
[1:1:0712/124446.670889:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 609, 7f20eeb25881
[1:1:0712/124446.679726:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"569 0x7f20ee1082e0 0xfeeb4531a60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.679888:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"569 0x7f20ee1082e0 0xfeeb4531a60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124446.680074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124446.680337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , ee, (e){try{for(var a="\u015c\u0165\u0168\u016c\u015e",r="",s=0;s<a.length;s++){var c=a.charCodeAt(s)-24
[1:1:0712/124446.680450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124446.913682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f20ec548bd0 0xfeeb4bf70d8 , "https://light.1688.com/"
[1:1:0712/124446.930927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , __def("@alife/next/0.x/index",["require","react/15.x/index","prop-types/15.x/index","classnames/2.x/
[1:1:0712/124446.931101:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124447.263245:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f20ec548bd0 0xfeeb4bf70d8 , "https://light.1688.com/"
[1:1:0712/124447.367643:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f20ec548bd0 0xfeeb4bf70d8 , "https://light.1688.com/"
[1:1:0712/124447.491708:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f20ec548bd0 0xfeeb4bf70d8 , "https://light.1688.com/"
[1:1:0712/124447.516646:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 179, 0x199524c029c8, 0xfeeb205da90
[1:1:0712/124447.516808:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 179
[1:1:0712/124447.516981:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 725
[1:1:0712/124447.517095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 725 0x7f20ec1e0070 0xfeeb6aff660 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124447.617407:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f20ec548bd0 0xfeeb4bf70d8 , "https://light.1688.com/"
[1:1:0712/124447.719565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 679 0x7f20ec548bd0 0xfeeb4bf70d8 , "https://light.1688.com/"
[1:1:0712/124447.735272:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124447.735450:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 2000
[1:1:0712/124447.735629:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 730
[1:1:0712/124447.735752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 730 0x7f20ec1e0070 0xfeeb6afa260 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
		remove user.15_23d0b2f7 -> 0
		remove user.16_d431430d -> 0
[1:1:0712/124448.494495:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124448.494733:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124448.495180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 732
[1:1:0712/124448.495350:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 732 0x7f20ec1e0070 0xfeeb73c99e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124448.495678:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124448.495816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124448.495979:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 733
[1:1:0712/124448.496089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 733 0x7f20ec1e0070 0xfeeb6fe6d60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124453.320690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124453.321356:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124453.321554:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 740
[1:1:0712/124453.321719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 740 0x7f20ec1e0070 0xfeeba6758e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124453.461277:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124453.461475:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124453.461732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 741
[1:1:0712/124453.461891:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 741 0x7f20ec1e0070 0xfeeb9afd2e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124455.125770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da78
[1:1:0712/124455.125976:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124455.126195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 745
[1:1:0712/124455.126317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 745 0x7f20ec1e0070 0xfeeb4bf75e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124455.207275:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da78
[1:1:0712/124455.207453:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124455.207658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 747
[1:1:0712/124455.207787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f20ec1e0070 0xfeeb4a480e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124456.301497:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124456.301692:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124456.301930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 756
[1:1:0712/124456.302085:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 756 0x7f20ec1e0070 0xfeeba8b6a60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124456.302364:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124456.302458:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124456.302618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 757
[1:1:0712/124456.302727:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 757 0x7f20ec1e0070 0xfeebb8e6e60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124457.494211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124457.494393:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124457.494630:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 764
[1:1:0712/124457.494787:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 764 0x7f20ec1e0070 0xfeeba5afee0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124457.871732:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124457.871918:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 3000
[1:1:0712/124457.872129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 766
[1:1:0712/124457.872246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 766 0x7f20ec1e0070 0xfeebb4e89e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124457.971141:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124457.971359:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124457.971721:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 767
[1:1:0712/124457.971911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 767 0x7f20ec1e0070 0xfeebc9f2f60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124459.093250:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124459.093463:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124459.093687:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 772
[1:1:0712/124459.093857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 772 0x7f20ec1e0070 0xfeebcfccb60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124459.097282:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124459.097495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124459.097738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 774
[1:1:0712/124459.097906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 774 0x7f20ec1e0070 0xfeebcac4760 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124459.098185:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124459.098279:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124459.098478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 775
[1:1:0712/124459.098621:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 775 0x7f20ec1e0070 0xfeebcbbec60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124500.251720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124500.251893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124500.252084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 782
[1:1:0712/124500.252204:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 782 0x7f20ec1e0070 0xfeeb8a54ee0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124500.252503:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124500.252624:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124500.252798:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 783
[1:1:0712/124500.252899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 783 0x7f20ec1e0070 0xfeebd954b60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124501.481929:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124501.482144:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124501.482330:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 789
[1:1:0712/124501.482494:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 789 0x7f20ec1e0070 0xfeebd954060 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124501.485840:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124501.486018:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124501.486209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 790
[1:1:0712/124501.486325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 790 0x7f20ec1e0070 0xfeebded1ae0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124501.486693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124501.486804:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124501.487000:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 792
[1:1:0712/124501.487179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 792 0x7f20ec1e0070 0xfeebda2e560 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124501.536891:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124501.537065:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124501.537326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 793
[1:1:0712/124501.537500:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 793 0x7f20ec1e0070 0xfeebc9f2be0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124501.537807:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124501.537958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124501.538117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 794
[1:1:0712/124501.538212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7f20ec1e0070 0xfeebbe9d260 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[17932:17932:0712/124501.995056:INFO:CONSOLE(9)] "list", source: https://b.alicdn.com/??@alife/bc-uc-textLine/1.x/index.7c0a4519.js,@alife/bc-uc-label/1.x/index.a782bc6f.js,@alife/bc-uc-number/2.x/index.dc1d63c1.js,@alife/bc-uc-price/2.x/index.198af7cb.js,@alife/ocms-fusion-1688-pc-cate1688-offer-2019/1.x/index.ebbc83ce.js,lodash.throttle/4.x/index.e607eed3.js,@alife/bc-uc-list/1.x/index.cd8f642b.js,@alife/ocms-fusion-1688-pc-cate1688-offerlist/1.x/index.e68e9b2a.js,@alife/ocms-fusion-1688-pc-cate1688-pindao-offer/1.x/index.c28113d2.js (9)
[1:1:0712/124503.080265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124503.080440:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124503.080647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 801
[1:1:0712/124503.080779:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 801 0x7f20ec1e0070 0xfeebc9f1ce0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124503.081158:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124503.081294:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124503.081498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 802
[1:1:0712/124503.081606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7f20ec1e0070 0xfeebe579d60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124503.419235:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da40
[1:1:0712/124503.419447:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124503.419691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 804
[1:1:0712/124503.419854:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f20ec1e0070 0xfeebe979860 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124503.492427:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 169, 0x199524c029c8, 0xfeeb205eb98
[1:1:0712/124503.492582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 169
[1:1:0712/124503.492745:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 805
[1:1:0712/124503.492841:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7f20ec1e0070 0xfeebf1ca4e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 679 0x7f20ec548bd0 0xfeeb4bf70d8 
[1:1:0712/124503.624988:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 16.4612, 2, 0
[1:1:0712/124503.625203:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/124503.690467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124503.690616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124503.874776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://light.1688.com/"
[1:1:0712/124503.875225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , D, (n){cn=n.gamma,en||(en=s(function(n){removeEventListener("deviceorientation",D),s(A,470)},30))}
[1:1:0712/124503.875340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124503.875736:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30, 0x199524c029c8, 0xfeeb205da38
[1:1:0712/124503.875839:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 30
[1:1:0712/124503.875989:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 843
[1:1:0712/124503.876093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 843 0x7f20ec1e0070 0xfeeb2af20e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 695 0x7f21047403d0 0xfeeb52a5860 
[1:1:0712/124503.876264:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "deviceorientation", "https://light.1688.com/"
[1:1:0712/124504.042954:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 680, 7f20eeb25881
[1:1:0712/124504.054851:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"561 0x7f20ec1e0070 0xfeeb3fc43e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124504.055019:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"561 0x7f20ec1e0070 0xfeeb3fc43e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124504.055215:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124504.055498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124504.055607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124504.056154:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124504.056256:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124504.056415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 852
[1:1:0712/124504.056516:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 852 0x7f20ec1e0070 0xfeebe81e360 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 680 0x7f20ec1e0070 0xfeeb44f06e0 
[1:1:0712/124505.043659:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/124505.043858:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://light.1688.com/"
[1:1:0712/124505.045189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (e){if(e&&e.length>0)for(var t=0;t<e.length;t++){var n=e[t]||{},o=r.nodelistToArray(n.addedNodes||[]
[1:1:0712/124505.045348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124505.073685:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 173, 0x199524c029c8, 0xfeeb205da90
[1:1:0712/124505.073840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 173
[1:1:0712/124505.074016:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 893
[1:1:0712/124505.074138:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 893 0x7f20ec1e0070 0xfeeb2a37a60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124505.178145:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 806 0x7f20ec1e0070 0xfeebf13fd60 , "https://light.1688.com/"
[1:1:0712/124505.180835:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x199524c029c8, 0xfeeb205d9b0
[1:1:0712/124505.180935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1000
[1:1:0712/124505.181102:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 894
[1:1:0712/124505.181207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7f20ec1e0070 0xfeebf55a8e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124505.183108:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://light.1688.com/"
[1:1:0712/124505.289683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://light.1688.com/"
[1:1:0712/124505.292214:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205d9e0
[1:1:0712/124505.292358:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124505.292544:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 897
[1:1:0712/124505.292653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7f20ec1e0070 0xfeebf3f5be0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124507.964050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 167, 0x199524c029c8, 0xfeeb205dd00
[1:1:0712/124507.964281:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 167
[1:1:0712/124507.964475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 926
[1:1:0712/124507.964628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 926 0x7f20ec1e0070 0xfeebfe917e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124508.142727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://light.1688.com/"
[1:1:0712/124508.145234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205d9e0
[1:1:0712/124508.145381:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124508.145627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 929
[1:1:0712/124508.145786:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f20ec1e0070 0xfeec087f8e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124508.148103:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x199524c029c8, 0xfeeb205d9e0
[1:1:0712/124508.148235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1500
[1:1:0712/124508.148421:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 931
[1:1:0712/124508.148545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7f20ec1e0070 0xfeec04358e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124508.347455:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://light.1688.com/"
[1:1:0712/124508.348464:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://light.1688.com/"
[1:1:0712/124508.350511:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205d9e0
[1:1:0712/124508.350645:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124508.350832:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 935
[1:1:0712/124508.350942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7f20ec1e0070 0xfeec07ce660 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 806 0x7f20ec1e0070 0xfeebf13fd60 
[1:1:0712/124508.644127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 733, 7f20eeb25881
[1:1:0712/124508.659527:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.659737:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.659981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124508.660244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124508.660332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124508.707191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 730, 7f20eeb25881
[1:1:0712/124508.720860:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.721016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.721214:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124508.721461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){var e='component[component-async="true"]:empty:before{background: transparent url(https://cbu01.a
[1:1:0712/124508.721566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124508.722998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 740, 7f20eeb25881
[1:1:0712/124508.737201:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.737394:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.737608:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124508.737884:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124508.738000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124508.746633:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 127, 0x199524c029c8, 0xfeeb205dab0
[1:1:0712/124508.746777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 127
[1:1:0712/124508.746941:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 970
[1:1:0712/124508.747045:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 970 0x7f20ec1e0070 0xfeeb370a8e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 740 0x7f20ec1e0070 0xfeeba6758e0 
[1:1:0712/124508.776328:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 741, 7f20eeb25881
[1:1:0712/124508.789253:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.789423:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.789627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124508.789895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124508.790008:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124508.797964:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 745, 7f20eeb25881
[1:1:0712/124508.812582:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.812755:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124508.812977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124508.813266:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , N, (e){B=0;var r=d(15,0),s="l",c="/",b=c.split("").reverse().join("");a(s,r,I,D,b)}
[1:1:0712/124508.813363:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.550308:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 747, 7f20eeb25881
[1:1:0712/124509.565627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.565836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.566091:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.566457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , e, (){D=null;var n=M.ra(!1,null);z.s(n),p.k(g,n)}
[1:1:0712/124509.566604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.604379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124509.604541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.605760:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 757, 7f20eeb25881
[1:1:0712/124509.620819:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.620995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.621225:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.621467:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124509.621578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.661876:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 764, 7f20eeb25881
[1:1:0712/124509.675883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.676064:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.676265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.676529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124509.676646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.684393:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 144, 0x199524c029c8, 0xfeeb205dab0
[1:1:0712/124509.684566:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 144
[1:1:0712/124509.684735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 979
[1:1:0712/124509.684844:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 979 0x7f20ec1e0070 0xfeeb47375e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 764 0x7f20ec1e0070 0xfeeba5afee0 
[1:1:0712/124509.685696:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 767, 7f20eeb25881
[1:1:0712/124509.699936:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.700123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.700326:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.700578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124509.700662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.737960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 775, 7f20eeb25881
[1:1:0712/124509.751616:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.751807:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.752017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.752291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124509.752421:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.759796:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 783, 7f20eeb25881
[1:1:0712/124509.774587:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.774770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.774981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.775248:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124509.775359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.782281:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 766, 7f20eeb25881
[1:1:0712/124509.795591:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.795811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124509.796035:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124509.796337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , g, (){var e=void 0;if(!this.state.mounted)return!1;if(this.props.rtl)e=this.state.currentSlide-this.pro
[1:1:0712/124509.796456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124509.901915:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 520, 0x199524c029c8, 0xfeeb205d910
[1:1:0712/124509.902128:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 520
[1:1:0712/124509.902347:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 980
[1:1:0712/124509.902512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 980 0x7f20ec1e0070 0xfeec0b3a860 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 766 0x7f20ec1e0070 0xfeebb4e89e0 
[1:1:0712/124509.904051:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x199524c029c8, 0xfeeb205d910
[1:1:0712/124509.904234:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 3000
[1:1:0712/124509.904424:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 981
[1:1:0712/124509.904530:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7f20ec1e0070 0xfeec02beee0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 766 0x7f20ec1e0070 0xfeebb4e89e0 
[1:1:0712/124510.026368:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 167, 0x199524c029c8, 0xfeeb205dc30
[1:1:0712/124510.026577:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 167
[1:1:0712/124510.026814:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 982
[1:1:0712/124510.026973:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 982 0x7f20ec1e0070 0xfeeb27ba960 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 766 0x7f20ec1e0070 0xfeebb4e89e0 
[1:1:0712/124510.061826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 792, 7f20eeb25881
[1:1:0712/124510.075341:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.075538:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.075764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.076015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124510.076125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.083426:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 794, 7f20eeb25881
[1:1:0712/124510.097642:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.097817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.098014:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.098265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124510.098362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.106497:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 802, 7f20eeb25881
[1:1:0712/124510.120145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.120344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.120581:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.120828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124510.120915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.156504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (e){l(e,function(e){e.intersectionRatio>0&&r(e)})}
[1:1:0712/124510.156697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.165820:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x199524c029c8, 0xfeeb205da90
[1:1:0712/124510.166012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 300
[1:1:0712/124510.166261:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 984
[1:1:0712/124510.166469:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 984 0x7f20ec1e0070 0xfeeb23cbb60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 858 0x7f20ee1082e0 0xfeebf55a860 
[1:1:0712/124510.175191:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x199524c029c8, 0xfeeb205da90
[1:1:0712/124510.175348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 300
[1:1:0712/124510.175526:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 985
[1:1:0712/124510.175655:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f20ec1e0070 0xfeeb4e7dbe0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 858 0x7f20ee1082e0 0xfeebf55a860 
[1:1:0712/124510.176953:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 804, 7f20eeb25881
[1:1:0712/124510.191000:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.191200:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.191433:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.191727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i(t,n)}
[1:1:0712/124510.191853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.382083:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 843, 7f20eeb25881
[1:1:0712/124510.395711:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"695 0x7f21047403d0 0xfeeb52a5860 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.395874:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"695 0x7f21047403d0 0xfeeb52a5860 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.396081:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.396364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (n){removeEventListener("deviceorientation",D),s(A,470)}
[1:1:0712/124510.396466:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.396940:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 470, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124510.397054:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 470
[1:1:0712/124510.397255:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 989
[1:1:0712/124510.397373:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 989 0x7f20ec1e0070 0xfeec15abbe0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 843 0x7f20ec1e0070 0xfeeb2af20e0 
[1:1:0712/124510.428067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 801, 7f20eeb25881
[1:1:0712/124510.442236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.442398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.442595:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.442856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){if(document.createEvent){var e=window.document.createEvent("UIEvents");e.initUIEvent("resize",!0,
[1:1:0712/124510.442961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124510.443867:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://light.1688.com/"
[1:1:0712/124510.444211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://light.1688.com/"
[1:1:0712/124510.520026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://light.1688.com/"
[1:1:0712/124510.545894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://light.1688.com/"
[1:1:0712/124510.646300:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x199524c029c8, 0xfeeb205da58
[1:1:0712/124510.646492:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 3000
[1:1:0712/124510.646943:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 992
[1:1:0712/124510.647064:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 992 0x7f20ec1e0070 0xfeebcac4be0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 801 0x7f20ec1e0070 0xfeebc9f1ce0 
[1:1:0712/124510.862351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 772, 7f20eeb25881
[1:1:0712/124510.877678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.877849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124510.878059:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124510.878308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , 
[1:1:0712/124510.878402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124511.034883:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 870 0x7f20ee1082e0 0xfeebf4e2fe0 , "https://light.1688.com/"
[1:1:0712/124511.036270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18309420424414672404_1562906691867({"traceId":"0baf604b15629066953537647e4096","hasError":fals
[1:1:0712/124511.036407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124511.038121:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124511.243444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 165, 0x199524c029c8, 0xfeeb205dd70
[1:1:0712/124511.243613:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 165
[1:1:0712/124511.243837:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1000
[1:1:0712/124511.243946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1000 0x7f20ec1e0070 0xfeeb73c7460 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 870 0x7f20ee1082e0 0xfeebf4e2fe0 
[1:1:0712/124511.454364:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 871 0x7f20ee1082e0 0xfeeb23403e0 , "https://light.1688.com/"
[1:1:0712/124511.455401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18309420424414672404_1562906691869({"traceId":"0baf604b15629066975197928e4096","hasError":fals
[1:1:0712/124511.455551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124511.456552:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124511.570335:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 149, 0x199524c029c8, 0xfeeb205dc30
[1:1:0712/124511.570550:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 149
[1:1:0712/124511.570795:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1014
[1:1:0712/124511.570988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1014 0x7f20ec1e0070 0xfeec01fa960 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 871 0x7f20ee1082e0 0xfeeb23403e0 
[1:1:0712/124511.844910:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 852, 7f20eeb25881
[1:1:0712/124511.860866:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"680 0x7f20ec1e0070 0xfeeb44f06e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124511.861097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"680 0x7f20ec1e0070 0xfeeb44f06e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124511.861313:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124511.861588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124511.861691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124511.862473:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124511.862569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124511.862728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1034
[1:1:0712/124511.862834:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1034 0x7f20ec1e0070 0xfeeb30e9260 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 852 0x7f20ec1e0070 0xfeebe81e360 
[1:1:0712/124511.909535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 875 0x7f20ee1082e0 0xfeebf5b4f60 , "https://light.1688.com/"
[1:1:0712/124511.910881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jsonp_1562906698072_5047({"traceId":"0baf604b15629066991298172e4096","hasError":false,"errors":[],"c
[1:1:0712/124511.911000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124511.930142:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 876 0x7f20ee1082e0 0xfeeb4a72560 , "https://light.1688.com/"
[1:1:0712/124511.931904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18309420424414672404_1562906691870({"traceId":"0baf604b15629067002808365e4096","hasError":fals
[1:1:0712/124511.932049:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124511.936310:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[17932:17932:0712/124512.272138:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2019/835/590/11436095538_763459896.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.273948:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2019/268/839/11431938862_64571608.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.275693:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2019/277/669/11288966772_440338425.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[1:1:0712/124512.356603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 104, 0x199524c029c8, 0xfeeb205dbf0
[1:1:0712/124512.356758:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 104
[1:1:0712/124512.356928:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1046
[1:1:0712/124512.357015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1046 0x7f20ec1e0070 0xfeec1f27be0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 876 0x7f20ee1082e0 0xfeeb4a72560 
[17932:17932:0712/124512.701208:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2019/900/039/10948930009_1847296260.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.707519:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2018/640/292/10272292046_824832573.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.712049:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2019/738/870/10896078837_1450555911.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.714785:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2014/724/110/1649011427_484886355.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.716983:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2018/441/033/9016330144_484886355.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.719168:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2017/498/588/4377885894_1286318578.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.721163:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2018/191/719/9274917191_857621802.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.723447:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2017/390/014/4411410093_1906277968.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[17932:17932:0712/124512.725006:INFO:CONSOLE(0)] "Mixed Content: The page at 'https://light.1688.com/' was loaded over HTTPS, but requested an insecure image 'http://img.china.alibaba.com/img/ibank/2018/050/127/9659721050_1103771427.search.jpg'. This content should also be served over HTTPS.", source: https://light.1688.com/ (0)
[1:1:0712/124512.809113:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 878 0x7f20ee1082e0 0xfeebac98f60 , "https://light.1688.com/"
[1:1:0712/124512.809734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jsonp_1562906700451_71086({"traceId":"0baf604b15629067015178598e4096","hasError":false,"errors":[],"
[1:1:0712/124512.809893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124512.843464:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 879 0x7f20ee1082e0 0xfeeb370aa60 , "https://light.1688.com/"
[1:1:0712/124512.844857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18309420424414672404_1562906691871({"traceId":"0baf604b15629067031188907e4096","hasError":fals
[1:1:0712/124512.844985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124512.846113:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[17932:17932:0712/124512.861625:INFO:CONSOLE(9)] "list", source: https://b.alicdn.com/??@alife/bc-uc-textLine/1.x/index.7c0a4519.js,@alife/bc-uc-label/1.x/index.a782bc6f.js,@alife/bc-uc-number/2.x/index.dc1d63c1.js,@alife/bc-uc-price/2.x/index.198af7cb.js,@alife/ocms-fusion-1688-pc-cate1688-offer-2019/1.x/index.ebbc83ce.js,lodash.throttle/4.x/index.e607eed3.js,@alife/bc-uc-list/1.x/index.cd8f642b.js,@alife/ocms-fusion-1688-pc-cate1688-offerlist/1.x/index.e68e9b2a.js,@alife/ocms-fusion-1688-pc-cate1688-pindao-offer/1.x/index.c28113d2.js (9)
[1:1:0712/124513.909738:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da10
[1:1:0712/124513.909926:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124513.910151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1079
[1:1:0712/124513.910293:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1079 0x7f20ec1e0070 0xfeec27afde0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 879 0x7f20ee1082e0 0xfeeb370aa60 
[1:1:0712/124513.928102:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x199524c029c8, 0xfeeb205da10
[1:1:0712/124513.928301:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 0
[1:1:0712/124513.928532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1080
[1:1:0712/124513.928672:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7f20ec1e0070 0xfeec28d5e60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 879 0x7f20ee1082e0 0xfeeb370aa60 
[1:1:0712/124513.931540:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205da10
[1:1:0712/124513.931669:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124513.931836:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1082
[1:1:0712/124513.931974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1082 0x7f20ec1e0070 0xfeeb6afa860 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 879 0x7f20ee1082e0 0xfeeb370aa60 
[1:1:0712/124514.001798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 881 0x7f20ee1082e0 0xfeeba95d3e0 , "https://light.1688.com/"
[1:1:0712/124514.003951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18309420424414672404_1562906691868({"traceId":"0baf604b15629066963347782e4096","hasError":fals
[1:1:0712/124514.004072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124514.007521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124514.938641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 142, 0x199524c029c8, 0xfeeb205dcf0
[1:1:0712/124514.938808:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 142
[1:1:0712/124514.939049:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1106
[1:1:0712/124514.939207:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7f20ec1e0070 0xfeec3124360 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 881 0x7f20ee1082e0 0xfeeba95d3e0 
[1:1:0712/124516.454686:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://localhost.wwbizsrv.alibaba.com:4013/?callback=jQuery18304761847137584623_1562906669421&_=1562906708171"
[1:1:0712/124516.862026:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 897, 7f20eeb25881
[1:1:0712/124516.879517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124516.879679:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124516.879880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124516.880148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){var t,n,r,i,o="padding:0;margin:0;border:0;display:block;overflow:hidden;",s=X.getElementsByTagNa
[1:1:0712/124516.880235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124517.390781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 152, 0x199524c029c8, 0xfeeb205def0
[1:1:0712/124517.390963:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 152
[1:1:0712/124517.391174:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1279
[1:1:0712/124517.391301:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1279 0x7f20ec1e0070 0xfeec3528fe0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 897 0x7f20ec1e0070 0xfeebf3f5be0 
[1:1:0712/124517.682300:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 894, 7f20eeb25881
[1:1:0712/124517.704944:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124517.705170:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124517.705677:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124517.705982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){_this.scrollTimer&&clearTimeout(_this.scrollTimer),_this.calculator(),_this.dot()}
[1:1:0712/124517.706116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124517.764832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124517.764982:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124517.765169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1289
[1:1:0712/124517.765327:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1289 0x7f20ec1e0070 0xfeec39008e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 894 0x7f20ec1e0070 0xfeebf55a8e0 
[1:1:0712/124517.805191:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124517.805361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 5000
[1:1:0712/124517.805580:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1297
[1:1:0712/124517.805742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1297 0x7f20ec1e0070 0xfeec3900360 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 894 0x7f20ec1e0070 0xfeebf55a8e0 
[1:1:0712/124517.812391:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 789, 7f20eeb25881
[1:1:0712/124517.835355:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124517.835577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"679 0x7f20ec548bd0 0xfeeb4bf70d8 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124517.835825:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124517.836109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , 
[1:1:0712/124517.836252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124517.878223:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 929, 7f20eeb25881
[1:1:0712/124517.897581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124517.897837:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124517.898119:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124517.898509:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){var t,n,r,i,o="padding:0;margin:0;border:0;display:block;overflow:hidden;",s=X.getElementsByTagNa
[1:1:0712/124517.898635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124517.994016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 147, 0x199524c029c8, 0xfeeb205def0
[1:1:0712/124517.994169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 147
[1:1:0712/124517.994394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1303
[1:1:0712/124517.994501:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7f20ec1e0070 0xfeec0b3f060 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 929 0x7f20ec1e0070 0xfeec087f8e0 
[1:1:0712/124518.286944:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 935, 7f20eeb25881
[1:1:0712/124518.306692:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124518.306876:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124518.307082:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124518.307369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){var n,r,i,o,a="padding:0;margin:0;border:0;display:block;overflow:hidden;",s=$.getElementsByTagNa
[1:1:0712/124518.307516:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124518.397535:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 149, 0x199524c029c8, 0xfeeb205def0
[1:1:0712/124518.397671:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 149
[1:1:0712/124518.397881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1306
[1:1:0712/124518.397990:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7f20ec1e0070 0xfeec387efe0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 935 0x7f20ec1e0070 0xfeec07ce660 
[1:1:0712/124518.809685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124518.809877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124518.832303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 931, 7f20eeb25881
[1:1:0712/124518.851921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124518.852112:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"806 0x7f20ec1e0070 0xfeebf13fd60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124518.853158:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124518.853498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){e.call(null,!1)}
[1:1:0712/124518.853584:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124518.854412:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124518.854506:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 1500
[1:1:0712/124518.854659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1311
[1:1:0712/124518.854763:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1311 0x7f20ec1e0070 0xfeec01fabe0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 931 0x7f20ec1e0070 0xfeec04358e0 
[1:1:0712/124519.071750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 984, 7f20eeb25881
[1:1:0712/124519.091742:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"858 0x7f20ee1082e0 0xfeebf55a860 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124519.091946:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"858 0x7f20ee1082e0 0xfeebf55a860 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124519.092148:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124519.092459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i=p.filterEndExposureSize(a,r),i>0&&goldlog.aplus_pubsub.publish(n,{size:i,eventType:r})}
[1:1:0712/124519.092592:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124519.163167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 985, 7f20eeb25881
[1:1:0712/124519.184092:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"858 0x7f20ee1082e0 0xfeebf55a860 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124519.184287:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"858 0x7f20ee1082e0 0xfeebf55a860 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124519.184531:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124519.184830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){i=p.filterEndExposureSize(a,r),i>0&&goldlog.aplus_pubsub.publish(n,{size:i,eventType:r})}
[1:1:0712/124519.184915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124519.307139:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 989, 7f20eeb25881
[17932:17932:0712/124519.307856:INFO:CONSOLE(33)] "Uncaught (in promise) Error: Not Found", source: https://b.alicdn.com/??@alife/next/0.x/index.a77cd33f.js,@alife/ocms-fusion-1688-pc-cate1688-banner-slider-new/1.x/index.215b6ce6.js,@alife/bc-base-comp-combo/1.x/index.e3cc84dc.js,@alife/puck-core/1.x/index.b4e7fba4.js,@alife/puck-csrftoken/1.x/index.5a9545e5.js,@alife/puck/3.x/index.6dd43b3f.js,@ali/tracker/4.x/index.bc4cd5f3.js,@alife/bc-wga-fetch/1.x/index.260abc84.js,@alife/bc-base-asyc-layout/1.x/index.a6057877.js,@alife/ocms-fusion-1688-pc-cate1688-discounts/1.x/index.f9e52b21.js,@alife/ocms-fusion-1688-pc-cate1688-recommendation/1.x/index.ee9cbab6.js,@alife/ocms-fusion-1688-pc-cate1688-superbrand/1.x/index.e99fc617.js,@alife/ocms-fusion-1688-pc-cate1688-toplist-group/1.x/index.d566d3e1.js,@alife/ocms-fusion-1688-pc-cate1688-leftcate/1.x/index.82bbf18b.js,@alife/ocms-fusion-1688-pc-cate1688-footer/1.x/index.431e0a84.js,@alife/ocms-fusion-1688-pc-cate1688-returnTop-button/1.x/index.d8d27ab9.js,@alife/ofe-cookie/1.x/index.3cd68d39.js,@alife/bc-searchbar1688/0.x/index.35e20b2d.js (33)
[1:1:0712/124519.326305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"843 0x7f20ec1e0070 0xfeeb2af20e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124519.326512:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"843 0x7f20ec1e0070 0xfeeb2af20e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124519.326760:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124519.327064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , A, (){en=0,addEventListener("deviceorientation",D)}
[1:1:0712/124519.327196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124519.932352:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1032 0x7f20ee1082e0 0xfeec1bd1f60 , "https://light.1688.com/"
[1:1:0712/124519.933352:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , callback({"content":{"useCache":false,"data":[{"resourceId":228483,"versionContent":"{\"sitemapConfi
[1:1:0712/124519.933493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124519.934249:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124520.040866:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 151, 0x199524c029c8, 0xfeeb205db30
[1:1:0712/124520.041153:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 151
[1:1:0712/124520.041326:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1349
[1:1:0712/124520.041435:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1349 0x7f20ec1e0070 0xfeec4332160 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 1032 0x7f20ee1082e0 0xfeec1bd1f60 
[1:1:0712/124520.369394:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1033 0x7f20ee1082e0 0xfeebbd077e0 , "https://light.1688.com/"
[1:1:0712/124520.370021:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18308108238583709664_1562906669096({"__cn_logon_id__":"","__cn_logon__":"false",version:"1.0"}
[1:1:0712/124520.370155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124520.370586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124520.452899:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 151, 0x199524c029c8, 0xfeeb205dbb0
[1:1:0712/124520.453169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 151
[1:1:0712/124520.453429:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1359
[1:1:0712/124520.453604:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1359 0x7f20ec1e0070 0xfeec42c2e60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 1033 0x7f20ee1082e0 0xfeebbd077e0 
[1:1:0712/124521.326006:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1034, 7f20eeb25881
[1:1:0712/124521.347818:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"852 0x7f20ec1e0070 0xfeebe81e360 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124521.348094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"852 0x7f20ec1e0070 0xfeebe81e360 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124521.348365:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124521.348645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124521.348745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124521.349759:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124521.349863:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124521.350021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1386
[1:1:0712/124521.350112:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1386 0x7f20ec1e0070 0xfeec46b8260 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 1034 0x7f20ec1e0070 0xfeeb30e9260 
[1:1:0712/124521.765508:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 992, 7f20eeb25881
[1:1:0712/124521.786081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"801 0x7f20ec1e0070 0xfeebc9f1ce0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124521.786268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"801 0x7f20ec1e0070 0xfeebc9f1ce0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124521.786465:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124521.786728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , g, (){var e=void 0;if(!this.state.mounted)return!1;if(this.props.rtl)e=this.state.currentSlide-this.pro
[1:1:0712/124521.786827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124521.885330:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 520, 0x199524c029c8, 0xfeeb205d910
[1:1:0712/124521.885520:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 520
[1:1:0712/124521.885717:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1405
[1:1:0712/124521.885864:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1405 0x7f20ec1e0070 0xfeec46d6060 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 992 0x7f20ec1e0070 0xfeebcac4be0 
[1:1:0712/124521.887193:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3000, 0x199524c029c8, 0xfeeb205d910
[1:1:0712/124521.887313:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 3000
[1:1:0712/124521.887501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1406
[1:1:0712/124521.887649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1406 0x7f20ec1e0070 0xfeec1e6cc60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 992 0x7f20ec1e0070 0xfeebcac4be0 
[1:1:0712/124522.012815:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 154, 0x199524c029c8, 0xfeeb205dc30
[1:1:0712/124522.012971:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 154
[1:1:0712/124522.013218:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1407
[1:1:0712/124522.013317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1407 0x7f20ec1e0070 0xfeec3a1efe0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 992 0x7f20ec1e0070 0xfeebcac4be0 
[1:1:0712/124522.019555:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1079, 7f20eeb25881
[1:1:0712/124522.040063:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"879 0x7f20ee1082e0 0xfeeb370aa60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124522.040283:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"879 0x7f20ee1082e0 0xfeeb370aa60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124522.040497:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124522.040768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , N, (e){B=0;var r=d(15,0),s="l",c="/",b=c.split("").reverse().join("");a(s,r,I,D,b)}
[1:1:0712/124522.040869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124522.802972:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1080, 7f20eeb25881
[1:1:0712/124522.823145:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"879 0x7f20ee1082e0 0xfeeb370aa60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124522.823360:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"879 0x7f20ee1082e0 0xfeeb370aa60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124522.823611:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124522.823922:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , e, (){D=null;var n=M.ra(!1,null);z.s(n),p.k(g,n)}
[1:1:0712/124522.824029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124524.346738:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (e){l(e,function(e){e.intersectionRatio>0&&r(e)})}
[1:1:0712/124524.346894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124525.578806:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1199 0x7f20ee1082e0 0xfeeb4fe11e0 , "https://light.1688.com/"
[1:1:0712/124525.580118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , !function(i){function t(i){window.dmtrack&&dmtrack.clickstat("//stat.1688.com/tracelog/click.html","
[1:1:0712/124525.580258:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124525.581277:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124525.610419:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1200 0x7f20ee1082e0 0xfeec352b460 , "https://light.1688.com/"
[1:1:0712/124525.610958:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , jQuery18308108238583709664_1562906669097({"data":{"sumOfKind":0},"success":true})
[1:1:0712/124525.611064:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124525.611539:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124525.674807:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 146, 0x199524c029c8, 0xfeeb205dbb0
[1:1:0712/124525.674980:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 146
[1:1:0712/124525.675169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1460
[1:1:0712/124525.675294:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1460 0x7f20ec1e0070 0xfeec38bbc60 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 1200 0x7f20ee1082e0 0xfeec352b460 
[1:1:0712/124528.454582:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , document.readyState
[1:1:0712/124528.454775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124528.524715:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1082, 7f20eeb25881
[1:1:0712/124528.547998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"879 0x7f20ee1082e0 0xfeeb370aa60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124528.548218:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"879 0x7f20ee1082e0 0xfeeb370aa60 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124528.548467:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124528.548746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , 
[1:1:0712/124528.548830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124528.603861:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_CONNECTION_REFUSED","https://localhost.wwbizsrv.alibaba.com:4813/?callback=jQuery18304761847137584623_1562906669422&_=1562906718877"
[1:1:0712/124529.126624:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.127063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.127184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.199845:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.200258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.200411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.334417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.334844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.334977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.420252:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.420668:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.420777:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.692887:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1311, 7f20eeb25881
[1:1:0712/124529.716251:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"931 0x7f20ec1e0070 0xfeec04358e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124529.716515:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"931 0x7f20ec1e0070 0xfeec04358e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124529.716765:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124529.717070:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){e.call(null,!1)}
[1:1:0712/124529.717180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.788458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.788825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.788924:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.825236:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.825598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.825699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.862016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.862382:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.862486:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.898403:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.898807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.898938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124529.981244:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124529.981611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124529.981713:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.018206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.018647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.018793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.055469:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.055895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.056052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.113875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.114378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.114562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.196878:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.197307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.197409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.256500:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.256854:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.256945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.292840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.293207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.293309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.329519:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.329871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.329993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.411523:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.411896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.412004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.471122:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.471474:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.471577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.575953:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.576325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.576426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.635934:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.636351:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.636472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.718209:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.718654:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.718790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.778326:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.778740:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.778890:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.862116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.862481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.862590:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124530.922174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124530.922537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124530.922639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.005731:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124531.006120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124531.006224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.064803:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124531.065224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124531.065366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.147774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124531.148224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124531.148347:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.208019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124531.208436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124531.208558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.245205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1386, 7f20eeb25881
[1:1:0712/124531.268378:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"1034 0x7f20ec1e0070 0xfeeb30e9260 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.268602:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"1034 0x7f20ec1e0070 0xfeeb30e9260 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.268817:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124531.269143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , t, (){e++,e>10&&(n=3e3),o(),setTimeout(t,n)}
[1:1:0712/124531.269260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.270225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x199524c029c8, 0xfeeb205d950
[1:1:0712/124531.270366:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 500
[1:1:0712/124531.270541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1571
[1:1:0712/124531.270652:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1571 0x7f20ec1e0070 0xfeec20305e0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 1386 0x7f20ec1e0070 0xfeec46b8260 
[1:1:0712/124531.294586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1405, 7f20eeb25881
[1:1:0712/124531.317575:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"992 0x7f20ec1e0070 0xfeebcac4be0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.317782:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"992 0x7f20ec1e0070 0xfeebcac4be0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.317987:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124531.318308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , h, (){t.setState(d);t.props.afterChange&&t.props.afterChange(o);delete t.animationEndCallback}
[1:1:0712/124531.318467:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.446949:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 153, 0x199524c029c8, 0xfeeb205dab0
[1:1:0712/124531.447139:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://light.1688.com/", 153
[1:1:0712/124531.447382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1572
[1:1:0712/124531.447553:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1572 0x7f20ec1e0070 0xfeec70beae0 , 5:3_https://light.1688.com/, 1, -5:3_https://light.1688.com/, 1405 0x7f20ec1e0070 0xfeec46d6060 
[1:1:0712/124531.448259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1289, 7f20eeb25881
[1:1:0712/124531.472244:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"894 0x7f20ec1e0070 0xfeebf55a8e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.472466:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"894 0x7f20ec1e0070 0xfeebf55a8e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.472706:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124531.472972:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/124531.473105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.524084:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://light.1688.com/, 1297, 7f20eeb25881
[1:1:0712/124531.546143:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"128e6eb82860","ptid":"894 0x7f20ec1e0070 0xfeebf55a8e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.546342:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://light.1688.com/","ptid":"894 0x7f20ec1e0070 0xfeebf55a8e0 ","rf":"5:3_https://light.1688.com/"}
[1:1:0712/124531.546561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://light.1688.com/"
[1:1:0712/124531.546847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , , (){window[r]&&(window[r].src="",i()),o.do_tracker_jserror({message:"loadTimeout",error:"",filename:"
[1:1:0712/124531.546966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
[1:1:0712/124531.644482:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://light.1688.com/"
[1:1:0712/124531.644862:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://light.1688.com/, 128e6eb82860, , dispatchEvent, (e,t){if(p._enabled){var n=TopLevelCallbackBookKeeping.getPooled(e,t);try{u.batchedUpdates(handleTop
[1:1:0712/124531.644960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://light.1688.com/", "light.1688.com", 3, 1, , , 0
