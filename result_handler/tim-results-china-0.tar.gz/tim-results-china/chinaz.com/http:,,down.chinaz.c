[0712/160735.584329:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/160735.584582:INFO:switcher_clone.cc(787)] backtrace rip is 7f96dadf0891
[0712/160736.121490:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/160736.121731:INFO:switcher_clone.cc(787)] backtrace rip is 7fda81a08891
[1:1:0712/160736.125715:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/160736.125888:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/160736.128606:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[17758:17758:0712/160736.877572:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/43e02e9b-6723-4eef-afcc-9af4d9f2a100
[0712/160736.972716:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/160736.972976:INFO:switcher_clone.cc(787)] backtrace rip is 7f25378a9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[17793:17793:0712/160737.124980:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=17793
[17804:17804:0712/160737.125299:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=17804
[17758:17758:0712/160737.130187:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[17758:17789:0712/160737.130551:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/160737.130665:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/160737.130822:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/160737.131119:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/160737.131227:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/160737.133408:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2f7bafa7, 1
[1:1:0712/160737.135088:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x258713d, 0
[1:1:0712/160737.135187:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x382b292d, 3
[1:1:0712/160737.135270:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x8349137, 2
[1:1:0712/160737.135356:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 3d715802 ffffffa7ffffffaf7b2f 37ffffff913408 2d292b38 , 10104, 4
[1:1:0712/160737.136073:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[17758:17789:0712/160737.136190:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING=qX��{/7�4-)+8�%
[17758:17789:0712/160737.136239:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is =qX��{/7�4-)+8([�%
[17758:17789:0712/160737.136380:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[17758:17789:0712/160737.136411:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 17812, 4, 3d715802 a7af7b2f 37913408 2d292b38 
[1:1:0712/160737.136659:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda7fc420a0, 3
[1:1:0712/160737.136769:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda7fdce080, 2
[1:1:0712/160737.136855:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda69a90d20, -2
[1:1:0712/160737.144908:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/160737.145393:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8349137
[1:1:0712/160737.145881:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8349137
[1:1:0712/160737.146681:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8349137
[1:1:0712/160737.147338:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.147460:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.147626:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.147727:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.147995:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8349137
[1:1:0712/160737.149134:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda81a087ba
[1:1:0712/160737.149281:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda819ffdef, 7fda81a0877a, 7fda81a0a0cf
[1:1:0712/160737.151075:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 8349137
[1:1:0712/160737.151297:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 8349137
[1:1:0712/160737.151604:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 8349137
[1:1:0712/160737.152376:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.152452:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.152537:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.152608:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 8349137
[1:1:0712/160737.153095:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 8349137
[1:1:0712/160737.153248:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda81a087ba
[1:1:0712/160737.153324:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda819ffdef, 7fda81a0877a, 7fda81a0a0cf
[1:1:0712/160737.155789:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/160737.155967:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/160737.156028:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffee2730308, 0x7ffee2730288)
[1:1:0712/160737.162594:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/160737.165329:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[17758:17758:0712/160737.561640:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160737.562145:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/160737.567433:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x28bc13bcc220
[1:1:0712/160737.567575:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[17758:17770:0712/160737.571890:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[17758:17770:0712/160737.571962:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160737.571989:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[17758:17758:0712/160737.572035:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[17758:17758:0712/160737.572112:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,17812, 4
[1:7:0712/160737.573573:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[17758:17782:0712/160737.608257:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/160737.861499:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/160738.543569:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160738.545245:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[17758:17758:0712/160738.622588:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[17758:17758:0712/160738.622655:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/160738.983254:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160739.052925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14a0daea1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/160739.053133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160739.058073:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14a0daea1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/160739.058195:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160739.104083:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160739.104231:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160739.238326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160739.240764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14a0daea1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/160739.240912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160739.252700:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160739.255640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14a0daea1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/160739.255772:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160739.259536:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160739.260168:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160739.261288:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x28bc13bcae20
[1:1:0712/160739.261392:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[17758:17758:0712/160739.262665:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[17758:17758:0712/160739.274227:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[17758:17758:0712/160739.274306:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/160739.293476:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160739.579990:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7fda6b66b2e0 0x28bc13d13fe0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160739.580653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14a0daea1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/160739.580790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160739.581374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[17758:17758:0712/160739.607665:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160739.608745:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x28bc13bcb820
[1:1:0712/160739.608874:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[17758:17758:0712/160739.610032:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/160739.615875:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160739.616033:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[17758:17758:0712/160739.617080:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[17758:17758:0712/160739.620936:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160739.621366:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160739.625708:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[17758:17770:0712/160739.625760:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160739.625778:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[17758:17758:0712/160739.625815:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[17758:17758:0712/160739.625874:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,17812, 4
[1:7:0712/160739.627274:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160739.873334:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/160740.053688:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 472 0x7fda6b66b2e0 0x28bc13f79660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/160740.054380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 14a0daea1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/160740.054548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/160740.055042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[17758:17758:0712/160740.145684:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[17758:17758:0712/160740.145758:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/160740.158278:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160740.329387:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[17758:17758:0712/160740.502910:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[17758:17789:0712/160740.503171:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/160740.503315:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/160740.503457:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/160740.503661:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/160740.503742:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/160740.505455:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160740.505676:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/160740.505894:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x113f1a55, 1
[1:1:0712/160740.506075:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x1fa455ad, 0
[1:1:0712/160740.506178:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x345bf42c, 3
[1:1:0712/160740.506267:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x82d66af, 2
[1:1:0712/160740.506345:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffad55ffffffa41f 551a3f11 ffffffaf662d08 2cfffffff45b34 , 10104, 5
[1:1:0712/160740.507053:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[17758:17789:0712/160740.507189:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�U�U?�f-,�[4�%
[17758:17789:0712/160740.507230:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �U�U?�f-,�[4��%
[1:1:0712/160740.507190:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda7fc420a0, 3
[1:1:0712/160740.507273:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda7fdce080, 2
[1:1:0712/160740.507363:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fda69a90d20, -2
[17758:17789:0712/160740.507506:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 17854, 5, ad55a41f 551a3f11 af662d08 2cf45b34 
[1:1:0712/160740.516926:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/160740.517140:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 82d66af
[1:1:0712/160740.517306:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 82d66af
[1:1:0712/160740.517574:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 82d66af
[1:1:0712/160740.518076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.518175:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.518265:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.518361:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.518614:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 82d66af
[1:1:0712/160740.518742:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda81a087ba
[1:1:0712/160740.518817:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda819ffdef, 7fda81a0877a, 7fda81a0a0cf
[1:1:0712/160740.520742:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 82d66af
[1:1:0712/160740.520941:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 82d66af
[1:1:0712/160740.521276:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 82d66af
[1:1:0712/160740.522096:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.522213:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.522311:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.522404:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 82d66af
[1:1:0712/160740.522916:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 82d66af
[1:1:0712/160740.523085:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fda81a087ba
[1:1:0712/160740.523168:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fda819ffdef, 7fda81a0877a, 7fda81a0a0cf
[1:1:0712/160740.525870:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/160740.526137:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/160740.526294:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffee2730308, 0x7ffee2730288)
[1:1:0712/160740.532568:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/160740.534772:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/160740.624721:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x28bc13ba5220
[1:1:0712/160740.624916:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/160740.694479:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/160740.696250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 14a0dafce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/160740.696698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/160740.699526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[17758:17758:0712/160741.014415:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160741.016349:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160741.026873:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[17758:17770:0712/160741.026948:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160741.027192:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://down.chinaz.com/
[17758:17758:0712/160741.027234:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://down.chinaz.com/, http://down.chinaz.com/soft/38078.htm, 1
[17758:17758:0712/160741.027414:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://down.chinaz.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:07:41 GMT Content-Type: text/html Last-Modified: Wed, 10 Jul 2019 03:06:30 GMT Accept-Ranges: bytes ETag: "6cc1679cc36d51:0" X-Frame-Options: SAMEORIGIN Content-Encoding: gzip Transfer-Encoding: chunked X-Via: 1.1 PSgdgzrmzBGPat195:1 (Cdn Cache Server V2.0), 1.1 PSnmgbynewtph21:6 (Cdn Cache Server V2.0) Connection: keep-alive  ,17854, 5
[1:7:0712/160741.029523:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160741.041413:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://down.chinaz.com/
[17758:17758:0712/160741.099152:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://down.chinaz.com/, http://down.chinaz.com/, 1
[17758:17758:0712/160741.099217:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://down.chinaz.com/, http://down.chinaz.com
[1:1:0712/160741.106456:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160741.150103:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.180249:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.180435:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.391882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7fda69743070 0x28bc13bf1fe0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.406967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , /*!
 * jQuery JavaScript Library v1.5.1
 * http://jquery.com/
 *
 * Copyright 2011, John Resig
 * Du
[1:1:0712/160741.407149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160741.410759:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160741.496879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7fda69743070 0x28bc13bf1fe0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.500927:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 164 0x7fda69743070 0x28bc13bf1fe0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.520104:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0255151, 95, 1
[1:1:0712/160741.520282:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.676484:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.676681:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.677934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7fda69743070 0x28bc13f00fe0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.678410:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.writeln("<a href=http://www.cnitidc.com target=_blank><img src=\"http://stats.chinaz.com/c0
[1:1:0712/160741.678520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160741.682117:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 202 0x7fda69743070 0x28bc13f00fe0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.689485:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0127521, 94, 1
[1:1:0712/160741.689639:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.846901:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.847069:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.848327:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 232 0x7fda69743070 0x28bc13dd8ce0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.848869:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.write("<a href=\"https://www.90qh.com/website/\" target=\"_blank\" rel=\"nofollow\"><img sr
[1:1:0712/160741.848976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160741.858276:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.011143, 101, 1
[1:1:0712/160741.858416:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160741.982269:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 255 0x7fda6b66b2e0 0x28bc13ca8ce0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160741.982945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0712/160741.983069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160742.041497:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160742.041646:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160742.042995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7fda69743070 0x28bc13f08960 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160742.043498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.writeln("<script type=\"text/javascript\">");
document.writeln("var cpro_id=\"u2344519\";"
[1:1:0712/160742.043618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160742.044503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 266 0x7fda69743070 0x28bc13f08960 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160742.228580:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/160742.344237:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 320 0x7fda69aabbd0 0x28bc13ca2b58 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160742.351434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/160742.351619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
		remove user.e_51321b0e -> 0
[1:1:0712/160745.710024:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[17758:17758:0712/160751.906163:INFO:CONSOLE(5)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cpro.baidustatic.com/cpro/ui/c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/soft230.js (5)
[17758:17758:0712/160751.907164:INFO:CONSOLE(5)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://cpro.baidustatic.com/cpro/ui/c.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/soft230.js (5)
[3:3:0712/160751.922900:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/160752.230766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/160752.230993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160752.404325:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160752.677431:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160752.677618:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160752.681149:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 411 0x7fda69743070 0x28bc1451cb60 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160752.682406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , //u1210584
document.writeln("<script type=\'text/javascript\' src=\'//a1.zhanzhang.net/site/2y6xh.j
[1:1:0712/160752.682578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[17758:17758:0712/160752.685082:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/site/2y6xh.js?yt=ciczqvp, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/ytciczqvp.js (2)
[17758:17758:0712/160752.689521:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/site/2y6xh.js?yt=ciczqvp, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/ytciczqvp.js (2)
[1:1:0712/160752.701870:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7fda6b66b2e0 0x28bc13eefde0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160752.702617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , ___adblockplus({"queryid" : "3f0e26e8b763194a","tuid" : "u2344519_0","placement" : {"basic" : {"sspI
[1:1:0712/160752.702722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160752.734445:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160752.735540:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160752.736635:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x28bc147ed220
[1:1:0712/160752.736751:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[17758:17758:0712/160752.737903:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: iframeu2344519_0, 4, 4, 
[1:1:0712/160752.744465:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160752.744850:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160752.746214:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[1:1:0712/160752.749511:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 500
[1:1:0712/160752.749786:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 443
[1:1:0712/160752.749906:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 443 0x7fda69743070 0x28bc1451c960 , 5:3_http://down.chinaz.com/, 1, -5:3_http://down.chinaz.com/, 414 0x7fda6b66b2e0 0x28bc13eefde0 
[1:1:0712/160752.753386:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 50
[1:1:0712/160752.753641:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 444
[1:1:0712/160752.753775:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 444 0x7fda69743070 0x28bc13f04d60 , 5:3_http://down.chinaz.com/, 1, -5:3_http://down.chinaz.com/, 414 0x7fda6b66b2e0 0x28bc13eefde0 
[17758:17758:0712/160752.920366:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160752.922476:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17758:0712/160752.937657:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[17758:17758:0712/160752.937716:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://pos.baidu.com/, http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364, 4
[17758:17758:0712/160752.937816:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 11685 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 08:07:52 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 16:07:52 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,17854, 5
[17758:17770:0712/160752.938846:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[17758:17770:0712/160752.938897:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[1:1:0712/160752.940803:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160752.940960:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:7:0712/160752.958405:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160753.046192:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 434, "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.048105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/160753.048263:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.188053:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 444, 7fda6c0888db
[1:1:0712/160753.196160:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc62860","ptid":"414 0x7fda6b66b2e0 0x28bc13eefde0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160753.196334:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/","ptid":"414 0x7fda6b66b2e0 0x28bc13eefde0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160753.196576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 493
[1:1:0712/160753.196680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 493 0x7fda69743070 0x28bc13c70ce0 , 5:3_http://down.chinaz.com/, 0, , 444 0x7fda69743070 0x28bc13f04d60 
[1:1:0712/160753.196843:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.197137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160753.197226:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.281402:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_http://pos.baidu.com/
[1:1:0712/160753.360481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160753.360643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.578286:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160753.660767:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 493, 7fda6c0888db
[1:1:0712/160753.671334:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"444 0x7fda69743070 0x28bc13f04d60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160753.671562:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"444 0x7fda69743070 0x28bc13f04d60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160753.671835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 521
[1:1:0712/160753.671977:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 521 0x7fda69743070 0x28bc14e68ce0 , 5:3_http://down.chinaz.com/, 0, , 493 0x7fda69743070 0x28bc13c70ce0 
[1:1:0712/160753.672129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.672415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160753.672566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.691784:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 443, 7fda6c0888db
[1:1:0712/160753.699649:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc62860","ptid":"414 0x7fda6b66b2e0 0x28bc13eefde0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160753.699799:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/","ptid":"414 0x7fda6b66b2e0 0x28bc13eefde0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160753.700004:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 525
[1:1:0712/160753.700098:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 525 0x7fda69743070 0x28bc14a7fb60 , 5:3_http://down.chinaz.com/, 0, , 443 0x7fda69743070 0x28bc1451c960 
[1:1:0712/160753.700256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.700535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160753.700627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.754343:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[17758:17758:0712/160753.767747:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_http://pos.baidu.com/, http://pos.baidu.com/, 4
[17758:17758:0712/160753.767802:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/160753.768028:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160753.781487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160753.781668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.864809:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160753.864961:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.866839:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 509 0x7fda69743070 0x28bc13baf1e0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.867325:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.writeln("<a href=\"http://www.kaidandashi.com\" target=_blank><img src=\"http://stats.china
[1:1:0712/160753.867431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160753.875494:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0104852, 113, 1
[1:1:0712/160753.875631:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160753.887457:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 510 0x7fda6b66b2e0 0x28bc1453fae0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160753.891798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , try{!function(t){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_ds_||(win
[1:1:0712/160753.891945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160754.249751:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160754.251570:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160754.252685:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x28bc1512c020
[1:1:0712/160754.252790:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[17758:17758:0712/160754.253922:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[1:1:0712/160754.260817:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160754.260952:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160754.261969:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[1:1:0712/160754.304012:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 511 0x7fda6b66b2e0 0x28bc13835f60 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160754.304608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , window.__baidu_dup_jobruner = {};
try {
    var storage = window.localStorage;
    if (storage &&
[1:1:0712/160754.304712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160754.305432:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://down.chinaz.com/soft/38078.htm"
[17758:17758:0712/160754.404894:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160754.406983:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160754.421357:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 5
[17758:17770:0712/160754.421424:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 5, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160754.421445:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[17758:17758:0712/160754.421487:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://pos.baidu.com/, http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0, 5
[17758:17758:0712/160754.421555:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:5_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 8276 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 08:07:54 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 16:07:54 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,17854, 5
[1:7:0712/160754.422641:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160754.452633:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 521, 7fda6c0888db
[1:1:0712/160754.462281:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"493 0x7fda69743070 0x28bc13c70ce0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160754.462453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"493 0x7fda69743070 0x28bc13c70ce0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160754.462715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 588
[1:1:0712/160754.462873:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 588 0x7fda69743070 0x28bc1528d260 , 5:3_http://down.chinaz.com/, 0, , 521 0x7fda69743070 0x28bc14e68ce0 
[1:1:0712/160754.463039:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160754.463315:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160754.463408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160754.559201:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160754.609460:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 525, 7fda6c0888db
[1:1:0712/160754.620354:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"443 0x7fda69743070 0x28bc1451c960 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160754.620501:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"443 0x7fda69743070 0x28bc1451c960 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160754.620698:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 602
[1:1:0712/160754.620781:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 602 0x7fda69743070 0x28bc152ba260 , 5:3_http://down.chinaz.com/, 0, , 525 0x7fda69743070 0x28bc14a7fb60 
[1:1:0712/160754.620906:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160754.621188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160754.621285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160754.667229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160754.667398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160754.801788:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160754.801959:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160754.803321:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552 0x7fda69743070 0x28bc14e64e60 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160754.803865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.writeln("<a href=\"http://www.idcjf.com/\" target=\"_blank\" rel=\"nofollow\"><img src=\"ht
[1:1:0712/160754.803998:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160754.808148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 552 0x7fda69743070 0x28bc14e64e60 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160754.812617:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0106199, 94, 1
[1:1:0712/160754.812781:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160755.138930:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:5_http://pos.baidu.com/
[1:1:0712/160755.192407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 588, 7fda6c0888db
[1:1:0712/160755.202922:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"521 0x7fda69743070 0x28bc14e68ce0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160755.203135:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"521 0x7fda69743070 0x28bc14e68ce0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160755.203383:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 636
[1:1:0712/160755.203524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 636 0x7fda69743070 0x28bc15292d60 , 5:3_http://down.chinaz.com/, 0, , 588 0x7fda69743070 0x28bc1528d260 
[1:1:0712/160755.203692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160755.203976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160755.204068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160755.243888:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160755.244027:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160755.377680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160755.377953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160755.390176:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 602, 7fda6c0888db
[1:1:0712/160755.398998:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"525 0x7fda69743070 0x28bc14a7fb60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160755.399134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"525 0x7fda69743070 0x28bc14a7fb60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160755.399329:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 649
[1:1:0712/160755.399429:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 649 0x7fda69743070 0x28bc14e64760 , 5:3_http://down.chinaz.com/, 0, , 602 0x7fda69743070 0x28bc152ba260 
[1:1:0712/160755.399566:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160755.399819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160755.399905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160755.555340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7fda6b66b2e0 0x28bc14e5d9e0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160755.560156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (function(){var l;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:
[1:1:0712/160755.560357:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
		remove user.f_b873b2ff -> 0
[1:1:0712/160755.679330:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x70a7d0829c8, 0x28bc13a36160
[1:1:0712/160755.679537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 1000
[1:1:0712/160755.679782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 665
[1:1:0712/160755.679948:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 665 0x7fda69743070 0x28bc13c5f060 , 5:3_http://down.chinaz.com/, 1, -5:3_http://down.chinaz.com/, 614 0x7fda6b66b2e0 0x28bc14e5d9e0 
[17758:17758:0712/160755.694293:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160755.695651:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x28bc15140e20
[1:1:0712/160755.695797:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[17758:17758:0712/160755.696589:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[17758:17758:0712/160755.714800:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_http://down.chinaz.com/, http://down.chinaz.com/, 6
[17758:17758:0712/160755.714892:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, http://down.chinaz.com/, http://down.chinaz.com
[1:1:0712/160755.732864:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3d21fdd57930, 5:3_http://down.chinaz.com/, 5:6_http://down.chinaz.com/, about:blank
[1:1:0712/160755.733027:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, open, 
[1:1:0712/160755.733270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "down.chinaz.com", 6, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160755.733828:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	rj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Uj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Tj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	bk (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	ak (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/160755.735506:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 614 0x7fda6b66b2e0 0x28bc14e5d9e0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160755.739657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, Yj, (a){if(a){if(!Kj(a)&&(a.id?a=Oj(a.id):a=null,!a))throw new M("'element' has already been filled.");i
[1:1:0712/160755.739830:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160755.740321:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Uj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Tj (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	bk (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	ak (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1

[1:1:0712/160755.778698:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160755.784332:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[17758:17758:0712/160755.786680:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: aswift_0, 7, 7, 
[1:1:0712/160755.787171:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x28bc14818820
[1:1:0712/160755.787315:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[1:1:0712/160755.804968:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://down.chinaz.com/soft/38078.htm"
[17758:17758:0712/160755.807769:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_http://down.chinaz.com/, http://down.chinaz.com/, 7
[17758:17758:0712/160755.807852:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, http://down.chinaz.com/, http://down.chinaz.com
[17758:17758:0712/160755.854426:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160755.855491:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x28bc14817420
[1:1:0712/160755.855622:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[17758:17758:0712/160755.856959:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_esf, 8, 8, 
[1:1:0712/160755.864474:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160755.864626:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160755.866976:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[17758:17758:0712/160755.873944:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160755.875531:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17758:0712/160755.892860:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://googleads.g.doubleclick.net/
[17758:17758:0712/160755.892917:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://googleads.g.doubleclick.net/, http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#, 8
[17758:17758:0712/160755.892978:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:8_http://googleads.g.doubleclick.net/, HTTP/1.1 200 OK P3P: policyref="http://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" Timing-Allow-Origin: * Vary: Accept-Encoding Date: Thu, 11 Jul 2019 19:19:43 GMT Expires: Thu, 25 Jul 2019 19:19:43 GMT Content-Type: text/html; charset=UTF-8 ETag: 6832606795824562093 X-Content-Type-Options: nosniff Content-Encoding: gzip Server: cafe Content-Length: 7008 X-XSS-Protection: 0 Age: 45325 Cache-Control: public, max-age=1209600  ,17854, 5
[17758:17770:0712/160755.900878:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 8
[17758:17770:0712/160755.900947:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 8, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/160755.902569:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160755.978536:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160755.978734:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160755.979996:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 620 0x7fda69743070 0x28bc152bb060 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160755.980510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.write("<a href=http://www.yisu.com target=_blank><img src=http://stats.chinaz.com/ym_g/imag
[1:1:0712/160755.980711:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160755.987016:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 620 0x7fda69743070 0x28bc152bb060 , "http://down.chinaz.com/soft/38078.htm"
[17758:17758:0712/160755.990976:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/common/web/source/3mct2.js?idvj=cescc, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/idvjcescc.js (2)
[17758:17758:0712/160755.994154:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/common/web/source/3mct2.js?idvj=cescc, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/idvjcescc.js (2)
[17758:17758:0712/160756.207964:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_http://pos.baidu.com/, http://pos.baidu.com/, 5
[1:1:0712/160756.207861:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[17758:17758:0712/160756.208020:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/160756.211239:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 636, 7fda6c0888db
[1:1:0712/160756.224754:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"588 0x7fda69743070 0x28bc1528d260 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160756.224933:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"588 0x7fda69743070 0x28bc1528d260 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160756.225194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 759
[1:1:0712/160756.225305:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 759 0x7fda69743070 0x28bc1583ed60 , 5:3_http://down.chinaz.com/, 0, , 636 0x7fda69743070 0x28bc15292d60 
[1:1:0712/160756.225459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160756.225749:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160756.225858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160756.362788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.364353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_http://pos.baidu.com/, 3d21fdd77378, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0712/160756.364751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364", "pos.baidu.com", 4, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160756.369507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.373499:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.376565:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.381453:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.510077:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.512519:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.518114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.603906:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.606202:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 645, "http://pos.baidu.com/pcom?conwid=230&conhei=160&rdid=2344519&dc=3&exps=110011&psi=87f1115982a2781655f1baee52644692&di=u2344519&dri=0&dis=0&dai=1&ps=353x734&coa=at%3D3%26rsi0%3D230%26rsi1%3D160%26pat%3D6%26tn%3DbaiduCustNativeAD%26rss1%3D%2523FFFFFF%26conBW%3D1%26adp%3D1%26ptt%3D0%26titFF%3D%2525E5%2525BE%2525AE%2525E8%2525BD%2525AF%2525E9%25259B%252585%2525E9%2525BB%252591%26titFS%3D14%26rss2%3D%2523000000%26titSU%3D0%26ptbg%3D90%26piw%3D0%26pih%3D0%26ptp%3D0&enu=encoding&dcb=___adblockplus&dtm=HTML_POST&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562918863196&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dbv=2&drs=1&pcs=902x620&pss=980x620&cfv=0&cpl=2&chi=2&cce=true&cec=GBK&tlm=1562727990&rw=635&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&ecd=1&uc=1855x1056&pis=-1x-1&sr=1920x1080&tcn=1562918863&qn=3f0e26e8b763194a&tt=1562918862359.912.10347.10364"
[1:1:0712/160756.644744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160756.644941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160757.559790:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 649, 7fda6c0888db
[1:1:0712/160757.572562:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"602 0x7fda69743070 0x28bc152ba260 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160757.572729:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"602 0x7fda69743070 0x28bc152ba260 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160757.572924:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 891
[1:1:0712/160757.573012:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 891 0x7fda69743070 0x28bc15adc8e0 , 5:3_http://down.chinaz.com/, 0, , 649 0x7fda69743070 0x28bc14e64760 
[1:1:0712/160757.573165:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160757.573469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160757.573616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160757.709766:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:8_http://googleads.g.doubleclick.net/
[1:1:0712/160758.026261:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 743, "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160758.027683:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/160758.027797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160758.164642:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160758.165697:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160758.166822:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x28bc15140420
[1:1:0712/160758.166956:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[17758:17758:0712/160758.167945:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[1:1:0712/160758.176259:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160758.176400:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160758.179988:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[1:1:0712/160758.344198:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[17758:17758:0712/160758.374564:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160758.376608:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160758.390719:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[17758:17770:0712/160758.390786:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160758.390802:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[17758:17758:0712/160758.390843:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://pos.baidu.com/, http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866, 9
[17758:17758:0712/160758.390913:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 13393 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 08:07:58 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 16:07:58 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,17854, 5
[1:7:0712/160758.392456:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160758.423593:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 759, 7fda6c0888db
[1:1:0712/160758.438297:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"636 0x7fda69743070 0x28bc15292d60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160758.438487:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"636 0x7fda69743070 0x28bc15292d60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160758.438793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 946
[1:1:0712/160758.438969:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 946 0x7fda69743070 0x28bc15da8360 , 5:3_http://down.chinaz.com/, 0, , 759 0x7fda69743070 0x28bc1583ed60 
[1:1:0712/160758.439196:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160758.439558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160758.439692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160758.641946:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160758.642757:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://down.chinaz.com/, 5:4_http://pos.baidu.com/
[1:1:0712/160758.642855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160758.642949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160758.646381:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160758.999673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160758.999837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160759.001205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 665, 7fda6c088881
[1:1:0712/160759.016689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc62860","ptid":"614 0x7fda6b66b2e0 0x28bc14e5d9e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160759.016878:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/","ptid":"614 0x7fda6b66b2e0 0x28bc14e5d9e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160759.017119:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160759.017388:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){return n.processGoogleToken(d,1)}
[1:1:0712/160759.017465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160759.622041:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 864 0x7fda6b66b2e0 0x28bc150f1ce0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160759.622584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , try{window.localStorage.setItem('google_pub_config','{"sraConfigs":{"2":{"sraTimeout":60000}}}');}ca
[1:1:0712/160759.622686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160759.640007:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 865 0x7fda6b66b2e0 0x28bc135542e0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160759.640525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , processGoogleToken({"newToken":"AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR
[1:1:0712/160759.640629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[17758:17758:0712/160800.197257:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_http://googleads.g.doubleclick.net/, http://googleads.g.doubleclick.net/, 8
[17758:17758:0712/160800.197343:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, http://googleads.g.doubleclick.net/, http://googleads.g.doubleclick.net
[1:1:0712/160800.197562:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160800.344303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 891, 7fda6c0888db
[1:1:0712/160800.359142:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"649 0x7fda69743070 0x28bc14e64760 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160800.359323:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"649 0x7fda69743070 0x28bc14e64760 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160800.359564:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1028
[1:1:0712/160800.359686:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1028 0x7fda69743070 0x28bc155ea2e0 , 5:3_http://down.chinaz.com/, 0, , 891 0x7fda69743070 0x28bc15adc8e0 
[1:1:0712/160800.359918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160800.360258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160800.360373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160800.983736:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160801.119823:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160801.120042:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.133371:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7fda69743070 0x28bc14aece60 , "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.134394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://pos.baidu.com/, 3d21fdd4af20, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0712/160801.134623:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0", "pos.baidu.com", 5, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160801.136886:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7fda69743070 0x28bc14aece60 , "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.141720:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7fda69743070 0x28bc14aece60 , "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.144982:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7fda69743070 0x28bc14aece60 , "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.223058:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7fda69743070 0x28bc14aece60 , "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.225831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 941 0x7fda69743070 0x28bc14aece60 , "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160801.344695:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:9_http://pos.baidu.com/
[1:1:0712/160801.401245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 946, 7fda6c0888db
[1:1:0712/160801.418525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"759 0x7fda69743070 0x28bc1583ed60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160801.418685:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"759 0x7fda69743070 0x28bc1583ed60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160801.418894:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1122
[1:1:0712/160801.418998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1122 0x7fda69743070 0x28bc15adc760 , 5:3_http://down.chinaz.com/, 0, , 946 0x7fda69743070 0x28bc15da8360 
[1:1:0712/160801.419177:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160801.419426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160801.419509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160801.771923:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160801.772314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){l.watchIframeLoaded=!0,l.viewContext.lastAdViewStatus=!l.viewContext.currAdViewStatus,l.sendMessa
[1:1:0712/160801.772437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160801.810231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160801.810409:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160802.321794:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160802.810123:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1028, 7fda6c0888db
[1:1:0712/160802.827793:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"891 0x7fda69743070 0x28bc15adc8e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160802.827967:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"891 0x7fda69743070 0x28bc15adc8e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160802.828189:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1160
[1:1:0712/160802.828292:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1160 0x7fda69743070 0x28bc160637e0 , 5:3_http://down.chinaz.com/, 0, , 1028 0x7fda69743070 0x28bc155ea2e0 
[1:1:0712/160802.828473:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160802.828729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160802.828813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160803.204807:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160803.204971:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160803.208233:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1062 0x7fda69743070 0x28bc15620e60 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160803.209263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , //源码开始
document.writeln("<ul>");
document.writeln("    <li>");
document.writeln("        
[1:1:0712/160803.209392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160803.252819:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1062 0x7fda69743070 0x28bc15620e60 , "http://down.chinaz.com/soft/38078.htm"
[17758:17758:0712/160803.277422:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/site/production/source/4zqv.js?bwoc=vovfs, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/soft280.js (1)
[17758:17758:0712/160803.278313:INFO:CONSOLE(1)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/site/production/source/4zqv.js?bwoc=vovfs, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/soft280.js (1)
[1:1:0712/160803.764609:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160803.765012:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://down.chinaz.com/, 5:5_http://pos.baidu.com/
[1:1:0712/160803.765128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160803.765227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160803.768116:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[17758:17758:0712/160804.255913:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_http://pos.baidu.com/, http://pos.baidu.com/, 9
[17758:17758:0712/160804.255986:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/160804.256241:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160804.298949:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1122, 7fda6c0888db
[1:1:0712/160804.319732:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"946 0x7fda69743070 0x28bc15da8360 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160804.319949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"946 0x7fda69743070 0x28bc15da8360 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160804.320251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1286
[1:1:0712/160804.320392:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1286 0x7fda69743070 0x28bc14fc4fe0 , 5:3_http://down.chinaz.com/, 0, , 1122 0x7fda69743070 0x28bc15adc760 
[1:1:0712/160804.320601:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160804.320875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160804.320971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160804.462312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160804.462475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160804.864706:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160804.864844:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/160804.866298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1148 0x7fda69743070 0x28bc13790160 , "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/160804.884307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_http://googleads.g.doubleclick.net/, 3d21fdd2c320, , , 
(function(){var m=this||self;
function n(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Arr
[1:1:0712/160804.884491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#", "googleads.g.doubleclick.net", 8, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160804.899160:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://googleads.g.doubleclick.net/pagead/html/r20190710/r20190131/zrt_lookup.html#"
[1:1:0712/160805.856838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1160, 7fda6c0888db
[1:1:0712/160805.877796:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1028 0x7fda69743070 0x28bc155ea2e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160805.877980:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1028 0x7fda69743070 0x28bc155ea2e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160805.878248:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1335
[1:1:0712/160805.878401:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1335 0x7fda69743070 0x28bc145f9760 , 5:3_http://down.chinaz.com/, 0, , 1160 0x7fda69743070 0x28bc160637e0 
[1:1:0712/160805.878637:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160805.878964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160805.879069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160806.166047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1213, "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160806.167545:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/160806.167683:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160806.344142:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160806.345749:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160806.346487:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x28bc149d7020
[1:1:0712/160806.347722:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[17758:17758:0712/160806.348286:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[1:1:0712/160806.356531:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160806.356723:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160806.357548:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[17758:17758:0712/160806.497293:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160806.499437:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160806.514039:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 10
[17758:17770:0712/160806.514106:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 10, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160806.514127:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[17758:17758:0712/160806.514171:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://pos.baidu.com/, http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1, 10
[17758:17758:0712/160806.514242:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:10_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 12031 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 08:08:06 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 16:08:06 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,17854, 5
[1:7:0712/160806.526318:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160807.768610:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160807.818977:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/160807.988191:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1286, 7fda6c0888db
[1:1:0712/160808.010716:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1122 0x7fda69743070 0x28bc15adc760 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160808.010916:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1122 0x7fda69743070 0x28bc15adc760 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160808.011187:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1453
[1:1:0712/160808.011303:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1453 0x7fda69743070 0x28bc16793160 , 5:3_http://down.chinaz.com/, 0, , 1286 0x7fda69743070 0x28bc14fc4fe0 
[1:1:0712/160808.011501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160808.011767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160808.011869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160808.104555:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160808.104718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160808.305778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1298 0x7fda69aabbd0 0x28bc138b9d58 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160808.317219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://down.chinaz.com/, 3d21fdd57930, , , (function(window,document,location){var p;function aa(a){var b=0;return function(){return b<a.length
[1:1:0712/160808.317406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.373789:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, D.google_process_slots, (){return sj(D)}
[1:1:0712/160808.373959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 2, , , 0
[1:1:0712/160808.374377:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.377636:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 30000, 0x70a7d0829c8, 0x28bc13a36160
[1:1:0712/160808.377737:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 30000
[1:1:0712/160808.377935:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 1468
[1:1:0712/160808.378041:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1468 0x7fda69743070 0x28bc167bce60 , 5:3_http://down.chinaz.com/, 2, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 1298 0x7fda69aabbd0 0x28bc138b9d58 
[1:1:0712/160808.381552:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3d21fdd24628, 5:3_http://down.chinaz.com/, 5:7_http://down.chinaz.com/, about:blank
[1:1:0712/160808.381658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, open, 
[1:1:0712/160808.381804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "down.chinaz.com", 7, 3, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.382273:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.383730:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1298 0x7fda69aabbd0 0x28bc138b9d58 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160808.384530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1298 0x7fda69aabbd0 0x28bc138b9d58 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160808.385226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, Mx, (a){var b=a.iframeWin,c=a.vars;b&&(c.google_iframe_start_time=b.google_iframe_start_time);var d=new 
[1:1:0712/160808.385373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.385823:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.387178:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getElementById, 
[1:1:0712/160808.387334:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160808.387842:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.388162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, now, 
[1:1:0712/160808.388289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 6, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.388717:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.389975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, indexOf, 
[1:1:0712/160808.390104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 7, , , 0
[1:1:0712/160808.390551:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	oh (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.390713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Kh, (a){return Jh(a).eids||[]}
[1:1:0712/160808.390853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 8, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.391267:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.391576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, indexOf, 
[1:1:0712/160808.391696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 9, , , 0
[1:1:0712/160808.392135:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	oh (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.392279:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, xj, (a,b){qj(uj,a,b,void 0)}
[1:1:0712/160808.392442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 10, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.392857:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.403717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, , (c){return Oh(a,c)}
[1:1:0712/160808.403942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 11, , , 0
[1:1:0712/160808.404602:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.409716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Jh, (a){a.google_ad_modifications||(a.google_ad_modifications={});return a.google_ad_modifications}
[1:1:0712/160808.409900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 12, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.410496:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.411026:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, call, 
[1:1:0712/160808.411184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 13, , , 0
[1:1:0712/160808.411825:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	v (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.412060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, push, 
[1:1:0712/160808.412229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 14, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.412824:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.412985:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, next, 
[1:1:0712/160808.413165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 15, , , 0
[1:1:0712/160808.413827:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ba (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.414025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, $a, (a,b){for(var c=a.length,d=Array(c),e=x(a)?a.split(""):a,f=0;f<c;f++)f in e&&(d[f]=b.call(void 0,e[f
[1:1:0712/160808.414310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 16, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.414943:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hm (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	Qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.460601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getRandomValues, 
[1:1:0712/160808.460952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 17, , , 0
[1:1:0712/160808.461783:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	of (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	vy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.462087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, y, (a){return"number"==typeof a}
[1:1:0712/160808.462343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 18, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.463003:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.474632:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getElementById, 
[1:1:0712/160808.474882:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 19, , , 0
[1:1:0712/160808.475492:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.475700:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Ok, (a){a.google_reactive_ads_global_state||(a.google_reactive_ads_global_state=new Nk);return a.google_
[1:1:0712/160808.475922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 20, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.476527:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zr (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.484485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, addEventListener, 
[1:1:0712/160808.484763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 21, , , 0
[1:1:0712/160808.485641:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.486050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, As, (a,b){var c=this;this.j=a;uk(b,"rctcnf",T(426,function(d,e){return Bs(c,d,e)}),T(427,Ta(Zk,b,"rach::
[1:1:0712/160808.486384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 22, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.487135:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.488015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, addEventListener, 
[1:1:0712/160808.488293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 23, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.489149:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	L (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	uk (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	As (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.489471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, Vm, (a){return!!Um(a)||null!=a.google_pgb_reactive}
[1:1:0712/160808.489721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 24, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.490356:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.498366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getElementById, 
[1:1:0712/160808.498703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 25, , , 0
[1:1:0712/160808.499580:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.499871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, nv, (){jv=iv();lv=jv.googleToken=jv.googleToken||{};var a=C();lv[1]&&lv[3]>a&&0<lv[2]||(lv[1]="",lv[2]=-
[1:1:0712/160808.500204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 26, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.500986:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.553892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, now, 
[1:1:0712/160808.554260:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 27, , , 0
[1:1:0712/160808.555084:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.555291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, round, 
[1:1:0712/160808.555611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 28, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.556298:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.556560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, now, 
[1:1:0712/160808.556773:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 29, , , 0
[1:1:0712/160808.557456:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.557626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, dv, (a,b,c){a-=b;return a>=(void 0===c?1E5:c)?"M":0<=a?a:"-M"}
[1:1:0712/160808.557870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 30, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.558514:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.657899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getBoundingClientRect, 
[1:1:0712/160808.658229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 31, , , 0
[1:1:0712/160808.659011:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.659283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, De, (a){return a?new Ee(Fe(a)):Va||(Va=new Ee)}
[1:1:0712/160808.659565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 32, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.660279:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	om (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.676466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, l.cb, (){return!(!window||!Array)}
[1:1:0712/160808.676839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 33, , , 0
[1:1:0712/160808.677762:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Yu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.678089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, mh, (a){return!(!a||!a.call)&&"function"===typeof a}
[1:1:0712/160808.678460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 34, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.679366:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yu (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.679930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, l.Qa, (){return this.i}
[1:1:0712/160808.680311:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 35, , , 0
[1:1:0712/160808.681290:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.681627:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 36, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, as, (a,b){if(!b)return null;var c=Ok(b);if(!c.wasReactiveAdConfigHandlerRegistered)return null;var d=0;N
[1:1:0712/160808.681989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 36, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.682776:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.690748:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 37, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getBoundingClientRect, 
[1:1:0712/160808.691075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 37, , , 0
[1:1:0712/160808.691840:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.692255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 38, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, xm, (a){return{visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[a.visibilityState||a.webkitVisibilit
[1:1:0712/160808.692551:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 38, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.693369:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	cw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	bw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.696228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 39, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.696511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 39, , , 0
[1:1:0712/160808.697363:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.697728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 40, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/160808.698109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 40, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.698933:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.699599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 41, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.699900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 41, , , 0
[1:1:0712/160808.700657:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.700814:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 42, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.701168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 42, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.701927:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.702220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 43, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.702513:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 43, , , 0
[1:1:0712/160808.703241:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.703408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 44, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.703712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 44, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.704433:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.708932:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 45, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, contains, 
[1:1:0712/160808.709302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 45, , , 0
[1:1:0712/160808.710059:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.710228:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 46, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/160808.710565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 46, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.711284:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.711868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 47, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.712164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 47, , , 0
[1:1:0712/160808.712881:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.713112:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 48, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/160808.713463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 48, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.714341:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.714577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 49, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.714917:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 49, , , 0
[1:1:0712/160808.715832:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.716120:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 50, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.716609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 50, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.717629:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.717899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 51, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.718300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 51, , , 0
[1:1:0712/160808.721074:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.721340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 52, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.721729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 52, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.722543:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.726000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 53, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, contains, 
[1:1:0712/160808.726453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 53, , , 0
[1:1:0712/160808.727389:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.727601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 54, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, nw, (a,b){var c=!1;"none"==b.display&&(Xv(a.j,"n"),a.o&&(c=!0));"hidden"!=b.visibility&&"collapse"!=b.vi
[1:1:0712/160808.728001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 54, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.728834:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.729277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 55, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.729685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 55, , , 0
[1:1:0712/160808.730604:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.730829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 56, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/160808.731281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 56, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.732114:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.732307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 57, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.732745:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 57, , , 0
[1:1:0712/160808.733698:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.733931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 58, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.734411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 58, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.735390:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.735729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 59, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.736230:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 59, , , 0
[1:1:0712/160808.737252:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.737515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 60, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.738012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 60, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.738870:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.743466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 61, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, contains, 
[1:1:0712/160808.744090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 61, , , 0
[1:1:0712/160808.745082:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.745427:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 62, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.746000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 62, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.746999:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.747781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 63, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.748288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 63, , , 0
[1:1:0712/160808.749264:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.749531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 64, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, pw, (a,b,c,d){var e=null;try{e=c.style}catch(z){Yv(a.j,"s")}var f=c.getAttribute("width"),g=vf(f),h=c.ge
[1:1:0712/160808.749994:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 64, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.750819:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.751044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 65, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.751433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 65, , , 0
[1:1:0712/160808.752165:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.752320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 66, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.752720:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 66, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.753486:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.753704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 67, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getAttribute, 
[1:1:0712/160808.754110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 67, , , 0
[1:1:0712/160808.754848:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.754999:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 68, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, vf, (a){return uf.test(a)&&(a=Number(a),!isNaN(a))?a:null}
[1:1:0712/160808.755415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 68, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.756240:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.757018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 69, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.757502:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 69, , , 0
[1:1:0712/160808.758325:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	kf (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	sw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.758624:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 70, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, sw, (a,b,c){if(3==b.nodeType)return/\S/.test(b.data)?1:0;if(1==b.nodeType){if(/^(head|script|style)$/i.t
[1:1:0712/160808.759086:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 70, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.759862:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	ow (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	pw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.763194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 71, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, contains, 
[1:1:0712/160808.763691:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 71, , , 0
[1:1:0712/160808.764581:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.764811:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 72, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, qw, (a){return!!a&&/^left|right$/.test(a.cssFloat||a.styleFloat)}
[1:1:0712/160808.765448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 72, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.766448:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	hw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	gw (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.770012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 73, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getElementById, 
[1:1:0712/160808.770677:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 73, , , 0
[1:1:0712/160808.771630:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.771843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 74, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, C, (){return+new Date}
[1:1:0712/160808.772490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 74, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.773499:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.778425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 75, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getBoundingClientRect, 
[1:1:0712/160808.779289:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 75, , , 0
[1:1:0712/160808.780166:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.782697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 76, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, C, (){return+new Date}
[1:1:0712/160808.783367:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 76, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.784156:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.786130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 77, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.786668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 77, , , 0
[1:1:0712/160808.787396:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.787598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 78, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.788149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 78, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.788861:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.789619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 79, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.790091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 79, , , 0
[1:1:0712/160808.790828:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.791095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 80, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.791606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 80, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.792322:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.792843:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 81, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.793355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 81, , , 0
[1:1:0712/160808.794127:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.794348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 82, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.794930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 82, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.795885:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.796552:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 83, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.797283:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 83, , , 0
[1:1:0712/160808.798415:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.798769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 84, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.799423:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 84, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.800344:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.801014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 85, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.801670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 85, , , 0
[1:1:0712/160808.802690:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.802993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 86, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.803634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 86, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.804448:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.805079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 87, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, getComputedStyle, 
[1:1:0712/160808.805666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 87, , , 0
[1:1:0712/160808.806434:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xg (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.806634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 88, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, test, 
[1:1:0712/160808.807181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 88, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.807894:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	yx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.912464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 89, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, createElement, 
[1:1:0712/160808.913298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 89, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.914329:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ve (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.915080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 90, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, N, (a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b.call(void 0,a[c],c,a)}
[1:1:0712/160808.915916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 90, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.916926:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.917572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 91, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, setAttribute, 
[1:1:0712/160808.918253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 91, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.919049:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.919267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 92, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, call, 
[1:1:0712/160808.919879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 92, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.920712:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.921062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 93, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, setAttribute, 
[1:1:0712/160808.921640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 93, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.922402:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.922584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 94, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, call, 
[1:1:0712/160808.923132:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 94, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.923862:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.924125:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 95, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, setAttribute, 
[1:1:0712/160808.924681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 95, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.925504:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.926060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 96, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, call, 
[1:1:0712/160808.926619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 96, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.927357:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.927659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 97, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, setAttribute, 
[1:1:0712/160808.928217:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 97, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.928952:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.929176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 98, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdd24628, call, 
[1:1:0712/160808.929732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 98, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.930463:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.930794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 99, -5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, setAttribute, 
[1:1:0712/160808.933453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 99, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160808.934696:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	N (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	zy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Ly (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	My (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Py (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Qy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	yy (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Px (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Nx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	qj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	xj (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Mx (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	<anonymous>:1:1
	ci (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	Xd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	Pd (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1
	D.google_process_slots (http://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js:1:1)
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160808.935066:INFO:switcher_impl.cc(1415)] 			[ERROR] updated frame chain. The number of frame chain is larger than the thresold, please check it! [num, thresold] = 100, 100
[17758:17758:0712/160808.939653:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160808.940734:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x28bc147ec820
[1:1:0712/160808.941169:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[17758:17758:0712/160808.941907:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_ads_frame1, 11, 11, 
[1:1:0712/160808.951981:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160808.952120:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160808.952898:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[1:1:0712/160809.224135:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x70a7d0829c8, 0x28bc13a36268
[1:1:0712/160809.224300:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 0
[1:1:0712/160809.224508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 1494
[1:1:0712/160809.224635:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1494 0x7fda69743070 0x28bc16a3e560 , 5:3_http://down.chinaz.com/, 100, , 1298 0x7fda69aabbd0 0x28bc138b9d58 
[1:1:0712/160809.226218:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x70a7d1ab328, 0x28bc13a36268
[1:1:0712/160809.226335:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 0
[1:1:0712/160809.226534:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 1496
[1:1:0712/160809.226675:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1496 0x7fda69743070 0x28bc16a4d560 , 5:3_http://down.chinaz.com/, 100, , 1298 0x7fda69aabbd0 0x28bc138b9d58 
[17758:17758:0712/160809.373974:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160809.376365:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160809.391496:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 11
[17758:17770:0712/160809.391562:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 11, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160809.391594:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://googleads.g.doubleclick.net/
[17758:17758:0712/160809.391636:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225, 11
[17758:17758:0712/160809.391711:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:11_https://googleads.g.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* content-type:text/html; charset=UTF-8 x-content-type-options:nosniff content-encoding:br date:Fri, 12 Jul 2019 08:08:09 GMT server:cafe content-length:6824 x-xss-protection:0 alt-svc:quic="googleads.g.doubleclick.net:443"; ma=2592000; v="46,43,39",quic=":443"; ma=2592000; v="46,43,39"  ,17854, 5
[1:7:0712/160809.402181:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160811.026087:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160811.053453:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1335, 7fda6c0888db
[1:1:0712/160811.076087:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1160 0x7fda69743070 0x28bc160637e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160811.076304:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1160 0x7fda69743070 0x28bc160637e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160811.076660:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1539
[1:1:0712/160811.076780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1539 0x7fda69743070 0x28bc16d6fc60 , 5:3_http://down.chinaz.com/, 0, , 1335 0x7fda69743070 0x28bc145f9760 
[1:1:0712/160811.076977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160811.077310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160811.077454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160811.505240:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:10_http://pos.baidu.com/
[1:1:0712/160811.999829:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0"
[1:1:0712/160812.001224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_http://pos.baidu.com/, 3d21fdd4af20, , window.onload, (){logo.init({containerId:"container",closeDirect:true,feedbackParentId:"container",deviceType:1})}
[1:1:0712/160812.001400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/s?hei=22&wid=930&di=u1210584&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&dtm=HTML_POST&dis=0&pcs=887x666&tpr=1562918874169&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ccd=24&pis=-1x-1&dc=3&chi=2&tcn=1562918874&psr=1920x1080&cpl=2&dri=0&tlm=1562727990&cmi=2&ari=2&cfv=0&cec=GBK&dai=2&exps=111000,116008,110011&par=1855x1056&pss=980x1240&col=en-US&cce=true&cja=false&ps=570x16&drs=1&cdo=-1&ant=0", "pos.baidu.com", 5, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160812.475308:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160812.475495:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.482796:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.497770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:9_http://pos.baidu.com/, 3d21fdd07448, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0712/160812.498026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866", "pos.baidu.com", 9, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160812.502093:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.505995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.510409:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.515123:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.773087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160812.776150:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432 0x7fda69743070 0x28bc138875e0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160813.020721:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160813.616127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1453, 7fda6c0888db
[1:1:0712/160813.640077:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1286 0x7fda69743070 0x28bc14fc4fe0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160813.640250:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1286 0x7fda69743070 0x28bc14fc4fe0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160813.640496:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1662
[1:1:0712/160813.640600:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1662 0x7fda69743070 0x28bc1637bae0 , 5:3_http://down.chinaz.com/, 0, , 1453 0x7fda69743070 0x28bc16793160 
[1:1:0712/160813.640774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160813.641050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160813.641169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160813.796139:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160813.796335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160814.881847:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 1494, 7fda6c088881
[1:1:0712/160814.908522:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdd579303d21fdc628603d21fdd246283d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdd246283d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd24628","ptid":"1298 0x7fda69aabbd0 0x28bc138b9d58 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160814.909565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/","ptid":"1298 0x7fda69aabbd0 0x28bc138b9d58 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160814.909865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160814.910215:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://down.chinaz.com/, 5:7_http://down.chinaz.com/
[1:1:0712/160814.910320:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (f){for(var g=[],h=0;h<arguments.length;++h)g[h]=arguments[h];return Pd(e,a,function(){return b.appl
[1:1:0712/160814.910419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160814.911477:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 1496, 7fda6c088881
[1:1:0712/160814.939785:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdd579303d21fdc628603d21fdd246283d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdd246283d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd246283d21fdd579303d21fdd24628","ptid":"1298 0x7fda69aabbd0 0x28bc138b9d58 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160814.940648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/","ptid":"1298 0x7fda69aabbd0 0x28bc138b9d58 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160814.940889:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160814.941188:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:6_http://down.chinaz.com/, 5:7_http://down.chinaz.com/
[1:1:0712/160814.941285:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_http://down.chinaz.com/, 3d21fdd57930, , , (){b.document.close()}
[1:1:0712/160814.941407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160814.941780:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:6_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdd57930, close, 
[1:1:0712/160814.941912:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160814.942173:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1

[1:1:0712/160815.128388:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:11_https://googleads.g.doubleclick.net/
[1:1:0712/160815.945622:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160815.945775:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160815.949488:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0036571, 82, 1
[1:1:0712/160815.949599:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160816.056398:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1539, 7fda6c0888db
[1:1:0712/160816.082681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1335 0x7fda69743070 0x28bc145f9760 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160816.082840:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1335 0x7fda69743070 0x28bc145f9760 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160816.083047:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1721
[1:1:0712/160816.083153:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1721 0x7fda69743070 0x28bc15ac17e0 , 5:3_http://down.chinaz.com/, 0, , 1539 0x7fda69743070 0x28bc16d6fc60 
[1:1:0712/160816.083337:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160816.083602:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160816.083701:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160816.461989:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[17758:17758:0712/160816.462448:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_http://pos.baidu.com/, http://pos.baidu.com/, 10
[17758:17758:0712/160816.462493:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, http://pos.baidu.com/, http://pos.baidu.com
[1:1:0712/160817.799760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.800200:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://down.chinaz.com/, 5:9_http://pos.baidu.com/
[1:1:0712/160817.800380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160817.800515:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160817.801977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.805494:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.805744:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.805859:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.805993:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.806380:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.806476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160817.806647:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.806820:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.807041:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (f){if(a.ampInaboxInitialized)return hg(a,"message",e),c;var g;a.ampInaboxPendingMessages&&(g=/^amp-
[1:1:0712/160817.807166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.807286:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.807721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.807826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160817.807992:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.808156:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.808366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.808509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 6, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.808635:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.808829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.808936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 7, , , 0
[1:1:0712/160817.809138:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.809289:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.809591:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.809786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 8, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.809959:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.810172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.810358:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 9, , , 0
[1:1:0712/160817.810558:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.810724:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.810992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.811179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 10, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.811346:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.811537:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.811697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 11, , , 0
[1:1:0712/160817.811884:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.812049:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.812288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.812490:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 12, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.812646:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.812857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.813075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 13, , , 0
[1:1:0712/160817.813357:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.813623:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.813936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.814160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 14, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.814317:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.814536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.814760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 15, , , 0
[1:1:0712/160817.814964:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160817.815130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160817.815419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160817.815643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 16, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160817.815786:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160817.815974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160817.816161:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 17, , , 0
[1:1:0712/160817.816341:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160819.357390:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160819.357586:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160819.358579:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1643 0x7fda69743070 0x28bc16852be0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160819.359637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:9_http://pos.baidu.com/, 3d21fdd07448, , , 
// var adJsUrlexp='//cpro.baidustatic.com/cpro/ui/noexpire/js/4.0.1/adClosefeedbackUpgrade.min.js';
[1:1:0712/160819.359802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866", "pos.baidu.com", 9, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160819.375586:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1643 0x7fda69743070 0x28bc16852be0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160819.377326:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1643 0x7fda69743070 0x28bc16852be0 , "http://pos.baidu.com/s?hei=220&wid=690&di=u3067266&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&tcn=1562918878&exps=111000,110011&tpr=1562918874169&cce=true&ccd=24&ari=2&pis=-1x-1&dri=0&psr=1920x1080&dtm=HTML_POST&cdo=-1&cpl=2&ps=1866x0&cja=false&dc=3&cec=GBK&cfv=0&cmi=2&pcs=887x666&par=1855x1056&tlm=1562727990&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&drs=1&dai=3&dis=0&ant=0&chi=2&col=en-US&pss=980x1866"
[1:1:0712/160819.651663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1662, 7fda6c0888db
[1:1:0712/160819.680758:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1453 0x7fda69743070 0x28bc16793160 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160819.680977:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1453 0x7fda69743070 0x28bc16793160 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160819.681290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1845
[1:1:0712/160819.681458:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1845 0x7fda69743070 0x28bc164fbc60 , 5:3_http://down.chinaz.com/, 0, , 1662 0x7fda69743070 0x28bc1637bae0 
[1:1:0712/160819.681709:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160819.682043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160819.682140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160819.769813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160819.769975:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160820.725324:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[17758:17758:0712/160820.725424:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/, 11
[17758:17758:0712/160820.725493:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net
[1:1:0712/160821.237277:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160821.237416:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160821.238636:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1718 0x7fda69743070 0x28bc15f95460 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160821.239087:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , //u2344569
document.writeln("<script type=\'text/javascript\' src=\'//a1.zhanzhang.net/source/openj
[1:1:0712/160821.239189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[17758:17758:0712/160821.241079:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/source/openjs/js/2v558m.js?lgvy=ccdfo, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/lgvyccdfo.js (2)
[17758:17758:0712/160821.244888:INFO:CONSOLE(2)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://a1.zhanzhang.net/source/openjs/js/2v558m.js?lgvy=ccdfo, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stats.chinaz.com/c0g/lgvyccdfo.js (2)
[1:1:0712/160821.536275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1721, 7fda6c0888db
[1:1:0712/160821.567411:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1539 0x7fda69743070 0x28bc16d6fc60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160821.567610:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1539 0x7fda69743070 0x28bc16d6fc60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160821.567897:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1920
[1:1:0712/160821.568011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1920 0x7fda69743070 0x28bc17518e60 , 5:3_http://down.chinaz.com/, 0, , 1721 0x7fda69743070 0x28bc15ac17e0 
[1:1:0712/160821.568209:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160821.568511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160821.568606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160821.843000:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160824.951899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1845, 7fda6c0888db
[1:1:0712/160824.983775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1662 0x7fda69743070 0x28bc1637bae0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160824.983994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1662 0x7fda69743070 0x28bc1637bae0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160824.984265:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1970
[1:1:0712/160824.984416:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1970 0x7fda69743070 0x28bc17568060 , 5:3_http://down.chinaz.com/, 0, , 1845 0x7fda69743070 0x28bc164fbc60 
[1:1:0712/160824.984635:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160824.984954:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160824.985085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160825.017451:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160825.017608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160826.072302:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1873 0x7fda6b66b2e0 0x28bc146f47e0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160826.090201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (function(window,document){var k;function aa(a){var b=0;return function(){return b<a.length?{done:!1
[1:1:0712/160826.090365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160826.131939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Km, (){var a=O(),b=a.__google_ad_urls;if(!b)return a.__google_ad_urls=new Gm(a);try{if(0<=b.getOseId())r
[1:1:0712/160826.132133:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.132724:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.133485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, sa, (a){return"function"==pa(a)}
[1:1:0712/160826.133603:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160826.134081:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[17758:17758:0712/160826.150726:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160826.151846:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 12, 0x28bc13ba2a20
[1:1:0712/160826.151985:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 12
[17758:17758:0712/160826.152979:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: google_osd_static_frame, 12, 12, 
[17758:17758:0712/160826.166784:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_http://down.chinaz.com/, http://down.chinaz.com/, 12
[17758:17758:0712/160826.166880:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 12, 12, http://down.chinaz.com/, http://down.chinaz.com
[1:1:0712/160826.184567:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3d21fdcaae60, 5:3_http://down.chinaz.com/, 5:12_http://down.chinaz.com/, about:blank
[1:1:0712/160826.184720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/, 3d21fdcaae60, 3d21fdc62860, addEventListener, 
[1:1:0712/160826.184846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "down.chinaz.com", 12, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.185303:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	vc (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	R (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Uh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.185571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdcaae60, Xf, (a,b,c,d){Wf(a);var e=S.g().m;a.a&&a.a.getNewBlocks(b,e);a.b&&a.b.getNewBlocks(b,e);a.c&&!c()&&(d(!0
[1:1:0712/160826.185702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160826.186080:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.187225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.getNewBlocks, (a,b){for(var c=this.j.length,d=0;d<c;d++){var e=this.j[d];!e.m&&e.j&&(e.m=!0,a(e.j,e.B,e.G,e.l,void
[1:1:0712/160826.187384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 6, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.187778:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.188126:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, , (b){for(var c=[],d=0;d<arguments.length;++d)c[d]=arguments[d];return a.Tb.apply(a,r(c))}
[1:1:0712/160826.188251:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 7, , , 0
[1:1:0712/160826.188717:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.213792:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getBoundingClientRect, 
[1:1:0712/160826.214061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 8, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.215593:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.217815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, Be, (a){return new H(a.top,a.right,a.bottom,a.left)}
[1:1:0712/160826.218088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 9, , , 0
[1:1:0712/160826.219269:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.220353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getBoundingClientRect, 
[1:1:0712/160826.220536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 10, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.221683:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ec (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.221940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, E, (a,b){this.x=void 0!==a?a:0;this.y=void 0!==b?b:0}
[1:1:0712/160826.222088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 11, , , 0
[1:1:0712/160826.223098:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.$a (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg [as constructor] (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.229403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.getOseId, (){return window&&Math.random&&navigator?this.l:-1}
[1:1:0712/160826.229658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 12, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.230318:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.230538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, bd, (a,b,c){(a=a.a[b])&&Zc(a,c)}
[1:1:0712/160826.230710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 13, , , 0
[1:1:0712/160826.231320:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.232881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Km, (){var a=O(),b=a.__google_ad_urls;if(!b)return a.__google_ad_urls=new Gm(a);try{if(0<=b.getOseId())r
[1:1:0712/160826.233130:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 14, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.233753:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.234318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, sa, (a){return"function"==pa(a)}
[1:1:0712/160826.234492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 15, , , 0
[1:1:0712/160826.235114:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.235893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.numBlocks, (){return this.j.length}
[1:1:0712/160826.236083:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 16, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.236616:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Yf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.236844:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, Sh, (a){Uh(a);Xf(a.a,function(b){for(var c=[],d=0;d<arguments.length;++d)c[d]=arguments[d];return a.Tb.a
[1:1:0712/160826.237010:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 17, , , 0
[1:1:0712/160826.237532:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.238145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.getNewBlocks, (a,b){for(var c=this.j.length,d=0;d<c;d++){var e=this.j[d];!e.m&&e.j&&(e.m=!0,a(e.j,e.B,e.G,e.l,void
[1:1:0712/160826.238348:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 18, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.238895:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.239423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, a.g, (){return a.Ta?a.Ta:a.Ta=new a}
[1:1:0712/160826.239625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 19, , , 0
[1:1:0712/160826.240183:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.268955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.getOseId, (){return window&&Math.random&&navigator?this.l:-1}
[1:1:0712/160826.269314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 20, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.270000:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Zf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.270251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, dh, (a,b){var c=Y;if(!c.B){c.B=!0;if(!c.s&&!ch()){var d=Q(137,function(e){for(var f=[],g=0;g<arguments.l
[1:1:0712/160826.270537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 21, , , 0
[1:1:0712/160826.271225:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.290444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160826.290802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 22, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.292379:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.292982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160826.293288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 23, , , 0
[1:1:0712/160826.294653:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.296712:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160826.297138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 24, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.298617:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.299447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160826.299733:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 25, , , 0
[1:1:0712/160826.301142:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.303529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160826.303906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 26, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.305228:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.305579:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160826.305873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 27, , , 0
[1:1:0712/160826.307090:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.i (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	dh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Xh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Qh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.394129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x70a7d0829c8, 0x28bc13a36190
[1:1:0712/160826.394334:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 100
[1:1:0712/160826.394533:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2016
[1:1:0712/160826.394708:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2016 0x7fda69743070 0x28bc175160e0 , 5:3_http://down.chinaz.com/, 27, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 1873 0x7fda6b66b2e0 0x28bc146f47e0 
[1:1:0712/160826.395846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3600000, 0x70a7d0829c8, 0x28bc13a36190
[1:1:0712/160826.395991:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 3600000
[1:1:0712/160826.396209:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2017
[1:1:0712/160826.396397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2017 0x7fda69743070 0x28bc175cb960 , 5:3_http://down.chinaz.com/, 27, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 1873 0x7fda6b66b2e0 0x28bc146f47e0 
[1:1:0712/160826.400527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, addEventListener, 
[1:1:0712/160826.400909:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 28, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160826.401651:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	vc (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	R (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	me (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Mh.k.Tb (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	Gm.p.getNewBlocks (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.401986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, O, (){var a=Ed.g();if(!a.a){if(!y)throw Error("Context has not been set and window is undefined.");a.a=
[1:1:0712/160826.402293:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 29, , , 0
[1:1:0712/160826.402718:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ie (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160826.403248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x70a7d0829c8, 0x28bc13a36190
[1:1:0712/160826.403362:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 250
[1:1:0712/160826.403541:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2018
[1:1:0712/160826.403650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2018 0x7fda69743070 0x28bc1757ed60 , 5:3_http://down.chinaz.com/, 29, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 1873 0x7fda6b66b2e0 0x28bc146f47e0 
[1:1:0712/160827.307389:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160827.868760:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1910, "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160827.870350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , !function(){var e='111000';try{!function(t){function a(e,t,a){var n=e?e:document.createElement('scri
[1:1:0712/160827.870439:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160828.094460:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160828.095399:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160828.096515:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 13, 0x28bc147ea020
[1:1:0712/160828.097357:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 13
[17758:17758:0712/160828.097717:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 13, 13, 
[1:1:0712/160828.105875:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160828.106073:INFO:render_frame_impl.cc(7019)] 	 [url] = http://down.chinaz.com
[17758:17758:0712/160828.108048:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://down.chinaz.com/
[17758:17758:0712/160828.280642:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160828.283127:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160828.296565:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 13
[17758:17770:0712/160828.296643:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 13, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160828.296673:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://pos.baidu.com/
[17758:17758:0712/160828.296715:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:13_http://pos.baidu.com/, http://pos.baidu.com/s?hei=360&wid=280&di=u2344569&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&ps=1686x700&exps=111000,115008,110011&cdo=-1&dri=0&dtm=HTML_POST&cmi=2&pcs=887x666&psr=1920x1080&col=en-US&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&ari=2&dis=0&tpr=1562918874169&chi=2&cfv=0&ant=0&dc=3&dai=5&ccd=24&cpl=2&drs=1&cec=GBK&pss=980x2107&tlm=1562727990&par=1855x1056&tcn=1562918908&cce=true&pis=-1x-1&cja=false, 13
[17758:17758:0712/160828.296793:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:13_http://pos.baidu.com/, HTTP/1.1 200 OK Cache-Control: post-check=0, pre-check=0 Connection: keep-alive Content-Encoding: gzip Content-Length: 12075 Content-Type: text/html;charset=UTF-8 Date: Fri, 12 Jul 2019 08:08:28 GMT Expires: Mon, 26 Jul 1997 05:00:00 GMT Last-Modified: Fri Jul 12 16:08:28 2019 P3p: CP=" OTI DSP COR IVA OUR IND COM " Pragma: no-cache Server: nginx X-Xss-Protection: 0  ,17854, 5
[1:7:0712/160828.298440:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160828.592554:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1920, 7fda6c0888db
[1:1:0712/160828.624413:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1721 0x7fda69743070 0x28bc15ac17e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160828.624636:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1721 0x7fda69743070 0x28bc15ac17e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160828.624890:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 2116
[1:1:0712/160828.624984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2116 0x7fda69743070 0x28bc146e01e0 , 5:3_http://down.chinaz.com/, 0, , 1920 0x7fda69743070 0x28bc17518e60 
[1:1:0712/160828.625180:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160828.625512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160828.625664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160828.674906:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160828.675045:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.682524:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.699588:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:10_http://pos.baidu.com/, 3d21fdcf7648, , , !function(e,n){"function"==typeof define&&define.amd?define("widget/logo",[],n):e.logo=n()}("undefin
[1:1:0712/160828.699800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1", "pos.baidu.com", 10, 1, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160828.703655:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.707356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.710652:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.719832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.886928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.889740:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.898388:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.949933:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160828.951866:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1930 0x7fda69743070 0x28bc14743260 , "http://pos.baidu.com/s?hei=300&wid=280&di=u3063614&ltu=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&psi=87f1115982a2781655f1baee52644692&cmi=2&tlm=1562727990&dtm=HTML_POST&ant=0&tcn=1562918886&dai=4&dis=0&drs=1&pcs=887x666&ccd=24&cpl=2&chi=2&tpr=1562918874169&cja=false&cce=true&ti=%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%7C%E4%BF%A1%E5%91%BC%E5%8D%8F%E5%90%8C%E5%8A%9E%E5%85%ACOA%E7%B3%BB%E7%BB%9F%20v1.9.5%E4%B8%8B%E8%BD%BD_%E7%BD%91%E7%AB%99%E6%BA%90%E7%A0%81_%E7%AB%99%E9%95%BF%E4%B8%8B%E8%BD%BD&pis=-1x-1&dri=0&cfv=0&dc=3&psr=1920x1080&cec=GBK&par=1855x1056&ps=1106x700&exps=111000,117008,110011&ari=2&col=en-US&pss=980x2107&cdo=-1"
[1:1:0712/160830.631181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160830.631338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160830.667312:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 1970, 7fda6c0888db
[1:1:0712/160830.704809:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1845 0x7fda69743070 0x28bc164fbc60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160830.705001:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1845 0x7fda69743070 0x28bc164fbc60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160830.705288:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 2216
[1:1:0712/160830.705454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2216 0x7fda69743070 0x28bc145980e0 , 5:3_http://down.chinaz.com/, 0, , 1970 0x7fda69743070 0x28bc17568060 
[1:1:0712/160830.705726:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160830.706060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160830.706276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160832.134810:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2016, 7fda6c088881
[1:1:0712/160832.168962:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc628603d21fdd579303d21fdc628603d21fdcaae603d21fdc628603d21fdd579303d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc62860","ptid":"1873 0x7fda6b66b2e0 0x28bc146f47e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160832.169387:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/","ptid":"1873 0x7fda6b66b2e0 0x28bc146f47e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160832.169671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160832.170015:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (c){for(var d=[],e=0;e<arguments.length;++e)d[e]=arguments[e];if(-1<b.a)return a.apply(null,r(d));tr
[1:1:0712/160832.170168:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160832.183189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160832.183420:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160832.184408:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.184705:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160832.184844:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160832.185749:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.186853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160832.186999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160832.187747:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.187945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160832.188052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160832.188721:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.190343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160832.190487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 6, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160832.191162:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.191354:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160832.191468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 7, , , 0
[1:1:0712/160832.192135:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.264343:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x70a7d0829c8, 0x28bc13a36150
[1:1:0712/160832.264490:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 100
[1:1:0712/160832.264638:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2236
[1:1:0712/160832.264785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2236 0x7fda69743070 0x28bc174991e0 , 5:3_http://down.chinaz.com/, 7, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 2016 0x7fda69743070 0x28bc175160e0 
[1:1:0712/160832.375445:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2018, 7fda6c088881
[1:1:0712/160832.410778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc628603d21fdd579303d21fdc628603d21fdcaae603d21fdc628603d21fdd579303d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc62860","ptid":"1873 0x7fda6b66b2e0 0x28bc146f47e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160832.411156:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:12_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/","ptid":"1873 0x7fda6b66b2e0 0x28bc146f47e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160832.411379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160832.411656:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (c){for(var d=[],e=0;e<arguments.length;++e)d[e]=arguments[e];if(-1<b.a)return a.apply(null,r(d));tr
[1:1:0712/160832.411764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160832.413788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Km, (){var a=O(),b=a.__google_ad_urls;if(!b)return a.__google_ad_urls=new Gm(a);try{if(0<=b.getOseId())r
[1:1:0712/160832.413922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160832.414394:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.415080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, sa, (a){return"function"==pa(a)}
[1:1:0712/160832.415188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160832.415646:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.419330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.getNewBlocks, (a,b){for(var c=this.j.length,d=0;d<c;d++){var e=this.j[d];!e.m&&e.j&&(e.m=!0,a(e.j,e.B,e.G,e.l,void
[1:1:0712/160832.419483:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160832.419878:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.420363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, O, (){var a=Ed.g();if(!a.a){if(!y)throw Error("Context has not been set and window is undefined.");a.a=
[1:1:0712/160832.420468:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160832.420785:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160832.421276:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x70a7d0829c8, 0x28bc13a36150
[1:1:0712/160832.421371:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 250
[1:1:0712/160832.421551:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2241
[1:1:0712/160832.421663:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2241 0x7fda69743070 0x28bc17595b60 , 5:3_http://down.chinaz.com/, 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 2018 0x7fda69743070 0x28bc1757ed60 
[1:1:0712/160833.326512:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160833.326993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[1:1:0712/160833.329013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2062 0x7fda69743070 0x28bc17579a60 , "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[1:1:0712/160833.330391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://googleads.g.doubleclick.net/, 3d21fdcfe730, , , var google_casm=[];
[1:1:0712/160833.330575:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225", "googleads.g.doubleclick.net", 11, 1, http://down.chinaz.com, down.chinaz.com, 7
[1:1:0712/160833.333353:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160833.334112:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160833.335235:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 14, 0x28bc15fb3420
[1:1:0712/160833.336024:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 14
[17758:17758:0712/160833.336441:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: ad_iframe, 14, 14, 
[17758:17758:0712/160833.349752:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:14_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/, 14
[17758:17758:0712/160833.349843:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 14, 14, https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net
[1:1:0712/160833.353503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2062 0x7fda69743070 0x28bc17579a60 , "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[1:1:0712/160833.369675:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 3d21fdc87818, 5:11_https://googleads.g.doubleclick.net/, 5:14_https://googleads.g.doubleclick.net/, about:blank
[1:1:0712/160833.369878:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:11_https://googleads.g.doubleclick.net/-5:14_https://googleads.g.doubleclick.net/, 3d21fdc87818, 3d21fdcfe730, open, 
[1:1:0712/160833.370067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "googleads.g.doubleclick.net", 14, 2, https://googleads.g.doubleclick.net, googleads.g.doubleclick.net, 11
[1:1:0712/160833.370294:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225:1:417

[1:1:0712/160833.371647:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2062 0x7fda69743070 0x28bc17579a60 , "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[1:1:0712/160833.374337:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17758:17758:0712/160833.375143:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/160833.376284:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 15, 0x28bc15fb2020
[1:1:0712/160833.376426:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 15
[17758:17758:0712/160833.377506:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 15, 15, 
[1:1:0712/160833.385610:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/160833.385797:INFO:render_frame_impl.cc(7019)] 	 [url] = https://googleads.g.doubleclick.net
[17758:17758:0712/160833.386697:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:11_https://googleads.g.doubleclick.net/
[1:1:0712/160833.387384:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2062 0x7fda69743070 0x28bc17579a60 , "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[1:1:0712/160833.390623:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2062 0x7fda69743070 0x28bc17579a60 , "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[17758:17758:0712/160833.466295:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17758:17758:0712/160833.468689:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17758:17770:0712/160833.484220:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 15
[17758:17770:0712/160833.484286:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 15, HandleIncomingMessage, HandleIncomingMessage
[17758:17758:0712/160833.484320:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://googleads.g.doubleclick.net/
[17758:17758:0712/160833.484373:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:15_https://googleads.g.doubleclick.net/, https://googleads.g.doubleclick.net/xbbe/pixel?d=CMbJCxCSx5oBGLH6rFkwAQ&v=APEucNX9o_LD4vuBk0y-b4KMOQ0PvQVM9w5Mu80YML9lref9d8oD36u8flCjMirP4GJ3_WR3c4ae9OgW9oOXT8tdPMtIet03zA, 15
[17758:17758:0712/160833.484450:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:15_https://googleads.g.doubleclick.net/, HTTP/1.1 200 status:200 p3p:policyref="https://googleads.g.doubleclick.net/pagead/gcn_p3p_.xml", CP="CURa ADMa DEVa TAIo PSAo PSDo OUR IND UNI PUR INT DEM STA PRE COM NAV OTC NOI DSP COR" timing-allow-origin:* content-type:text/html; charset=UTF-8 x-content-type-options:nosniff date:Fri, 12 Jul 2019 08:08:33 GMT server:cafe content-length:0 x-xss-protection:0 alt-svc:quic="googleads.g.doubleclick.net:443"; ma=2592000; v="46,43,39",quic=":443"; ma=2592000; v="46,43,39"  ,17854, 5
[1:7:0712/160833.486270:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/160835.499124:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/160835.730710:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:13_http://pos.baidu.com/
[1:1:0712/160836.344960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.345392:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 5:3_http://down.chinaz.com/, 5:10_http://pos.baidu.com/
[1:1:0712/160836.345530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160836.345650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160836.347110:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.351083:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.351390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.351548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.351732:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.351947:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.352062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160836.352256:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.352458:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.352710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (f){if(a.ampInaboxInitialized)return hg(a,"message",e),c;var g;a.ampInaboxPendingMessages&&(g=/^amp-
[1:1:0712/160836.352875:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.353051:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.353464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.353602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160836.353806:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.353935:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.354184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.354343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 6, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.354499:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.354696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.354831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 7, , , 0
[1:1:0712/160836.355015:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.355181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.355418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.355578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 8, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.355716:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.355931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.356470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 9, , , 0
[1:1:0712/160836.356666:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.356839:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.357121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.357331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 10, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.357501:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.357722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.357941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 11, , , 0
[1:1:0712/160836.358165:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.358326:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.358590:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.358800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 12, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.358964:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.359158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.359327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 13, , , 0
[1:1:0712/160836.359514:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.359662:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.359892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.360078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 14, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.360227:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.360423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.360583:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 15, , , 0
[1:1:0712/160836.360749:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.360887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160836.361141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, e, (g){try{var h=JSON.parse(g.data)}catch(k){return}!h||h.googMsgType!==b||d&&/[:|%3A]javascript\(/i.te
[1:1:0712/160836.361328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 16, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160836.361463:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 

[1:1:0712/160836.361637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, toString, 
[1:1:0712/160836.361803:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 17, , , 0
[1:1:0712/160836.361989:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	e (https://pagead2.googlesyndication.com/pagead/js/r20190710/r20190131/show_ads_impl.js:1:1)

[1:1:0712/160836.362111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160837.283902:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 2116, 7fda6c0888db
[1:1:0712/160837.325416:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1920 0x7fda69743070 0x28bc17518e60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160837.325625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1920 0x7fda69743070 0x28bc17518e60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160837.325851:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 2478
[1:1:0712/160837.325955:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2478 0x7fda69743070 0x28bc180c8060 , 5:3_http://down.chinaz.com/, 0, , 2116 0x7fda69743070 0x28bc146e01e0 
[1:1:0712/160837.326235:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160837.326559:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160837.326674:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160838.591760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.readyState
[1:1:0712/160838.591925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160838.671013:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 2216, 7fda6c0888db
[1:1:0712/160838.709206:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1970 0x7fda69743070 0x28bc17568060 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160838.709425:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1970 0x7fda69743070 0x28bc17568060 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160838.709684:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://down.chinaz.com/, 2509
[1:1:0712/160838.709792:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2509 0x7fda69743070 0x28bc181363e0 , 5:3_http://down.chinaz.com/, 0, , 2216 0x7fda69743070 0x28bc145980e0 
[1:1:0712/160838.710005:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160838.710302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (){var t=Array.prototype.slice.apply(arguments);return o.apply(n,t.concat(i))}
[1:1:0712/160838.710414:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160839.700135:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2236, 7fda6c088881
[1:1:0712/160839.740550:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc628603d21fdd246283d21fdc62860","ptid":"2016 0x7fda69743070 0x28bc175160e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160839.740797:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/","ptid":"2016 0x7fda69743070 0x28bc175160e0 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160839.741049:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160839.741371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (c){for(var d=[],e=0;e<arguments.length;++e)d[e]=arguments[e];if(-1<b.a)return a.apply(null,r(d));tr
[1:1:0712/160839.741458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160839.751691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160839.751876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160839.752660:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160839.752877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160839.752971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160839.753761:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160839.754769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160839.754904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160839.755617:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160839.755809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160839.755913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160839.756603:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160839.758216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/, 3d21fdd24628, 3d21fdc62860, getComputedStyle, 
[1:1:0712/160839.758361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 7, 6, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160839.759069:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160839.759265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd24628, parseFloat, 
[1:1:0712/160839.759392:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 7, , , 0
[1:1:0712/160839.763846:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	dg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	eg (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	ig (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	jg.k.Za (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Pf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	fh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	bh.Db (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160839.847353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x70a7d0829c8, 0x28bc13a36150
[1:1:0712/160839.847542:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 100
[1:1:0712/160839.847715:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2531
[1:1:0712/160839.847811:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2531 0x7fda69743070 0x28bc180e00e0 , 5:3_http://down.chinaz.com/, 7, -5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:7_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 2236 0x7fda69743070 0x28bc174991e0 
[1:1:0712/160840.054770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2241, 7fda6c088881
[1:1:0712/160840.092634:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"3d21fdc628603d21fdd579303d21fdc628603d21fdd579303d21fdc62860","ptid":"2018 0x7fda69743070 0x28bc1757ed60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160840.092846:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/","ptid":"2018 0x7fda69743070 0x28bc1757ed60 ","rf":"5:3_http://down.chinaz.com/"}
[1:1:0712/160840.093077:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160840.093355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , (c){for(var d=[],e=0;e<arguments.length;++e)d[e]=arguments[e];if(-1<b.a)return a.apply(null,r(d));tr
[1:1:0712/160840.093453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160840.094992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, Km, (){var a=O(),b=a.__google_ad_urls;if(!b)return a.__google_ad_urls=new Gm(a);try{if(0<=b.getOseId())r
[1:1:0712/160840.095128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 2, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160840.095616:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160840.096274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, sa, (a){return"function"==pa(a)}
[1:1:0712/160840.096415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 3, , , 0
[1:1:0712/160840.096889:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Wf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Vf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Rh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160840.100134:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/, 3d21fdd57930, 3d21fdc62860, p.getNewBlocks, (a,b){for(var c=this.j.length,d=0;d<c;d++){var e=this.j[d];!e.m&&e.j&&(e.m=!0,a(e.j,e.B,e.G,e.l,void
[1:1:0712/160840.100273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 6, 4, http://down.chinaz.com, down.chinaz.com, 3
[1:1:0712/160840.100652:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Xf (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Sh (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160840.101150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 3d21fdc62860, 3d21fdd57930, O, (){var a=Ed.g();if(!a.a){if(!y)throw Error("Context has not been set and window is undefined.");a.a=
[1:1:0712/160840.101272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 5, , , 0
[1:1:0712/160840.101602:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Ph (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	be (https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1)
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1
	https://www.googletagservices.com/activeview/js/current/osd.js?cb=%2Fr20100101:1:1

[1:1:0712/160840.102054:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 250, 0x70a7d0829c8, 0x28bc13a36150
[1:1:0712/160840.102144:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://down.chinaz.com/soft/38078.htm", 250
[1:1:0712/160840.102304:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://down.chinaz.com/, 2541
[1:1:0712/160840.102406:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 2541 0x7fda69743070 0x28bc16d8c6e0 , 5:3_http://down.chinaz.com/, 5, -5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/-5:6_http://down.chinaz.com/-5:3_http://down.chinaz.com/, 2241 0x7fda69743070 0x28bc17595b60 
[1:1:0712/160842.245653:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:15_https://googleads.g.doubleclick.net/
[1:1:0712/160842.341386:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2320, "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225"
[1:1:0712/160842.344736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:14_https://googleads.g.doubleclick.net/, 3d21fdc87818, , , if (!window.mraid) {document.write('\x3cdiv id="ad_unit"\x3e');}document.write('\x3cscript type\x3d\
[1:1:0712/160842.344913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://googleads.g.doubleclick.net/pagead/ads?client=ca-pub-4194977297280070&output=html&h=280&slotname=7977509648&adk=3474838518&adf=2894330219&w=336&lmt=1562727990&guci=2.2.0.0.2.2.0.0&format=336x280&url=http%3A%2F%2Fdown.chinaz.com%2Fsoft%2F38078.htm&flash=0&wgl=1&adsid=AGt39rRUXB7TfgVnn1zOXf2f9iOUxGyG3k7t52yCr9PYkrzJGFLE8yE1OoNeGYfD7rsR&dt=1562918875685&bpp=181&bdt=14624&fdt=12700&idt=12703&shv=r20190710&cbv=r20190131&saldr=aa&abxe=1&correlator=523575255784&frm=20&pv=2&ga_vid=2000503107.1562918889&ga_sid=1562918889&ga_hid=1483739119&ga_fc=0&iag=0&icsg=142378165870592&dssz=27&mdo=0&mso=8&u_tz=480&u_his=2&u_java=0&u_h=1080&u_w=1920&u_ah=1056&u_aw=1855&u_cd=24&u_nplug=2&u_nmime=2&adx=355&ady=1252&biw=887&bih=666&scr_x=0&scr_y=0&eid=4089042&oid=3&rx=0&eae=0&fc=656&brdim=983%2C24%2C983%2C24%2C1855%2C24%2C912%2C767%2C902%2C681&vis=1&rsz=%7C%7ClEbr%7C&abl=CS&pfx=0&fu=1048&bc=23&jar=2019-07-12-07&ifi=1&uci=1.g2w7gu3a82su&fsb=1&xpc=ZMNQd1icDf&p=http%3A//down.chinaz.com&dtd=13225", "googleads.g.doubleclick.net", 14, 1, https://googleads.g.doubleclick.net, googleads.g.doubleclick.net, 11
[1:1:0712/160844.726368:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/160844.726532:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160844.729923:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 2392 0x7fda69743070 0x28bc17f9dee0 , "http://down.chinaz.com/soft/38078.htm"
[1:1:0712/160844.730531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://down.chinaz.com/, 3d21fdc62860, , , document.writeln("<p>本站部分带宽由 <a href=\"http://www.idcicp.com/?source=downchinaz\" targ
[1:1:0712/160844.730699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://down.chinaz.com/soft/38078.htm", "down.chinaz.com", 3, 1, , , 0
[1:1:0712/160844.733997:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00735998, 55, 1
[1:1:0712/160844.734126:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
