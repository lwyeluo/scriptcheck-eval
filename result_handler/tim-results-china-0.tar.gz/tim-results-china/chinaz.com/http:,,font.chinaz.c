[0712/155316.995527:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155316.995780:INFO:switcher_clone.cc(787)] backtrace rip is 7efe25bcc891
[0712/155317.538943:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155317.539200:INFO:switcher_clone.cc(787)] backtrace rip is 7fea33362891
[1:1:0712/155317.543019:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/155317.543186:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/155317.546057:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[16082:16082:0712/155318.294376:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/0a513df6-71c4-4af1-9136-295a9b6c54bd
[0712/155318.391791:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/155318.392042:INFO:switcher_clone.cc(787)] backtrace rip is 7f5f99bcb891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[16115:16115:0712/155318.539204:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16115
[16128:16128:0712/155318.539514:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16128
[16082:16082:0712/155318.543655:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[16082:16113:0712/155318.544008:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/155318.544118:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155318.544263:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155318.544544:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155318.544655:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/155318.546467:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3a02b956, 1
[1:1:0712/155318.546692:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x15134102, 0
[1:1:0712/155318.546796:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xb52472a, 3
[1:1:0712/155318.546886:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2307084d, 2
[1:1:0712/155318.546974:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 02411315 56ffffffb9023a 4d080723 2a47520b , 10104, 4
[1:1:0712/155318.547653:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16082:16113:0712/155318.547768:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGAV�:M#*GRI
[16082:16113:0712/155318.547810:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is AV�:M#*GR��I
[16082:16113:0712/155318.547953:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[16082:16113:0712/155318.547985:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16130, 4, 02411315 56b9023a 4d080723 2a47520b 
[1:1:0712/155318.548441:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea3159c0a0, 3
[1:1:0712/155318.549688:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea31728080, 2
[1:1:0712/155318.549775:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea1b3ead20, -2
[1:1:0712/155318.557756:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155318.558203:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2307084d
[1:1:0712/155318.558680:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2307084d
[1:1:0712/155318.559468:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2307084d
[1:1:0712/155318.560039:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.560164:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.560268:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.560368:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.560642:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2307084d
[1:1:0712/155318.560783:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fea333627ba
[1:1:0712/155318.560854:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fea33359def, 7fea3336277a, 7fea333640cf
[1:1:0712/155318.562572:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2307084d
[1:1:0712/155318.562734:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2307084d
[1:1:0712/155318.563032:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2307084d
[1:1:0712/155318.563816:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.563953:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.564047:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.564126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2307084d
[1:1:0712/155318.564601:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2307084d
[1:1:0712/155318.564776:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fea333627ba
[1:1:0712/155318.564841:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fea33359def, 7fea3336277a, 7fea333640cf
[1:1:0712/155318.567389:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155318.567600:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155318.567710:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcfafee9e8, 0x7ffcfafee968)
[1:1:0712/155318.574465:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155318.577219:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[16082:16082:0712/155318.984015:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16082:16082:0712/155318.984497:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/155318.992985:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x83916cb220
[1:1:0712/155318.993155:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[16082:16094:0712/155318.993689:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[16082:16094:0712/155318.993747:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[16082:16082:0712/155318.993801:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[16082:16082:0712/155318.993847:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[16082:16082:0712/155318.993918:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,16130, 4
[1:7:0712/155318.994651:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[16082:16107:0712/155319.055469:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/155319.264852:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[16082:16094:0712/155319.585312:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -100
[1:1:0712/155319.950543:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155319.952141:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[16082:16082:0712/155320.029688:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[16082:16082:0712/155320.029754:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155320.403488:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155320.472128:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155320.472303:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155320.477401:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/155320.477524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155320.534200:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155320.534345:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155320.674414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155320.676856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155320.676985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155320.693520:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 365, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155320.696413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/155320.696546:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155320.700243:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[16082:16082:0712/155320.700917:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155320.702009:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x83916c9e20
[1:1:0712/155320.702108:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16082:16082:0712/155320.703443:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[16082:16082:0712/155320.714794:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[16082:16082:0712/155320.714883:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/155320.734291:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155321.026956:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7fea1cfc52e0 0x83919671e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155321.027635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/155321.027761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155321.028316:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16082:16082:0712/155321.053943:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/155321.054912:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x83916ca820
[1:1:0712/155321.055853:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[16082:16082:0712/155321.056310:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/155321.062460:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/155321.062892:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[16082:16082:0712/155321.065401:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[16082:16082:0712/155321.069948:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16082:16082:0712/155321.070381:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16082:16094:0712/155321.074947:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[16082:16094:0712/155321.074999:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[16082:16082:0712/155321.075015:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[16082:16082:0712/155321.075053:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[16082:16082:0712/155321.075112:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,16130, 4
[1:7:0712/155321.076512:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155321.343180:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/155321.535283:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 479 0x7fea1cfc52e0 0x83919d7760 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155321.536043:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/155321.536221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/155321.536708:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16082:16082:0712/155321.617092:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[16082:16082:0712/155321.617162:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/155321.628905:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155321.782465:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[16082:16082:0712/155321.940619:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[16082:16113:0712/155321.940954:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/155321.941096:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/155321.941231:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/155321.941426:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/155321.941505:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/155321.953317:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xd0bc675, 1
[1:1:0712/155321.953558:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x207b54b9, 0
[1:1:0712/155321.953735:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x33de35c9, 3
[1:1:0712/155321.953896:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3e32f2d8, 2
[1:1:0712/155321.954032:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb9547b20 75ffffffc60b0d ffffffd8fffffff2323e ffffffc935ffffffde33 , 10104, 5
[1:1:0712/155321.954808:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16082:16113:0712/155321.955015:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�T{ u���2>�5�3CJ
[16082:16113:0712/155321.955066:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �T{ u���2>�5�3�kCJ
[1:1:0712/155321.955005:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea3159c0a0, 3
[16082:16113:0712/155321.955215:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16178, 5, b9547b20 75c60b0d d8f2323e c935de33 
[1:1:0712/155321.955397:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea31728080, 2
[1:1:0712/155321.955509:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fea1b3ead20, -2
[1:1:0712/155321.961383:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155321.961575:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155321.965080:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/155321.965346:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e32f2d8
[1:1:0712/155321.965560:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e32f2d8
[1:1:0712/155321.965896:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e32f2d8
[1:1:0712/155321.966448:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.966571:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.966686:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.966779:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.967046:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e32f2d8
[1:1:0712/155321.967235:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fea333627ba
[1:1:0712/155321.967363:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fea33359def, 7fea3336277a, 7fea333640cf
[1:1:0712/155321.969129:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3e32f2d8
[1:1:0712/155321.969391:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3e32f2d8
[1:1:0712/155321.969744:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3e32f2d8
[1:1:0712/155321.970691:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.970810:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.970940:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.971065:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3e32f2d8
[1:1:0712/155321.971577:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3e32f2d8
[1:1:0712/155321.971742:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fea333627ba
[1:1:0712/155321.971820:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fea33359def, 7fea3336277a, 7fea333640cf
[1:1:0712/155321.974496:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/155321.974700:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/155321.974782:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffcfafee9e8, 0x7ffcfafee968)
[1:1:0712/155321.980616:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/155321.982718:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/155322.103084:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x83916a6220
[1:1:0712/155322.103264:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16082:16082:0712/155322.157079:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16082:16082:0712/155322.159090:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/155322.164844:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 545, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155322.166606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1f68c98ce5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/155322.166780:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155322.169225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[16082:16094:0712/155322.177811:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[16082:16094:0712/155322.177880:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[16082:16082:0712/155322.180804:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://font.chinaz.com/
[16082:16082:0712/155322.180859:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://font.chinaz.com/, http://font.chinaz.com/, 1
[16082:16082:0712/155322.180920:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://font.chinaz.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 07:53:22 GMT Content-Type: text/html Content-Length: 7909 Connection: keep-alive Content-Encoding: gzip Last-Modified: Fri, 12 Jul 2019 02:13:00 GMT Accept-Ranges: bytes ETag: "09e1545738d51:0" Server: Microsoft-IIS/8.5 X-Powered-By: ASP.NET X-Via: 1.1 hangkuan194:6 (Cdn Cache Server V2.0), 1.1 bjdxtck19:0 (Cdn Cache Server V2.0)  ,16178, 5
[1:7:0712/155322.183559:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/155322.216440:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://font.chinaz.com/
[1:1:0712/155322.251761:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/155322.252150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1f68c97a1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/155322.252314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[16082:16082:0712/155322.286186:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://font.chinaz.com/, http://font.chinaz.com/, 1
[16082:16082:0712/155322.286249:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://font.chinaz.com/, http://font.chinaz.com
[1:1:0712/155322.292041:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/155322.334595:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155322.372410:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155322.372575:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://font.chinaz.com/"
[1:1:0712/155322.385485:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155322.386277:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/155322.386418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1f68c98ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/155322.386535:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155322.445741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/155322.446160:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/155322.446256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1f68c98ce5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/155322.446364:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/155322.524221:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155322.749217:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7fea1b09d070 0x8391852260 , "http://font.chinaz.com/"
[1:1:0712/155322.753503:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155322.755281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , /*!
 * jQuery JavaScript Library v1.4.1
 * http://jquery.com/
 *
 * Copyright 2010, John Resig
 * Du
[1:1:0712/155322.755454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
		remove user.d_23efd5b9 -> 0
[1:1:0712/155322.775654:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7fea1b09d070 0x8391852260 , "http://font.chinaz.com/"
[1:1:0712/155322.821603:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7fea1b09d070 0x8391852260 , "http://font.chinaz.com/"
[1:1:0712/155322.824442:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 199 0x7fea1b09d070 0x8391852260 , "http://font.chinaz.com/"
[1:1:0712/155322.831485:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 1000
[1:1:0712/155322.831757:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 210
[1:1:0712/155322.831881:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 210 0x7fea1b09d070 0x83916c5960 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 199 0x7fea1b09d070 0x8391852260 
[1:1:0712/155322.923131:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.102853, 1344, 1
[1:1:0712/155322.923313:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155323.209618:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155323.209795:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://font.chinaz.com/"
[1:1:0712/155323.211251:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7fea1b09d070 0x8391971de0 , "http://font.chinaz.com/"
[1:1:0712/155323.213772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (function(){function p(){this.c="300636";this.ca="z";this.Y="";this.V="";this.X="";this.D="156291341
[1:1:0712/155323.213920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155323.535542:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 293, "http://font.chinaz.com/"
[1:1:0712/155323.536936:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/155323.537060:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155324.266502:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 293, "http://font.chinaz.com/"
[1:1:0712/155324.795915:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 404 (Not Found)","http://font.chinaz.com/style/images/f_view.png"
[1:1:0712/155324.903463:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 210, 7fea1d9e2881
[1:1:0712/155324.909792:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35cde70a2860","ptid":"199 0x7fea1b09d070 0x8391852260 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155324.909965:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://font.chinaz.com/","ptid":"199 0x7fea1b09d070 0x8391852260 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155324.910175:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155324.910629:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , cz_showAuditInfo(1)
[1:1:0712/155324.910750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155324.927586:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 394, "http://font.chinaz.com/"
[1:1:0712/155324.928895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/155324.929017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155324.942511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 394, "http://font.chinaz.com/"
[1:1:0712/155325.389205:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://font.chinaz.com/"
[1:1:0712/155325.390146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/155325.390282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155325.409611:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://font.chinaz.com/"
[1:1:0712/155325.409937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/155325.410066:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155325.419742:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 462, "http://font.chinaz.com/"
[1:1:0712/155325.420819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , 

    document.write('<link href="//csstools.chinaz.com/myuser/max-templates/passport/styles/topba
[1:1:0712/155325.420953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155325.518013:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://font.chinaz.com/"
[1:1:0712/155325.518647:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , onerror, javascript:this.src='http://user.sc.chinaz.com/images/user.png';
[1:1:0712/155325.518775:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155325.535191:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/155325.644354:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/155325.644520:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://font.chinaz.com/"
[1:1:0712/155325.645722:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://font.chinaz.com/"
[1:1:0712/155325.646037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , L, (){r.removeEventListener("DOMContentLoaded",
L,false);c.ready()}
[1:1:0712/155325.646155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155325.826059:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 2000
[1:1:0712/155325.826385:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 510
[1:1:0712/155325.826548:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 510 0x7fea1b09d070 0x839193e9e0 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 484 0x7fea1b09d070 0x8391ae57e0 
[1:1:0712/155325.862580:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 3000
[1:1:0712/155325.862859:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 526
[1:1:0712/155325.863009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 526 0x7fea1b09d070 0x83917b96e0 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 484 0x7fea1b09d070 0x8391ae57e0 
[1:1:0712/155326.001684:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 496 0x7fea1cfc52e0 0x83919010e0 , "http://font.chinaz.com/"
[1:1:0712/155326.004219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , 
//----Begin MaxAjaxEngine----
if(!dialogProxyUrl )
	dialogProxyUrl = "httpproxy.aspx";
root = "";
i
[1:1:0712/155326.004390:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155326.010904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://font.chinaz.com/"
[1:1:0712/155326.256112:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://font.chinaz.com/"
[1:1:0712/155326.256554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , ready, (){if(!c.isReady){if(!r.body)return setTimeout(c.ready,13);c.isReady=true;if(P){for(var a,b=0;a=P[b+
[1:1:0712/155326.256699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155327.137337:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/155327.835279:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 510, 7fea1d9e28db
[1:1:0712/155327.843319:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35cde70a2860","ptid":"484 0x7fea1b09d070 0x8391ae57e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155327.843517:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://font.chinaz.com/","ptid":"484 0x7fea1b09d070 0x8391ae57e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155327.843793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 550
[1:1:0712/155327.843959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7fea1b09d070 0x839167cfe0 , 5:3_http://font.chinaz.com/, 0, , 510 0x7fea1b09d070 0x839193e9e0 
[1:1:0712/155327.844160:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155327.844478:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (){
		showImg(index)
		index++;
		if(index==len){index=0;}
	 }
[1:1:0712/155327.844601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155328.872111:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 526, 7fea1d9e2881
[1:1:0712/155328.880406:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35cde70a2860","ptid":"484 0x7fea1b09d070 0x8391ae57e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155328.880592:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://font.chinaz.com/","ptid":"484 0x7fea1b09d070 0x8391ae57e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155328.880822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155328.881291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , AutoScroll("#scrollDiv")
[1:1:0712/155328.881445:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155328.882871:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 3000
[1:1:0712/155328.883095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 552
[1:1:0712/155328.883219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 552 0x7fea1b09d070 0x83912f0de0 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 526 0x7fea1b09d070 0x83917b96e0 
[1:1:0712/155329.835109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 550, 7fea1d9e28db
[1:1:0712/155329.842473:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"510 0x7fea1b09d070 0x839193e9e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155329.842648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"510 0x7fea1b09d070 0x839193e9e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155329.842884:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 554
[1:1:0712/155329.843032:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 554 0x7fea1b09d070 0x8391927a60 , 5:3_http://font.chinaz.com/, 0, , 550 0x7fea1b09d070 0x839167cfe0 
[1:1:0712/155329.843228:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155329.843534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (){
		showImg(index)
		index++;
		if(index==len){index=0;}
	 }
[1:1:0712/155329.843651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155331.834724:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 554, 7fea1d9e28db
[1:1:0712/155331.842213:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"550 0x7fea1b09d070 0x839167cfe0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155331.842392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"550 0x7fea1b09d070 0x839167cfe0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155331.842647:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 557
[1:1:0712/155331.842807:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 557 0x7fea1b09d070 0x839192e060 , 5:3_http://font.chinaz.com/, 0, , 554 0x7fea1b09d070 0x8391927a60 
[1:1:0712/155331.842998:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155331.843264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (){
		showImg(index)
		index++;
		if(index==len){index=0;}
	 }
[1:1:0712/155331.843379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155331.891226:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 552, 7fea1d9e2881
[1:1:0712/155331.898536:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35cde70a2860","ptid":"526 0x7fea1b09d070 0x83917b96e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155331.898742:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://font.chinaz.com/","ptid":"526 0x7fea1b09d070 0x83917b96e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155331.898974:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155331.899319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , AutoScroll("#scrollDiv")
[1:1:0712/155331.899478:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155331.900750:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 3000
[1:1:0712/155331.900931:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 559
[1:1:0712/155331.901044:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 559 0x7fea1b09d070 0x83919441e0 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 552 0x7fea1b09d070 0x83912f0de0 
[1:1:0712/155333.184935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/155333.185318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[16082:16082:0712/155333.351542:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -356
[16082:16082:0712/155333.353563:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=300636&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s4.cnzz.com/stat.php?id=300636&web_id=300636 (17)
[16082:16082:0712/155333.354389:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=300636&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s4.cnzz.com/stat.php?id=300636&web_id=300636 (17)
[16082:16082:0712/155333.375751:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=4164921&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s15.cnzz.com/stat.php?id=4164921&web_id=4164921 (17)
[16082:16082:0712/155333.376733:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=4164921&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s15.cnzz.com/stat.php?id=4164921&web_id=4164921 (17)
[3:3:0712/155333.467664:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/155333.943205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 557, 7fea1d9e28db
[1:1:0712/155333.953239:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"554 0x7fea1b09d070 0x8391927a60 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155333.953416:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"554 0x7fea1b09d070 0x8391927a60 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155333.953642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 608
[1:1:0712/155333.953765:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 608 0x7fea1b09d070 0x83918ef460 , 5:3_http://font.chinaz.com/, 0, , 557 0x7fea1b09d070 0x839192e060 
[1:1:0712/155333.953919:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155333.954185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (){
		showImg(index)
		index++;
		if(index==len){index=0;}
	 }
[1:1:0712/155333.954298:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155334.288036:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://font.chinaz.com/"
[1:1:0712/155334.288466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , j, (){return typeof c!=="undefined"&&!c.event.triggered?c.event.handle.apply(j.elem,arguments):v}
[1:1:0712/155334.288598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155334.910821:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 559, 7fea1d9e2881
[1:1:0712/155334.918782:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35cde70a2860","ptid":"552 0x7fea1b09d070 0x83912f0de0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155334.918956:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://font.chinaz.com/","ptid":"552 0x7fea1b09d070 0x83912f0de0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155334.919183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155334.919535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , AutoScroll("#scrollDiv")
[1:1:0712/155334.919671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155334.920907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 3000
[1:1:0712/155334.921093:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 647
[1:1:0712/155334.921220:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 647 0x7fea1b09d070 0x839172a0e0 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 559 0x7fea1b09d070 0x83919441e0 
[1:1:0712/155335.835094:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 608, 7fea1d9e28db
[1:1:0712/155335.843573:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"557 0x7fea1b09d070 0x839192e060 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155335.843757:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"557 0x7fea1b09d070 0x839192e060 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155335.844002:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 651
[1:1:0712/155335.844159:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 651 0x7fea1b09d070 0x839171cf60 , 5:3_http://font.chinaz.com/, 0, , 608 0x7fea1b09d070 0x83918ef460 
[1:1:0712/155335.844355:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155335.844650:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (){
		showImg(index)
		index++;
		if(index==len){index=0;}
	 }
[1:1:0712/155335.844764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155337.836528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 651, 7fea1d9e28db
[1:1:0712/155337.845448:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"608 0x7fea1b09d070 0x83918ef460 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155337.845629:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"608 0x7fea1b09d070 0x83918ef460 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155337.845882:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://font.chinaz.com/, 656
[1:1:0712/155337.846038:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 656 0x7fea1b09d070 0x8391ab13e0 , 5:3_http://font.chinaz.com/, 0, , 651 0x7fea1b09d070 0x839171cf60 
[1:1:0712/155337.846230:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155337.846536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , (){
		showImg(index)
		index++;
		if(index==len){index=0;}
	 }
[1:1:0712/155337.846655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155337.930787:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 647, 7fea1d9e2881
[1:1:0712/155337.939480:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"35cde70a2860","ptid":"559 0x7fea1b09d070 0x83919441e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155337.939685:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://font.chinaz.com/","ptid":"559 0x7fea1b09d070 0x83919441e0 ","rf":"5:3_http://font.chinaz.com/"}
[1:1:0712/155337.939931:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://font.chinaz.com/"
[1:1:0712/155337.940282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://font.chinaz.com/, 35cde70a2860, , , AutoScroll("#scrollDiv")
[1:1:0712/155337.940438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://font.chinaz.com/", "font.chinaz.com", 3, 1, , , 0
[1:1:0712/155337.941765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://font.chinaz.com/", 3000
[1:1:0712/155337.941975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://font.chinaz.com/, 658
[1:1:0712/155337.942095:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 658 0x7fea1b09d070 0x83919705e0 , 5:3_http://font.chinaz.com/, 1, -5:3_http://font.chinaz.com/, 647 0x7fea1b09d070 0x839172a0e0 
