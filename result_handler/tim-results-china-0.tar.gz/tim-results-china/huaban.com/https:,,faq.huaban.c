[0712/161018.036081:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/161018.036337:INFO:switcher_clone.cc(787)] backtrace rip is 7f8a9ebb0891
[0712/161018.576700:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/161018.576944:INFO:switcher_clone.cc(787)] backtrace rip is 7f7a45f08891
[1:1:0712/161018.580742:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/161018.580895:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/161018.583720:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[18177:18177:0712/161019.347074:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/3f96958d-0b67-4941-ae66-1b034be54dbf
[0712/161019.408999:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/161019.409264:INFO:switcher_clone.cc(787)] backtrace rip is 7f3d0dae3891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[18209:18209:0712/161019.556353:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18209
[18222:18222:0712/161019.556630:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18222
[18177:18177:0712/161019.600528:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[18177:18207:0712/161019.600974:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/161019.601099:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/161019.602800:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/161019.603106:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/161019.603216:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/161019.604880:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xc4a39a3, 1
[1:1:0712/161019.605099:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x235e4723, 0
[1:1:0712/161019.605247:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31dde2d9, 3
[1:1:0712/161019.605396:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26ee508, 2
[1:1:0712/161019.605555:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 23475e23 ffffffa3394a0c 08ffffffe56e02 ffffffd9ffffffe2ffffffdd31 , 10104, 4
[1:1:0712/161019.606273:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18177:18207:0712/161019.606431:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING#G^#�9J�n���1e�	
[18177:18207:0712/161019.606471:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is #G^#�9J�n���1��e�	
[1:1:0712/161019.606420:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7a441420a0, 3
[18177:18207:0712/161019.606601:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[18177:18207:0712/161019.606633:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18230, 4, 23475e23 a3394a0c 08e56e02 d9e2dd31 
[1:1:0712/161019.606902:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7a442ce080, 2
[1:1:0712/161019.606993:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7a2df90d20, -2
[1:1:0712/161019.614599:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/161019.615036:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26ee508
[1:1:0712/161019.615472:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26ee508
[1:1:0712/161019.616206:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26ee508
[1:1:0712/161019.616762:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.616842:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.616915:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.617007:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.617302:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26ee508
[1:1:0712/161019.617528:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7a45f087ba
[1:1:0712/161019.617665:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7a45effdef, 7f7a45f0877a, 7f7a45f0a0cf
[1:1:0712/161019.619435:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26ee508
[1:1:0712/161019.619634:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26ee508
[1:1:0712/161019.620295:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26ee508
[1:1:0712/161019.621133:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.621305:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.621421:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.621520:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26ee508
[1:1:0712/161019.622006:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26ee508
[1:1:0712/161019.622144:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7a45f087ba
[1:1:0712/161019.622198:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7a45effdef, 7f7a45f0877a, 7f7a45f0a0cf
[1:1:0712/161019.624704:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/161019.624870:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/161019.624934:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff7b1bae98, 0x7fff7b1bae18)
[1:1:0712/161019.631669:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/161019.634361:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[18177:18177:0712/161020.025075:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18177:18177:0712/161020.025601:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18177:18189:0712/161020.034099:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[18177:18189:0712/161020.034164:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[18177:18177:0712/161020.034186:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[18177:18177:0712/161020.034229:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[18177:18177:0712/161020.034297:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,18230, 4
[1:7:0712/161020.049764:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/161020.110656:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3cb660435220
[1:1:0712/161020.111201:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[18177:18200:0712/161020.121061:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/161020.315105:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/161021.012815:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/161021.014386:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18177:18177:0712/161021.163114:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[18177:18177:0712/161021.163210:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/161021.456817:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/161021.509147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/161021.509307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161021.514249:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/161021.514372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161021.578498:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/161021.578638:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161021.730235:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161021.732689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/161021.732828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161021.744832:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161021.747774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/161021.747911:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161021.751744:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18177:18177:0712/161021.752381:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/161021.753536:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3cb660433e20
[1:1:0712/161021.753661:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18177:18177:0712/161021.754927:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[18177:18177:0712/161021.766353:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[18177:18177:0712/161021.766433:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/161021.786034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161022.087869:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7f7a2fb6b2e0 0x3cb6605aa360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161022.088547:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/161022.088694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161022.089303:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18177:18177:0712/161022.115346:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/161022.116446:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3cb660434820
[1:1:0712/161022.116600:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18177:18177:0712/161022.117860:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/161022.123755:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/161022.123904:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[18177:18177:0712/161022.129349:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[18177:18177:0712/161022.133666:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18177:18177:0712/161022.134085:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18177:18189:0712/161022.139087:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[18177:18189:0712/161022.139149:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[18177:18177:0712/161022.139170:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[18177:18177:0712/161022.139213:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[18177:18177:0712/161022.139280:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,18230, 4
[1:7:0712/161022.141088:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/161022.402455:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/161022.520969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f7a2fb6b2e0 0x3cb660612c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161022.521611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/161022.521755:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161022.522162:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18177:18177:0712/161022.665385:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[18177:18177:0712/161022.665468:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/161022.676609:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/161022.815629:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[18177:18177:0712/161022.964890:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[18177:18207:0712/161022.965169:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/161022.965300:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/161022.965433:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/161022.965629:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/161022.965708:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/161022.970306:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33d93661, 1
[1:1:0712/161022.970544:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2044e38a, 0
[1:1:0712/161022.970702:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2e959d9c, 3
[1:1:0712/161022.970803:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x15f1316d, 2
[1:1:0712/161022.970872:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff8affffffe34420 6136ffffffd933 6d31fffffff115 ffffff9cffffff9dffffff952e , 10104, 5
[1:1:0712/161022.971708:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18177:18207:0712/161022.971890:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��D a6�3m1����.�h�	
[18177:18207:0712/161022.971935:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��D a6�3m1����.H�h�	
[1:1:0712/161022.971884:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7a441420a0, 3
[18177:18207:0712/161022.972073:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18274, 5, 8ae34420 6136d933 6d31f115 9c9d952e 
[1:1:0712/161022.972056:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7a442ce080, 2
[1:1:0712/161022.972218:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f7a2df90d20, -2
[1:1:0712/161022.981646:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/161022.981852:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15f1316d
[1:1:0712/161022.982021:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15f1316d
[1:1:0712/161022.982352:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15f1316d
[1:1:0712/161022.982897:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.983049:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.983165:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.983281:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.983539:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15f1316d
[1:1:0712/161022.983718:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7a45f087ba
[1:1:0712/161022.983810:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7a45effdef, 7f7a45f0877a, 7f7a45f0a0cf
[1:1:0712/161022.985503:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 15f1316d
[1:1:0712/161022.985675:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 15f1316d
[1:1:0712/161022.985982:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 15f1316d
[1:1:0712/161022.986776:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.986910:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.987030:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.987134:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 15f1316d
[1:1:0712/161022.987631:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 15f1316d
[1:1:0712/161022.987803:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f7a45f087ba
[1:1:0712/161022.987885:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f7a45effdef, 7f7a45f0877a, 7f7a45f0a0cf
[1:1:0712/161022.990627:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/161022.990949:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/161022.991042:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fff7b1bae98, 0x7fff7b1bae18)
[1:1:0712/161022.997211:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/161022.999387:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/161023.004061:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/161023.004204:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.112789:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3cb6603b5220
[1:1:0712/161023.112987:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/161023.168667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 531, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.170376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/161023.170552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161023.173043:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.243634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/161023.244046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3be798881f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/161023.244198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/161023.299749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.300587:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/161023.300746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/161023.300900:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161023.364294:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.364815:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/161023.364920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/161023.365021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161023.479096:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/161023.627120:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/161023.700562:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/161023.735352:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/161023.769490:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/161023.824547:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/161023.849933:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/161023.893942:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/161023.923057:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.923577:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161023.923757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161023.943980:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.944570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161023.944719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161023.976993:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.977434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161023.977568:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161023.997594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161023.998022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161023.998145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.028247:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.028662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161024.028787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.047785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.048229:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161024.048369:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.078355:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.078863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161024.079090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.100621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.101122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161024.101316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.132440:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.132905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161024.133027:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.164655:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.165107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161024.165233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.217904:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.218337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161024.218479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.258954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.259434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161024.259831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.294213:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.294698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161024.294872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.316603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.317167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161024.317322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.349367:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.349858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/161024.350073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/161024.381445:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/161024.381998:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 3be7989ae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/161024.382556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[18177:18177:0712/161024.420880:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18177:18177:0712/161024.423415:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18177:18189:0712/161024.440294:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[18177:18189:0712/161024.440362:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[18177:18177:0712/161024.440483:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://faq.huaban.com/
[18177:18177:0712/161024.440527:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://faq.huaban.com/, https://faq.huaban.com/, 1
[18177:18177:0712/161024.440587:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://faq.huaban.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 08:10:24 GMT Content-Type: text/html; charset=UTF-8 Content-Length: 6598 Connection: keep-alive X-Powered-By: PHP/5.6.31 Vary: Accept-Encoding, Cookie Cache-Control: max-age=3, must-revalidate Content-Encoding: gzip Last-Modified: Fri, 12 Jul 2019 08:03:43 GMT  ,18274, 5
[1:7:0712/161024.446410:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/161024.461507:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://faq.huaban.com/
[18177:18177:0712/161024.519279:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://faq.huaban.com/, https://faq.huaban.com/, 1
[18177:18177:0712/161024.519344:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://faq.huaban.com/, https://faq.huaban.com
[1:1:0712/161024.529493:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/161024.570972:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/161024.605735:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/161024.607682:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://faq.huaban.com/"
[1:1:0712/161024.631917:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 138 0x7f7a2dc43070 0x3cb66011cd60 , "https://faq.huaban.com/"
[1:1:0712/161024.642387:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , 
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","
[1:1:0712/161024.647633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161024.648924:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/161025.177809:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/161025.475567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 257 0x7f7a2fb6b2e0 0x3cb6605e7260 , "https://faq.huaban.com/"
[1:1:0712/161025.477169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , // Source: wp-includes/js/twemoji.min.js
var twemoji=function(){"use strict";function a(a,b){return 
[1:1:0712/161025.477360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161025.650133:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.652507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , /*! jQuery v1.12.4 | (c) jQuery Foundation | jquery.org/license */
!function(a,b){"object"==typeof m
[1:1:0712/161025.652682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161025.773954:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.795734:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.799974:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.818436:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.821079:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.838735:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.842833:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 272 0x7f7a2dfabbd0 0x3cb6606454d8 , "https://faq.huaban.com/"
[1:1:0712/161025.912981:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.140666, 315, 1
[1:1:0712/161025.913206:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/161026.075635:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/161026.075826:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://faq.huaban.com/"
[1:1:0712/161026.077118:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.077960:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , /***
@title:
Live Search

@version:
2.0

@author:
Andreas Lagerkvist

@date:
2008-08-31

[1:1:0712/161026.078082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161026.079132:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.081677:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.085531:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.088608:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.091292:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.093588:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 306 0x7f7a2dc43070 0x3cb6605e7c60 , "https://faq.huaban.com/"
[1:1:0712/161026.096889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://faq.huaban.com/"
[1:1:0712/161026.171700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://faq.huaban.com/"
[1:1:0712/161026.611681:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3856bc3829c8, 0x3cb66023a9e0
[1:1:0712/161026.611890:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://faq.huaban.com/", 0
[1:1:0712/161026.612142:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://faq.huaban.com/, 345
[1:1:0712/161026.612310:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 345 0x7f7a2dc43070 0x3cb6605a79e0 , 5:3_https://faq.huaban.com/, 1, -5:3_https://faq.huaban.com/, 306 0x7f7a2dc43070 0x3cb6605e7c60 
[1:1:0712/161026.668783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3856bc3829c8, 0x3cb66023a9e0
[1:1:0712/161026.668968:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://faq.huaban.com/", 0
[1:1:0712/161026.669198:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://faq.huaban.com/, 348
[1:1:0712/161026.669362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 348 0x7f7a2dc43070 0x3cb660a734e0 , 5:3_https://faq.huaban.com/, 1, -5:3_https://faq.huaban.com/, 306 0x7f7a2dc43070 0x3cb6605e7c60 
[1:1:0712/161026.748079:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0x3856bc3829c8, 0x3cb66023a9e0
[1:1:0712/161026.748284:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://faq.huaban.com/", 10
[1:1:0712/161026.748500:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://faq.huaban.com/, 349
[1:1:0712/161026.748638:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 349 0x7f7a2dc43070 0x3cb6608f0460 , 5:3_https://faq.huaban.com/, 1, -5:3_https://faq.huaban.com/, 306 0x7f7a2dc43070 0x3cb6605e7c60 
[1:1:0712/161026.768842:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://faq.huaban.com/"
[1:1:0712/161026.771073:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://faq.huaban.com/"
[1:1:0712/161026.906171:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 405 ()","https://hb-faq.b0.upaiyun.com/assets/fonts/sy-sans.woff"
[1:1:0712/161026.958969:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://faq.huaban.com/, 345, 7f7a30588881
[1:1:0712/161026.964533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2bb196c82860","ptid":"306 0x7f7a2dc43070 0x3cb6605e7c60 ","rf":"5:3_https://faq.huaban.com/"}
[1:1:0712/161026.964716:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://faq.huaban.com/","ptid":"306 0x7f7a2dc43070 0x3cb6605e7c60 ","rf":"5:3_https://faq.huaban.com/"}
[1:1:0712/161026.964878:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://faq.huaban.com/"
[1:1:0712/161026.965213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , scroller, () {
      var scrollTop = $window.scrollTop(),
        documentHeight = $document.height(),
       
[1:1:0712/161026.965327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161027.121681:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://faq.huaban.com/, 348, 7f7a30588881
[1:1:0712/161027.127670:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2bb196c82860","ptid":"306 0x7f7a2dc43070 0x3cb6605e7c60 ","rf":"5:3_https://faq.huaban.com/"}
[1:1:0712/161027.127822:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://faq.huaban.com/","ptid":"306 0x7f7a2dc43070 0x3cb6605e7c60 ","rf":"5:3_https://faq.huaban.com/"}
[1:1:0712/161027.127963:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://faq.huaban.com/"
[1:1:0712/161027.128220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , (){hb=void 0}
[1:1:0712/161027.128332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161027.139439:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://faq.huaban.com/, 349, 7f7a30588881
[1:1:0712/161027.145969:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2bb196c82860","ptid":"306 0x7f7a2dc43070 0x3cb6605e7c60 ","rf":"5:3_https://faq.huaban.com/"}
[1:1:0712/161027.146170:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://faq.huaban.com/","ptid":"306 0x7f7a2dc43070 0x3cb6605e7c60 ","rf":"5:3_https://faq.huaban.com/"}
[1:1:0712/161027.146379:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://faq.huaban.com/"
[1:1:0712/161027.146637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , () {
			var flex = $( '.flex-viewport' );

			if ( args.woocommerce_gallery === '1' && flex.length )
[1:1:0712/161027.146736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161027.235783:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 385 0x7f7a2fb6b2e0 0x3cb66062a7e0 , "https://faq.huaban.com/"
[1:1:0712/161027.237345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , !function(){var t={iu:"https://certify.alexametrics.com/atrk.gif?",ver:"20130128",opts:{atrk_acct:""
[1:1:0712/161027.237481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161027.277226:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 405 ()","https://hb-faq.b0.upaiyun.com/assets/fonts/sy-sans.ttf"
[1:1:0712/161027.830658:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://faq.huaban.com/"
[1:1:0712/161027.831100:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , h, (){c.readyCallback()}
[1:1:0712/161027.831254:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161027.831560:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://faq.huaban.com/"
[1:1:0712/161027.831855:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://faq.huaban.com/"
[1:1:0712/161028.276089:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/161035.240341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/161035.240527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[18177:18177:0712/161035.397510:INFO:CONSOLE(2)] "JQMIGRATE: Migrate is installed, version 1.4.1", source: https://faq.huaban.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1 (2)
[18177:18177:0712/161035.400849:INFO:CONSOLE(66)] "hkb-jquery-live-search", source: https://faq.huaban.com/wp-content/plugins/ht-knowledge-base/js/jquery.livesearch.js?ver=5.1.1 (66)
[3:3:0712/161035.447726:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/161036.188472:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://faq.huaban.com/"
[1:1:0712/161036.188948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://faq.huaban.com/, 2bb196c82860, , resizer, () {
      windowHeight = $window.height();

      for (var i = 0, l = sticked.length; i < l; i++) {
[1:1:0712/161036.189105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://faq.huaban.com/", "faq.huaban.com", 3, 1, , , 0
[1:1:0712/161036.190014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://faq.huaban.com/"
