[0712/105858.587352:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105858.587594:INFO:switcher_clone.cc(787)] backtrace rip is 7f566e19c891
[0712/105859.163813:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105859.164067:INFO:switcher_clone.cc(787)] backtrace rip is 7f9021040891
[1:1:0712/105859.167947:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/105859.168107:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/105859.170916:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[31870:31870:0712/105900.008180:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/19f2a37f-ed64-4256-a1b3-56206e5a7adc
[0712/105900.138658:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/105900.138912:INFO:switcher_clone.cc(787)] backtrace rip is 7f4202171891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[31870:31870:0712/105900.292977:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[31870:31902:0712/105900.293408:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/105900.293528:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/105900.293714:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/105900.294039:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/105900.294161:INFO:zygote_linux.cc(633)] 		cid is 4
[31904:31904:0712/105900.295802:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=31904
[1:1:0712/105900.298495:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xcb09ac2, 1
[1:1:0712/105900.298746:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x23e749f, 0
[1:1:0712/105900.298851:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x20aeaaf3, 3
[1:1:0712/105900.298938:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3c585c3f, 2
[1:1:0712/105900.299021:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff9f743e02 ffffffc2ffffff9affffffb00c 3f5c583c fffffff3ffffffaaffffffae20 , 10104, 4
[1:1:0712/105900.299751:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31870:31902:0712/105900.299874:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�t>�?\X<� �c�-
[31870:31902:0712/105900.299916:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �t>�?\X<� (;�c�-
[31870:31902:0712/105900.300064:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[31870:31902:0712/105900.300099:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31918, 4, 9f743e02 c29ab00c 3f5c583c f3aaae20 
[1:1:0712/105900.300478:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f901f27a0a0, 3
[1:1:0712/105900.300590:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f901f406080, 2
[1:1:0712/105900.300691:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90090c8d20, -2
[31917:31917:0712/105900.305577:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=31917
[1:1:0712/105900.308708:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/105900.309181:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c585c3f
[1:1:0712/105900.309653:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c585c3f
[1:1:0712/105900.310395:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c585c3f
[1:1:0712/105900.310946:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.311089:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.311195:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.311288:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.311517:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c585c3f
[1:1:0712/105900.311638:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90210407ba
[1:1:0712/105900.311691:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9021037def, 7f902104077a, 7f90210420cf
[1:1:0712/105900.313371:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3c585c3f
[1:1:0712/105900.313772:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3c585c3f
[1:1:0712/105900.314116:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3c585c3f
[1:1:0712/105900.314895:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.314985:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.315060:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.315132:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3c585c3f
[1:1:0712/105900.315615:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3c585c3f
[1:1:0712/105900.315753:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90210407ba
[1:1:0712/105900.315804:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9021037def, 7f902104077a, 7f90210420cf
[1:1:0712/105900.318394:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/105900.318584:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/105900.318685:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd2cfdd0e8, 0x7ffd2cfdd068)
[1:1:0712/105900.325473:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/105900.328149:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[31870:31870:0712/105900.603226:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[31870:31870:0712/105900.603471:ERROR:in_progress_cache_impl.cc(188)] Cache is not initialized, cannot RetrieveEntry.
[1:1:0712/105900.846827:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x3b56d0292220
[1:1:0712/105900.846988:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[31870:31870:0712/105900.880933:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31870:31870:0712/105900.881431:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31870:31870:0712/105900.891512:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[31870:31870:0712/105900.891574:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[31870:31870:0712/105900.891641:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,31918, 4
[31870:31896:0712/105900.893759:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[31870:31882:0712/105900.893806:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[31870:31882:0712/105900.893862:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/105900.897786:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105901.186755:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/105901.915776:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/105901.917394:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[31870:31870:0712/105901.937068:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[31870:31870:0712/105901.937143:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/105902.387958:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105902.452696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/105902.452894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105902.459378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/105902.459578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105902.504865:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105902.504993:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105902.651638:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105902.654457:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/105902.654644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105902.668081:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105902.671860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/105902.672040:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105902.676213:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[31870:31870:0712/105902.676975:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/105902.678152:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b56d0290e20
[1:1:0712/105902.678277:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[31870:31870:0712/105902.679529:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[31870:31870:0712/105902.691076:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[31870:31870:0712/105902.691156:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/105902.711101:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105903.033363:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f900aca32e0 0x3b56d0502160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105903.034101:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/105903.034238:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105903.034890:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[31870:31870:0712/105903.065620:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[31870:31870:0712/105903.068775:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/105903.066661:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x3b56d0291820
[1:1:0712/105903.069146:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/105903.095040:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/105903.095183:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[31870:31870:0712/105903.095862:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[31870:31870:0712/105903.107706:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31870:31870:0712/105903.109018:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31870:31882:0712/105903.114324:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[31870:31882:0712/105903.114393:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[31870:31870:0712/105903.114409:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[31870:31870:0712/105903.114454:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[31870:31870:0712/105903.114518:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,31918, 4
[1:7:0712/105903.116365:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/105903.401567:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/105903.548644:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f900aca32e0 0x3b56d047e2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105903.549268:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/105903.549426:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105903.549810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[31870:31870:0712/105903.663696:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[31870:31902:0712/105903.663961:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/105903.664083:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/105903.664233:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/105903.664423:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/105903.664500:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/105903.666453:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33eff933, 1
[1:1:0712/105903.666659:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x139ac40d, 0
[1:1:0712/105903.666749:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3525b624, 3
[1:1:0712/105903.666829:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3bee30b2, 2
[1:1:0712/105903.666905:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 0dffffffc4ffffff9a13 33fffffff9ffffffef33 ffffffb230ffffffee3b 24ffffffb62535 , 10104, 5
[1:1:0712/105903.667603:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[31870:31902:0712/105903.667744:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGĚ3��3�0�;$�%5Ef�-
[31870:31902:0712/105903.667784:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ě3��3�0�;$�%5��Ef�-
[1:1:0712/105903.667742:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f901f27a0a0, 3
[1:1:0712/105903.667825:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f901f406080, 2
[31870:31902:0712/105903.667925:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 31967, 5, 0dc49a13 33f9ef33 b230ee3b 24b62535 
[1:1:0712/105903.667912:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f90090c8d20, -2
[1:1:0712/105903.676959:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/105903.677224:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3bee30b2
[1:1:0712/105903.677399:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3bee30b2
[1:1:0712/105903.677674:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3bee30b2
[1:1:0712/105903.678174:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.678289:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.678400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.678515:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.678782:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3bee30b2
[1:1:0712/105903.678927:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90210407ba
[1:1:0712/105903.679015:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9021037def, 7f902104077a, 7f90210420cf
[1:1:0712/105903.680650:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3bee30b2
[1:1:0712/105903.680800:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3bee30b2
[1:1:0712/105903.681251:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3bee30b2
[1:1:0712/105903.682012:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.682139:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.682253:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.682365:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3bee30b2
[1:1:0712/105903.682863:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3bee30b2
[1:1:0712/105903.683046:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f90210407ba
[1:1:0712/105903.683132:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f9021037def, 7f902104077a, 7f90210420cf
[1:1:0712/105903.684652:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/105903.685682:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/105903.685959:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/105903.686072:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd2cfdd0e8, 0x7ffd2cfdd068)
[1:1:0712/105903.692070:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/105903.694032:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[31870:31870:0712/105903.740329:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[31870:31870:0712/105903.740401:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/105903.851673:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x3b56d0270220
[1:1:0712/105903.851867:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/105903.884927:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/105904.136776:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/105904.136938:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105904.277356:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105904.279194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/105904.279373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105904.281918:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105904.319104:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/105904.319477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 11c2aca01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/105904.319578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/105904.363026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105904.363772:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/105904.363897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/105904.364035:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105904.427826:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105904.428291:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/105904.428419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/105904.428556:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105904.585912:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/105904.660306:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/105904.693707:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/105904.739181:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/105904.877259:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://vk.com/"
[1:1:0712/105904.937450:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/105904.963132:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/105904.997814:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/105905.028139:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.028606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.028889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.056667:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.057378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.057512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.079135:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.079572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.079685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.113269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.113759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.113920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.138314:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.138800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.138988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.171082:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.171571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.171737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.211264:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.211688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.211831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.240700:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.241241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.241395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.269101:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.269512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.269651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.288621:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.289313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.289520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.323811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.324275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.324419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.380804:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.381270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.381398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.400954:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.401356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.401488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.431543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.433438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.433622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.453824:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.454272:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/105905.454453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/105905.482892:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/105905.483307:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 11c2acb2e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/105905.483453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[31870:31870:0712/105905.587847:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('http://yyk.baixing.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
[1:1:0712/105917.119955:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[31870:31870:0712/110007.255900:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[31870:31870:0712/110007.256711:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[31870:31870:0712/110007.271833:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://yyk.baixing.com/
[31870:31870:0712/110007.271892:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://yyk.baixing.com/, http://yyk.baixing.com/, 1
[31870:31870:0712/110007.271951:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://yyk.baixing.com/, HTTP/1.0 503 Service Unavailable Cache-Control: no-cache Connection: close Content-Type: text/html  ,31967, 5
[31870:31882:0712/110007.273356:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[31870:31882:0712/110007.273431:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/110007.274449:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/110007.289616:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://yyk.baixing.com/
[1:1:0712/110007.295431:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 503 (Service Unavailable)","http://yyk.baixing.com/"
[31870:31870:0712/110007.342986:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://yyk.baixing.com/, http://yyk.baixing.com/, 1
[31870:31870:0712/110007.343049:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://yyk.baixing.com/, http://yyk.baixing.com
[1:1:0712/110007.351323:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/110007.399225:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/110007.429257:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/110007.445697:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://yyk.baixing.com/"
