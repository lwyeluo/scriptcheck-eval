[0712/205911.251106:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/205911.251459:INFO:switcher_clone.cc(787)] backtrace rip is 7f6414bb5891
[0712/205911.841396:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/205911.841655:INFO:switcher_clone.cc(787)] backtrace rip is 7f599455d891
[1:1:0712/205911.845621:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/205911.845792:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/205911.848557:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/205912.822670:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/205912.822985:INFO:switcher_clone.cc(787)] backtrace rip is 7f281c812891
[30680:30680:0712/205912.877621:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/17834436-336c-45b9-9b8e-fb68e55acdf7
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[30714:30714:0712/205913.009800:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30714
[30725:30725:0712/205913.023815:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=30725
[30680:30680:0712/205913.216024:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[30680:30710:0712/205913.216501:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/205913.217157:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/205913.217330:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/205913.217644:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/205913.217764:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/205913.219472:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x15b94ebb, 1
[1:1:0712/205913.219714:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf8b86e4, 0
[1:1:0712/205913.219835:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1bb180a8, 3
[1:1:0712/205913.219951:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26346650, 2
[1:1:0712/205913.220066:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe4ffffff86ffffff8b0f ffffffbb4effffffb915 50663426 ffffffa8ffffff80ffffffb11b , 10104, 4
[1:1:0712/205913.220731:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30680:30710:0712/205913.220827:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING䆋�N�Pf4&���;�� 
[30680:30710:0712/205913.220870:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 䆋�N�Pf4&����';�� 
[1:1:0712/205913.220825:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59927970a0, 3
[30680:30710:0712/205913.220988:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[30680:30710:0712/205913.221051:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30733, 4, e4868b0f bb4eb915 50663426 a880b11b 
[1:1:0712/205913.221304:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5992923080, 2
[1:1:0712/205913.221400:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f597c5e5d20, -2
[1:1:0712/205913.229276:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/205913.229740:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26346650
[1:1:0712/205913.230212:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26346650
[1:1:0712/205913.230997:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26346650
[1:1:0712/205913.231558:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.231676:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.231781:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.231882:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.232131:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26346650
[1:1:0712/205913.232282:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599455d7ba
[1:1:0712/205913.232387:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5994554def, 7f599455d77a, 7f599455f0cf
[1:1:0712/205913.234087:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26346650
[1:1:0712/205913.234276:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26346650
[1:1:0712/205913.234594:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26346650
[1:1:0712/205913.235774:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.235901:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.236018:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.236126:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26346650
[1:1:0712/205913.236642:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26346650
[1:1:0712/205913.236820:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599455d7ba
[1:1:0712/205913.236894:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5994554def, 7f599455d77a, 7f599455f0cf
[1:1:0712/205913.239436:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/205913.239677:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/205913.239768:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde15cc528, 0x7ffde15cc4a8)
[1:1:0712/205913.246781:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/205913.249892:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[30680:30680:0712/205913.747471:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30680:30680:0712/205913.747944:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30680:30692:0712/205913.756247:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[30680:30692:0712/205913.756319:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[30680:30680:0712/205913.756346:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[30680:30680:0712/205913.756398:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[30680:30680:0712/205913.756464:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,30733, 4
[1:7:0712/205913.758702:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/205913.819627:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x30d81e330220
[1:1:0712/205913.819782:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[30680:30704:0712/205913.916275:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/205914.064939:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/205914.847734:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/205914.849529:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[30680:30680:0712/205915.160740:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[30680:30680:0712/205915.160805:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/205915.358123:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/205915.441077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d751d661f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/205915.441271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/205915.446447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d751d661f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/205915.446578:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/205915.498567:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/205915.498761:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/205915.653010:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/205915.655770:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d751d661f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/205915.660240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/205915.680661:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/205915.684459:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d751d661f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/205915.684766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/205915.689227:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[30680:30680:0712/205915.691002:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/205915.691544:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x30d81e32ee20
[1:1:0712/205915.691825:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[30680:30680:0712/205915.702066:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[30680:30680:0712/205915.716490:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[30680:30680:0712/205915.716596:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[30680:30680:0712/205915.724868:WARNING:render_frame_host_impl.cc(414)] InterfaceRequest was dropped, the document is no longer active: content::mojom::RendererAudioOutputStreamFactory
[1:1:0712/205915.728811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/205916.092420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 422 0x7f597e1c02e0 0x30d81e4385e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/205916.093180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d751d661f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/205916.093371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/205916.093978:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30680:30680:0712/205916.125739:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/205916.126342:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x30d81e32f820
[1:1:0712/205916.126642:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[30680:30680:0712/205916.128272:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/205916.133864:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/205916.134056:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[30680:30680:0712/205916.142111:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[30680:30680:0712/205916.148680:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30680:30680:0712/205916.149953:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30680:30692:0712/205916.155217:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[30680:30692:0712/205916.155335:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[30680:30680:0712/205916.155341:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[30680:30680:0712/205916.155412:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[30680:30680:0712/205916.155481:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,30733, 4
[1:7:0712/205916.157758:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[30680:30680:0712/205916.163787:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[30680:30710:0712/205916.164049:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/205916.164183:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/205916.164327:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/205916.164536:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/205916.164622:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/205916.172397:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xc082914, 1
[1:1:0712/205916.172637:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3b2f12bd, 0
[1:1:0712/205916.172756:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x8f8080f, 3
[1:1:0712/205916.172848:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x85284ec, 2
[1:1:0712/205916.172931:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffbd122f3b 1429080c ffffffecffffff845208 0f08fffffff808 , 10104, 5
[1:1:0712/205916.173666:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[30680:30710:0712/205916.173813:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�/;)�R��� 
[30680:30710:0712/205916.173856:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �/;)�R��_�� 
[30680:30710:0712/205916.173996:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 30774, 5, bd122f3b 1429080c ec845208 0f08f808 
[1:1:0712/205916.174187:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f59927970a0, 3
[1:1:0712/205916.174288:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5992923080, 2
[1:1:0712/205916.174387:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f597c5e5d20, -2
[1:1:0712/205916.184438:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/205916.184669:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 85284ec
[1:1:0712/205916.184828:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 85284ec
[1:1:0712/205916.185099:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 85284ec
[1:1:0712/205916.185602:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.185765:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.185914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.186169:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.186487:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 85284ec
[1:1:0712/205916.186650:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599455d7ba
[1:1:0712/205916.186713:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5994554def, 7f599455d77a, 7f599455f0cf
[1:1:0712/205916.188370:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 85284ec
[1:1:0712/205916.188538:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 85284ec
[1:1:0712/205916.188836:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 85284ec
[1:1:0712/205916.189666:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.189792:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.189908:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.190014:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 85284ec
[1:1:0712/205916.190542:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 85284ec
[1:1:0712/205916.190743:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f599455d7ba
[1:1:0712/205916.190846:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5994554def, 7f599455d77a, 7f599455f0cf
[1:1:0712/205916.193517:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/205916.193720:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/205916.193784:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde15cc528, 0x7ffde15cc4a8)
[1:1:0712/205916.200786:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/205916.203666:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/205916.302931:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x30d81e2c5220
[1:1:0712/205916.303094:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/205916.431172:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[30680:30680:0712/205916.600150:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30680:30680:0712/205916.602386:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30680:30692:0712/205916.622917:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[30680:30692:0712/205916.622980:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[30680:30680:0712/205916.624880:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://yuanxian.le.com/
[30680:30680:0712/205916.624927:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://yuanxian.le.com/, http://yuanxian.le.com/?ref=ym0101, 1
[30680:30680:0712/205916.624991:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://yuanxian.le.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 12:59:16 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 13:04:16 GMT Cache-Control: max-age=300 Content-Encoding: gzip Leeco: 0.019-SLBMTAuMTI0LjEzMC4zMQo=-ID200122.66.73:80-200  ,30774, 5
[1:7:0712/205916.630507:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/205916.645160:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://yuanxian.le.com/
[1:1:0712/205916.651535:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f597e1c02e0 0x30d81e6a3660 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/205916.652131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 3d751d661f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/205916.652237:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/205916.652635:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[30680:30680:0712/205916.695826:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://yuanxian.le.com/, http://yuanxian.le.com/, 1
[30680:30680:0712/205916.695884:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://yuanxian.le.com/, http://yuanxian.le.com
[1:1:0712/205916.709010:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/205916.749402:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/205916.768413:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/205916.791822:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/205916.796180:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://yuanxian.le.com/?ref=ym0101"
[1:1:0712/205916.813290:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/205917.258416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 185 0x7f597c298070 0x30d81e4821e0 , "http://yuanxian.le.com/?ref=ym0101"
[1:1:0712/205917.259247:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://yuanxian.le.com/, 1c3994142860, , , location.href=location.href.replace('yuanxian','vip');
[1:1:0712/205917.259384:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://yuanxian.le.com/?ref=ym0101", "yuanxian.le.com", 3, 1, , , 0
[1:1:0712/205917.327950:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/205917.334131:INFO:render_frame_impl.cc(7019)] 	 [url] = http://yuanxian.le.com
[1:1:0712/205921.985935:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/205933.656461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://yuanxian.le.com/, 1c3994142860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/205933.656700:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://yuanxian.le.com/?ref=ym0101", "yuanxian.le.com", 3, 1, , , 0
[1:1:0712/205933.657924:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[30680:30680:0712/205933.867407:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_http://yuanxian.le.com/
[3:3:0712/205933.939002:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[30680:30680:0712/205933.944861:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[30680:30680:0712/205933.948645:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[30680:30692:0712/205933.975129:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[30680:30692:0712/205933.975197:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[30680:30680:0712/205933.978746:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://vip.le.com/
[30680:30680:0712/205933.978793:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://vip.le.com/, http://vip.le.com/?ref=ym0101, 1
[30680:30680:0712/205933.978843:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://vip.le.com/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 12:59:34 GMT Content-Type: text/html Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Expires: Fri, 12 Jul 2019 13:04:34 GMT Cache-Control: max-age=300 Content-Encoding: gzip Leeco: 0.003-SLBMTAuMTI0LjEzMC4yNgo=-ID200112.41.82:80-200  ,30774, 5
[1:7:0712/205933.979372:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/205934.108971:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://vip.le.com/
[1:1:0712/205934.436214:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/205934.610620:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[30680:30680:0712/205934.654973:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://vip.le.com/, http://vip.le.com/, 1
[30680:30680:0712/205934.655027:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://vip.le.com/, http://vip.le.com
[1:1:0712/205934.726207:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/205934.726926:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.248693:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 713 0x7f597c298070 0x30d81e95a060 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.249499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://vip.le.com/, 1c3994142860, , , 
            var __INFO__ = {
                pageInfo : {
                    'site':'P',
         
[1:1:0712/205935.249621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://vip.le.com/?ref=ym0101", "vip.le.com", 3, 1, , , 0
[1:1:0712/205935.255082:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 713 0x7f597c298070 0x30d81e95a060 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.257350:INFO:document.cc(5190)] >>> Document::setDomain. [old, new] = "vip.le.com", "le.com"
[1:1:0712/205935.272434:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 713 0x7f597c298070 0x30d81e95a060 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.301472:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 713 0x7f597c298070 0x30d81e95a060 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.332373:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0823481, 549, 1
[1:1:0712/205935.332525:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/205935.956841:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/205935.957008:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.957445:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 761 0x7f597c298070 0x30d81ea7e360 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.957945:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://vip.le.com/, 1c3994142860, , , 
          //搜索框关键词
          (function(){
              __INFO__.search_word = ['总裁
[1:1:0712/205935.958065:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://vip.le.com/?ref=ym0101", "le.com", 3, 1, , , 0
[1:1:0712/205935.958876:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 761 0x7f597c298070 0x30d81ea7e360 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205935.962333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 761 0x7f597c298070 0x30d81ea7e360 , "http://vip.le.com/?ref=ym0101"
		remove user.d_4fc23964 -> 0
[1:1:0712/205936.093973:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x27efd8264af8, 0x30d81e14e9d0
[1:1:0712/205936.094162:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://vip.le.com/?ref=ym0101", 4
[1:1:0712/205936.094390:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://vip.le.com/, 804
[1:1:0712/205936.094531:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 804 0x7f597c298070 0x30d81ea7ee60 , 5:3_http://vip.le.com/, 1, -5:3_http://vip.le.com/, 761 0x7f597c298070 0x30d81ea7e360 
[1:1:0712/205936.099038:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 4, 0x27efd8264af8, 0x30d81e14e9d0
[1:1:0712/205936.099173:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://vip.le.com/?ref=ym0101", 4
[1:1:0712/205936.099345:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://vip.le.com/, 805
[1:1:0712/205936.099455:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 805 0x7f597c298070 0x30d81ea81660 , 5:3_http://vip.le.com/, 1, -5:3_http://vip.le.com/, 761 0x7f597c298070 0x30d81ea7e360 
[1:1:0712/205936.116286:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 761 0x7f597c298070 0x30d81ea7e360 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205936.455994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x27efd8264af8, 0x30d81e14eac0
[1:1:0712/205936.456182:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://vip.le.com/?ref=ym0101", 0
[1:1:0712/205936.456532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://vip.le.com/, 836
[1:1:0712/205936.456649:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 836 0x7f597c298070 0x30d81e4afa60 , 5:3_http://vip.le.com/, 1, -5:3_http://vip.le.com/, 761 0x7f597c298070 0x30d81ea7e360 
[1:1:0712/205936.457236:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.500176, 0, 0
[1:1:0712/205936.457386:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/205937.367582:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/205937.367819:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://vip.le.com/?ref=ym0101"
[1:1:0712/205937.369567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 837 0x7f597c298070 0x30d81ed166e0 , "http://vip.le.com/?ref=ym0101"
[1:1:0712/205937.371329:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://vip.le.com/, 1c3994142860, , , (function(a){function b(d){if(c[d])return c[d].exports;var f=c[d]={i:d,l:!1,exports:{}};return a[d].
[1:1:0712/205937.371518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://vip.le.com/?ref=ym0101", "le.com", 3, 1, , , 0
