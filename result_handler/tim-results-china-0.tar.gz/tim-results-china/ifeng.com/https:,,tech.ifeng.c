[0712/163141.325483:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/163141.325754:INFO:switcher_clone.cc(787)] backtrace rip is 7f46ee998891
[0712/163141.877512:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/163141.877762:INFO:switcher_clone.cc(787)] backtrace rip is 7f5828c38891
[1:1:0712/163141.881548:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/163141.881716:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/163141.884487:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[20494:20494:0712/163142.655179:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1b5e7ca3-3555-47f2-b608-106d2ed20bbc
[0712/163142.726168:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/163142.726415:INFO:switcher_clone.cc(787)] backtrace rip is 7feaabae9891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[20528:20528:0712/163142.883526:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20528
[20539:20539:0712/163142.883828:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=20539
[20494:20494:0712/163142.908632:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[20494:20524:0712/163142.909237:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/163142.909379:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/163142.909569:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/163142.909946:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/163142.910108:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/163142.911800:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x7584a6d, 1
[1:1:0712/163142.911981:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3470d4f3, 0
[1:1:0712/163142.912059:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x13b6ff2a, 3
[1:1:0712/163142.912178:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2fc3e9f1, 2
[1:1:0712/163142.912267:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffff3ffffffd47034 6d4a5807 fffffff1ffffffe9ffffffc32f 2affffffffffffffb613 , 10104, 4
[1:1:0712/163142.912940:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20494:20524:0712/163142.913056:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��p4mJX���/*����l8
[20494:20524:0712/163142.913097:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��p4mJX���/*�����l8
[1:1:0712/163142.913055:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5826e720a0, 3
[1:1:0712/163142.913150:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5826ffe080, 2
[20494:20524:0712/163142.913236:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/163142.913230:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5810cc0d20, -2
[20494:20524:0712/163142.913321:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20547, 4, f3d47034 6d4a5807 f1e9c32f 2affb613 
[1:1:0712/163142.920574:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/163142.921002:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2fc3e9f1
[1:1:0712/163142.921464:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2fc3e9f1
[1:1:0712/163142.922184:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2fc3e9f1
[1:1:0712/163142.922718:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.922833:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.922947:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.923056:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.923312:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2fc3e9f1
[1:1:0712/163142.923466:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5828c387ba
[1:1:0712/163142.923538:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5828c2fdef, 7f5828c3877a, 7f5828c3a0cf
[1:1:0712/163142.925247:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2fc3e9f1
[1:1:0712/163142.925437:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2fc3e9f1
[1:1:0712/163142.925770:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2fc3e9f1
[1:1:0712/163142.926547:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.926673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.926797:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.926906:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2fc3e9f1
[1:1:0712/163142.927435:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2fc3e9f1
[1:1:0712/163142.927618:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5828c387ba
[1:1:0712/163142.927707:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5828c2fdef, 7f5828c3877a, 7f5828c3a0cf
[1:1:0712/163142.930277:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/163142.930483:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/163142.930597:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc05b3cf38, 0x7ffc05b3ceb8)
[1:1:0712/163142.937408:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/163142.940139:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[20494:20494:0712/163143.353181:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163143.353699:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20494:20506:0712/163143.362676:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[20494:20506:0712/163143.362748:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163143.362772:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[20494:20494:0712/163143.362817:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[20494:20494:0712/163143.362883:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,20547, 4
[1:7:0712/163143.366003:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[20494:20518:0712/163143.429484:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/163143.430549:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x1cf73f230220
[1:1:0712/163143.433627:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[1:1:0712/163143.676409:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/163144.376013:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/163144.377556:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[20494:20494:0712/163144.441129:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[20494:20494:0712/163144.441199:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/163144.813907:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163144.861116:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/163144.861272:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163144.866617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/163144.866782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163144.952815:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163144.952975:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163145.111038:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163145.113600:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/163145.113730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163145.131248:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163145.134223:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/163145.134360:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163145.138300:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163145.138927:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163145.140064:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1cf73f22ee20
[1:1:0712/163145.140169:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[20494:20494:0712/163145.141350:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[20494:20494:0712/163145.152881:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[20494:20494:0712/163145.152968:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/163145.172964:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163145.468816:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7f581289b2e0 0x1cf73f444c60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163145.469548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/163145.469719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163145.470344:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20494:20494:0712/163145.495564:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163145.496649:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1cf73f22f820
[1:1:0712/163145.496788:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[20494:20494:0712/163145.497910:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/163145.503803:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163145.503975:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[20494:20494:0712/163145.504742:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[20494:20494:0712/163145.508722:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163145.509185:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20494:20506:0712/163145.513672:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[20494:20506:0712/163145.513726:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163145.513750:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[20494:20494:0712/163145.513789:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[20494:20494:0712/163145.513849:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,20547, 4
[1:7:0712/163145.515241:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163145.764150:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/163145.966454:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 473 0x7f581289b2e0 0x1cf73f58c7e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163145.967040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/163145.967215:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163145.967584:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[20494:20494:0712/163146.043903:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[20494:20494:0712/163146.043974:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/163146.055775:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163146.226558:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[20494:20494:0712/163146.299957:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[20494:20524:0712/163146.300244:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/163146.300370:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/163146.300504:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/163146.300694:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/163146.300774:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/163146.302964:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x27e68a6f, 1
[1:1:0712/163146.303441:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x25869afd, 0
[1:1:0712/163146.313164:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x38a420c9, 3
[1:1:0712/163146.313328:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0xe69ea0, 2
[1:1:0712/163146.313443:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = fffffffdffffff9affffff8625 6fffffff8affffffe627 ffffffa0ffffff9effffffe600 ffffffc920ffffffa438 , 10104, 5
[1:1:0712/163146.314204:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[20494:20524:0712/163146.314399:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���%o��'���
[20494:20524:0712/163146.314444:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���%o��'���
[1:1:0712/163146.314389:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5826e720a0, 3
[20494:20524:0712/163146.314589:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 20589, 5, fd9a8625 6f8ae627 a09ee600 c920a438 
[1:1:0712/163146.314577:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5826ffe080, 2
[1:1:0712/163146.314684:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f5810cc0d20, -2
[1:1:0712/163146.326793:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/163146.327037:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e69ea0
[1:1:0712/163146.327268:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e69ea0
[1:1:0712/163146.327541:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e69ea0
[1:1:0712/163146.328032:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.328137:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.328246:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.328386:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.328637:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e69ea0
[1:1:0712/163146.328774:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5828c387ba
[1:1:0712/163146.328847:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5828c2fdef, 7f5828c3877a, 7f5828c3a0cf
[1:1:0712/163146.330524:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal e69ea0
[1:1:0712/163146.330699:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal e69ea0
[1:1:0712/163146.331000:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal e69ea0
[1:1:0712/163146.331750:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.331864:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.331965:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.332065:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal e69ea0
[1:1:0712/163146.332538:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal e69ea0
[1:1:0712/163146.332716:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f5828c387ba
[1:1:0712/163146.332796:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f5828c2fdef, 7f5828c3877a, 7f5828c3a0cf
[1:1:0712/163146.335270:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/163146.335484:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/163146.335595:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffc05b3cf38, 0x7ffc05b3ceb8)
[1:1:0712/163146.341638:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/163146.343599:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/163146.432612:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x1cf73f1c5220
[1:1:0712/163146.432775:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/163146.448041:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163146.448269:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163146.650605:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163146.652267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/163146.652419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163146.654894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163146.709745:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/163146.710105:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2546e4d81f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/163146.710221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/163146.774767:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163146.775685:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/163146.775850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/163146.776419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163146.850879:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163146.857541:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/163146.857678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/163146.857832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.036013:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/163147.228558:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/163147.277836:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/163147.305060:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/163147.343189:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/163147.370253:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/163147.408211:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/163147.435808:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/163147.502605:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.503050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.503204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.534735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.535166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.535310:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.558898:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.559332:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.559474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.610283:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.610779:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.610956:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.643090:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.643583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.643764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.719198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.719637:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.719790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.752181:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.752625:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.752769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.774177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.774618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.774761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.806738:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.807190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.807343:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.828014:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.828494:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.828665:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.860931:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.861421:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.861566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.881812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.882193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.882344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.916223:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.916655:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.916787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.938355:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.938755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.938895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.971966:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.972378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/163147.972518:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/163147.994730:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/163147.995146:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2546e4eae5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/163147.995288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[20494:20494:0712/163148.294458:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('https://tech.ifeng.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
[20494:20494:0712/163148.412202:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163148.415208:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20494:20494:0712/163148.428040:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://tech.ifeng.com/
[20494:20494:0712/163148.428097:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tech.ifeng.com/, https://tech.ifeng.com/c/7o8tHReAl1E, 1
[20494:20494:0712/163148.428159:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://tech.ifeng.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:31:47 GMT Content-Type: text/html; charset=utf-8 Transfer-Encoding: chunked Connection: keep-alive Server: openresty/1.13.6.1 deviceType: pc Shanktracerid: 7ced2930a47f11e9913f794542d627a5 Cache-Control: max-age=120 Pid: 1 Expires: Fri, 12 Jul 2019 08:33:47 GMT Hostname: web-content-prod-dpt-66958dc687-j8lzk Server-Info: ifeng-A shankrouter: cmpp_dyn_webq69v32_syq Content-Encoding: gzip Content-Security-Policy: upgrade-insecure-requests X-Via: 1.1 k56:7 (Cdn Cache Server V2.0), 1.1 hkuan33:6 (Cdn Cache Server V2.0)  ,20589, 5
[20494:20506:0712/163148.429100:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[20494:20506:0712/163148.429155:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/163148.429555:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163148.449062:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://tech.ifeng.com/
[20494:20494:0712/163148.505418:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://tech.ifeng.com/, https://tech.ifeng.com/, 1
[20494:20494:0712/163148.505860:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163148.520173:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163148.568305:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163148.594737:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163148.594895:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.673067:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.674130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){"use strict";e.console||(e.console={});for(var r,n,t=e.console,o=function(){},a=["memor
[1:1:0712/163148.674262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163148.677262:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/163148.688205:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2374b5f029c8, 0x1cf73f0561b8
[1:1:0712/163148.688367:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 0
[1:1:0712/163148.688584:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 171
[1:1:0712/163148.688696:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 171 0x7f5810973070 0x1cf73f2fbfe0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 154
[1:1:0712/163148.690075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.698886:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2374b5f029c8, 0x1cf73f056198
[1:1:0712/163148.699053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 5000
[1:1:0712/163148.699249:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 174
[1:1:0712/163148.699375:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 174 0x7f5810973070 0x1cf73edd6660 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 154
[1:1:0712/163148.704709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.705972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.707942:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.740530:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 154, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.772247:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/163148.775146:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.776530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){var t={};function r(n){if(t[n])return t[n].exports;var o=t[n]={i:n,l:!1,exports:{}};ret
[1:1:0712/163148.776696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163148.824957:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.826769:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.829483:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.831278:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.832403:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 160, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.833828:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b5f029c8, 0x1cf73f056198
[1:1:0712/163148.833956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163148.834137:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 234
[1:1:0712/163148.834265:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 234 0x7f5810973070 0x1cf73f1d38e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 160
[1:1:0712/163148.940129:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 171, 7f58132b8881
[1:1:0712/163148.943371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"154","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163148.943526:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"154","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163148.943694:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163148.943989:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){var e=((location.hash||"").match(/([#&])BJ_ERROR=([^&$]+)/)||[])[2];e&&console.error("BJ_ERROR",d
[1:1:0712/163148.944110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163149.085515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (window.webpackJsonp=window.webpackJsonp||[]).push([[1],{21:function(t,e,n){"use strict";var r=n(0);
[1:1:0712/163149.085705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163149.169027:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 241 0x7f581289b2e0 0x1cf73f2f3d60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163149.170261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e,n){"use strict";var i=function(e){var n=e||{},i=void 0!==e.navigator?e.navigator:{},r=fu
[1:1:0712/163149.170403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163149.351973:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){function t(t){for(var n,l,i=t[0],c=t[1],u=t[2],d=0,f=[];d<i.length;d++)l=i[d],o[l]&&f.p
[1:1:0712/163149.352163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163149.417281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (window.webpackJsonp=window.webpackJsonp||[]).push([[0],[function(e,t){e.exports=function(e){return 
[1:1:0712/163149.417458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163149.418193:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 260 0x7f581289b2e0 0x1cf73f2f33e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163149.419169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 260 0x7f581289b2e0 0x1cf73f2f33e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163149.419972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 260 0x7f581289b2e0 0x1cf73f2f33e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163151.159937:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.160152:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 120000
[1:1:0712/163151.160416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 272
[1:1:0712/163151.160564:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 272 0x7f5810973070 0x1cf74043dbe0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.163844:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.164035:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 120000
[1:1:0712/163151.164274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 273
[1:1:0712/163151.164433:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 273 0x7f5810973070 0x1cf7405ca1e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.170673:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.170838:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163151.171037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 277
[1:1:0712/163151.171167:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 277 0x7f5810973070 0x1cf73fe882e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.185745:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.185907:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163151.186090:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 281
[1:1:0712/163151.186199:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 281 0x7f5810973070 0x1cf7405dd8e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.203873:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.204041:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163151.204220:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 284
[1:1:0712/163151.204356:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 284 0x7f5810973070 0x1cf7405bc560 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.208619:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.208771:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163151.208955:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 286
[1:1:0712/163151.209100:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 286 0x7f5810973070 0x1cf740600de0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.218896:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.219061:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163151.219259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 288
[1:1:0712/163151.219384:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 288 0x7f5810973070 0x1cf740661e60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.231439:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x2374b5f029c8, 0x1cf73f0560f8
[1:1:0712/163151.231602:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 1
[1:1:0712/163151.231781:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 291
[1:1:0712/163151.231892:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 291 0x7f5810973070 0x1cf74068cc60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.267580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163151.267752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163151.267948:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 310
[1:1:0712/163151.268059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 310 0x7f5810973070 0x1cf740268260 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163151.600341:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/163159.840556:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.840754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.840958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 372
[1:1:0712/163159.841069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 372 0x7f5810973070 0x1cf7406fd6e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.844094:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.847740:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.848041:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 374
[1:1:0712/163159.848156:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 374 0x7f5810973070 0x1cf73f7cbb60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.858720:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.858909:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.859130:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 378
[1:1:0712/163159.859265:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 378 0x7f5810973070 0x1cf74072ae60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.867162:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.867347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 0
[1:1:0712/163159.867552:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 383
[1:1:0712/163159.867687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 383 0x7f5810973070 0x1cf7408404e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.869393:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.869513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.869700:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 384
[1:1:0712/163159.869822:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 384 0x7f5810973070 0x1cf740848260 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.880580:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.880782:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.881074:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 388
[1:1:0712/163159.881284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 388 0x7f5810973070 0x1cf7408535e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.883421:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.883576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.883773:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 389
[1:1:0712/163159.883910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 389 0x7f5810973070 0x1cf7408538e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.907808:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.907993:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.908195:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 395
[1:1:0712/163159.908335:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 395 0x7f5810973070 0x1cf74072a8e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.910163:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.912899:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.913316:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 396
[1:1:0712/163159.913487:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 396 0x7f5810973070 0x1cf740863de0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.948389:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.948578:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.948786:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 400
[1:1:0712/163159.948899:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 400 0x7f5810973070 0x1cf7408537e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.950642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.950795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.950978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 401
[1:1:0712/163159.951397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 401 0x7f5810973070 0x1cf7408a7360 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.961674:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.962047:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.963397:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 406
[1:1:0712/163159.963550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 406 0x7f5810973070 0x1cf7408c1460 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.966059:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.966223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.966433:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 407
[1:1:0712/163159.966544:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 407 0x7f5810973070 0x1cf740863360 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.994156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.996235:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163159.996637:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 415
[1:1:0712/163159.996782:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 415 0x7f5810973070 0x1cf7408e9de0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163159.998643:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163159.998799:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163159.999053:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 416
[1:1:0712/163159.999175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7f5810973070 0x1cf7408f4260 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.028441:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.029100:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163200.029303:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 424
[1:1:0712/163200.029474:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 424 0x7f5810973070 0x1cf7402e77e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.031347:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.031496:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163200.031658:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 426
[1:1:0712/163200.031804:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 426 0x7f5810973070 0x1cf74092e7e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.045845:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.046867:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163200.047103:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 431
[1:1:0712/163200.047269:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 431 0x7f5810973070 0x1cf7408c1d60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.049140:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.049314:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163200.049509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 433
[1:1:0712/163200.049711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 433 0x7f5810973070 0x1cf740945de0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.059611:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.059847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163200.060077:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 437
[1:1:0712/163200.060229:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 437 0x7f5810973070 0x1cf740963e60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.062774:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.062957:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163200.063143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 438
[1:1:0712/163200.063262:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 438 0x7f5810973070 0x1cf7408f4360 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.083700:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.083882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163200.084071:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 445
[1:1:0712/163200.084171:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 445 0x7f5810973070 0x1cf7408f4b60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.097308:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 15000, 0x2374b5f029c8, 0x1cf73f0560d8
[1:1:0712/163200.097506:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 15000
[1:1:0712/163200.097758:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 450
[1:1:0712/163200.097927:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 450 0x7f5810973070 0x1cf740990ce0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 260 0x7f581289b2e0 0x1cf73f2f33e0 
[1:1:0712/163200.099163:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://tech.ifeng.com/c/7o8tHReAl1E"
[3:3:0712/163200.373964:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[20494:20494:0712/163200.406412:INFO:CONSOLE(4)] "commentAd 无广告", source:  (4)
[20494:20494:0712/163200.410560:INFO:CONSOLE(4)] "asideAd3 无广告", source:  (4)
[1:1:0712/163200.728263:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163200.728713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , s.onreadystatechange, ()=>{if(4===s.readyState)if(s.status>=200&&s.status<300||304===s.status)switch((0,o.default)(e),r){c
[1:1:0712/163200.728851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163200.729526:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163200.730960:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163200.761118:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/163201.104167:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163201.104348:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163201.104590:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 507
[1:1:0712/163201.104695:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 507 0x7f5810973070 0x1cf7409904e0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 321
[1:1:0712/163201.555798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/163201.555976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.741688:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 234, 7f58132b8881
[1:1:0712/163202.751421:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"160","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.751637:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"160","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.751869:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.752231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163202.752332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.762164:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 291, 7f58132b8881
[1:1:0712/163202.770806:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.770989:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.771260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.771599:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163202.771693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.778908:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 174, 7f58132b8881
[1:1:0712/163202.789233:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"154","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.789410:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"154","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.789658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.789918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163202.790001:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.791945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 2000
[1:1:0712/163202.792126:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 623
[1:1:0712/163202.792251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 623 0x7f5810973070 0x1cf73f2ea460 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 174 0x7f5810973070 0x1cf73edd6660 
[1:1:0712/163202.803424:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 383, 7f58132b8881
[1:1:0712/163202.813614:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.813796:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163202.814002:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.814288:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163202.814401:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.855075:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 491 0x7f581289b2e0 0x1cf73f3d91e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.855571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (window.webpackJsonp=window.webpackJsonp||[]).push([[7],{11:function(e,t,r){"use strict";var o=r(9),
[1:1:0712/163202.855672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.857066:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.868721:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 492 0x7f581289b2e0 0x1cf7409ba5e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.869306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){var n={};function t(r){if(n[r])return n[r].exports;var o=n[r]={i:r,l:!1,exports:{}};ret
[1:1:0712/163202.869411:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163202.870354:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.911420:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 494 0x7f581289b2e0 0x1cf74089a960 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163202.912488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , getRecommend({"code":0,"message":"成功","data":{"data":[{"createtime":"2019-07-12 12:44:22","thumb
[1:1:0712/163202.912591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
		remove user.f_ec6aa2c2 -> 0
[1:1:0712/163206.527378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163206.539652:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 495 0x7f581289b2e0 0x1cf73f3d9de0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163206.540270:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , getWirelessData({"code":0,"message":"成功","data":[{"id":1,"image_url":"https://media.yc.ifeng.com
[1:1:0712/163206.540446:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163206.677035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163206.710529:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 497 0x7f581289b2e0 0x1cf73f2fab60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163206.711409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , getVideo({"code":0,"message":"成功","data":[{"summary":"undefined","publishTime":"2019-07-12 11:35
[1:1:0712/163206.711571:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.078829:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.090753:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 498 0x7f581289b2e0 0x1cf74066d960 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.091408:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292031985576({"23186":{"ap":"23186","b":"41","cf":"iis","code":"%3Ciframe%20src%3D%22https%3
[1:1:0712/163207.091542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.098233:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163207.099131:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163207.100233:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x1cf73f1c3420
[1:1:0712/163207.100350:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[20494:20494:0712/163207.101387:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[1:1:0712/163207.108087:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163207.108242:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.ifeng.com
[20494:20494:0712/163207.108980:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.ifeng.com/
[20494:20494:0712/163207.119278:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163207.120889:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20494:20506:0712/163207.135135:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 4
[20494:20506:0712/163207.135200:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 4, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163207.135226:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ifeng.com/
[20494:20494:0712/163207.135272:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.ifeng.com/, https://www.ifeng.com/a_if/baidu/190624/spbnytl02.html, 4
[20494:20494:0712/163207.135337:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:4_https://www.ifeng.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:30:56 GMT Content-Type: text/html; charset=utf-8 Expires: Fri, 12 Jul 2019 08:32:56 GMT Server: openresty/1.13.6.1 Cache-Control: max-age=120 deviceType: pc shankrouter: cmpp_dyn_webq69v32_syq Content-Encoding: gzip Content-Security-Policy: upgrade-insecure-requests X-Via: 1.1 hk53:7 (Cdn Cache Server V2.0), 1.1 tianjin22:1 (Cdn Cache Server V2.0)  ,20589, 5
[1:7:0712/163207.137092:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163207.168087:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 502 0x7f581289b2e0 0x1cf74066d3e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.168798:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292031983794({"5875":{"ap":"5875","b":"89","cf":"iamsfloor","code":"%3Cscript%20type%3D%27te
[1:1:0712/163207.168918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.192243:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7f581289b2e0 0x1cf7405dd2e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.192813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292031987799({"2166":{"ap":"2166","b":"69","cf":"iis","code":"%3Cscript%3E%0D%0A%28function%
[1:1:0712/163207.192908:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163207.198347:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163207.199489:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x1cf73f1c4820
[1:1:0712/163207.200429:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[20494:20494:0712/163207.200674:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[20494:20494:0712/163207.213881:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:5_https://tech.ifeng.com/, https://tech.ifeng.com/, 5
[20494:20494:0712/163207.213968:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163207.230060:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a313978f8, 5:3_https://tech.ifeng.com/, 5:5_https://tech.ifeng.com/, about:blank
[1:1:0712/163207.230219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, open, 
[1:1:0712/163207.230365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 5, 2, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163207.230760:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=2166&uid=1562919047573_kxif731029&w=640&h=90&dm=tech.ifeng.com&tc=1562920319876&cl=8&cb=fa_0_156292031987799&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163207.233628:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 503 0x7f581289b2e0 0x1cf7405dd2e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.237645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163207.237817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 3, , , 0
[1:1:0712/163207.238137:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=2166&uid=1562919047573_kxif731029&w=640&h=90&dm=tech.ifeng.com&tc=1562920319876&cl=8&cb=fa_0_156292031987799&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163207.244007:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 438, 7f58132b8881
[1:1:0712/163207.256056:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163207.256290:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163207.256569:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.256910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163207.257002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.418268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.418716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.418851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.453578:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.453963:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.454076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.494137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.494562:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.494685:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.522269:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.522649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.522823:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.562853:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.563287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.563460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.592873:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.593300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.593412:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.633550:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.633915:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.634021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.661711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.662093:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.662196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.702336:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.702709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.702824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.731889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.732257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.732370:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.771849:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.772244:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.772373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.799854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.800274:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.800417:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.839806:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.840263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.840410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.869188:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.869626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.869729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.908955:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.909363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.909476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.938575:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.938950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.939072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163207.978543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163207.978910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163207.979024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.008375:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.008745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163208.008855:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.050253:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.050653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163208.050769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.079597:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.080022:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163208.080143:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.119817:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.120201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163208.120315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.150122:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.150499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163208.150619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.202026:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 559 0x7f581289b2e0 0x1cf74043d560 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.202583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292031990569({"23309":{"ap":"23309","b":"41","cf":"iis","code":"%3Ciframe%20src%3D%22https%3
[1:1:0712/163208.202699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163208.205381:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163208.206167:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163208.207240:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x1cf73f1c2a20
[1:1:0712/163208.207342:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[20494:20494:0712/163208.208464:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[1:1:0712/163208.214761:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163208.214942:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.ifeng.com
[20494:20494:0712/163208.216392:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.ifeng.com/
[20494:20494:0712/163208.230290:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163208.231834:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/163208.234189:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 560 0x7f581289b2e0 0x1cf740a4ef60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163208.234840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_15629203199457({"2343":{"ap":"2343","b":"89","cf":"iamsfloor","code":"%3Cscript%20type%3D%27tex
[1:1:0712/163208.234953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20506:0712/163208.247402:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 6
[20494:20506:0712/163208.247461:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 6, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163208.247492:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ifeng.com/
[20494:20494:0712/163208.247532:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://www.ifeng.com/, https://www.ifeng.com/a_if/baidu/190711/qpdnytwdz.html, 6
[20494:20494:0712/163208.247590:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:6_https://www.ifeng.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:30:57 GMT Content-Type: text/html; charset=utf-8 Expires: Fri, 12 Jul 2019 08:32:17 GMT Server: openresty/1.13.6.1 Cache-Control: max-age=120 deviceType: pc shankrouter: cmpp_dyn_webq70v32_syq Content-Encoding: gzip Content-Security-Policy: upgrade-insecure-requests Age: 40 X-Via: 1.1 hk55:4 (Cdn Cache Server V2.0), 1.1 tj21:5 (Cdn Cache Server V2.0)  ,20589, 5
[1:7:0712/163208.254382:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163208.360231:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163208.360385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163209.721232:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 573 0x7f581289b2e0 0x1cf73fc15e60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.722062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292031995892({"23181":{"ap":"23181","b":"54","cf":"iis","code":"%3Ciframe%20src%3D%22https%3
[1:1:0712/163209.722182:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163209.725463:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163209.727420:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163209.727589:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x1cf7441bca20
[20494:20494:0712/163209.729667:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[1:1:0712/163209.728458:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[1:1:0712/163209.739151:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163209.739373:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.ifeng.com
[20494:20494:0712/163209.740195:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.ifeng.com/
[20494:20494:0712/163209.754132:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163209.755824:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20494:20494:0712/163209.772041:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ifeng.com/
[20494:20494:0712/163209.772098:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://www.ifeng.com/, https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html, 7
[20494:20494:0712/163209.772160:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:7_https://www.ifeng.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:30:59 GMT Content-Type: text/html; charset=utf-8 Expires: Fri, 12 Jul 2019 08:32:56 GMT Server: openresty/1.13.6.1 Cache-Control: max-age=120 deviceType: pc shankrouter: ucms_shank_tarapi145v137_taiji Content-Encoding: gzip Content-Security-Policy: upgrade-insecure-requests Age: 3 X-Via: 1.1 hk53:8 (Cdn Cache Server V2.0), 1.1 tj18:3 (Cdn Cache Server V2.0)  ,20589, 5
[1:1:0712/163209.775045:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 574 0x7f581289b2e0 0x1cf740e4b160 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.775701:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292031999035({"23183":{"ap":"23183","b":"69","cf":"iis","code":"%3Cscript%3E%0D%0A%28functio
[1:1:0712/163209.775802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20506:0712/163209.780814:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 7
[20494:20506:0712/163209.780878:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 7, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/163209.781252:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163209.783058:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x1cf743dda220
[1:1:0712/163209.783172:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[20494:20494:0712/163209.784293:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[20494:20494:0712/163209.786430:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[20494:20494:0712/163209.804319:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:8_https://tech.ifeng.com/, https://tech.ifeng.com/, 8
[20494:20494:0712/163209.804418:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163209.821420:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a3137b670, 5:3_https://tech.ifeng.com/, 5:8_https://tech.ifeng.com/, about:blank
[1:1:0712/163209.821788:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, open, 
[1:1:0712/163209.821957:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 8, 2, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163209.822419:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23183&uid=1562919047573_kxif731029&w=300&h=250&dm=tech.ifeng.com&tc=1562920319990&cl=8&cb=fa_0_156292031999035&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163209.824008:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 574 0x7f581289b2e0 0x1cf740e4b160 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.828184:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163209.828377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 3, , , 0
[1:1:0712/163209.828708:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23183&uid=1562919047573_kxif731029&w=300&h=250&dm=tech.ifeng.com&tc=1562920319990&cl=8&cb=fa_0_156292031999035&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163209.865313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 576 0x7f581289b2e0 0x1cf7406cc960 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.865908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292032002575({"23184":{"ap":"23184","b":"41","cf":"iis","code":"%3Ciframe%20src%3D%22https%3
[1:1:0712/163209.866016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163209.868777:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163209.869594:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163209.870677:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x1cf744176220
[1:1:0712/163209.870801:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[20494:20494:0712/163209.871868:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[1:1:0712/163209.878352:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163209.878499:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.ifeng.com
[20494:20494:0712/163209.879274:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.ifeng.com/
[20494:20494:0712/163209.889933:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163209.891661:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/163209.899507:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 577 0x7f581289b2e0 0x1cf740e4b4e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.900145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292032004267({"23185":{"ap":"23185","b":"89","cf":"iamsfloor","code":"%3Cscript%20type%3D%27
[1:1:0712/163209.900276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20506:0712/163209.906397:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 9
[20494:20506:0712/163209.906458:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 9, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163209.906489:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ifeng.com/
[20494:20494:0712/163209.906533:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://www.ifeng.com/, https://www.ifeng.com/a_if/baidu/190624/spbnyjx04.html, 9
[20494:20494:0712/163209.906602:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:9_https://www.ifeng.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 08:30:59 GMT Content-Type: text/html; charset=utf-8 Expires: Fri, 12 Jul 2019 08:32:56 GMT Server: openresty/1.13.6.1 Cache-Control: max-age=120 deviceType: pc shankrouter: ucms_shank_router153v136_taiji Content-Encoding: gzip Content-Security-Policy: upgrade-insecure-requests Age: 3 X-Via: 1.1 k52:2 (Cdn Cache Server V2.0), 1.1 tj21:4 (Cdn Cache Server V2.0)  ,20589, 5
[1:7:0712/163209.908496:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163209.948375:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7f581289b2e0 0x1cf73fc235e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.948996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292032005737({"2842":{"ap":"2842","b":"47","cf":"iis","code":"%3Cscript%20src%3D%27%2F%2Fp0.
[1:1:0712/163209.949138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163209.953567:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163209.954777:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x1cf743dd9820
[1:1:0712/163209.954928:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[20494:20494:0712/163209.955971:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[20494:20494:0712/163209.968554:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:10_https://tech.ifeng.com/, https://tech.ifeng.com/, 10
[20494:20494:0712/163209.968635:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163209.984323:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a3134e190, 5:3_https://tech.ifeng.com/, 5:10_https://tech.ifeng.com/, about:blank
[1:1:0712/163209.984491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://tech.ifeng.com/-5:10_https://tech.ifeng.com/, 304a3134e190, 304a312c2860, open, 
[1:1:0712/163209.984620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 10, 2, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163209.985020:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=2842&uid=1562919047573_kxif731029&w=1000&h=90&dm=tech.ifeng.com&tc=1562920320055&cl=8&cb=fa_0_156292032005737&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163209.986600:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 579 0x7f581289b2e0 0x1cf73fc235e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163209.989852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://tech.ifeng.com/-5:10_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3134e190, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163209.990041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 3, , , 0
[1:1:0712/163209.990386:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=2842&uid=1562919047573_kxif731029&w=1000&h=90&dm=tech.ifeng.com&tc=1562920320055&cl=8&cb=fa_0_156292032005737&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163210.013474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 580 0x7f581289b2e0 0x1cf7405ddfe0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163210.014187:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292032008030({"4247":{"ap":"4247","b":"89","cf":"iams","code":"%3Cscript%20type%3D%27text%2F
[1:1:0712/163210.014314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163210.020829:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2374b5f029c8, 0x1cf73f056188
[1:1:0712/163210.020956:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 5000
[1:1:0712/163210.021146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 951
[1:1:0712/163210.021270:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 951 0x7f5810973070 0x1cf7449b5860 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 580 0x7f581289b2e0 0x1cf7405ddfe0 
[1:1:0712/163210.070131:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 582 0x7f581289b2e0 0x1cf73fd321e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163210.074581:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (window.webpackJsonp=window.webpackJsonp||[]).push([[5],{1071:function(e,r,t){"use strict";var a=t(1
[1:1:0712/163210.074798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163213.077259:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f056310
[1:1:0712/163213.077458:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163213.077728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 957
[1:1:0712/163213.077884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 957 0x7f5810973070 0x1cf746486760 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 582 0x7f581289b2e0 0x1cf73fd321e0 
[1:1:0712/163213.082663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60000, 0x2374b5f029c8, 0x1cf73f056310
[1:1:0712/163213.082840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 60000
[1:1:0712/163213.083091:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 958
[1:1:0712/163213.083246:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7f5810973070 0x1cf746cced60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 582 0x7f581289b2e0 0x1cf73fd321e0 
[1:1:0712/163213.087994:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163213.106892:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 583 0x7f581289b2e0 0x1cf73f2eefe0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163213.107535:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){var t={};function n(r){if(t[r])return t[r].exports;var i=t[r]={i:r,l:!1,exports:{}};ret
[1:1:0712/163213.107658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163213.109207:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163213.135520:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163213.135671:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163213.135849:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 976
[1:1:0712/163213.135959:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 976 0x7f5810973070 0x1cf740963e60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 583 0x7f581289b2e0 0x1cf73f2eefe0 
[1:1:0712/163213.136607:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163213.136690:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163213.136842:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 977
[1:1:0712/163213.136934:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f5810973070 0x1cf745f56860 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 583 0x7f581289b2e0 0x1cf73f2eefe0 
[1:1:0712/163213.148396:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163213.148586:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163213.148800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 981
[1:1:0712/163213.148910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 981 0x7f5810973070 0x1cf746bd5260 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 583 0x7f581289b2e0 0x1cf73f2eefe0 
[1:1:0712/163213.269103:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163213.269271:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163213.269570:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 986
[1:1:0712/163213.269700:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 986 0x7f5810973070 0x1cf7448e6d60 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 583 0x7f581289b2e0 0x1cf73f2eefe0 
[1:1:0712/163213.270405:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163213.270518:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163213.270738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 987
[1:1:0712/163213.270879:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 987 0x7f5810973070 0x1cf746d91ae0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 583 0x7f581289b2e0 0x1cf73f2eefe0 
[1:1:0712/163213.281381:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163213.281574:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163213.281801:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 991
[1:1:0712/163213.281961:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 991 0x7f5810973070 0x1cf746d9b160 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 583 0x7f581289b2e0 0x1cf73f2eefe0 
[1:1:0712/163214.116629:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 623, 7f58132b88db
[1:1:0712/163214.132191:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"174 0x7f5810973070 0x1cf73edd6660 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163214.132422:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"174 0x7f5810973070 0x1cf73edd6660 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163214.132643:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1001
[1:1:0712/163214.132735:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1001 0x7f5810973070 0x1cf73edae5e0 , 5:3_https://tech.ifeng.com/, 0, , 623 0x7f5810973070 0x1cf73f2ea460 
[1:1:0712/163214.132913:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163214.133214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163214.133313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163214.479358:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:4_https://www.ifeng.com/
[1:1:0712/163214.538180:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163214.538920:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , l.onload, (){localStorage.setItem(n,JSON.stringify({url:e,content:l.responseText,ver:a})),new Function(l.respo
[1:1:0712/163214.539055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.110869:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.111275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.111377:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.133686:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.134052:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.134154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.171928:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.172338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.172491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.195423:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.195835:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.195973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.219204:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.219659:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.219831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.243346:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.243713:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.243818:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.281509:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.281967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.282094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.305496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.305938:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.306030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.329377:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.329761:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.329862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.351766:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.352167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.352326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.391258:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.391660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.391831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.415200:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.415603:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.415750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.438529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.438901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.439034:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.461608:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.462037:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.462183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.501690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.502206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.502365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.525646:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.526162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.526349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.549636:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.550010:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.550113:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.573589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.573949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.574058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.611717:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.612104:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.612205:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.635554:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.635923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.636025:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.659438:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.659815:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.659928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.682324:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.682689:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.682793:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.720889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.721363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.721545:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.745392:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.745886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.746088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.768193:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.768669:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.769103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.792062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.792464:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.792605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.830660:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.831058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.831162:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.854013:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.854384:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.854484:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.877737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.878108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.878221:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.900197:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.900564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.900671:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.939932:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.940342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.940462:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.963679:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.964044:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.964145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163215.985976:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163215.986363:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163215.986482:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.009410:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.009760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.009860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.048011:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.048376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.048485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.071230:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.071598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.071706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.094852:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.095220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.095320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.118666:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.119040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.119140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.157166:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.157540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.157642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.180656:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.181025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.181181:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.203480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.203916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.204055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.227198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.227598:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.227699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.266529:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.266905:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.267007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.288508:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.288916:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.289116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.311241:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.311595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.311706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.335007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.335376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.335475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.373332:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.373757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.373913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.398035:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.398456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.398605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.421308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.421742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.421865:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.445812:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.446275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.446424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.485218:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.485641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.485787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.509629:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.510074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.510210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.532482:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.532886:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.532974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.555810:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.556176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.556301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.595577:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.595940:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.596042:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.619123:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.619506:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.619628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.643124:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.643484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.643587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.667188:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.667564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.667666:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.706198:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.706620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.706739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163216.730737:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163216.731122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163216.731225:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163217.067242:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:6_https://www.ifeng.com/
[1:1:0712/163217.140939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163217.141151:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163217.378147:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (e,n)=>{e.forEach(e=>{e.intersectionRatio>0&&t.trigger("lazyload",e.target)})}
[1:1:0712/163217.378302:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163219.822381:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:7_https://www.ifeng.com/
[1:1:0712/163220.384651:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:9_https://www.ifeng.com/
[1:1:0712/163220.708646:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 946, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163220.709318:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:10_https://tech.ifeng.com/, 304a3134e190, , , var postercallback=function(data){var games_ad=data.loc,datas=data.data,curDate=new Date().getTime()
[1:1:0712/163220.709463:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 10, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163220.709781:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x2374b60124b0, 0x1cf73f0561c8
[1:1:0712/163220.709861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 100
[1:1:0712/163220.710031:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1109
[1:1:0712/163220.710143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1109 0x7f5810973070 0x1cf74438ad60 , 5:3_https://tech.ifeng.com/, 1, -5:10_https://tech.ifeng.com/, 946
[1:1:0712/163220.710672:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 946, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163221.482890:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 987, 7f58132b8881
[1:1:0712/163221.502056:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"583 0x7f581289b2e0 0x1cf73f2eefe0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163221.502270:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"583 0x7f581289b2e0 0x1cf73f2eefe0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163221.502488:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163221.502786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163221.502915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163221.664644:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163221.665143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163221.665290:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163221.707735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163221.708145:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163221.708280:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163221.859362:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:4_https://www.ifeng.com/, https://www.ifeng.com/, 4
[20494:20494:0712/163221.859432:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://www.ifeng.com/, https://www.ifeng.com
[1:1:0712/163221.859761:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163221.900225:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163221.900604:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163221.900702:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163222.330212:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1001, 7f58132b88db
[1:1:0712/163222.348557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"623 0x7f5810973070 0x1cf73f2ea460 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163222.348724:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"623 0x7f5810973070 0x1cf73f2ea460 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163222.348933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1172
[1:1:0712/163222.349023:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1172 0x7f5810973070 0x1cf7478332e0 , 5:3_https://tech.ifeng.com/, 0, , 1001 0x7f5810973070 0x1cf73edae5e0 
[1:1:0712/163222.349247:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163222.349511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163222.349608:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163222.406570:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163222.407023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163222.407148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163222.444570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 951, 7f58132b8881
[1:1:0712/163222.463415:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"580 0x7f581289b2e0 0x1cf7405ddfe0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163222.463589:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"580 0x7f581289b2e0 0x1cf7405ddfe0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163222.463756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163222.464005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163222.464105:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163222.465601:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 450, 7f58132b8881
[1:1:0712/163222.483539:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163222.483710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"260 0x7f581289b2e0 0x1cf73f2f33e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163222.483903:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163222.484202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163222.484322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163222.487846:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x2374b5f029c8, 0x1cf73f056150
[1:1:0712/163222.487997:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 500
[1:1:0712/163222.488177:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1174
[1:1:0712/163222.488300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1174 0x7f5810973070 0x1cf744326de0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 450 0x7f5810973070 0x1cf740990ce0 
[1:1:0712/163222.499147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x2374b5f029c8, 0x1cf73f056150
[1:1:0712/163222.499340:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 10000
[1:1:0712/163222.499567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1178
[1:1:0712/163222.499731:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1178 0x7f5810973070 0x1cf73ee46160 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 450 0x7f5810973070 0x1cf740990ce0 
[20494:20494:0712/163222.626177:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:6_https://www.ifeng.com/, https://www.ifeng.com/, 6
[20494:20494:0712/163222.626247:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://www.ifeng.com/, https://www.ifeng.com
[1:1:0712/163222.627183:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163222.687308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163222.687708:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163222.687846:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163222.765782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163222.765931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163223.573840:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163223.574252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163223.574355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163223.718908:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:7_https://www.ifeng.com/, https://www.ifeng.com/, 7
[20494:20494:0712/163223.718983:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://www.ifeng.com/, https://www.ifeng.com
[1:1:0712/163223.719259:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163223.919902:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163223.920361:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163223.920510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163224.005338:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[20494:20494:0712/163224.005813:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:9_https://www.ifeng.com/, https://www.ifeng.com/, 9
[20494:20494:0712/163224.005860:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, https://www.ifeng.com/, https://www.ifeng.com
[1:1:0712/163224.050391:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.050812:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163224.050949:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163224.168841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.169301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163224.169438:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163224.190450:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1109, 7f58132b8881
[1:1:0712/163224.210011:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a3134e190","ptid":"946","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163224.210184:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:10_https://tech.ifeng.com/","ptid":"946","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163224.210374:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.210641:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:10_https://tech.ifeng.com/, 304a3134e190, , , (){var gamesDoms={};try{var gamesIds=getClass("div","play_game_public");for(var j=0;j<gamesIds.lengt
[1:1:0712/163224.210764:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 10, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163224.258444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1118 0x7f581289b2e0 0x1cf7477918e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.260376:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){var t={};function i(l){if(t[l])return t[l].exports;var o=t[l]={i:l,l:!1,exports:{}};ret
[1:1:0712/163224.260544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163224.284181:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1119 0x7f581289b2e0 0x1cf744995060 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.284746:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (function(){var commentJsonVarStr___={"doc_url":"ucms_7o8tHReAl1E","join_count":0,"count":0,"allcoun
[1:1:0712/163224.284834:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163224.328026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.467639:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1125 0x7f581289b2e0 0x1cf7448e5d60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.468271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (function(){var surveyJsonVarStr___={"code":1,"msg":"success","data":{"browse":{"ucms_7o8tHReAl1Edin
[1:1:0712/163224.468395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163224.511775:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.532948:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1126 0x7f581289b2e0 0x1cf74777e8e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.533755:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292033314543({"23187":{"ap":"23187","b":"69","cf":"iis","code":"%3Cscript%3E%0D%0A%09%28func
[1:1:0712/163224.533936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163224.540339:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163224.541647:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x1cf743f64020
[1:1:0712/163224.541808:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[20494:20494:0712/163224.542744:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 11, 11, 
[20494:20494:0712/163224.556413:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:11_https://tech.ifeng.com/, https://tech.ifeng.com/, 11
[20494:20494:0712/163224.556507:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163224.576279:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a31308cc8, 5:3_https://tech.ifeng.com/, 5:11_https://tech.ifeng.com/, about:blank
[1:1:0712/163224.576434:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, open, 
[1:1:0712/163224.576558:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 11, 2, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163224.577291:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23187,23188&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333144&cl=8&cb=fa_0_156292033314543&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163224.578686:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1126 0x7f581289b2e0 0x1cf74777e8e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.582601:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163224.582779:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 3, , , 0
[1:1:0712/163224.583117:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23187,23188&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333144&cl=8&cb=fa_0_156292033314543&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[20494:20494:0712/163224.590724:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163224.591118:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 12, 0x1cf744195420
[1:1:0712/163224.591252:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 12
[20494:20494:0712/163224.593119:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 12, 12, 
[20494:20494:0712/163224.606306:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:12_https://tech.ifeng.com/, https://tech.ifeng.com/, 12
[20494:20494:0712/163224.606390:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 12, 12, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163224.626630:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a31311d58, 5:3_https://tech.ifeng.com/, 5:12_https://tech.ifeng.com/, about:blank
[1:1:0712/163224.626838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, open, 
[1:1:0712/163224.627002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 12, 4, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163224.627446:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23187,23188&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333144&cl=8&cb=fa_0_156292033314543&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163224.629114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1126 0x7f581289b2e0 0x1cf74777e8e0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.633452:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163224.633656:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 5, , , 0
[1:1:0712/163224.634022:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23187,23188&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333144&cl=8&cb=fa_0_156292033314543&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163224.690114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1128 0x7f581289b2e0 0x1cf743161f60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.691074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292033327825({"23189":{"ap":"23189","b":"69","cf":"iis","code":"%3Cscript%3E%0D%0A%09%28func
[1:1:0712/163224.691199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163224.697531:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163224.698680:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 13, 0x1cf744196820
[1:1:0712/163224.698821:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 13
[20494:20494:0712/163224.700237:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 13, 13, 
[20494:20494:0712/163224.713786:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:13_https://tech.ifeng.com/, https://tech.ifeng.com/, 13
[20494:20494:0712/163224.713890:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 13, 13, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163224.732303:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a3131c1c8, 5:3_https://tech.ifeng.com/, 5:13_https://tech.ifeng.com/, about:blank
[1:1:0712/163224.732492:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, open, 
[1:1:0712/163224.732607:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 13, 2, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163224.733001:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23189,23190&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333277&cl=8&cb=fa_0_156292033327825&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163224.734416:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1128 0x7f581289b2e0 0x1cf743161f60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.738341:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163224.738510:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 3, , , 0
[1:1:0712/163224.738873:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23189,23190&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333277&cl=8&cb=fa_0_156292033327825&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[20494:20494:0712/163224.745102:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163224.746304:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 14, 0x1cf744195e20
[1:1:0712/163224.746468:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 14
[20494:20494:0712/163224.747299:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 14, 14, 
[20494:20494:0712/163224.763439:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:14_https://tech.ifeng.com/, https://tech.ifeng.com/, 14
[20494:20494:0712/163224.763522:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 14, 14, https://tech.ifeng.com/, https://tech.ifeng.com
[1:1:0712/163224.781569:INFO:switcher_impl.cc(1369)] 			updated frame chain. [WARN] subject_frame does not exist in protected memory. [subject_frame, principals, url] = 304a312e7b08, 5:3_https://tech.ifeng.com/, 5:14_https://tech.ifeng.com/, about:blank
[1:1:0712/163224.781785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, open, 
[1:1:0712/163224.782021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "about:blank", "tech.ifeng.com", 14, 4, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163224.783334:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	n (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	t.default (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.codeHandler (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.setElContent (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23189,23190&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333277&cl=8&cb=fa_0_156292033327825&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163224.784882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1128 0x7f581289b2e0 0x1cf743161f60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163224.789215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, t.isTpl, (e){return e.hasOwnProperty("data")&&e.hasOwnProperty("script")&&e.hasOwnProperty("callback")}
[1:1:0712/163224.789400:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 5, , , 0
[1:1:0712/163224.789726:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.adDataHanlder (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1
	window.(anonymous function) (https://c0.ifengimg.com/m/mobile_inice_v202.js:1:1)
	https://ax.ifeng.com/showcode?adids=23189,23190&uid=1562919047573_kxif731029&w=300,300&h=56,56&dm=tech.ifeng.com&tc=1562920333277&cl=8&cb=fa_0_156292033327825&keywords=%E8%83%8E%E5%84%BF%20%E5%8C%BB%E5%AD%A6%20%E6%88%90%E5%83%8F%20ct%20%E5%89%82%E9%87%8F%20%E6%AF%8D%E4%B9%B3%E5%96%82%E5%85%BB%20%E5%AD%95%E5%A6%87%20%E5%BF%83%E8%82%8C%20%E9%A3%8E%E9%99%A9%20%E6%A0%B8%E7%A3%81%E5%85%B1%E6%8C%AF%20%E6%94%BE%E5%B0%84%E6%80%A7%20%E8%B6%85%E5%A3%B0%20%E8%83%8E%E5%BF%83%20%E5%90%8C%E4%BD%8D%E7%B4%A0%20%E6%9E%9C%E5%A3%B3%20%E6%A0%B8%E7%94%B5%E7%AB%99%20%E5%A3%B0%E6%B3%A2%20%E5%88%87%E5%B0%94%E8%AF%BA%E8%B4%9D%E5%88%A9%20%E7%A7%8D%E7%B1%BB%20%E7%AD%94%E6%A1%88:1:1

[1:1:0712/163225.379682:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163225.696486:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163225.696908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163225.697000:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163225.826990:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163225.827381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163225.827479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163225.870711:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163225.871144:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163225.871273:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163225.916694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1171 0x7f5826ffe080 0x1cf747838560 1 0 0x1cf747838578 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163225.921378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163225.921527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.474084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.474247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163226.475240:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.475484:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.475634:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.476273:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.597661:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.597920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163226.598620:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.598897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.599111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.599677:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.601189:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.601374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163226.601928:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.602151:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.602379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.602911:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.616202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.616398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163226.616992:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.617215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.617376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.617905:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.618924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.619074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163226.619651:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.619829:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.619979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.620507:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.626724:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.626945:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163226.627617:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.627852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.628075:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.628819:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.629776:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, getBoundingClientRect, 
[1:1:0712/163226.629988:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163226.630639:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.630968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, floor, 
[1:1:0712/163226.631190:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.631798:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.633122:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, getComputedStyle, 
[1:1:0712/163226.633307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163226.633906:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.634254:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163226.634487:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.635087:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.635868:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, getComputedStyle, 
[1:1:0712/163226.636070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163226.636766:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.637166:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, parseInt, 
[1:1:0712/163226.637398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.638009:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.642925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.643189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163226.643862:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.644055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.644274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.644805:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.648828:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.649050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 22, , , 0
[1:1:0712/163226.649677:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.649863:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.650087:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 23, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.650667:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.652373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.652596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 24, , , 0
[1:1:0712/163226.653321:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.653503:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.653729:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 25, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.654320:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.662261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.662530:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 26, , , 0
[1:1:0712/163226.663273:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.663460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.663708:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 27, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.664314:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.679488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.679794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 28, , , 0
[1:1:0712/163226.680455:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.680649:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.680905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 29, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.681504:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.683385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.683626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 30, , , 0
[1:1:0712/163226.684251:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.684428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.684670:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 31, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.685270:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.687102:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.687375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 32, , , 0
[1:1:0712/163226.688041:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.688257:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.688598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 33, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.689404:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.691636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163226.692094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 34, , , 0
[1:1:0712/163226.692894:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.693150:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163226.693560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 35, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163226.694308:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163226.966987:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163227.183071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163227.183227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.184552:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1172, 7f58132b88db
[1:1:0712/163227.206602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1001 0x7f5810973070 0x1cf73edae5e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163227.206833:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1001 0x7f5810973070 0x1cf73edae5e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163227.207125:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1394
[1:1:0712/163227.207298:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1394 0x7f5810973070 0x1cf740735f60 , 5:3_https://tech.ifeng.com/, 0, , 1172 0x7f5810973070 0x1cf7478332e0 
[1:1:0712/163227.207542:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.207881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163227.208007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.209945:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1174, 7f58132b8881
[1:1:0712/163227.231979:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312c2860","ptid":"450 0x7f5810973070 0x1cf740990ce0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163227.232147:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://tech.ifeng.com/","ptid":"450 0x7f5810973070 0x1cf740990ce0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163227.232340:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.232638:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163227.232726:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.318288:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.318707:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163227.318845:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.369413:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.369965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163227.370155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.443386:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.443800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163227.443955:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.495541:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.495949:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163227.496063:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163227.568152:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163227.568525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , Pn, (e,t){if(_n){var n=ze(t);if(null===(n=I(n))||"number"!=typeof n.tag||2===tn(n)||(n=null),kn.length){
[1:1:0712/163227.568626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163228.083863:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163228.307794:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1242 0x7f5826ffe080 0x1cf747730240 1 0 0x1cf747730258 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163228.309704:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://tech.ifeng.com/, 304a3137b670, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163228.309889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.841756:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.841941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163228.842558:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.842759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.842913:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.843409:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.880721:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.880928:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163228.881448:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.881693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.881886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.882354:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.883615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.883788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163228.884380:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.884635:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.884808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.885355:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.898471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.898667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163228.899258:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.899439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.899601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.900132:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.901261:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.901407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163228.901981:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.902159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.902324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.902865:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.909980:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.910199:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163228.910803:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.910995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.911185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.911740:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.912425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, getBoundingClientRect, 
[1:1:0712/163228.912598:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163228.913190:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.913432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, floor, 
[1:1:0712/163228.913625:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.914167:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.915292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, getComputedStyle, 
[1:1:0712/163228.915470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163228.916035:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.916359:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163228.916570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.917171:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.917754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, getComputedStyle, 
[1:1:0712/163228.917943:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163228.918514:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.918785:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, parseInt, 
[1:1:0712/163228.918993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.919524:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.923605:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.923837:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163228.924496:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.924731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.925019:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.925687:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.930381:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.930709:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 22, , , 0
[1:1:0712/163228.931555:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.931818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.932108:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 23, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.932833:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.934686:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.934930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 24, , , 0
[1:1:0712/163228.935601:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.935791:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.936018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 25, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.936594:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.943839:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.944109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 26, , , 0
[1:1:0712/163228.944925:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.945426:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.945792:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 27, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.946606:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.961378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.961714:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 28, , , 0
[1:1:0712/163228.962449:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.962688:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.963026:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 29, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.963617:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.965367:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.965597:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 30, , , 0
[1:1:0712/163228.966210:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.966385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.966642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 31, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.967223:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.968847:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.969144:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 32, , , 0
[1:1:0712/163228.969756:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.969934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.970200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 33, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.970768:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.972413:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163228.972667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 34, , , 0
[1:1:0712/163228.973305:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163228.973524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163228.973813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 35, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163228.974424:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163229.102212:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163231.463538:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163231.463738:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ifeng.com/a_if/baidu/190624/spbnytl02.html"
[1:1:0712/163231.466694:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1363 0x7f5810973070 0x1cf7448f8660 , "https://www.ifeng.com/a_if/baidu/190624/spbnytl02.html"
[1:1:0712/163231.480678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.ifeng.com/, 304a3138fef8, , , 
    (function() {
        var s = "_" + Math.random().toString(36).slice(2);
        document.write
[1:1:0712/163231.480876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/baidu/190624/spbnytl02.html", "www.ifeng.com", 4, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163231.951878:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1384, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163231.952629:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , , ___adblockplus({"queryid" : "eb9e0c87f056bb72","tuid" : "1174825_0","placement" : {"basic" : {"sspId
[1:1:0712/163231.952799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163231.958614:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163231.960219:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163231.960678:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 15, 0x1cf743dd8420
[1:1:0712/163231.960809:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 15
[20494:20494:0712/163231.962463:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 15, 15, 
[1:1:0712/163231.971494:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163231.971684:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.ifeng.com
[1:1:0712/163231.972980:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1384, "https://tech.ifeng.com/c/7o8tHReAl1E"
[20494:20494:0712/163231.973691:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.ifeng.com/
[1:1:0712/163231.976747:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b6007e50, 0x1cf73f0561a0
[1:1:0712/163231.976930:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163231.977231:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1497
[1:1:0712/163231.977411:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1497 0x7f5810973070 0x1cf74443b5e0 , 5:3_https://tech.ifeng.com/, 1, -5:5_https://tech.ifeng.com/, 1384
[1:1:0712/163231.979925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163231.980093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163231.980777:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/rcmm?psi=eba1604f53464b4bb1240e938322c42f&di=1174825&dri=0&dis=1&dai=0&ps=7993x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920346&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=640x90&sr=1920x1080&tcn=1562920347&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163231.980997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163231.981149:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163231.981746:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/rcmm?psi=eba1604f53464b4bb1240e938322c42f&di=1174825&dri=0&dis=1&dai=0&ps=7993x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920346&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=640x90&sr=1920x1080&tcn=1562920347&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[20494:20494:0712/163231.982368:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163231.984143:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/163231.989823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163231.990013:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163231.990647:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/rcmm?psi=eba1604f53464b4bb1240e938322c42f&di=1174825&dri=0&dis=1&dai=0&ps=7993x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920346&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=640x90&sr=1920x1080&tcn=1562920347&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163231.990892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163231.991052:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163231.991609:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/rcmm?psi=eba1604f53464b4bb1240e938322c42f&di=1174825&dri=0&dis=1&dai=0&ps=7993x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920346&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=640x90&sr=1920x1080&tcn=1562920347&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163231.993937:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a313978f8, toString, 
[1:1:0712/163231.994081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163231.994663:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/rcmm?psi=eba1604f53464b4bb1240e938322c42f&di=1174825&dri=0&dis=1&dai=0&ps=7993x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920346&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=640x90&sr=1920x1080&tcn=1562920347&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163231.994903:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:5_https://tech.ifeng.com/, 304a313978f8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163231.995441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163231.995988:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/rcmm?psi=eba1604f53464b4bb1240e938322c42f&di=1174825&dri=0&dis=1&dai=0&ps=7993x0&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920346&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=640x90&sr=1920x1080&tcn=1562920347&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[20494:20506:0712/163231.999226:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 15
[20494:20506:0712/163231.999282:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 15, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163231.999322:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://s2.yylady.cn/
[20494:20494:0712/163231.999364:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:15_https://s2.yylady.cn/, https://s2.yylady.cn/corner/html/lx_text_640x50.html, 15
[20494:20494:0712/163231.999425:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:15_https://s2.yylady.cn/, HTTP/1.1 200 OK Server: AliyunOSS Date: Fri, 12 Jul 2019 08:13:53 GMT Content-Type: text/html Vary: Accept-Encoding x-oss-request-id: 5D2841415369E81C980E7DD3 Last-Modified: Tue, 30 Oct 2018 05:14:33 GMT x-oss-object-type: Normal x-oss-hash-crc64ecma: 4726078379100487885 x-oss-storage-class: Standard Content-MD5: EA/7NCNayMHcYHD5gV83Fg== x-oss-server-time: 1 Content-Encoding: gzip  ,20589, 5
[1:7:0712/163232.001257:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163232.167114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1388 0x7f581289b2e0 0x1cf747b89760 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163232.167809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , fa_0_156292034249611({"9060":{"ap":"9060","b":"59","cf":"iis","code":"%3C%21--%23%7B%0D%0A%20%20%20%
[1:1:0712/163232.167931:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163232.174413:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 5000, 0x2374b5f029c8, 0x1cf73f056188
[1:1:0712/163232.174562:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 5000
[1:1:0712/163232.174741:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1507
[1:1:0712/163232.174863:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1507 0x7f5810973070 0x1cf747b53de0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 1388 0x7f581289b2e0 0x1cf747b89760 
[1:1:0712/163232.230914:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163232.231047:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ifeng.com/a_if/baidu/190711/qpdnytwdz.html"
[1:1:0712/163232.233824:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1390 0x7f5810973070 0x1cf743b6b6e0 , "https://www.ifeng.com/a_if/baidu/190711/qpdnytwdz.html"
[1:1:0712/163232.247362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://www.ifeng.com/, 304a31366220, , , 
    (function() {
        var s = "_" + Math.random().toString(36).slice(2);
        document.write
[1:1:0712/163232.247549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/baidu/190711/qpdnytwdz.html", "www.ifeng.com", 6, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163232.353923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163232.354077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163233.092996:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163233.093192:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html"
[1:1:0712/163233.095976:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1421 0x7f5810973070 0x1cf7482b36e0 , "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html"
[1:1:0712/163233.111292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_https://www.ifeng.com/, 304a31375960, , , 
  (function () {
    var s = "_" + Math.random().toString(36).slice(2);
    document.write('<div id
[1:1:0712/163233.111481:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html", "www.ifeng.com", 7, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.333831:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1394, 7f58132b88db
[1:1:0712/163233.357657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1172 0x7f5810973070 0x1cf7478332e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163233.357823:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1172 0x7f5810973070 0x1cf7478332e0 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163233.358051:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1548
[1:1:0712/163233.358155:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1548 0x7f5810973070 0x1cf7489c0460 , 5:3_https://tech.ifeng.com/, 0, , 1394 0x7f5810973070 0x1cf740735f60 
[1:1:0712/163233.358342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163233.358615:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163233.358719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163233.458187:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163233.458935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://tech.ifeng.com/, 304a3137b670, , , ___adblockplus({"queryid" : "9aa915520688a9e8","tuid" : "5925722_0","placement" : {"basic" : {"sspId
[1:1:0712/163233.459062:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.465712:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1432, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163233.470044:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b600e8d0, 0x1cf73f0561a0
[1:1:0712/163233.470201:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163233.470394:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1553
[1:1:0712/163233.470543:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1553 0x7f5810973070 0x1cf748a218e0 , 5:3_https://tech.ifeng.com/, 1, -5:8_https://tech.ifeng.com/, 1432
[1:1:0712/163233.472794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163233.472939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163233.473683:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/pclm?psi=54b93814672bd1e3d3ee132a2758a1d5&di=5925722&dri=0&dis=1&dai=0&ps=3708x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920348&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x250&sr=1920x1080&tcn=1562920349&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163233.473926:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163233.474067:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.474696:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/pclm?psi=54b93814672bd1e3d3ee132a2758a1d5&di=5925722&dri=0&dis=1&dai=0&ps=3708x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920348&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x250&sr=1920x1080&tcn=1562920349&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163233.479258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163233.479442:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163233.480126:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/pclm?psi=54b93814672bd1e3d3ee132a2758a1d5&di=5925722&dri=0&dis=1&dai=0&ps=3708x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920348&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x250&sr=1920x1080&tcn=1562920349&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163233.480377:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163233.480573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.481513:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/pclm?psi=54b93814672bd1e3d3ee132a2758a1d5&di=5925722&dri=0&dis=1&dai=0&ps=3708x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920348&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x250&sr=1920x1080&tcn=1562920349&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163233.484135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163233.484317:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163233.485011:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/pclm?psi=54b93814672bd1e3d3ee132a2758a1d5&di=5925722&dri=0&dis=1&dai=0&ps=3708x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920348&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x250&sr=1920x1080&tcn=1562920349&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163233.485271:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163233.485457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.486167:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/pclm?psi=54b93814672bd1e3d3ee132a2758a1d5&di=5925722&dri=0&dis=1&dai=0&ps=3708x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920348&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x250&sr=1920x1080&tcn=1562920349&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163233.518647:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163233.518837:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ifeng.com/a_if/baidu/190624/spbnyjx04.html"
[1:1:0712/163233.522005:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1433 0x7f5810973070 0x1cf747b8f760 , "https://www.ifeng.com/a_if/baidu/190624/spbnyjx04.html"
[1:1:0712/163233.538340:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:9_https://www.ifeng.com/, 304a31347de0, , , 
    (function() {
        var s = "_" + Math.random().toString(36).slice(2);
        document.write
[1:1:0712/163233.538580:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/baidu/190624/spbnyjx04.html", "www.ifeng.com", 9, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.672826:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1438 0x7f581289b2e0 0x1cf7482a5fe0 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163233.673491:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:10_https://tech.ifeng.com/, 304a3134e190, , , postercallback({"loc":"play_game_44295081","data":[{"url":"https:\/\/p3.ifengimg.com\/bd95085924c117
[1:1:0712/163233.673667:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 10, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163233.677428:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[20494:20494:0712/163233.678350:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/163233.679458:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 16, 0x1cf744174e20
[1:1:0712/163233.679577:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 16
[20494:20494:0712/163233.680620:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 16, 16, 
[1:1:0712/163233.688199:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/163233.688359:INFO:render_frame_impl.cc(7019)] 	 [url] = https://tech.ifeng.com
[20494:20494:0712/163233.689206:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 5:3_https://tech.ifeng.com/
[20494:20494:0712/163233.746417:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[20494:20494:0712/163233.748757:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[20494:20506:0712/163233.763482:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 16
[20494:20506:0712/163233.763545:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 16, HandleIncomingMessage, HandleIncomingMessage
[20494:20494:0712/163233.763577:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://p3.ifengimg.com/
[20494:20494:0712/163233.763618:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:16_https://p3.ifengimg.com/, https://p3.ifengimg.com/bd95085924c117e3/2019/4/jdqtdl1000X90V1.html?clickTag=https%3A%2F%2Fax.ifeng.com%2Fc%3Fp%3DjZPDDatwJv8qP_sZCOVa6cu2FRgLNmZDNy8yadeY28aecb-1SwOI3b7utPBvlV3lovYewxOv3tPH4QtQQVn-Xix6ov2tMtgjxvbig3HRl2f0byc1pE3vFmKQOMxYu90G4CGMLziE5QeaTi59y9aWyNzb1t1KfMKH3tTNakrgyL-Y161tVy9z-Lorz6g0lnfOvZ1sR44s2nJ6ikck7RnzfsklR7oxwnzaVIqkit8DrQr7bVc8z93PamYtiuc8nageN-4gD7LsKVBJm1RDQwxyW0ks6oUJAOCdQRLeMwdM_-4%26u%3Dhttp%3A%2F%2Fgames.ifeng.com%2Fwebgame%2Fzcy%2Fzcy10087.shtml%3Faf%3D44295081, 16
[20494:20494:0712/163233.763693:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:16_https://p3.ifengimg.com/, HTTP/1.1 200 OK Server: NWSs Date: Fri, 12 Jul 2019 08:25:17 GMT Content-Type: text/html Content-Length: 1916 Connection: keep-alive Cache-Control: max-age=31536000 Expires: Sat, 11 Jul 2020 08:25:17 GMT Last-Modified: Fri, 25 Jan 2019 08:57:48 GMT Content-Encoding: gzip X-NWS-LOG-UUID: 4d30e1c6-9c76-4edc-9d93-43a570a25687 X-Cache-Lookup: Hit From Disktank3 Gz Access-Control-Allow-Origin: *  ,20589, 5
[1:7:0712/163233.773892:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/163234.226266:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163234.226685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163234.226788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163234.478631:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163234.479077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163234.479193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163234.555418:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163234.555867:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163234.555987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163234.606984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163234.607403:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163234.607520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163235.142831:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1499, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163235.143836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , , (function(){function p(){this.c="1257375399";this.ca="z";this.Y="";this.V="";this.X="";this.D="15629
[1:1:0712/163235.143973:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163235.365158:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:15_https://s2.yylady.cn/
[1:1:0712/163235.774782:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163235.774962:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163235.906431:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1497, 7f58132b8881
[1:1:0712/163235.932216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a313978f8","ptid":"1384","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163235.932418:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:5_https://tech.ifeng.com/","ptid":"1384","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163235.932650:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163235.932943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/163235.933095:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163236.783211:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 ()","https://wx4.sinaimg.cn/mw690/65f12779gy1fwc4dtit8ej201b00ejrc.jpg"
[1:1:0712/163237.309965:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:16_https://p3.ifengimg.com/
[1:1:0712/163237.344340:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1593 0x7f5826ffe080 0x1cf748b346a0 1 0 0x1cf748b346b8 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163237.346309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://tech.ifeng.com/, 304a31308cc8, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163237.346475:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.890069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.890281:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163237.890941:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.891199:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.891382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.891950:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.932595:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.932799:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163237.933369:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.933586:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.933750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.934219:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.935662:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.935873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163237.936448:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.936621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.936790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.937353:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.950540:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.950727:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163237.951329:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.951520:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.951689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.952218:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.953390:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.953569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163237.954266:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.954493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.954747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.955596:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.962489:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.962758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163237.963520:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.963767:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.963964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.965422:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.966246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, getBoundingClientRect, 
[1:1:0712/163237.966425:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163237.967038:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.967292:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, floor, 
[1:1:0712/163237.967473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.968061:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.969305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, getComputedStyle, 
[1:1:0712/163237.969489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163237.970105:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.970436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163237.970620:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.971170:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.971817:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, getComputedStyle, 
[1:1:0712/163237.972003:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163237.972693:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.973013:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, parseInt, 
[1:1:0712/163237.973262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.973829:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.978849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.979059:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163237.979670:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.979858:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.980068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.980585:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.984908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.985213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 22, , , 0
[1:1:0712/163237.985973:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.986216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.986572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 23, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.987368:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.989466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163237.989781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 24, , , 0
[1:1:0712/163237.990652:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163237.990907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163237.991271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 25, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163237.992750:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.000524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163238.000781:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 26, , , 0
[1:1:0712/163238.001564:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.001766:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.002032:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 27, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.002666:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.016473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163238.016812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 28, , , 0
[1:1:0712/163238.017756:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.018003:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.018328:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 29, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.019471:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.021472:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163238.021805:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 30, , , 0
[1:1:0712/163238.022681:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.022924:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.023313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 31, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.024084:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.025969:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163238.026262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 32, , , 0
[1:1:0712/163238.026974:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.027155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.027433:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 33, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.028055:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.029805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163238.030077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 34, , , 0
[1:1:0712/163238.031024:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.031203:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.031485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 35, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.032086:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.135691:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1596 0x7f5826ffe080 0x1cf747a2dba0 1 0 0x1cf747a2dbb8 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163238.137539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:12_https://tech.ifeng.com/, 304a31311d58, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163238.137730:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.724251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.724473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163238.725209:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.725483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.725648:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.726285:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.764365:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.764572:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163238.765120:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.765324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.765476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.765897:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.767091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.767228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163238.767704:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.767889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.768037:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.768464:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.780810:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.781016:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163238.781770:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.781970:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.782170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.782754:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.783797:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.783985:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163238.784564:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.784816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.785006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.787057:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.793793:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.794012:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163238.794635:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.794816:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.794987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.795540:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.796255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, getBoundingClientRect, 
[1:1:0712/163238.796410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163238.796948:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.797217:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, floor, 
[1:1:0712/163238.797406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.797938:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.799115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, getComputedStyle, 
[1:1:0712/163238.799292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163238.799868:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.800179:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163238.800366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.800911:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.801550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, getComputedStyle, 
[1:1:0712/163238.801751:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163238.802318:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.802597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, parseInt, 
[1:1:0712/163238.802807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.803333:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.807685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.807921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163238.808511:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.808698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.808923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.809507:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.813860:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.814128:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 22, , , 0
[1:1:0712/163238.814801:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.815004:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.815244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 23, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.815822:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.817507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.817741:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 24, , , 0
[1:1:0712/163238.818517:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.818751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.819007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 25, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.819759:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.827931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.828198:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 26, , , 0
[1:1:0712/163238.828903:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.829148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.829413:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 27, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.830016:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.843747:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.844090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 28, , , 0
[1:1:0712/163238.844834:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.845020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.845301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 29, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.845888:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.847558:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.847812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 30, , , 0
[1:1:0712/163238.848412:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.848583:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.848836:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 31, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.849439:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.851074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.851375:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 32, , , 0
[1:1:0712/163238.852089:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.852301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.852659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 33, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.853437:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.855253:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163238.855655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 34, , , 0
[1:1:0712/163238.856499:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.856768:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163238.857166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 35, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163238.857883:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163238.994493:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1599 0x7f5826ffe080 0x1cf747b62e20 1 0 0x1cf747b62e38 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163238.996299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:13_https://tech.ifeng.com/, 304a3131c1c8, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163238.996428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.549872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.550030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163239.550680:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.550893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.551051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.551681:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.589935:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.590139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163239.590694:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.590889:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.591036:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.591492:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.592741:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.592879:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163239.593394:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.593571:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.593703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.594129:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.606928:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.607156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163239.607846:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.608067:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.608247:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.608899:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.610142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.610315:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163239.610957:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.611148:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.611341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.611919:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.617643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.617802:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163239.618382:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.618560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.618722:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.619242:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.619943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, getBoundingClientRect, 
[1:1:0712/163239.620115:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163239.620644:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.620873:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, floor, 
[1:1:0712/163239.621106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.621680:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.623011:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, getComputedStyle, 
[1:1:0712/163239.623231:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163239.623817:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.624136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163239.624333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.624892:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.625534:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, getComputedStyle, 
[1:1:0712/163239.625718:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163239.626296:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.626564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, parseInt, 
[1:1:0712/163239.626760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.627293:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.631461:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.631676:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163239.632288:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.632505:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.632763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.633416:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.638095:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.638455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 22, , , 0
[1:1:0712/163239.639256:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.639725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.640038:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 23, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.640770:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.642645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.642886:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 24, , , 0
[1:1:0712/163239.643585:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.643769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.643996:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 25, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.644572:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.651608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.651840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 26, , , 0
[1:1:0712/163239.652506:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.652677:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.652922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 27, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.653534:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.667348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.667678:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 28, , , 0
[1:1:0712/163239.668477:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.668710:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.668990:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 29, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.669849:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.671743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.672085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 30, , , 0
[1:1:0712/163239.672903:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.673164:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.673493:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 31, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.674244:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.676054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.676338:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 32, , , 0
[1:1:0712/163239.676986:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.677213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.677470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 33, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.678055:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.679702:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163239.679974:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 34, , , 0
[1:1:0712/163239.680591:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.680765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163239.681024:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 35, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.681635:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163239.725485:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1553, 7f58132b8881
[1:1:0712/163239.751663:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a3137b670","ptid":"1432","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163239.751828:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:8_https://tech.ifeng.com/","ptid":"1432","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163239.752019:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163239.752286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://tech.ifeng.com/, 304a3137b670, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/163239.752406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163239.834665:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1603 0x7f5826ffe080 0x1cf7481607e0 1 0 0x1cf7481607f8 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163239.836556:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:14_https://tech.ifeng.com/, 304a312e7b08, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163239.836717:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.369564:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.369806:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163240.370573:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.370826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.370987:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.371682:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.411864:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.412045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163240.412557:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.412731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.412858:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.413455:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.414660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.414795:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163240.415278:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.415458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.415624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.416051:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.428263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.428476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163240.429172:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.429374:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.429559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.430164:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.431204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.431359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163240.431930:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.432106:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.432267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.432808:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.439123:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.439460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163240.441264:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.441504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.441712:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.442324:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.443131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, getBoundingClientRect, 
[1:1:0712/163240.443301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163240.443839:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.444097:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, floor, 
[1:1:0712/163240.444270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.444812:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.446014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, getComputedStyle, 
[1:1:0712/163240.446193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163240.446771:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.447109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163240.447304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.447836:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.448439:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, getComputedStyle, 
[1:1:0712/163240.448619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163240.449220:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.449497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, parseInt, 
[1:1:0712/163240.449709:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.450255:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.454378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.454577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163240.455247:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.455475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.455759:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.456297:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.460725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 22, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.460989:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 22, , , 0
[1:1:0712/163240.461698:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.461913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 23, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.462216:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 23, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.462822:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.464422:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 24, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.464627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 24, , , 0
[1:1:0712/163240.465356:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.465538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 25, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.465788:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 25, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.466379:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWin (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.474569:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 26, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.474893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 26, , , 0
[1:1:0712/163240.475702:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.475902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 27, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.476204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 27, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.476886:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.490996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 28, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.491435:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 28, , , 0
[1:1:0712/163240.492430:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.492678:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 29, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.493021:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 29, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.493832:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.495870:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 30, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.496218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 30, , , 0
[1:1:0712/163240.496924:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.497167:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 31, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.497453:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 31, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.498085:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.499771:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 32, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.500014:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 32, , , 0
[1:1:0712/163240.500617:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.500794:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 33, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.501111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 33, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.501696:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.503295:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 34, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163240.503541:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 34, , , 0
[1:1:0712/163240.504149:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.504312:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 35, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163240.504582:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 35, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163240.505206:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getValue (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getSearchParams (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://dup.baidustatic.com/js/os.js:1:1

[1:1:0712/163240.788805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1548, 7f58132b88db
[1:1:0712/163240.816865:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1394 0x7f5810973070 0x1cf740735f60 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163240.817050:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1394 0x7f5810973070 0x1cf740735f60 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163240.817299:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1707
[1:1:0712/163240.817405:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1707 0x7f5810973070 0x1cf748aeb7e0 , 5:3_https://tech.ifeng.com/, 0, , 1548 0x7f5810973070 0x1cf7489c0460 
[1:1:0712/163240.817595:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163240.817865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163240.817964:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163241.246682:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1627, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163241.247694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/163241.247867:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[20494:20494:0712/163241.388067:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:15_https://s2.yylady.cn/, https://s2.yylady.cn/, 15
[20494:20494:0712/163241.388142:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 15, 15, https://s2.yylady.cn/, https://s2.yylady.cn
[1:1:0712/163241.389112:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163241.453972:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1633 0x7f581289b2e0 0x1cf743b6e960 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163241.455055:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , !function(e){var t={};function n(i){if(t[i])return t[i].exports;var o=t[i]={i:i,l:!1,exports:{}};ret
[1:1:0712/163241.455214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163241.460825:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163241.470347:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 7000, 0x2374b5f029c8, 0x1cf73f056210
[1:1:0712/163241.470513:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 7000
[1:1:0712/163241.470702:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1728
[1:1:0712/163241.470815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1728 0x7f5810973070 0x1cf749ea4460 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 1633 0x7f581289b2e0 0x1cf743b6e960 
[1:1:0712/163241.651770:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163241.652241:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , t.onload.t.onerror, (){this.onload=t.onerror=null,document.body.removeChild(this)}
[1:1:0712/163241.652380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163241.770109:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163241.770376:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[20494:20494:0712/163242.494792:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:16_https://p3.ifengimg.com/, https://p3.ifengimg.com/, 16
[20494:20494:0712/163242.494864:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 16, 16, https://p3.ifengimg.com/, https://p3.ifengimg.com
[1:1:0712/163242.494906:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/163242.638727:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1677, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163242.639573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://tech.ifeng.com/, 304a31308cc8, , , ___adblockplus({"queryid" : "ce5734f49492011e","tuid" : "5925766_0","placement" : {"basic" : {"sspId
[1:1:0712/163242.639737:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163242.650247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b601da88, 0x1cf73f0561a0
[1:1:0712/163242.650431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163242.650627:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1764
[1:1:0712/163242.650751:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1764 0x7f5810973070 0x1cf747ae35e0 , 5:3_https://tech.ifeng.com/, 1, -5:11_https://tech.ifeng.com/, 1677
[1:1:0712/163242.652986:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163242.653180:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163242.653848:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/mcdm?psi=c4ae07ea2b448c433a62d8d58d0ac248&di=5925766&dri=0&dis=1&dai=0&ps=746x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920357&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920358&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163242.654578:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163242.654739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163242.655640:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/mcdm?psi=c4ae07ea2b448c433a62d8d58d0ac248&di=5925766&dri=0&dis=1&dai=0&ps=746x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920357&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920358&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163242.657369:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163242.657561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163242.658288:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/mcdm?psi=c4ae07ea2b448c433a62d8d58d0ac248&di=5925766&dri=0&dis=1&dai=0&ps=746x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920357&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920358&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163242.658593:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163242.658786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163242.659443:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/mcdm?psi=c4ae07ea2b448c433a62d8d58d0ac248&di=5925766&dri=0&dis=1&dai=0&ps=746x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920357&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920358&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163242.662183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31308cc8, toString, 
[1:1:0712/163242.662378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163242.663177:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/mcdm?psi=c4ae07ea2b448c433a62d8d58d0ac248&di=5925766&dri=0&dis=1&dai=0&ps=746x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920357&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920358&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163242.663447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:11_https://tech.ifeng.com/, 304a31308cc8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163242.663658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163242.664392:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/mcdm?psi=c4ae07ea2b448c433a62d8d58d0ac248&di=5925766&dri=0&dis=1&dai=0&ps=746x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920357&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920358&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.090242:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1690, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163243.091115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:12_https://tech.ifeng.com/, 304a31311d58, , , ___adblockplus({"queryid" : "78a7e413568a49d3","tuid" : "5925767_0","placement" : {"basic" : {"sspId
[1:1:0712/163243.091275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.102015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b5fe2c80, 0x1cf73f0561a0
[1:1:0712/163243.102210:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163243.102464:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1776
[1:1:0712/163243.102651:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1776 0x7f5810973070 0x1cf74a5c7860 , 5:3_https://tech.ifeng.com/, 1, -5:12_https://tech.ifeng.com/, 1690
[1:1:0712/163243.104857:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163243.105111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163243.106050:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/kcwm?psi=f926f4d5460ecfe83287c9d832867853&di=5925767&dri=0&dis=1&dai=0&ps=1268x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920358&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920359&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.106645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.106852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.107495:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/kcwm?psi=f926f4d5460ecfe83287c9d832867853&di=5925767&dri=0&dis=1&dai=0&ps=1268x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920358&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920359&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.109057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163243.109239:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163243.109952:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/kcwm?psi=f926f4d5460ecfe83287c9d832867853&di=5925767&dri=0&dis=1&dai=0&ps=1268x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920358&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920359&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.110200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.110371:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.112894:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/kcwm?psi=f926f4d5460ecfe83287c9d832867853&di=5925767&dri=0&dis=1&dai=0&ps=1268x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920358&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920359&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.115572:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a31311d58, toString, 
[1:1:0712/163243.115771:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163243.116570:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/kcwm?psi=f926f4d5460ecfe83287c9d832867853&di=5925767&dri=0&dis=1&dai=0&ps=1268x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920358&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920359&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.116825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:12_https://tech.ifeng.com/, 304a31311d58, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.117011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.117771:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/kcwm?psi=f926f4d5460ecfe83287c9d832867853&di=5925767&dri=0&dis=1&dai=0&ps=1268x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920358&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920359&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.341157:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1697, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163243.342080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:13_https://tech.ifeng.com/, 304a3131c1c8, , , ___adblockplus({"queryid" : "f4f0d885241a0e45","tuid" : "5925769_0","placement" : {"basic" : {"sspId
[1:1:0712/163243.342235:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.353278:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b5fe54b8, 0x1cf73f0561a0
[1:1:0712/163243.353446:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163243.353659:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1787
[1:1:0712/163243.354189:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1787 0x7f5810973070 0x1cf74a54e6e0 , 5:3_https://tech.ifeng.com/, 1, -5:13_https://tech.ifeng.com/, 1697
[1:1:0712/163243.356652:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163243.357120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163243.357892:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/icsm?psi=0f18c9ee1b39e8604c409ec3581f1e85&di=5925769&dri=0&dis=1&dai=0&ps=2146x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920359&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.358212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.358382:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.359041:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/icsm?psi=0f18c9ee1b39e8604c409ec3581f1e85&di=5925769&dri=0&dis=1&dai=0&ps=2146x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920359&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.360838:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163243.360993:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163243.361688:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/icsm?psi=0f18c9ee1b39e8604c409ec3581f1e85&di=5925769&dri=0&dis=1&dai=0&ps=2146x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920359&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.361993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.362175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.362829:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/icsm?psi=0f18c9ee1b39e8604c409ec3581f1e85&di=5925769&dri=0&dis=1&dai=0&ps=2146x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920359&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.365614:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3131c1c8, toString, 
[1:1:0712/163243.365828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163243.366675:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/icsm?psi=0f18c9ee1b39e8604c409ec3581f1e85&di=5925769&dri=0&dis=1&dai=0&ps=2146x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920359&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.366908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:13_https://tech.ifeng.com/, 304a3131c1c8, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.367079:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.367734:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/icsm?psi=0f18c9ee1b39e8604c409ec3581f1e85&di=5925769&dri=0&dis=1&dai=0&ps=2146x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920359&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.622560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1704, "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163243.623350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:14_https://tech.ifeng.com/, 304a312e7b08, , , ___adblockplus({"queryid" : "32bf1ba1cf541770","tuid" : "5925770_0","placement" : {"basic" : {"sspId
[1:1:0712/163243.623523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.634570:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b5fe7cf0, 0x1cf73f0561a0
[1:1:0712/163243.634745:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 800
[1:1:0712/163243.634958:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1799
[1:1:0712/163243.635099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1799 0x7f5810973070 0x1cf749b9d560 , 5:3_https://tech.ifeng.com/, 1, -5:14_https://tech.ifeng.com/, 1704
[1:1:0712/163243.637336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163243.637522:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163243.638301:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/dchm?psi=7c19d20cc83e30826893fb1a4ef1dcd8&di=5925770&dri=0&dis=1&dai=0&ps=2668x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920360&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.639425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.639655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.640312:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/dchm?psi=7c19d20cc83e30826893fb1a4ef1dcd8&di=5925770&dri=0&dis=1&dai=0&ps=2668x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920360&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.641943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163243.642164:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163243.643079:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/dchm?psi=7c19d20cc83e30826893fb1a4ef1dcd8&di=5925770&dri=0&dis=1&dai=0&ps=2668x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920360&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.643409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.644629:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.645305:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/dchm?psi=7c19d20cc83e30826893fb1a4ef1dcd8&di=5925770&dri=0&dis=1&dai=0&ps=2668x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920360&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.647962:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a312e7b08, toString, 
[1:1:0712/163243.648204:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163243.648960:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/dchm?psi=7c19d20cc83e30826893fb1a4ef1dcd8&di=5925770&dri=0&dis=1&dai=0&ps=2668x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920360&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.649243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:14_https://tech.ifeng.com/, 304a312e7b08, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163243.649443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.650205:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getOneParam (https://dup.baidustatic.com/js/os.js:1:1)
	Object.addDebugSign (https://dup.baidustatic.com/js/os.js:1:1)
	Object.painterLoadedCallback (https://dup.baidustatic.com/js/os.js:1:1)
	Object.callback (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	https://pos.baidu.com/dchm?psi=7c19d20cc83e30826893fb1a4ef1dcd8&di=5925770&dri=0&dis=1&dai=0&ps=2668x700&enu=encoding&dcb=___adblockplus&dtm=SSP_JSONP&dvi=0.0&dci=-1&dpt=none&tsr=0&tpr=1562920346643&ti=%E5%AD%95%E5%A6%87%E8%83%BD%E6%8E%A5%E8%A7%A6X%E7%BA%BF%E5%90%97%EF%BC%9F%E5%85%B3%E4%BA%8E%E6%80%80%E5%AD%95%E6%9C%9F%E9%97%B4%E7%9A%84%E8%BE%90%E5%B0%84%E9%97%AE%E9%A2%98%EF%BC%8C%E8%BF%99%E9%87%8C%E6%98%AF%E7%AD%94%E6%A1%88_%E5%87%A4%E5%87%B0%E7%BD%91%E7%A7%91%E6%8A%80&ari=2&dbv=2&drs=1&pcs=887x666&pss=1000x8908&cfv=0&cpl=2&chi=2&cce=true&cec=UTF-8&tlm=1562920360&prot=2&rw=320&ltu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&liu=https%3A%2F%2Ftech.ifeng.com%2Fc%2F7o8tHReAl1E&ecd=1&uc=1855x1056&pis=300x56&sr=1920x1080&tcn=1562920360&exps=110011&lto=https%3A%2F%2Ftech.ifeng.com&ltl=1:1:1

[1:1:0712/163243.902589:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163243.903385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/163243.903552:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163243.995282:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163244.641806:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163244.642006:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163244.677122:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1740 0x7f5826ffe080 0x1cf749f21380 1 0 0x1cf749f21398 , "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html"
[1:1:0712/163244.678904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_https://www.ifeng.com/, 304a31375960, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163244.679051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html", "www.ifeng.com", 7, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.505752:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1746 0x7f5826ffe080 0x1cf740e4e740 1 0 0x1cf740e4e758 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163245.508517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:8_https://tech.ifeng.com/, 304a3137b670, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163245.508699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.819012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 2, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.819179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 2, , , 0
[1:1:0712/163245.819867:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.820091:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 3, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.820244:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 3, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.820793:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	https://dup.baidustatic.com/js/os.js:1:1
	Object.getPageSearchId (https://dup.baidustatic.com/js/os.js:1:1)
	Object.prepareApi (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.861176:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 4, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.861366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 4, , , 0
[1:1:0712/163245.862009:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.862209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 5, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.862374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 5, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.862944:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.864019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 6, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.864189:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 6, , , 0
[1:1:0712/163245.864779:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.864966:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 7, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.865202:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 7, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.865762:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.870725:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 8, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.870877:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 8, , , 0
[1:1:0712/163245.871554:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.871737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 9, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.871936:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 9, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.872607:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.873324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 10, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, getBoundingClientRect, 
[1:1:0712/163245.873520:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 10, , , 0
[1:1:0712/163245.874105:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.874391:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 11, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, floor, 
[1:1:0712/163245.874637:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 11, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.875299:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.876338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 12, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, getComputedStyle, 
[1:1:0712/163245.876560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 12, , , 0
[1:1:0712/163245.877228:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.877554:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 13, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, getStyle, (t,e){if(!t)return"";var i="";i=e.indexOf("-")>-1?e.replace(/[-][^-]{1}/g,function(t){return t.charA
[1:1:0712/163245.877763:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 13, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.878332:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.878995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 14, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, getComputedStyle, 
[1:1:0712/163245.879172:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 14, , , 0
[1:1:0712/163245.879718:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getStyle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.879994:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 15, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, parseInt, 
[1:1:0712/163245.880196:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 15, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.880756:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.getPositionCore (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getPosition (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.885206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 16, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.885496:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 16, , , 0
[1:1:0712/163245.886122:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.886404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 17, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.886710:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 17, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.887341:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.891967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 18, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.892240:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 18, , , 0
[1:1:0712/163245.892921:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.893181:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 19, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.893406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 19, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.893999:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getDocumentTitle (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.901456:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 20, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/, 304a312c2860, 304a3137b670, toString, 
[1:1:0712/163245.901663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 20, , , 0
[1:1:0712/163245.902314:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.checkParentAccess (https://dup.baidustatic.com/js/os.js:1:1)
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163245.902501:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 21, -5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/-5:3_https://tech.ifeng.com/-5:8_https://tech.ifeng.com/, 304a3137b670, 304a312c2860, isInIframe, (t,e){return t=t||window,t!=window.top&&t!=t.parent||!this.isWindow(t)}
[1:1:0712/163245.902728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 8, 21, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163245.903293:INFO:binding_security.cc(243)] >>> BindingSecurity::PrintStack. stack is 
	Object.isInCrossDomainIframe (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getNotCrossDomainTopWindow (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getTopWindowUrl (https://dup.baidustatic.com/js/os.js:1:1)
	Object.value (https://dup.baidustatic.com/js/os.js:1:1)
	Object.snap (https://dup.baidustatic.com/js/os.js:1:1)
	Object.getParamObj (https://dup.baidustatic.com/js/os.js:1:1)
	Object.requestSlotInfo (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	Object.launch (https://dup.baidustatic.com/js/os.js:1:1)
	Object.process (https://dup.baidustatic.com/js/os.js:1:1)
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1
	https://cpro.baidustatic.com/cpro/ui/c.js:1:1

[1:1:0712/163246.280150:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163246.754567:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 ()","https://wx4.sinaimg.cn/mw690/65f12779gy1fwc4dtit8ej201b00ejrc.jpg"
[1:1:0712/163246.816030:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1707, 7f58132b88db
[1:1:0712/163246.844250:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1548 0x7f5810973070 0x1cf7489c0460 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163246.844426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1548 0x7f5810973070 0x1cf7489c0460 ","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163246.844638:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://tech.ifeng.com/, 1896
[1:1:0712/163246.844742:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1896 0x7f5810973070 0x1cf7481f5f60 , 5:3_https://tech.ifeng.com/, 0, , 1707 0x7f5810973070 0x1cf748aeb7e0 
[1:1:0712/163246.844932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163246.845246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (){try{return n.apply(this,t||arguments)}catch(r){if(o(r),r.stack&&console&&console.error&&console.e
[1:1:0712/163246.845361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163247.087511:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 ()","https://wx4.sinaimg.cn/mw690/65f12779gy1fwc4dtit8ej201b00ejrc.jpg"
[20494:20506:0712/163247.106008:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[20494:20506:0712/163247.146943:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/163247.455339:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 ()","https://wx4.sinaimg.cn/mw690/65f12779gy1fwc4dtit8ej201b00ejrc.jpg"
[1:1:0712/163247.488833:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1764, 7f58132b8881
[1:1:0712/163247.517561:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a31308cc8","ptid":"1677","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163247.517740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:11_https://tech.ifeng.com/","ptid":"1677","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163247.517938:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163247.518207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:11_https://tech.ifeng.com/, 304a31308cc8, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/163247.518329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 11, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163247.822525:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 403 ()","https://wx4.sinaimg.cn/mw690/65f12779gy1fwc4dtit8ej201b00ejrc.jpg"
[1:1:0712/163247.913971:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1807 0x7f581289b2e0 0x1cf74a5173e0 , "https://www.ifeng.com/a_if/baidu/190624/spbnytl02.html"
[1:1:0712/163247.916751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:4_https://www.ifeng.com/, 304a3138fef8, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163247.916914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/baidu/190624/spbnytl02.html", "www.ifeng.com", 4, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163248.657503:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1776, 7f58132b8881
[1:1:0712/163248.686351:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a31311d58","ptid":"1690","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163248.686564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:12_https://tech.ifeng.com/","ptid":"1690","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163248.686768:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163248.687042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:12_https://tech.ifeng.com/, 304a31311d58, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/163248.687173:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 12, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163248.717154:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/163248.717306:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://s2.yylady.cn/corner/html/lx_text_640x50.html"
[1:1:0712/163248.724833:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.00743699, 63, 1
[1:1:0712/163248.724988:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/163248.848211:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163248.848617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:5_https://tech.ifeng.com/, 304a313978f8, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/163248.848753:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 5, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163248.849463:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1787, 7f58132b8881
[1:1:0712/163248.879081:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a3131c1c8","ptid":"1697","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163248.879250:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:13_https://tech.ifeng.com/","ptid":"1697","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163248.879447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163248.879716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:13_https://tech.ifeng.com/, 304a3131c1c8, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/163248.879840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 13, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163249.031582:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1825 0x7f581289b2e0 0x1cf7444b6760 , "https://www.ifeng.com/a_if/baidu/190711/qpdnytwdz.html"
[1:1:0712/163249.034364:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:6_https://www.ifeng.com/, 304a31366220, , , try{!function(){window.___baidu_union_||(window.___baidu_union_={}),window.___baidu_union_dup_||(win
[1:1:0712/163249.034526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/baidu/190711/qpdnytwdz.html", "www.ifeng.com", 6, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163249.697109:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1799, 7f58132b8881
[1:1:0712/163249.727965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"304a312e7b08","ptid":"1704","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163249.728164:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:14_https://tech.ifeng.com/","ptid":"1704","rf":"5:3_https://tech.ifeng.com/"}
[1:1:0712/163249.728419:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163249.728735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:14_https://tech.ifeng.com/, 304a312e7b08, , , (){r.expand.fire("adloaded",t.id)}
[1:1:0712/163249.728914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 14, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163249.792052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1832 0x7f581289b2e0 0x1cf74a629a60 , "https://tech.ifeng.com/c/7o8tHReAl1E"
[1:1:0712/163249.792698:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , (function(){
var json={"tplid":2,"ads":[{"img":"https://s3m.mediav.com/galileo/540325-952f0bae17ec10
[1:1:0712/163249.792817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163249.818875:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x2374b5f029c8, 0x1cf73f056190
[1:1:0712/163249.819025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://tech.ifeng.com/c/7o8tHReAl1E", 0
[1:1:0712/163249.819194:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://tech.ifeng.com/, 1944
[1:1:0712/163249.819300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1944 0x7f5810973070 0x1cf74b4c0ee0 , 5:3_https://tech.ifeng.com/, 1, -5:3_https://tech.ifeng.com/, 1832 0x7f581289b2e0 0x1cf74a629a60 
[1:1:0712/163250.002373:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://tech.ifeng.com/, 304a312c2860, , , document.readyState
[1:1:0712/163250.002537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://tech.ifeng.com/c/7o8tHReAl1E", "tech.ifeng.com", 3, 1, , , 0
[1:1:0712/163250.521450:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1852, "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html"
[1:1:0712/163250.522328:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:7_https://www.ifeng.com/, 304a31375960, , , ___adblockplus({"queryid" : "43c8f3216ced967f","tuid" : "5989276_0","placement" : {"basic" : {"sspId
[1:1:0712/163250.522509:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html", "www.ifeng.com", 7, 1, https://tech.ifeng.com, tech.ifeng.com, 3
[1:1:0712/163250.530656:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1852, "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html"
[1:1:0712/163250.533800:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 800, 0x2374b601ac10, 0x1cf73f0561a0
[1:1:0712/163250.533948:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html", 800
[1:1:0712/163250.534175:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:7_https://www.ifeng.com/, 1960
[1:1:0712/163250.534314:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1960 0x7f5810973070 0x1cf74aba74e0 , 5:7_https://www.ifeng.com/, 1, -5:7_https://www.ifeng.com/, 1852
[1:1:0712/163250.551438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1852, "https://www.ifeng.com/a_if/shangjie/181130/qpdnyjx01.html"
