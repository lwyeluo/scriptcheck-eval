[0712/123430.121637:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/123430.121889:INFO:switcher_clone.cc(787)] backtrace rip is 7f0e89887891
[0712/123430.664008:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/123430.664272:INFO:switcher_clone.cc(787)] backtrace rip is 7f2b60681891
[1:1:0712/123430.668090:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/123430.668251:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/123430.671053:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[16209:16209:0712/123431.387041:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/76b7cba7-9af6-4c8d-834c-0262de419d7c
[0712/123431.495270:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/123431.495531:INFO:switcher_clone.cc(787)] backtrace rip is 7fe26d1d4891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[16209:16209:0712/123431.636202:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[16209:16239:0712/123431.636570:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/123431.636695:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/123431.636849:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/123431.637159:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/123431.637272:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/123431.639001:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x33672aa8, 1
[1:1:0712/123431.639225:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x133b5e37, 0
[1:1:0712/123431.639320:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x172ffd95, 3
[1:1:0712/123431.639410:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1fd4f128, 2
[1:1:0712/123431.639505:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 375e3b13 ffffffa82a6733 28fffffff1ffffffd41f ffffff95fffffffd2f17 , 10104, 4
[16241:16241:0712/123431.639884:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16241
[1:1:0712/123431.640193:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16209:16239:0712/123431.640331:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING7^;�*g3(����/6ч&
[16209:16239:0712/123431.640370:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 7^;�*g3(����/�H6ч&
[16209:16239:0712/123431.640524:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[16209:16239:0712/123431.640559:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16255, 4, 375e3b13 a82a6733 28f1d41f 95fd2f17 
[16256:16256:0712/123431.640591:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=16256
[1:1:0712/123431.640804:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2b5e8bb0a0, 3
[1:1:0712/123431.640913:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2b5ea47080, 2
[1:1:0712/123431.640995:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2b48709d20, -2
[1:1:0712/123431.648788:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/123431.649242:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1fd4f128
[1:1:0712/123431.649706:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1fd4f128
[1:1:0712/123431.650484:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1fd4f128
[1:1:0712/123431.651034:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.651129:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.651219:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.651307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.651549:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1fd4f128
[1:1:0712/123431.651728:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2b606817ba
[1:1:0712/123431.651788:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2b60678def, 7f2b6068177a, 7f2b606830cf
[1:1:0712/123431.653507:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1fd4f128
[1:1:0712/123431.653685:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1fd4f128
[1:1:0712/123431.653992:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1fd4f128
[1:1:0712/123431.654783:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.654884:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.654980:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.655073:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1fd4f128
[1:1:0712/123431.655569:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1fd4f128
[1:1:0712/123431.655734:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2b606817ba
[1:1:0712/123431.655805:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2b60678def, 7f2b6068177a, 7f2b606830cf
[1:1:0712/123431.658506:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/123431.658723:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/123431.658835:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffb9931e08, 0x7fffb9931d88)
[1:1:0712/123431.666747:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/123431.669431:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[16209:16209:0712/123432.045559:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16209:16209:0712/123432.046051:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16209:16221:0712/123432.054408:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[16209:16221:0712/123432.054476:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[16209:16209:0712/123432.054502:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[16209:16209:0712/123432.054545:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[16209:16209:0712/123432.054613:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,16255, 4
[1:7:0712/123432.055452:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/123432.062152:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x193dd9895220
[1:1:0712/123432.062298:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[16209:16232:0712/123432.126504:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/123432.306905:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/123433.017466:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/123433.019074:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[16209:16209:0712/123433.082007:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[16209:16209:0712/123433.082068:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/123433.440485:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/123433.504050:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21a5ca6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/123433.504227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/123433.509283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21a5ca6c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/123433.509404:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/123433.555832:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/123433.555990:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/123433.694063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/123433.696521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21a5ca6c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/123433.696659:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/123433.708781:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/123433.711731:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21a5ca6c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/123433.711868:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/123433.715650:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[16209:16209:0712/123433.716318:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/123433.717434:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x193dd9893e20
[1:1:0712/123433.717549:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16209:16209:0712/123433.718928:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[16209:16209:0712/123433.730086:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[16209:16209:0712/123433.730178:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/123433.749363:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/123434.045951:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 420 0x7f2b4a2e42e0 0x193dd9ad7160 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/123434.046617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21a5ca6c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/123434.046739:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/123434.047275:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16209:16209:0712/123434.073354:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/123434.074453:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x193dd9894820
[1:1:0712/123434.074580:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[16209:16209:0712/123434.075806:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/123434.081375:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/123434.081568:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[16209:16209:0712/123434.086598:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[16209:16209:0712/123434.091047:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[16209:16209:0712/123434.091522:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[16209:16221:0712/123434.096209:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[16209:16221:0712/123434.096275:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[16209:16209:0712/123434.096297:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[16209:16209:0712/123434.096345:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[16209:16209:0712/123434.096407:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,16255, 4
[1:7:0712/123434.098820:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/123434.364887:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/123434.535728:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f2b4a2e42e0 0x193dd9c285e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/123434.536323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 21a5ca6c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/123434.536485:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/123434.536800:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[16209:16209:0712/123434.625689:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[16209:16209:0712/123434.625763:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/123434.635246:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123434.765731:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/123434.967797:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/123434.967953:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[16209:16209:0712/123434.995232:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[16209:16239:0712/123434.995487:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/123434.995610:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/123434.995736:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/123434.995914:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/123434.995989:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/123434.998282:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x3dcf946b, 1
[1:1:0712/123434.998502:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x223cf8b8, 0
[1:1:0712/123434.998614:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3490675d, 3
[1:1:0712/123434.998774:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x706feef, 2
[1:1:0712/123434.998920:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffb8fffffff83c22 6bffffff94ffffffcf3d ffffffeffffffffe0607 5d67ffffff9034 , 10104, 5
[1:1:0712/123434.999674:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[16209:16239:0712/123434.999878:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING��<"k��=��]g�4Xԇ&
[16209:16239:0712/123434.999924:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ��<"k��=��]g�4lXԇ&
[1:1:0712/123434.999872:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2b5e8bb0a0, 3
[16209:16239:0712/123435.000063:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 16305, 5, b8f83c22 6b94cf3d effe0607 5d679034 
[1:1:0712/123435.000234:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2b5ea47080, 2
[1:1:0712/123435.000335:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2b48709d20, -2
[1:1:0712/123435.009272:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/123435.009458:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 706feef
[1:1:0712/123435.009608:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 706feef
[1:1:0712/123435.009861:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 706feef
[1:1:0712/123435.010358:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.010455:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.010551:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.010640:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.010888:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 706feef
[1:1:0712/123435.011014:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2b606817ba
[1:1:0712/123435.011087:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2b60678def, 7f2b6068177a, 7f2b606830cf
[1:1:0712/123435.012780:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 706feef
[1:1:0712/123435.012972:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 706feef
[1:1:0712/123435.013265:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 706feef
[1:1:0712/123435.014058:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.014231:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.014383:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.014518:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 706feef
[1:1:0712/123435.015010:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 706feef
[1:1:0712/123435.015179:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2b606817ba
[1:1:0712/123435.015260:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2b60678def, 7f2b6068177a, 7f2b606830cf
[1:1:0712/123435.017850:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/123435.018105:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/123435.018213:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7fffb9931e08, 0x7fffb9931d88)
[1:1:0712/123435.024676:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/123435.026809:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/123435.123664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 536, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/123435.125438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 21a5ca7ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/123435.125617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/123435.128042:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/123435.133991:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x193dd985c220
[1:1:0712/123435.134163:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[16209:16221:0712/123435.494781:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[16209:16221:0712/123435.495223:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[16209:16221:0712/123435.766649:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[16209:16209:0712/123435.851654:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_null/, , 1
[16209:16209:0712/123435.851779:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, , null
[1:1:0712/123435.863596:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.863892:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864072:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864226:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864380:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864530:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864662:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864792:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.864942:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865136:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865281:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865422:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865557:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865682:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865805:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.865927:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866092:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866225:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866347:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866469:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866609:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866734:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.866876:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867004:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867140:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867266:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867387:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867517:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867665:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867788:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.867919:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868043:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868180:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868319:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868444:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868565:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868689:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868824:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.868983:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.869129:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.869268:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.869400:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/123435.926141:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/123435.961078:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/123436.157444:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/123436.157603:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/123436.175214:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f2b483bc070 0x193dd9933360 , "chrome-error://chromewebdata/"
[1:1:0712/123436.176650:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f2b483bc070 0x193dd9933360 , "chrome-error://chromewebdata/"
[1:1:0712/123436.178165:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f2b483bc070 0x193dd9933360 , "chrome-error://chromewebdata/"
[1:1:0712/123436.182224:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f2b483bc070 0x193dd9933360 , "chrome-error://chromewebdata/"
[1:1:0712/123436.201669:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0440512, 81, 1
[1:1:0712/123436.201836:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[3:3:0712/123436.243660:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/123436.557149:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/123436.557332:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-error://chromewebdata/"
[1:1:0712/123436.558289:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f2b483bc070 0x193dd9908c60 , "chrome-error://chromewebdata/"
[1:1:0712/123436.560955:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f2b483bc070 0x193dd9908c60 , "chrome-error://chromewebdata/"
[1:1:0712/123436.563006:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f2b483bc070 0x193dd9908c60 , "chrome-error://chromewebdata/"
[1:1:0712/123436.575119:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f2b483bc070 0x193dd9908c60 , "chrome-error://chromewebdata/"
[1:1:0712/123436.577486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f2b483bc070 0x193dd9908c60 , "chrome-error://chromewebdata/"
[1:1:0712/123436.626841:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/123436.629148:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-error://chromewebdata/"
[1:1:0712/123436.775677:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/123436.784308:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/123436.795334:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "loadstart", "chrome-error://chromewebdata/"
[1:1:0712/123436.799493:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "chrome-error://chromewebdata/"
[1:1:0712/123436.813220:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/123436.813368:INFO:render_frame_impl.cc(7019)] 	 [url] = null
[16209:16209:0712/123436.813934:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 0:0_switcher://chrome
[16209:16221:0712/123436.912417:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[16209:16221:0712/123437.248739:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
