[0712/193520.405560:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/193520.405816:INFO:switcher_clone.cc(787)] backtrace rip is 7f6bd85ad891
[0712/193520.950904:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/193520.951152:INFO:switcher_clone.cc(787)] backtrace rip is 7f2de44b6891
[1:1:0712/193520.955022:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/193520.955194:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/193520.957897:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[18442:18442:0712/193521.770787:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/193521.806502:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/193521.806814:INFO:switcher_clone.cc(787)] backtrace rip is 7f6721d2e891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/75756907-5635-4d94-9d47-4640449b62ed
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[18475:18475:0712/193521.957111:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18475
[18488:18488:0712/193521.957404:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18488
[18442:18442:0712/193522.026937:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[18442:18473:0712/193522.027375:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/193522.027525:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/193522.027723:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/193522.028046:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/193522.028205:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/193522.029993:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xc3c39af, 1
[1:1:0712/193522.030218:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2089282a, 0
[1:1:0712/193522.030349:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x15697f15, 3
[1:1:0712/193522.030471:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x124c3e0, 2
[1:1:0712/193522.030619:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 2a28ffffff8920 ffffffaf393c0c ffffffe0ffffffc32401 157f6915 , 10104, 4
[1:1:0712/193522.031300:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18442:18473:0712/193522.031436:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING*(� �9<��$i��/
[18442:18473:0712/193522.031487:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is *(� �9<��$ih��/
[1:1:0712/193522.031428:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2de26f00a0, 3
[1:1:0712/193522.031530:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2de287c080, 2
[18442:18473:0712/193522.031679:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/193522.031637:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2dcc53ed20, -2
[18442:18473:0712/193522.031717:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18496, 4, 2a288920 af393c0c e0c32401 157f6915 
[1:1:0712/193522.039046:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/193522.039480:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 124c3e0
[1:1:0712/193522.039934:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 124c3e0
[1:1:0712/193522.040671:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 124c3e0
[1:1:0712/193522.041345:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.041493:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.041656:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.041816:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.042135:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 124c3e0
[1:1:0712/193522.042331:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2de44b67ba
[1:1:0712/193522.042457:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2de44addef, 7f2de44b677a, 7f2de44b80cf
[1:1:0712/193522.044355:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 124c3e0
[1:1:0712/193522.044629:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 124c3e0
[1:1:0712/193522.044943:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 124c3e0
[1:1:0712/193522.045847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.046347:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.046472:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.046586:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 124c3e0
[1:1:0712/193522.047144:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 124c3e0
[1:1:0712/193522.047328:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2de44b67ba
[1:1:0712/193522.047383:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2de44addef, 7f2de44b677a, 7f2de44b80cf
[1:1:0712/193522.050309:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/193522.050536:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/193522.050636:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeb2767b58, 0x7ffeb2767ad8)
[1:1:0712/193522.057375:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/193522.060044:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[18442:18442:0712/193522.470506:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18442:18442:0712/193522.471041:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18442:18454:0712/193522.478922:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[18442:18454:0712/193522.478986:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[18442:18442:0712/193522.479002:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[18442:18442:0712/193522.479051:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[18442:18442:0712/193522.479118:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,18496, 4
[1:7:0712/193522.481061:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/193522.513362:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x354c626dd220
[1:1:0712/193522.513510:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[18442:18467:0712/193522.541059:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/193522.722504:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/193523.487652:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193523.489192:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18442:18442:0712/193523.637251:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[18442:18442:0712/193523.637326:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/193523.957044:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193524.044040:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/193524.044229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193524.049304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/193524.049459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193524.083044:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193524.083186:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193524.236257:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193524.238765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/193524.238898:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193524.250778:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193524.253729:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/193524.253853:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193524.257643:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18442:18442:0712/193524.258252:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/193524.259331:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x354c626dbe20
[1:1:0712/193524.260154:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18442:18442:0712/193524.260585:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[18442:18442:0712/193524.272753:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[18442:18442:0712/193524.272831:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/193524.292358:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193524.582802:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 417 0x7f2dce1192e0 0x354c629863e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193524.583465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/193524.583616:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193524.584180:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18442:18442:0712/193524.608839:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/193524.610013:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x354c626dc820
[1:1:0712/193524.610178:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18442:18442:0712/193524.611454:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/193524.617113:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/193524.617276:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[18442:18442:0712/193524.618151:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[18442:18442:0712/193524.622056:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18442:18442:0712/193524.622440:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18442:18454:0712/193524.626940:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[18442:18454:0712/193524.626993:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[18442:18442:0712/193524.627013:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[18442:18442:0712/193524.627050:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[18442:18442:0712/193524.627108:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,18496, 4
[1:7:0712/193524.628465:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/193524.887043:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/193525.081264:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f2dce1192e0 0x354c62a8a560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193525.081853:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/193525.082007:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193525.082378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18442:18442:0712/193525.164865:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[18442:18442:0712/193525.164938:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/193525.176486:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/193525.340795:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[18442:18442:0712/193525.413941:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[18442:18473:0712/193525.414204:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/193525.414328:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/193525.414490:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/193525.414684:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/193525.414760:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/193525.416876:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x114a3bca, 1
[1:1:0712/193525.417105:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x383da859, 0
[1:1:0712/193525.417198:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x12f3499a, 3
[1:1:0712/193525.417282:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1a741faa, 2
[1:1:0712/193525.417360:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 59ffffffa83d38 ffffffca3b4a11 ffffffaa1f741a ffffff9a49fffffff312 , 10104, 5
[1:1:0712/193525.418046:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18442:18473:0712/193525.418271:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGY�=8�;J�t�I���/
[18442:18473:0712/193525.418321:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Y�=8�;J�t�I����/
[1:1:0712/193525.418265:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2de26f00a0, 3
[18442:18473:0712/193525.418478:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18538, 5, 59a83d38 ca3b4a11 aa1f741a 9a49f312 
[1:1:0712/193525.418458:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2de287c080, 2
[1:1:0712/193525.418781:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2dcc53ed20, -2
[1:1:0712/193525.428126:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/193525.428327:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1a741faa
[1:1:0712/193525.428486:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1a741faa
[1:1:0712/193525.428741:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1a741faa
[1:1:0712/193525.429307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.429407:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.429501:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.429591:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.429845:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1a741faa
[1:1:0712/193525.429974:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2de44b67ba
[1:1:0712/193525.430055:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2de44addef, 7f2de44b677a, 7f2de44b80cf
[1:1:0712/193525.431892:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1a741faa
[1:1:0712/193525.432077:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1a741faa
[1:1:0712/193525.432418:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1a741faa
[1:1:0712/193525.433269:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.433446:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.433612:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.433734:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1a741faa
[1:1:0712/193525.434250:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1a741faa
[1:1:0712/193525.434426:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2de44b67ba
[1:1:0712/193525.434508:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2de44addef, 7f2de44b677a, 7f2de44b80cf
[1:1:0712/193525.437272:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/193525.437501:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/193525.437624:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffeb2767b58, 0x7ffeb2767ad8)
[1:1:0712/193525.443734:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/193525.445702:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/193525.532128:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x354c626af220
[1:1:0712/193525.532284:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/193525.554290:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193525.554444:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193525.757396:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 537, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193525.759287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 08071252e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/193525.759491:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193525.762034:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193525.820918:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193525.821404:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 080712401f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/193525.821536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[18442:18442:0712/193525.903056:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18442:18442:0712/193525.906573:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/193525.907374:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193525.908143:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/193525.908267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 08071252e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/193525.908410:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[18442:18454:0712/193525.925484:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[18442:18454:0712/193525.925548:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[18442:18442:0712/193525.926318:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://zhaopin.58.com/
[18442:18442:0712/193525.926370:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://zhaopin.58.com/, https://zhaopin.58.com/?from=10178#/?_q, 1
[18442:18442:0712/193525.926438:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://zhaopin.58.com/, HTTP/1.1 200 status:200 server:nginx date:Fri, 12 Jul 2019 11:35:25 GMT content-type:text/html;charset=UTF-8 set-cookie:from=10178; Path=/ x-host:orderonline content-encoding:gzip vary:Accept-Encoding  ,18538, 5
[1:7:0712/193525.930372:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/193525.943647:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://zhaopin.58.com/
[1:1:0712/193525.973531:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193525.973961:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/193525.997234:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 08071252e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/193525.997636:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193526.015906:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18442:18442:0712/193526.026912:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://zhaopin.58.com/, https://zhaopin.58.com/, 1
[18442:18442:0712/193526.026974:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://zhaopin.58.com/, https://zhaopin.58.com
[1:1:0712/193526.048654:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193526.079242:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193526.079426:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193526.287967:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193526.350609:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 168 0x7f2dcc559bd0 0x354c627688d8 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193526.356757:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , /*!
 * jQuery JavaScript Library v1.12.4
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://si
[1:1:0712/193526.356946:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193526.369355:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193526.381743:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
		remove user.d_7dfac502 -> 0
[1:1:0712/193526.521658:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175, "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193526.522709:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , /*!
 * jQuery-ajaxTransport-XDomainRequest - v1.0.4 - 2015-03-05
 * https://github.com/MoonScript/jQ
[1:1:0712/193526.522870:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193526.526391:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 175, "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193526.552462:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.taobao.com/"
[1:1:0712/193526.580816:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/193526.624903:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/193526.666613:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/193530.690805:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[18442:18454:0712/193537.985510:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -100
[18442:18454:0712/193538.019660:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[3:3:0712/193539.913676:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/193540.085704:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10000, 0x11e0c48a29c8, 0x354c625393d8
[1:1:0712/193540.085916:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 10000
[1:1:0712/193540.086173:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 210
[1:1:0712/193540.086337:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 210 0x7f2dcc1f1070 0x354c6277da60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 175
[1:1:0712/193540.097918:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.5744, 0, 0
[1:1:0712/193540.098442:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193540.176385:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/193540.176604:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193540.252465:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193540.252633:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193540.253262:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7f2dcc1f1070 0x354c62bce2e0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193540.253883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , // pc&m适配
    var url  = '';
    if(window.location.href.indexOf("resourcesDetail") != -1 ||$("l
[1:1:0712/193540.253982:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193540.260060:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7f2dcc1f1070 0x354c62bce2e0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193540.464141:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f2dcc1f1070 0x354c62a61ae0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193540.465242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , !function(e){function n(r){if(t[r])return t[r].exports;var a=t[r]={i:r,l:!1,exports:{}};return e[r].
[1:1:0712/193540.465381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193540.470596:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f2dcc1f1070 0x354c62a61ae0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193540.521038:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 242 0x7f2dcc1f1070 0x354c62a61ae0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193540.589612:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x11e0c48a29c8, 0x354c625394f8
[1:1:0712/193540.589784:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 0
[1:1:0712/193540.589991:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 259
[1:1:0712/193540.590115:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 259 0x7f2dcc1f1070 0x354c62a74fe0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 242 0x7f2dcc1f1070 0x354c62a61ae0 
[1:1:0712/193540.955489:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 120000, 0x11e0c48a29c8, 0x354c625394f8
[1:1:0712/193540.955673:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 120000
[1:1:0712/193540.955936:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 260
[1:1:0712/193540.956055:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 260 0x7f2dcc1f1070 0x354c62a653e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 242 0x7f2dcc1f1070 0x354c62a61ae0 
[1:1:0712/193541.042600:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.576347, 0, 0
[1:1:0712/193541.042797:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193541.068333:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 248 0x7f2dce1192e0 0x354c629f83e0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.071194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (function(){var h={},mt={},c={id:"a99d45a8c951f35a2762925f999040a5",dm:["zhaopin.58.com"],js:"tongji
[1:1:0712/193541.071306:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.082614:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539148
[1:1:0712/193541.082783:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193541.082995:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 272
[1:1:0712/193541.083119:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 272 0x7f2dcc1f1070 0x354c628f38e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 248 0x7f2dce1192e0 0x354c629f83e0 
[1:1:0712/193541.209278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193541.209469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.221203:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.222317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , n, (n){n.source===t&&"string"==typeof n.data&&0===n.data.indexOf(e)&&a(+n.data.slice(e.length))}
[1:1:0712/193541.222488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.253275:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193541.253534:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.255162:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 264 0x7f2dcc1f1070 0x354c627c89e0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.256045:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , var dynamicLoading = {
  css: function(path){
 if(!path || path.length === 0){
  throw new Error('ar
[1:1:0712/193541.256193:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.264111:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 500, 0x11e0c48a29c8, 0x354c625391c8
[1:1:0712/193541.264314:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 500
[1:1:0712/193541.264532:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 312
[1:1:0712/193541.264659:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 312 0x7f2dcc1f1070 0x354c62763de0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 264 0x7f2dcc1f1070 0x354c627c89e0 
[1:1:0712/193541.266794:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.303146:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.308559:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 259, 7f2dceb36881
[1:1:0712/193541.314518:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"242 0x7f2dcc1f1070 0x354c62a61ae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193541.314740:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"242 0x7f2dcc1f1070 0x354c62a61ae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193541.314995:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.315301:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (){Ui.devtools&&ia&&ia.emit("init",ze)}
[1:1:0712/193541.315419:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.472367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 272, 7f2dceb36881
[1:1:0712/193541.478387:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"248 0x7f2dce1192e0 0x354c629f83e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193541.478589:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"248 0x7f2dce1192e0 0x354c629f83e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193541.478803:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.479098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193541.479207:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.479565:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193541.479651:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193541.479854:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 328
[1:1:0712/193541.479951:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 328 0x7f2dcc1f1070 0x354c630981e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 272 0x7f2dcc1f1070 0x354c628f38e0 
[1:1:0712/193541.556321:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193541.556473:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.705076:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.705508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0712/193541.705626:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.745819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193541.745971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.776169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 328, 7f2dceb36881
[1:1:0712/193541.781157:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"272 0x7f2dcc1f1070 0x354c628f38e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193541.781282:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"272 0x7f2dcc1f1070 0x354c628f38e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193541.781453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.781717:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193541.781812:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193541.782117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193541.782223:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193541.782408:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 361
[1:1:0712/193541.782536:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 361 0x7f2dcc1f1070 0x354c62a7cce0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 328 0x7f2dcc1f1070 0x354c630981e0 
[1:1:0712/193541.790847:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 341 0x7f2dce1192e0 0x354c62a77de0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193541.792877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , webpackJsonp([0],{311:function(t,e){t.exports="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAA
[1:1:0712/193541.793099:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.037107:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 200, 0x11e0c48a29c8, 0x354c62539140
[1:1:0712/193544.037329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 200
[1:1:0712/193544.037594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 369
[1:1:0712/193544.037761:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 369 0x7f2dcc1f1070 0x354c649f2a60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 341 0x7f2dce1192e0 0x354c62a77de0 
[18442:18442:0712/193544.044107:INFO:CONSOLE(1)] "", source: https://j1.58cdn.com.cn/crop/baseteam/other/zhaopinbusiness/js/0.56c71c6f14b50ca0dbd0.js (1)
[1:1:0712/193544.435353:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.470438:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 342 0x7f2dce1192e0 0x354c630587e0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.471471:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , !function(e){function n(r){if(t[r])return t[r].exports;var o=t[r]={i:r,l:!1,exports:{}};return e[r].
[1:1:0712/193544.471862:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.620470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193544.620735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.623174:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 312, 7f2dceb36881
[1:1:0712/193544.631173:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"264 0x7f2dcc1f1070 0x354c627c89e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193544.631396:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"264 0x7f2dcc1f1070 0x354c627c89e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193544.631937:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.632259:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (){
        dynamicLoading.js("//j1.58cdn.com.cn/crop/baseteam/other/kefusystem/js/kefuapp.js?123456
[1:1:0712/193544.632437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.902792:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.903251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0712/193544.903826:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.904467:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.905894:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.917074:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 361, 7f2dceb36881
[1:1:0712/193544.924838:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"328 0x7f2dcc1f1070 0x354c630981e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193544.925059:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"328 0x7f2dcc1f1070 0x354c630981e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193544.925630:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.927308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193544.927523:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.927885:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193544.927968:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193544.928143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 431
[1:1:0712/193544.928237:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 431 0x7f2dcc1f1070 0x354c623e9f60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 361 0x7f2dcc1f1070 0x354c62a7cce0 
[1:1:0712/193544.928856:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 369, 7f2dceb36881
[1:1:0712/193544.935530:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"341 0x7f2dce1192e0 0x354c62a77de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193544.935711:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"341 0x7f2dce1192e0 0x354c62a77de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193544.935929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.936194:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (){var t=document.createElement("script");t.src="//tracklog.58.com/referrer4.js";var e=document.getE
[1:1:0712/193544.936300:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.963194:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.963576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0712/193544.963698:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193544.964659:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193544.966586:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193545.751658:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193545.816084:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1000, 0x11e0c48a29c8, 0x354c62539210
[1:1:0712/193545.816273:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 1000
[1:1:0712/193545.816516:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 436
[1:1:0712/193545.816645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 436 0x7f2dcc1f1070 0x354c65964ae0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 406
[1:1:0712/193546.714567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193546.714794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193546.943957:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 431, 7f2dceb36881
[1:1:0712/193546.950860:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"361 0x7f2dcc1f1070 0x354c62a7cce0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193546.951027:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"361 0x7f2dcc1f1070 0x354c62a7cce0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193546.951224:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193546.951525:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193546.951624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193546.951906:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193546.951990:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193546.952151:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 466
[1:1:0712/193546.952253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 466 0x7f2dcc1f1070 0x354c623c7b60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 431 0x7f2dcc1f1070 0x354c623e9f60 
[1:1:0712/193547.008003:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193547.008400:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0712/193547.008497:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193547.008848:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193547.010405:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[18442:18442:0712/193547.020909:INFO:CONSOLE(1)] "[object Object]", source: https://j1.58cdn.com.cn/crop/baseteam/other/zhaopinbusiness/js/app_v20190619161150.js (1)
[1:1:0712/193550.680225:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193550.680450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193550.773532:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 436, 7f2dceb36881
[1:1:0712/193550.783717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"406","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193550.783943:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"406","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193550.784184:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193550.784498:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (){0==e.$route.query.initialTabIndex?(window.clickLog&&window.clickLog("from=pcsc-page-hysp"),e.$sto
[1:1:0712/193550.784611:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193550.828313:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 464 0x7f2dce1192e0 0x354c65081a60 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193550.831396:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (function(J){var c=J,h=document,p=c.location,D=c.performance;if(!c.TJ58){c.TJ58=!0;null==c.String.pr
[1:1:0712/193550.831567:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193553.616731:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 466, 7f2dceb36881
[1:1:0712/193553.629664:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"431 0x7f2dcc1f1070 0x354c623e9f60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193553.629836:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"431 0x7f2dcc1f1070 0x354c623e9f60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193553.630030:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193553.630306:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193553.630403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193553.630760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193553.630850:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193553.631021:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 794
[1:1:0712/193553.631127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 794 0x7f2dcc1f1070 0x354c69e17160 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 466 0x7f2dcc1f1070 0x354c623c7b60 
[1:1:0712/193553.631575:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 210, 7f2dceb36881
[1:1:0712/193553.643848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"175","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193553.644036:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"175","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193553.644245:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193553.644529:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , (){void 0;
m=null;a&&a()}
[1:1:0712/193553.644645:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193553.804299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193553.804465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193553.911809:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193553.912210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , d.(anonymous function), (){if(d&&(4===d.readyState||v)&&(0!==d.status||d.responseURL&&0===d.responseURL.indexOf("file:"))){v
[1:1:0712/193553.912316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193553.912537:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193553.913739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[18442:18442:0712/193553.922356:INFO:CONSOLE(1)] "[object Object]", source: https://j1.58cdn.com.cn/crop/baseteam/other/zhaopinbusiness/js/app_v20190619161150.js (1)
		remove user.f_e8c11254 -> 0
[1:1:0712/193557.300845:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193557.301319:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , i.onreadystatechange, (){}
[1:1:0712/193557.301456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193557.301819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193557.303039:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193558.153763:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 794, 7f2dceb36881
[1:1:0712/193558.166399:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"466 0x7f2dcc1f1070 0x354c623c7b60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193558.166567:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"466 0x7f2dcc1f1070 0x354c623c7b60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193558.166754:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193558.167025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193558.167123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193558.167430:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193558.167528:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193558.167732:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 818
[1:1:0712/193558.167843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 818 0x7f2dcc1f1070 0x354c6832e6e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 794 0x7f2dcc1f1070 0x354c69e17160 
[1:1:0712/193558.180925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193558.181117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193558.495623:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193558.495790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193558.529354:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 818, 7f2dceb36881
[1:1:0712/193558.546339:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"794 0x7f2dcc1f1070 0x354c69e17160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193558.546598:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"794 0x7f2dcc1f1070 0x354c69e17160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193558.546872:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193558.547224:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193558.547365:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193558.547725:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193558.547869:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193558.548095:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 834
[1:1:0712/193558.548212:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 834 0x7f2dcc1f1070 0x354c6b2644e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 818 0x7f2dcc1f1070 0x354c6832e6e0 
[1:1:0712/193558.662006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193558.662165:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193558.713120:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 835 0x7f2dce1192e0 0x354c69017de0 , "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193558.721314:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , webpackJsonp([0],{"+72Q":function(t,e){var n={utf8:{stringToBytes:function(t){return n.bin.stringToB
[1:1:0712/193558.721504:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193558.849353:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x11e0c48a29c8, 0x354c62539148
[1:1:0712/193558.849504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 0
[1:1:0712/193558.849730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 844
[1:1:0712/193558.849835:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 844 0x7f2dcc1f1070 0x354c64cccae0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 835 0x7f2dce1192e0 0x354c69017de0 
[1:1:0712/193559.077834:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x11e0c48a29c8, 0x354c62539148
[1:1:0712/193559.077988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 0
[1:1:0712/193559.078204:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 845
[1:1:0712/193559.078312:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 845 0x7f2dcc1f1070 0x354c6b3ba0e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 835 0x7f2dce1192e0 0x354c69017de0 
[1:1:0712/193559.275561:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 834, 7f2dceb36881
[1:1:0712/193559.290883:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"818 0x7f2dcc1f1070 0x354c6832e6e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.291067:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"818 0x7f2dcc1f1070 0x354c6832e6e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.291265:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.291528:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193559.291614:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.291917:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193559.292012:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193559.292234:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 854
[1:1:0712/193559.292362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 854 0x7f2dcc1f1070 0x354c6798c0e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 834 0x7f2dcc1f1070 0x354c6b2644e0 
[1:1:0712/193559.305769:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193559.305902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.321447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.321925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , elemData.handle, (e) {

                    // Discard the second event of a jQuery.event.trigger() and
             
[1:1:0712/193559.322074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.326174:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.326707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.327545:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.328255:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c625392f0
[1:1:0712/193559.328360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193559.328599:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 856
[1:1:0712/193559.328711:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 856 0x7f2dcc1f1070 0x354c65783660 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 846 0x7f2dcc1f1070 0x354c6581b7e0 
[1:1:0712/193559.349825:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 844, 7f2dceb36881
[1:1:0712/193559.364517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"835 0x7f2dce1192e0 0x354c69017de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.364702:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"835 0x7f2dce1192e0 0x354c69017de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.364902:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.365208:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , ready, (t){(!0===t?--ut.readyWait:ut.isReady)||(ut.isReady=!0,!0!==t&&--ut.readyWait>0||(Tt.resolveWith(Z,[
[1:1:0712/193559.365325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.371394:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 845, 7f2dceb36881
[1:1:0712/193559.384521:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"835 0x7f2dce1192e0 0x354c69017de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.384718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"835 0x7f2dce1192e0 0x354c69017de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.384920:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.385215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , ready, (t){(!0===t?--ut.readyWait:ut.isReady)||(ut.isReady=!0,!0!==t&&--ut.readyWait>0||(Tt.resolveWith(Z,[
[1:1:0712/193559.385335:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.470355:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , , document.readyState
[1:1:0712/193559.470534:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.497112:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 856, 7f2dceb36881
[1:1:0712/193559.509595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"846 0x7f2dcc1f1070 0x354c6581b7e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.509761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"846 0x7f2dcc1f1070 0x354c6581b7e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.509963:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.510246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193559.510362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.510667:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193559.510765:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193559.510937:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 861
[1:1:0712/193559.511036:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 861 0x7f2dcc1f1070 0x354c629f87e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 856 0x7f2dcc1f1070 0x354c65783660 
[1:1:0712/193559.624551:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 861, 7f2dceb36881
[1:1:0712/193559.636574:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"856 0x7f2dcc1f1070 0x354c65783660 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.636760:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"856 0x7f2dcc1f1070 0x354c65783660 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.636954:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.637243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193559.637395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.637759:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193559.637871:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193559.638057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 863
[1:1:0712/193559.638179:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 863 0x7f2dcc1f1070 0x354c6962a9e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 861 0x7f2dcc1f1070 0x354c629f87e0 
[1:1:0712/193559.750567:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 863, 7f2dceb36881
[1:1:0712/193559.762557:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"861 0x7f2dcc1f1070 0x354c629f87e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.762756:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"861 0x7f2dcc1f1070 0x354c629f87e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.763000:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.763323:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193559.763477:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.763831:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193559.763955:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193559.764139:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 865
[1:1:0712/193559.764248:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 865 0x7f2dcc1f1070 0x354c6afb2660 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 863 0x7f2dcc1f1070 0x354c6962a9e0 
[1:1:0712/193559.876386:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 865, 7f2dceb36881
[1:1:0712/193559.888439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"863 0x7f2dcc1f1070 0x354c6962a9e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.888633:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"863 0x7f2dcc1f1070 0x354c6962a9e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193559.888863:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193559.889156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193559.889312:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193559.889672:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193559.889784:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193559.889973:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 868
[1:1:0712/193559.890094:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 868 0x7f2dcc1f1070 0x354c6b3ba6e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 865 0x7f2dcc1f1070 0x354c6afb2660 
[1:1:0712/193600.003166:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 868, 7f2dceb36881
[1:1:0712/193600.015783:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"865 0x7f2dcc1f1070 0x354c6afb2660 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.015973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"865 0x7f2dcc1f1070 0x354c6afb2660 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.016216:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.016524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.016655:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.016953:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.017063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.017290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 870
[1:1:0712/193600.017404:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 870 0x7f2dcc1f1070 0x354c69dff160 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 868 0x7f2dcc1f1070 0x354c6b3ba6e0 
[1:1:0712/193600.127780:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 870, 7f2dceb36881
[1:1:0712/193600.140749:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"868 0x7f2dcc1f1070 0x354c6b3ba6e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.140919:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"868 0x7f2dcc1f1070 0x354c6b3ba6e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.141136:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.141475:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.141633:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.142004:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.142121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.142309:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 873
[1:1:0712/193600.142442:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 873 0x7f2dcc1f1070 0x354c677f3c60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 870 0x7f2dcc1f1070 0x354c69dff160 
[1:1:0712/193600.255433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 873, 7f2dceb36881
[1:1:0712/193600.268048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"870 0x7f2dcc1f1070 0x354c69dff160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.268223:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"870 0x7f2dcc1f1070 0x354c69dff160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.268445:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.268743:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.268849:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.269163:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.269274:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.269458:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 875
[1:1:0712/193600.269579:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 875 0x7f2dcc1f1070 0x354c6b270ae0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 873 0x7f2dcc1f1070 0x354c677f3c60 
[1:1:0712/193600.382546:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 875, 7f2dceb36881
[1:1:0712/193600.395002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"873 0x7f2dcc1f1070 0x354c677f3c60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.395190:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"873 0x7f2dcc1f1070 0x354c677f3c60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.395424:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.395742:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.395907:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.396265:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.396383:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.396567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 877
[1:1:0712/193600.396680:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 877 0x7f2dcc1f1070 0x354c6907ca60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 875 0x7f2dcc1f1070 0x354c6b270ae0 
[1:1:0712/193600.509207:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 877, 7f2dceb36881
[1:1:0712/193600.521516:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"875 0x7f2dcc1f1070 0x354c6b270ae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.521710:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"875 0x7f2dcc1f1070 0x354c6b270ae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.521954:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.522280:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.522437:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.522801:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.522915:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.523099:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 881
[1:1:0712/193600.523222:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 881 0x7f2dcc1f1070 0x354c6b280160 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 877 0x7f2dcc1f1070 0x354c6907ca60 
[1:1:0712/193600.635773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 881, 7f2dceb36881
[1:1:0712/193600.648124:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"877 0x7f2dcc1f1070 0x354c6907ca60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.648309:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"877 0x7f2dcc1f1070 0x354c6907ca60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.648532:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.648824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.648923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.649248:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.649400:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.649596:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 884
[1:1:0712/193600.649719:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 884 0x7f2dcc1f1070 0x354c6b28b4e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 881 0x7f2dcc1f1070 0x354c6b280160 
[1:1:0712/193600.763352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 884, 7f2dceb36881
[1:1:0712/193600.776324:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"881 0x7f2dcc1f1070 0x354c6b280160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.776506:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"881 0x7f2dcc1f1070 0x354c6b280160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.776708:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.776978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.777116:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.777428:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.777537:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.777724:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 886
[1:1:0712/193600.777846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 886 0x7f2dcc1f1070 0x354c67e75c60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 884 0x7f2dcc1f1070 0x354c6b28b4e0 
[1:1:0712/193600.891079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 886, 7f2dceb36881
[1:1:0712/193600.903786:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"884 0x7f2dcc1f1070 0x354c6b28b4e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.903975:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"884 0x7f2dcc1f1070 0x354c6b28b4e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193600.904218:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193600.904531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193600.904675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193600.904974:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193600.905099:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193600.905251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 888
[1:1:0712/193600.905370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 888 0x7f2dcc1f1070 0x354c62a7b5e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 886 0x7f2dcc1f1070 0x354c67e75c60 
[1:1:0712/193601.018654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 888, 7f2dceb36881
[1:1:0712/193601.031386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"886 0x7f2dcc1f1070 0x354c67e75c60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.031573:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"886 0x7f2dcc1f1070 0x354c67e75c60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.031824:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.032142:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.032287:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.032621:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.032717:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.032887:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 890
[1:1:0712/193601.032986:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 890 0x7f2dcc1f1070 0x354c64cccae0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 888 0x7f2dcc1f1070 0x354c62a7b5e0 
[1:1:0712/193601.146128:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 890, 7f2dceb36881
[1:1:0712/193601.158904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"888 0x7f2dcc1f1070 0x354c62a7b5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.159094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"888 0x7f2dcc1f1070 0x354c62a7b5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.159371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.159695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.159852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.160211:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.160329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.160518:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 892
[1:1:0712/193601.160628:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 892 0x7f2dcc1f1070 0x354c6b1cf8e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 890 0x7f2dcc1f1070 0x354c64cccae0 
[1:1:0712/193601.273862:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 892, 7f2dceb36881
[1:1:0712/193601.286553:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"890 0x7f2dcc1f1070 0x354c64cccae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.286743:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"890 0x7f2dcc1f1070 0x354c64cccae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.286984:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.287298:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.287455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.287812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.287924:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.288108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 894
[1:1:0712/193601.288217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7f2dcc1f1070 0x354c627cf4e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 892 0x7f2dcc1f1070 0x354c6b1cf8e0 
[1:1:0712/193601.401363:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 894, 7f2dceb36881
[1:1:0712/193601.414070:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"892 0x7f2dcc1f1070 0x354c6b1cf8e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.414257:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"892 0x7f2dcc1f1070 0x354c6b1cf8e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.414494:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.414813:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.414976:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.415332:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.415448:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.415635:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 896
[1:1:0712/193601.415756:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7f2dcc1f1070 0x354c64cf3de0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 894 0x7f2dcc1f1070 0x354c627cf4e0 
[1:1:0712/193601.528807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 896, 7f2dceb36881
[1:1:0712/193601.541609:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"894 0x7f2dcc1f1070 0x354c627cf4e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.541811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"894 0x7f2dcc1f1070 0x354c627cf4e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.542058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.542394:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.542588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.542956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.543069:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.543258:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 899
[1:1:0712/193601.543381:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 899 0x7f2dcc1f1070 0x354c6b01cce0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 896 0x7f2dcc1f1070 0x354c64cf3de0 
[1:1:0712/193601.656667:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 899, 7f2dceb36881
[1:1:0712/193601.669565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"896 0x7f2dcc1f1070 0x354c64cf3de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.669751:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"896 0x7f2dcc1f1070 0x354c64cf3de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.669992:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.670308:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.670472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.670830:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.670947:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.671132:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 901
[1:1:0712/193601.671253:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 901 0x7f2dcc1f1070 0x354c6b2698e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 899 0x7f2dcc1f1070 0x354c6b01cce0 
[1:1:0712/193601.784539:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 901, 7f2dceb36881
[1:1:0712/193601.797439:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"899 0x7f2dcc1f1070 0x354c6b01cce0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.797625:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"899 0x7f2dcc1f1070 0x354c6b01cce0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.797865:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.798183:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.798340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.798698:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.798821:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.799007:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 903
[1:1:0712/193601.799127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 903 0x7f2dcc1f1070 0x354c69985f60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 901 0x7f2dcc1f1070 0x354c6b2698e0 
[1:1:0712/193601.912603:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 903, 7f2dceb36881
[1:1:0712/193601.925479:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"901 0x7f2dcc1f1070 0x354c6b2698e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.925666:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"901 0x7f2dcc1f1070 0x354c6b2698e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193601.925927:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193601.926243:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193601.926406:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193601.926777:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193601.926898:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193601.927084:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 905
[1:1:0712/193601.927205:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 905 0x7f2dcc1f1070 0x354c6b1cf760 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 903 0x7f2dcc1f1070 0x354c69985f60 
[1:1:0712/193602.040628:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 905, 7f2dceb36881
[1:1:0712/193602.053572:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"903 0x7f2dcc1f1070 0x354c69985f60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.053759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"903 0x7f2dcc1f1070 0x354c69985f60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.053999:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.054317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.054474:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.054832:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.054944:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.055129:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 907
[1:1:0712/193602.055251:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 907 0x7f2dcc1f1070 0x354c695006e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 905 0x7f2dcc1f1070 0x354c6b1cf760 
[1:1:0712/193602.168572:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 907, 7f2dceb36881
[1:1:0712/193602.181444:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"905 0x7f2dcc1f1070 0x354c6b1cf760 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.181631:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"905 0x7f2dcc1f1070 0x354c6b1cf760 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.181870:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.182185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.182349:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.182706:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.182822:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.183011:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 909
[1:1:0712/193602.183143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 909 0x7f2dcc1f1070 0x354c6b01cb60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 907 0x7f2dcc1f1070 0x354c695006e0 
[1:1:0712/193602.296645:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 909, 7f2dceb36881
[1:1:0712/193602.309683:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"907 0x7f2dcc1f1070 0x354c695006e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.309871:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"907 0x7f2dcc1f1070 0x354c695006e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.310113:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.310430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.310587:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.310946:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.311058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.311241:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 911
[1:1:0712/193602.311362:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 911 0x7f2dcc1f1070 0x354c6b3bbe60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 909 0x7f2dcc1f1070 0x354c6b01cb60 
[1:1:0712/193602.424809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 911, 7f2dceb36881
[1:1:0712/193602.437717:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"909 0x7f2dcc1f1070 0x354c6b01cb60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.437906:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"909 0x7f2dcc1f1070 0x354c6b01cb60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.438167:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.438482:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.438692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.439055:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.439169:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.439360:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 913
[1:1:0712/193602.439481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 913 0x7f2dcc1f1070 0x354c67ac1060 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 911 0x7f2dcc1f1070 0x354c6b3bbe60 
[1:1:0712/193602.553216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 913, 7f2dceb36881
[1:1:0712/193602.566465:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"911 0x7f2dcc1f1070 0x354c6b3bbe60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.566658:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"911 0x7f2dcc1f1070 0x354c6b3bbe60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.566922:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.567242:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.567397:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.567760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.567872:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.568057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 915
[1:1:0712/193602.568180:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 915 0x7f2dcc1f1070 0x354c68b00d60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 913 0x7f2dcc1f1070 0x354c67ac1060 
[1:1:0712/193602.681720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 915, 7f2dceb36881
[1:1:0712/193602.694678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"913 0x7f2dcc1f1070 0x354c67ac1060 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.694865:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"913 0x7f2dcc1f1070 0x354c67ac1060 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.695102:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.695437:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.695621:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.695989:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.696102:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.696291:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 917
[1:1:0712/193602.696412:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 917 0x7f2dcc1f1070 0x354c67e599e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 915 0x7f2dcc1f1070 0x354c68b00d60 
[1:1:0712/193602.810049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 917, 7f2dceb36881
[1:1:0712/193602.823073:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"915 0x7f2dcc1f1070 0x354c68b00d60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.823261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"915 0x7f2dcc1f1070 0x354c68b00d60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.823499:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.823818:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.823966:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.824322:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.824431:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.824614:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 919
[1:1:0712/193602.824723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 919 0x7f2dcc1f1070 0x354c6b3bb2e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 917 0x7f2dcc1f1070 0x354c67e599e0 
[1:1:0712/193602.938367:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 919, 7f2dceb36881
[1:1:0712/193602.951695:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"917 0x7f2dcc1f1070 0x354c67e599e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.951886:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"917 0x7f2dcc1f1070 0x354c67e599e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193602.952128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193602.952436:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193602.952588:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193602.952913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193602.953002:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193602.953196:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 921
[1:1:0712/193602.953317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f2dcc1f1070 0x354c6b28d5e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 919 0x7f2dcc1f1070 0x354c6b3bb2e0 
[1:1:0712/193603.067122:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 921, 7f2dceb36881
[1:1:0712/193603.080305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"919 0x7f2dcc1f1070 0x354c6b3bb2e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.080481:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"919 0x7f2dcc1f1070 0x354c6b3bb2e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.080679:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.080944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.081078:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.081466:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.081616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.081817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 923
[1:1:0712/193603.081937:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 923 0x7f2dcc1f1070 0x354c693fbd60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 921 0x7f2dcc1f1070 0x354c6b28d5e0 
[1:1:0712/193603.195500:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 923, 7f2dceb36881
[1:1:0712/193603.208542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"921 0x7f2dcc1f1070 0x354c6b28d5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.208700:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"921 0x7f2dcc1f1070 0x354c6b28d5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.208888:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.209197:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.209368:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.209728:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.209840:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.210028:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 925
[1:1:0712/193603.210175:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 925 0x7f2dcc1f1070 0x354c69e1b560 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 923 0x7f2dcc1f1070 0x354c693fbd60 
[1:1:0712/193603.323798:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 925, 7f2dceb36881
[1:1:0712/193603.336886:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"923 0x7f2dcc1f1070 0x354c693fbd60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.337044:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"923 0x7f2dcc1f1070 0x354c693fbd60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.337291:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.337611:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.337769:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.338129:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.338241:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.338426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 927
[1:1:0712/193603.338545:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 927 0x7f2dcc1f1070 0x354c6b3bc1e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 925 0x7f2dcc1f1070 0x354c69e1b560 
[1:1:0712/193603.452809:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 927, 7f2dceb36881
[1:1:0712/193603.466211:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"925 0x7f2dcc1f1070 0x354c69e1b560 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.466401:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"925 0x7f2dcc1f1070 0x354c69e1b560 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.466646:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.466982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.467155:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.467558:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.467672:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.467858:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 929
[1:1:0712/193603.467984:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 929 0x7f2dcc1f1070 0x354c650866e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 927 0x7f2dcc1f1070 0x354c6b3bc1e0 
[1:1:0712/193603.582213:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 929, 7f2dceb36881
[1:1:0712/193603.595708:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"927 0x7f2dcc1f1070 0x354c6b3bc1e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.595901:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"927 0x7f2dcc1f1070 0x354c6b3bc1e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.596166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.596480:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.596622:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.596950:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.597051:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.597290:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 931
[1:1:0712/193603.597415:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 931 0x7f2dcc1f1070 0x354c6b2866e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 929 0x7f2dcc1f1070 0x354c650866e0 
[1:1:0712/193603.711872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 931, 7f2dceb36881
[1:1:0712/193603.725636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"929 0x7f2dcc1f1070 0x354c650866e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.725843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"929 0x7f2dcc1f1070 0x354c650866e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.726106:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.726435:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.726601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.726971:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.727084:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.727270:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 933
[1:1:0712/193603.727395:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 933 0x7f2dcc1f1070 0x354c6b3bcbe0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 931 0x7f2dcc1f1070 0x354c6b2866e0 
[1:1:0712/193603.841377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 933, 7f2dceb36881
[1:1:0712/193603.854700:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"931 0x7f2dcc1f1070 0x354c6b2866e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.854897:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"931 0x7f2dcc1f1070 0x354c6b2866e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193603.855140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193603.855460:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193603.855617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193603.855979:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193603.856090:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193603.856276:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 935
[1:1:0712/193603.856397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 935 0x7f2dcc1f1070 0x354c693fb8e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 933 0x7f2dcc1f1070 0x354c6b3bcbe0 
[1:1:0712/193604.031169:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 935, 7f2dceb36881
[1:1:0712/193604.048782:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"933 0x7f2dcc1f1070 0x354c6b3bcbe0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.048984:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"933 0x7f2dcc1f1070 0x354c6b3bcbe0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.049211:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193604.049568:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193604.049734:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193604.050131:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193604.050339:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193604.050594:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 950
[1:1:0712/193604.050725:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 950 0x7f2dcc1f1070 0x354c6581b5e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 935 0x7f2dcc1f1070 0x354c693fb8e0 
[1:1:0712/193604.331781:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 950, 7f2dceb36881
[1:1:0712/193604.344997:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"935 0x7f2dcc1f1070 0x354c693fb8e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.345217:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"935 0x7f2dcc1f1070 0x354c693fb8e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.345409:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193604.345685:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193604.345783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193604.346073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193604.346163:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193604.346327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 966
[1:1:0712/193604.346432:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 966 0x7f2dcc1f1070 0x354c685006e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 950 0x7f2dcc1f1070 0x354c6581b5e0 
[1:1:0712/193604.588275:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 966, 7f2dceb36881
[1:1:0712/193604.603513:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"950 0x7f2dcc1f1070 0x354c6581b5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.603697:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"950 0x7f2dcc1f1070 0x354c6581b5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.603918:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193604.604214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193604.605169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193604.605603:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193604.605766:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193604.606026:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 977
[1:1:0712/193604.606208:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 977 0x7f2dcc1f1070 0x354c69dffae0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 966 0x7f2dcc1f1070 0x354c685006e0 
[1:1:0712/193604.759143:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 977, 7f2dceb36881
[1:1:0712/193604.773120:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"966 0x7f2dcc1f1070 0x354c685006e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.773282:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"966 0x7f2dcc1f1070 0x354c685006e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193604.773491:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193604.773765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193604.773864:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193604.774154:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193604.774243:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193604.774412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 985
[1:1:0712/193604.774513:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f2dcc1f1070 0x354c627635e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 977 0x7f2dcc1f1070 0x354c69dffae0 
[1:1:0712/193604.993188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 985, 7f2dceb36881
[1:1:0712/193605.006502:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"977 0x7f2dcc1f1070 0x354c69dffae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.006655:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"977 0x7f2dcc1f1070 0x354c69dffae0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.006847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.007127:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.007245:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.007552:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.007646:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.007818:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 994
[1:1:0712/193605.007915:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 994 0x7f2dcc1f1070 0x354c64ce94e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 985 0x7f2dcc1f1070 0x354c627635e0 
[1:1:0712/193605.130997:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 994, 7f2dceb36881
[1:1:0712/193605.145835:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"985 0x7f2dcc1f1070 0x354c627635e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.145996:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"985 0x7f2dcc1f1070 0x354c627635e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.146192:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.146481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.146585:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.146872:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.146953:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.147113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1003
[1:1:0712/193605.147192:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1003 0x7f2dcc1f1070 0x354c69e17a60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 994 0x7f2dcc1f1070 0x354c64ce94e0 
[1:1:0712/193605.259985:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1003, 7f2dceb36881
[1:1:0712/193605.274896:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"994 0x7f2dcc1f1070 0x354c64ce94e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.275094:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"994 0x7f2dcc1f1070 0x354c64ce94e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.275364:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.275727:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.275896:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.276263:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.276410:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.276656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1009
[1:1:0712/193605.276768:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1009 0x7f2dcc1f1070 0x354c693fbd60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1003 0x7f2dcc1f1070 0x354c69e17a60 
[1:1:0712/193605.417804:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1009, 7f2dceb36881
[1:1:0712/193605.432841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1003 0x7f2dcc1f1070 0x354c69e17a60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.432994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1003 0x7f2dcc1f1070 0x354c69e17a60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.433194:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.433518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.433672:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.434057:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.434160:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.434339:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1017
[1:1:0712/193605.434452:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1017 0x7f2dcc1f1070 0x354c695ed8e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1009 0x7f2dcc1f1070 0x354c693fbd60 
[1:1:0712/193605.559580:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1017, 7f2dceb36881
[1:1:0712/193605.574626:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1009 0x7f2dcc1f1070 0x354c693fbd60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.574777:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1009 0x7f2dcc1f1070 0x354c693fbd60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.575012:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.575330:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.575461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.575788:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.575904:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.576069:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1023
[1:1:0712/193605.576177:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1023 0x7f2dcc1f1070 0x354c69985160 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1017 0x7f2dcc1f1070 0x354c695ed8e0 
[1:1:0712/193605.688855:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1023, 7f2dceb36881
[1:1:0712/193605.704017:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1017 0x7f2dcc1f1070 0x354c695ed8e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.704195:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1017 0x7f2dcc1f1070 0x354c695ed8e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.704390:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.704671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.704774:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.705083:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.705189:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.705364:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1029
[1:1:0712/193605.705482:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1029 0x7f2dcc1f1070 0x354c667f5de0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1023 0x7f2dcc1f1070 0x354c69985160 
[1:1:0712/193605.817482:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1029, 7f2dceb36881
[1:1:0712/193605.832660:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1023 0x7f2dcc1f1070 0x354c69985160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.832817:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1023 0x7f2dcc1f1070 0x354c69985160 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.833018:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.833345:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.833461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.833796:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.833900:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.834083:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1035
[1:1:0712/193605.834203:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1035 0x7f2dcc1f1070 0x354c6b01c5e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1029 0x7f2dcc1f1070 0x354c667f5de0 
[1:1:0712/193605.947795:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1035, 7f2dceb36881
[1:1:0712/193605.963295:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1029 0x7f2dcc1f1070 0x354c667f5de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.963453:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1029 0x7f2dcc1f1070 0x354c667f5de0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193605.963644:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193605.963923:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193605.964047:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193605.964367:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193605.964472:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193605.964634:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1041
[1:1:0712/193605.964737:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7f2dcc1f1070 0x354c6b2611e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1035 0x7f2dcc1f1070 0x354c6b01c5e0 
[1:1:0712/193606.078601:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1041, 7f2dceb36881
[1:1:0712/193606.094147:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1035 0x7f2dcc1f1070 0x354c6b01c5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.094344:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1035 0x7f2dcc1f1070 0x354c6b01c5e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.094545:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.094824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.094938:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.095251:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.095345:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.095508:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1047
[1:1:0712/193606.095615:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1047 0x7f2dcc1f1070 0x354c627620e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1041 0x7f2dcc1f1070 0x354c6b2611e0 
[1:1:0712/193606.224963:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1047, 7f2dceb36881
[1:1:0712/193606.240841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1041 0x7f2dcc1f1070 0x354c6b2611e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.240994:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1041 0x7f2dcc1f1070 0x354c6b2611e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.241171:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.241466:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.241618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.242050:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.242200:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.242426:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1056
[1:1:0712/193606.242558:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1056 0x7f2dcc1f1070 0x354c6b3b62e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1047 0x7f2dcc1f1070 0x354c627620e0 
[1:1:0712/193606.360762:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1056, 7f2dceb36881
[1:1:0712/193606.378889:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1047 0x7f2dcc1f1070 0x354c627620e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.379082:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1047 0x7f2dcc1f1070 0x354c627620e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.379308:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.379618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.379747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.380086:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.380196:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.380386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1062
[1:1:0712/193606.380505:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1062 0x7f2dcc1f1070 0x354c64cb6ee0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1056 0x7f2dcc1f1070 0x354c6b3b62e0 
[1:1:0712/193606.490720:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1062, 7f2dceb36881
[1:1:0712/193606.506805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1056 0x7f2dcc1f1070 0x354c6b3b62e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.506967:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1056 0x7f2dcc1f1070 0x354c6b3b62e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.507161:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.507438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.507549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.507854:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.507947:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.508134:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1068
[1:1:0712/193606.508276:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1068 0x7f2dcc1f1070 0x354c6b3baf60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1062 0x7f2dcc1f1070 0x354c64cb6ee0 
[1:1:0712/193606.625468:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1068, 7f2dceb36881
[1:1:0712/193606.641533:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1062 0x7f2dcc1f1070 0x354c64cb6ee0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.641680:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1062 0x7f2dcc1f1070 0x354c64cb6ee0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.641932:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.642218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.642324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.642636:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.642733:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.642900:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1074
[1:1:0712/193606.643011:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7f2dcc1f1070 0x354c6b561ee0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1068 0x7f2dcc1f1070 0x354c6b3baf60 
[1:1:0712/193606.761757:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1074, 7f2dceb36881
[1:1:0712/193606.778010:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1068 0x7f2dcc1f1070 0x354c6b3baf60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.778170:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1068 0x7f2dcc1f1070 0x354c6b3baf60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.778362:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.778636:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.778750:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.779061:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.779154:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.779330:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1080
[1:1:0712/193606.779436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1080 0x7f2dcc1f1070 0x354c6b588e60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1074 0x7f2dcc1f1070 0x354c6b561ee0 
[1:1:0712/193606.883528:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1080, 7f2dceb36881
[1:1:0712/193606.903807:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1074 0x7f2dcc1f1070 0x354c6b561ee0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.904002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1074 0x7f2dcc1f1070 0x354c6b561ee0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193606.904229:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193606.904536:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193606.904662:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193606.905098:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193606.905213:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193606.905415:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1087
[1:1:0712/193606.905543:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1087 0x7f2dcc1f1070 0x354c6b565960 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1080 0x7f2dcc1f1070 0x354c6b588e60 
[1:1:0712/193607.089840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1087, 7f2dceb36881
[1:1:0712/193607.105175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1080 0x7f2dcc1f1070 0x354c6b588e60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.105326:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1080 0x7f2dcc1f1070 0x354c6b588e60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.105521:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193607.105805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193607.105916:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193607.106219:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193607.106322:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193607.106506:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1095
[1:1:0712/193607.106617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1095 0x7f2dcc1f1070 0x354c6b561e60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1087 0x7f2dcc1f1070 0x354c6b565960 
[1:1:0712/193607.307617:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1095, 7f2dceb36881
[1:1:0712/193607.323953:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1087 0x7f2dcc1f1070 0x354c6b565960 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.324099:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1087 0x7f2dcc1f1070 0x354c6b565960 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.324286:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193607.324553:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193607.324640:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193607.325011:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193607.325138:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193607.325338:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1105
[1:1:0712/193607.325454:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1105 0x7f2dcc1f1070 0x354c6b2616e0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1095 0x7f2dcc1f1070 0x354c6b561e60 
[1:1:0712/193607.496004:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1105, 7f2dceb36881
[1:1:0712/193607.512775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1095 0x7f2dcc1f1070 0x354c6b561e60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.512932:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1095 0x7f2dcc1f1070 0x354c6b561e60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.513134:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193607.513424:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193607.513537:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193607.513852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193607.513945:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193607.514109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1113
[1:1:0712/193607.514211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1113 0x7f2dcc1f1070 0x354c6b580ce0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1105 0x7f2dcc1f1070 0x354c6b2616e0 
[1:1:0712/193607.793612:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1113, 7f2dceb36881
[1:1:0712/193607.810405:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1105 0x7f2dcc1f1070 0x354c6b2616e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.810553:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1105 0x7f2dcc1f1070 0x354c6b2616e0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193607.810739:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193607.811019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193607.811120:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193607.811426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193607.811517:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193607.811681:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1124
[1:1:0712/193607.811780:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7f2dcc1f1070 0x354c693e5e60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1113 0x7f2dcc1f1070 0x354c6b580ce0 
[1:1:0712/193607.999895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1124, 7f2dceb36881
[1:1:0712/193608.016627:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1113 0x7f2dcc1f1070 0x354c6b580ce0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.016773:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1113 0x7f2dcc1f1070 0x354c6b580ce0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.016962:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193608.017250:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193608.017352:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193608.017657:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193608.017754:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193608.017930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1132
[1:1:0712/193608.018045:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1132 0x7f2dcc1f1070 0x354c67efcbe0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1124 0x7f2dcc1f1070 0x354c693e5e60 
[1:1:0712/193608.189342:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1132, 7f2dceb36881
[1:1:0712/193608.206554:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1124 0x7f2dcc1f1070 0x354c693e5e60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.206715:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1124 0x7f2dcc1f1070 0x354c693e5e60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.206916:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193608.207205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193608.207326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193608.207629:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193608.207723:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193608.207876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1140
[1:1:0712/193608.207966:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1140 0x7f2dcc1f1070 0x354c6b3babe0 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1132 0x7f2dcc1f1070 0x354c67efcbe0 
[1:1:0712/193608.412895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1140, 7f2dceb36881
[1:1:0712/193608.430172:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1132 0x7f2dcc1f1070 0x354c67efcbe0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.430332:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1132 0x7f2dcc1f1070 0x354c67efcbe0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.430528:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193608.430825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193608.430926:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193608.431234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193608.431329:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193608.431498:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1150
[1:1:0712/193608.431606:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1150 0x7f2dcc1f1070 0x354c62a6dd60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1140 0x7f2dcc1f1070 0x354c6b3babe0 
[1:1:0712/193608.555351:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1150, 7f2dceb36881
[1:1:0712/193608.572720:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1140 0x7f2dcc1f1070 0x354c6b3babe0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.572880:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1140 0x7f2dcc1f1070 0x354c6b3babe0 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.573080:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193608.573353:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193608.573456:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193608.573759:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193608.573852:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193608.574014:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1155
[1:1:0712/193608.574093:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1155 0x7f2dcc1f1070 0x354c6b59da60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1150 0x7f2dcc1f1070 0x354c62a6dd60 
[1:1:0712/193608.699563:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1155, 7f2dceb36881
[1:1:0712/193608.716906:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1150 0x7f2dcc1f1070 0x354c62a6dd60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.717100:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1150 0x7f2dcc1f1070 0x354c62a6dd60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.717299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193608.717584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193608.717684:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193608.717994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193608.718095:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193608.718266:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1161
[1:1:0712/193608.718376:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1161 0x7f2dcc1f1070 0x354c6b586260 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1155 0x7f2dcc1f1070 0x354c6b59da60 
[1:1:0712/193608.845266:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1161, 7f2dceb36881
[1:1:0712/193608.862775:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"12eb9ee62860","ptid":"1155 0x7f2dcc1f1070 0x354c6b59da60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.862929:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://zhaopin.58.com/","ptid":"1155 0x7f2dcc1f1070 0x354c6b59da60 ","rf":"5:3_https://zhaopin.58.com/"}
[1:1:0712/193608.863112:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://zhaopin.58.com/?from=10178#/?_q"
[1:1:0712/193608.863378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://zhaopin.58.com/, 12eb9ee62860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0712/193608.863480:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://zhaopin.58.com/?from=10178#/?_q", "zhaopin.58.com", 3, 1, , , 0
[1:1:0712/193608.863783:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x11e0c48a29c8, 0x354c62539150
[1:1:0712/193608.863876:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://zhaopin.58.com/?from=10178#/?_q", 100
[1:1:0712/193608.864037:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://zhaopin.58.com/, 1167
[1:1:0712/193608.864130:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1167 0x7f2dcc1f1070 0x354c65783f60 , 5:3_https://zhaopin.58.com/, 1, -5:3_https://zhaopin.58.com/, 1161 0x7f2dcc1f1070 0x354c6b586260 
