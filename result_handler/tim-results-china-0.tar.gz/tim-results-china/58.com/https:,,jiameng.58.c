[0712/193338.943445:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/193338.943704:INFO:switcher_clone.cc(787)] backtrace rip is 7f634b81d891
[0712/193339.486212:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/193339.486447:INFO:switcher_clone.cc(787)] backtrace rip is 7f2ff60a6891
[1:1:0712/193339.490293:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/193339.490460:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/193339.493363:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[18091:18091:0712/193340.313820:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
[0712/193340.331072:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/193340.331321:INFO:switcher_clone.cc(787)] backtrace rip is 7f2214ed0891

DevTools listening on ws://127.0.0.1:9222/devtools/browser/d9e908f3-1c75-4f0f-b6f7-ff6762445aa3
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[18123:18123:0712/193340.480794:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18123
[18136:18136:0712/193340.481121:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=18136
[18091:18091:0712/193340.563927:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[18091:18121:0712/193340.564435:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/193340.564563:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/193340.564711:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/193340.564990:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/193340.565103:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/193340.566831:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2d67afbb, 1
[1:1:0712/193340.567050:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xc0eef4f, 0
[1:1:0712/193340.567169:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3b36da6, 3
[1:1:0712/193340.567271:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x27634417, 2
[1:1:0712/193340.567381:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4fffffffef0e0c ffffffbbffffffaf672d 17446327 ffffffa66dffffffb303 , 10104, 4
[1:1:0712/193340.568018:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18091:18121:0712/193340.568149:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGO���g-Dc'�m���X!
[18091:18121:0712/193340.568196:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is O���g-Dc'�m��4��X!
[1:1:0712/193340.568145:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2ff42e00a0, 3
[1:1:0712/193340.568286:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2ff446c080, 2
[1:1:0712/193340.568368:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2fde12ed20, -2
[18091:18121:0712/193340.568417:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[18091:18121:0712/193340.568449:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18144, 4, 4fef0e0c bbaf672d 17446327 a66db303 
[1:1:0712/193340.575864:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/193340.576277:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27634417
[1:1:0712/193340.576704:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27634417
[1:1:0712/193340.577447:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27634417
[1:1:0712/193340.577968:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.578074:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.578171:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.578264:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.578502:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27634417
[1:1:0712/193340.578642:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2ff60a67ba
[1:1:0712/193340.578721:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2ff609ddef, 7f2ff60a677a, 7f2ff60a80cf
[1:1:0712/193340.580354:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 27634417
[1:1:0712/193340.580486:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 27634417
[1:1:0712/193340.580746:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 27634417
[1:1:0712/193340.581554:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.581667:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.581764:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.581859:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 27634417
[1:1:0712/193340.582351:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 27634417
[1:1:0712/193340.582527:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2ff60a67ba
[1:1:0712/193340.582578:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2ff609ddef, 7f2ff60a677a, 7f2ff60a80cf
[1:1:0712/193340.585229:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/193340.585450:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/193340.585561:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdb8fdd638, 0x7ffdb8fdd5b8)
[1:1:0712/193340.591852:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/193340.594690:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[18091:18091:0712/193341.005519:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18091:18091:0712/193341.006038:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18091:18091:0712/193341.014455:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[18091:18091:0712/193341.014515:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[18091:18091:0712/193341.014580:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,18144, 4
[18091:18102:0712/193341.014983:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[18091:18102:0712/193341.015034:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/193341.015784:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/193341.086494:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xd64bef1d220
[1:1:0712/193341.086645:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[18091:18116:0712/193341.099014:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/193341.290221:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/193341.990397:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193341.992204:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[18091:18091:0712/193342.134188:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[18091:18091:0712/193342.134305:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/193342.432398:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193342.484483:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/193342.484646:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193342.489612:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/193342.489740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193342.565467:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193342.565617:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193342.726136:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 355, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193342.728691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/193342.728833:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193342.740801:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 356, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193342.743758:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/193342.743894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193342.747733:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[18091:18091:0712/193342.748387:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/193342.749517:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd64bef1be20
[1:1:0712/193342.749626:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[18091:18091:0712/193342.750924:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[18091:18091:0712/193342.762526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[18091:18091:0712/193342.762607:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/193342.782188:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193343.103704:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 416 0x7f2fdfd092e0 0xd64bf08bb60 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193343.104416:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/193343.104566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193343.105179:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18091:18091:0712/193343.131512:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/193343.132643:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xd64bef1c820
[1:1:0712/193343.132794:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[18091:18091:0712/193343.133868:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/193343.139930:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/193343.140092:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[18091:18091:0712/193343.141384:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[18091:18091:0712/193343.145566:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18091:18091:0712/193343.145972:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18091:18102:0712/193343.150540:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[18091:18102:0712/193343.150594:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[18091:18091:0712/193343.150613:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[18091:18091:0712/193343.150655:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[18091:18091:0712/193343.150715:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,18144, 4
[1:7:0712/193343.152151:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/193343.417651:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/193343.550115:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 467 0x7f2fdfd092e0 0xd64bf2e1260 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193343.550693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/193343.550852:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193343.551212:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[18091:18091:0712/193343.671690:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[18091:18091:0712/193343.671774:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/193343.683295:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/193343.834035:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[18091:18091:0712/193343.902317:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[18091:18121:0712/193343.902613:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/193343.902749:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/193343.902895:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/193343.903132:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/193343.903216:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/193343.905736:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x13dd7ccb, 1
[1:1:0712/193343.905993:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x33a45f84, 0
[1:1:0712/193343.906169:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x95f8d38, 3
[1:1:0712/193343.906329:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x367418b, 2
[1:1:0712/193343.906479:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffff845fffffffa433 ffffffcb7cffffffdd13 ffffff8b416703 38ffffff8d5f09 , 10104, 5
[1:1:0712/193343.907248:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[18091:18121:0712/193343.907464:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�_�3�|��Ag8�_	��X!
[18091:18121:0712/193343.907505:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �_�3�|��Ag8�_	�b��X!
[18091:18121:0712/193343.907624:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 18186, 5, 845fa433 cb7cdd13 8b416703 388d5f09 
[1:1:0712/193343.907466:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2ff42e00a0, 3
[1:1:0712/193343.907860:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2ff446c080, 2
[1:1:0712/193343.907976:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f2fde12ed20, -2
[1:1:0712/193343.917519:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/193343.917723:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 367418b
[1:1:0712/193343.917895:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 367418b
[1:1:0712/193343.918150:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 367418b
[1:1:0712/193343.918654:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.918754:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.918847:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.918939:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.919189:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 367418b
[1:1:0712/193343.919318:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2ff60a67ba
[1:1:0712/193343.919403:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2ff609ddef, 7f2ff60a677a, 7f2ff60a80cf
[1:1:0712/193343.921143:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 367418b
[1:1:0712/193343.921332:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 367418b
[1:1:0712/193343.921645:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 367418b
[1:1:0712/193343.922423:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.922556:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.922673:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.922781:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 367418b
[1:1:0712/193343.923263:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 367418b
[1:1:0712/193343.923433:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f2ff60a67ba
[1:1:0712/193343.923514:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f2ff609ddef, 7f2ff60a677a, 7f2ff60a80cf
[1:1:0712/193343.926154:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/193343.926385:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/193343.926496:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffdb8fdd638, 0x7ffdb8fdd5b8)
[1:1:0712/193343.932669:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/193343.934636:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/193344.024315:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xd64bee9b220
[1:1:0712/193344.024521:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/193344.052371:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193344.052569:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193344.239750:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 539, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193344.241470:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/193344.241663:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193344.244192:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193344.295906:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/193344.296264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 182179361f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/193344.296354:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/193344.341264:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193344.341993:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/193344.342090:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/193344.342213:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193344.406977:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193344.407471:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/193344.407618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/193344.407776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193344.567826:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/193344.731497:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.taobao.com/"
[1:1:0712/193344.756009:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/193344.798219:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/193344.841391:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/193344.878578:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/193344.913459:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/193344.938483:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/193344.976922:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193344.977465:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193344.977682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.008727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.009282:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.009479:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.032046:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.032504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.032641:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.060278:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.060693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.060828:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.081429:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.081851:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.081986:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.110536:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.110948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.111085:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.140660:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.141138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.141279:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.168971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.169517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.169732:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.207799:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.208263:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.208489:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.226745:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.227222:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.227355:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.265628:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.266118:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.266274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.303762:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.304180:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.304318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.324813:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.325286:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.325422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.352828:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.353313:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.353470:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.373672:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.374082:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/193345.374206:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/193345.403111:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/193345.403530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 18217948e5b8, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/193345.403680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[18091:18091:0712/193345.474758:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('https://jiameng.58.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
[18091:18091:0712/193350.094740:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[18091:18091:0712/193350.097351:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[18091:18102:0712/193350.115050:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[18091:18091:0712/193350.115121:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://jiameng.58.com/
[18091:18102:0712/193350.115133:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[18091:18091:0712/193350.115165:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://jiameng.58.com/, https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl, 1
[18091:18091:0712/193350.115231:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_https://jiameng.58.com/, HTTP/1.1 200 status:200 server:nginx date:Fri, 12 Jul 2019 11:33:50 GMT content-type:text/html;charset=UTF-8 x-host:investment_business content-encoding:gzip vary:Accept-Encoding  ,18186, 5
[1:7:0712/193350.120284:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/193350.132483:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_https://jiameng.58.com/
[18091:18091:0712/193350.185872:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_https://jiameng.58.com/, https://jiameng.58.com/, 1
[18091:18091:0712/193350.185933:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://jiameng.58.com/, https://jiameng.58.com
[1:1:0712/193350.200194:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/193350.244817:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193350.279897:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193350.280092:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193350.350875:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0706608, 754, 1
[1:1:0712/193350.351113:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193350.472265:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193350.472454:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193350.634659:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193350.826071:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f2fde149bd0 0xd64bf088c58 , "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193350.829767:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/193350.832544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , , /*! jQuery v@1.8.1 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};re
[1:1:0712/193350.832719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
		remove user.d_8bc8a375 -> 0
[1:1:0712/193350.940173:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f2fde149bd0 0xd64bf088c58 , "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193350.944745:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f2fde149bd0 0xd64bf088c58 , "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193350.949213:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f2fde149bd0 0xd64bf088c58 , "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193350.951435:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7f2fde149bd0 0xd64bf088c58 , "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193357.379181:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[18091:18091:0712/193404.311078:INFO:CONSOLE(268)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic7.58cdn.com.cn/p1/big/n_v2761e50626f394fabbbeb601ad74dca92.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (268)
[18091:18091:0712/193404.312529:INFO:CONSOLE(277)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic8.58cdn.com.cn/p1/big/n_v2c4d6a3862f484717979163d6918d9d9f.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (277)
[18091:18091:0712/193404.313938:INFO:CONSOLE(286)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic6.58cdn.com.cn/p1/big/n_v2786393440aba477d94b92e27d96db6bd.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (286)
[18091:18091:0712/193404.315360:INFO:CONSOLE(295)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic6.58cdn.com.cn/p2/big/n_v1bj3gzr3fuh4vrwsxjaaa.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (295)
[18091:18091:0712/193404.316782:INFO:CONSOLE(304)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic3.58cdn.com.cn/p1/big/n_v233bdbfe0ce2346eb99ab35e3356b00ca.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (304)
[18091:18091:0712/193404.318244:INFO:CONSOLE(313)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic3.58cdn.com.cn/p2/big/n_v25e7ec52cf57d44dca752388a87d0a321.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (313)
[18091:18091:0712/193404.319716:INFO:CONSOLE(322)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic4.58cdn.com.cn/p1/big/n_v247cfa79afbea4669b810d9021e58b081.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (322)
[18091:18091:0712/193404.321160:INFO:CONSOLE(331)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic3.58cdn.com.cn/p2/big/n_v2b99e851747544463bde086ead9b1ec61.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (331)
[18091:18091:0712/193404.322582:INFO:CONSOLE(340)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic7.58cdn.com.cn/p2/big/n_v1bkujjdyoiy3ft6ybyz4a.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (340)
[18091:18091:0712/193404.323908:INFO:CONSOLE(349)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic8.58cdn.com.cn/p1/big/n_v2fa2d357170c74ad3a3fdce13c2e4aa8c.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (349)
[18091:18091:0712/193404.325313:INFO:CONSOLE(358)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic8.58cdn.com.cn/p1/big/n_v2dddc3f53d64c46848e1a1a9f9ae34c67.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (358)
[18091:18091:0712/193404.326790:INFO:CONSOLE(367)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://pic1.58cdn.com.cn/p1/big/n_v2968b03282d0c455c93cc7b2f881d6dd4.jpg'. This content should also be served over HTTPS.", source: https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl (367)
[18091:18091:0712/193404.351210:INFO:CONSOLE(1)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://img.58cdn.com.cn/ds/zhaoshang/img/fb_icon6.png'. This content should also be served over HTTPS.", source: https://tracklog.58.com/referrer4.js (1)
[18091:18091:0712/193404.352856:INFO:CONSOLE(1)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://img.58cdn.com.cn/ds/zhaoshang/img/icon_3.png'. This content should also be served over HTTPS.", source: https://tracklog.58.com/referrer4.js (1)
[18091:18091:0712/193404.354361:INFO:CONSOLE(1)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://img.58cdn.com.cn/ds/zhaoshang/img/icon_3.png'. This content should also be served over HTTPS.", source: https://tracklog.58.com/referrer4.js (1)
[18091:18091:0712/193404.355923:INFO:CONSOLE(1)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://img.58cdn.com.cn/ds/zhaoshang/img/fb_icon5.png'. This content should also be served over HTTPS.", source: https://tracklog.58.com/referrer4.js (1)
[18091:18091:0712/193404.357342:INFO:CONSOLE(1)] "Mixed Content: The page at 'https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl' was loaded over HTTPS, but requested an insecure image 'http://img.58cdn.com.cn/ds/zhaoshang/img/fb_banner.png'. This content should also be served over HTTPS.", source: https://tracklog.58.com/referrer4.js (1)
[3:3:0712/193404.363634:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/193404.470347:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 13.5316, 0, 0
[1:1:0712/193404.470572:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/193404.824406:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/193404.824628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
[1:1:0712/193405.237572:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/193405.237759:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193405.239141:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193405.240074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , D, (){e.addEventListener?(e.removeEventListener("DOMContentLoaded",D,!1),p.ready()):e.readyState==="com
[1:1:0712/193405.240256:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
[1:1:0712/193405.371067:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3978617e29c8, 0xd64bed23440
[1:1:0712/193405.371261:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", 0
[1:1:0712/193405.371555:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jiameng.58.com/, 370
[1:1:0712/193405.371697:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 370 0x7f2fddde1070 0xd64bf19bee0 , 5:3_https://jiameng.58.com/, 1, -5:3_https://jiameng.58.com/, 331 0x7f2fddde1070 0xd64bf1ea5e0 
[1:1:0712/193405.424376:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193405.425599:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "click", "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193405.860880:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , , document.readyState
[1:1:0712/193405.861074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
[1:1:0712/193405.883805:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_https://jiameng.58.com/, 370, 7f2fe0726881
[1:1:0712/193405.890467:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"2da83c062860","ptid":"331 0x7f2fddde1070 0xd64bf1ea5e0 ","rf":"5:3_https://jiameng.58.com/"}
[1:1:0712/193405.890632:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_https://jiameng.58.com/","ptid":"331 0x7f2fddde1070 0xd64bf1ea5e0 ","rf":"5:3_https://jiameng.58.com/"}
[1:1:0712/193405.890818:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193405.891132:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , , (){me.play();if(me.settings.pause){me.element.on("mouseover mouseout",function(e){me.stop();e.type==
[1:1:0712/193405.891224:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
[1:1:0712/193405.891877:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", 6000
[1:1:0712/193405.892096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_https://jiameng.58.com/, 410
[1:1:0712/193405.892197:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7f2fddde1070 0xd64bebf2ae0 , 5:3_https://jiameng.58.com/, 1, -5:3_https://jiameng.58.com/, 370 0x7f2fddde1070 0xd64bf19bee0 
[1:1:0712/193406.155984:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , , document.readyState
[1:1:0712/193406.156139:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
[1:1:0712/193406.333019:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl"
[1:1:0712/193406.333671:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , ready, (a){if(a===!0?--p.readyWait:p.isReady)return;if(!e.body)return setTimeout(p.ready,1);p.isReady=!0;if
[1:1:0712/193406.333857:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
[1:1:0712/193406.374215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_https://jiameng.58.com/, 2da83c062860, , , document.readyState
[1:1:0712/193406.374454:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://jiameng.58.com/investment/nologic/page?from=pc_fangxin_zhaoshangjiameng_cssywzl", "jiameng.58.com", 3, 1, , , 0
