[0713/022524.530005:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/022524.530267:INFO:switcher_clone.cc(787)] backtrace rip is 7f650c346891
[0713/022525.070698:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/022525.070944:INFO:switcher_clone.cc(787)] backtrace rip is 7f4489b92891
[1:1:0713/022525.074783:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/022525.074968:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/022525.077721:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/022525.903642:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/022525.903908:INFO:switcher_clone.cc(787)] backtrace rip is 7fa076f63891
[17891:17891:0713/022525.977477:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/2df1cd97-1f7e-4024-a581-13baab3a6367
[17924:17924:0713/022526.053116:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=17924
[17937:17937:0713/022526.053412:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=17937
[17891:17891:0713/022526.222058:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[17891:17922:0713/022526.222488:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/022526.222603:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/022526.222766:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/022526.223063:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/022526.223190:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/022526.224929:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x5ce98e8, 1
[1:1:0713/022526.225136:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x32616d7e, 0
[1:1:0713/022526.225264:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x338cbca7, 3
[1:1:0713/022526.225337:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x26d419f8, 2
[1:1:0713/022526.225457:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7e6d6132 ffffffe8ffffff98ffffffce05 fffffff819ffffffd426 ffffffa7ffffffbcffffff8c33 , 10104, 4
[1:1:0713/022526.226120:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[17891:17922:0713/022526.226231:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING~ma2����&���3�K,3
[1:1:0713/022526.226221:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4487dcc0a0, 3
[17891:17922:0713/022526.226284:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ~ma2����&���3��K,3
[1:1:0713/022526.226296:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4487f58080, 2
[17891:17922:0713/022526.226438:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[17891:17922:0713/022526.226483:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 17945, 4, 7e6d6132 e898ce05 f819d426 a7bc8c33 
[1:1:0713/022526.226367:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4471c1ad20, -2
[1:1:0713/022526.234139:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/022526.234561:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26d419f8
[1:1:0713/022526.235008:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26d419f8
[1:1:0713/022526.235737:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26d419f8
[1:1:0713/022526.236329:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.236447:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.236539:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.236613:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.236853:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26d419f8
[1:1:0713/022526.236975:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4489b927ba
[1:1:0713/022526.237046:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4489b89def, 7f4489b9277a, 7f4489b940cf
[1:1:0713/022526.238857:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 26d419f8
[1:1:0713/022526.239022:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 26d419f8
[1:1:0713/022526.239357:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 26d419f8
[1:1:0713/022526.240148:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.240271:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.240389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.240511:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 26d419f8
[1:1:0713/022526.240998:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 26d419f8
[1:1:0713/022526.241203:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4489b927ba
[1:1:0713/022526.241306:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4489b89def, 7f4489b9277a, 7f4489b940cf
[1:1:0713/022526.243812:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/022526.244019:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/022526.244132:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5cd3b7d8, 0x7ffd5cd3b758)
[1:1:0713/022526.250924:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/022526.253601:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[17891:17891:0713/022526.665135:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17891:17891:0713/022526.665683:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17891:17903:0713/022526.674213:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[17891:17903:0713/022526.674284:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[17891:17891:0713/022526.674329:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[17891:17891:0713/022526.674372:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[17891:17891:0713/022526.674441:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,17945, 4
[1:7:0713/022526.676631:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/022526.721743:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xf5e269b220
[1:1:0713/022526.721897:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[17891:17917:0713/022526.730782:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/022526.920730:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[17891:17903:0713/022527.327950:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -100
[1:1:0713/022527.690738:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/022527.692563:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[17891:17891:0713/022527.969594:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[17891:17891:0713/022527.969712:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/022528.192892:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022528.299129:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/022528.299332:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/022528.309694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/022528.309851:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/022528.342506:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022528.342670:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022528.497811:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 363, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022528.500300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/022528.500448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/022528.516958:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 364, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022528.519917:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/022528.520050:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/022528.523823:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[17891:17891:0713/022528.524476:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/022528.525651:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf5e2699e20
[1:1:0713/022528.525900:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[17891:17891:0713/022528.526920:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[17891:17891:0713/022528.538976:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[17891:17891:0713/022528.539066:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/022528.559345:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022528.850299:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7f44737f52e0 0xf5e2883ae0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022528.850991:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/022528.851146:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/022528.851728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[17891:17891:0713/022528.876849:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/022528.877697:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xf5e269a820
[1:1:0713/022528.878120:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[17891:17891:0713/022528.879154:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/022528.885178:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/022528.885376:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[17891:17891:0713/022528.886675:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[17891:17891:0713/022528.890511:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[17891:17891:0713/022528.890893:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[17891:17903:0713/022528.895225:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[17891:17903:0713/022528.895278:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[17891:17891:0713/022528.895376:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[17891:17891:0713/022528.895413:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[17891:17891:0713/022528.895470:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,17945, 4
[1:7:0713/022528.896918:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/022529.175890:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/022529.315092:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 471 0x7f44737f52e0 0xf5e2a4fde0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022529.315640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/022529.315757:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/022529.316072:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[17891:17891:0713/022529.478952:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[17891:17891:0713/022529.479066:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/022529.488391:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[17891:17891:0713/022529.586608:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[17891:17922:0713/022529.586880:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/022529.587003:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/022529.587136:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/022529.587321:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/022529.587401:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/022529.589708:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x2c62df9b, 1
[1:1:0713/022529.589933:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x273f7f61, 0
[1:1:0713/022529.590050:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1f53526a, 3
[1:1:0713/022529.590155:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1c4749a0, 2
[1:1:0713/022529.590257:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 617f3f27 ffffff9bffffffdf622c ffffffa049471c 6a52531f , 10104, 5
[1:1:0713/022529.590955:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[17891:17922:0713/022529.591135:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGa?'��b,�IGjRS�M,3
[17891:17922:0713/022529.591179:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is a?'��b,�IGjRSx�M,3
[1:1:0713/022529.591126:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4487dcc0a0, 3
[17891:17922:0713/022529.591310:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 17986, 5, 617f3f27 9bdf622c a049471c 6a52531f 
[1:1:0713/022529.591873:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4487f58080, 2
[1:1:0713/022529.591975:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4471c1ad20, -2
[1:1:0713/022529.601329:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/022529.601531:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1c4749a0
[1:1:0713/022529.601685:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1c4749a0
[1:1:0713/022529.601941:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1c4749a0
[1:1:0713/022529.602449:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.602545:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.602638:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.602730:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.602984:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1c4749a0
[1:1:0713/022529.603114:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4489b927ba
[1:1:0713/022529.603196:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4489b89def, 7f4489b9277a, 7f4489b940cf
[1:1:0713/022529.604859:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1c4749a0
[1:1:0713/022529.605020:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1c4749a0
[1:1:0713/022529.605331:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1c4749a0
[1:1:0713/022529.606125:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.606263:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.606384:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.606489:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1c4749a0
[1:1:0713/022529.606989:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1c4749a0
[1:1:0713/022529.607172:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4489b927ba
[1:1:0713/022529.607280:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4489b89def, 7f4489b9277a, 7f4489b940cf
[1:1:0713/022529.609863:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/022529.610096:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/022529.610209:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffd5cd3b7d8, 0x7ffd5cd3b758)
[1:1:0713/022529.616153:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/022529.618115:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/022529.625750:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022529.704486:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xf5e266a220
[1:1:0713/022529.704684:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/022529.901070:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022529.901264:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/022530.055503:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[17891:17891:0713/022530.056426:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:1:0713/022530.057299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2314ea4ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/022530.057469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[17891:17891:0713/022530.058326:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0713/022530.060026:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[17891:17891:0713/022530.078109:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://edu.jiameng.com/
[17891:17891:0713/022530.078167:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://edu.jiameng.com/, http://edu.jiameng.com/, 1
[17891:17891:0713/022530.078227:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://edu.jiameng.com/, HTTP/1.1 200 OK Server: Tengine Date: Fri, 12 Jul 2019 18:17:04 GMT Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,17986, 5
[17891:17903:0713/022530.078260:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[17891:17903:0713/022530.078313:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/022530.080139:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/022530.093498:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://edu.jiameng.com/
[1:1:0713/022530.108262:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/022530.108703:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 2314ea3c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/022530.108831:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[17891:17891:0713/022530.146043:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://edu.jiameng.com/, http://edu.jiameng.com/, 1
[17891:17891:0713/022530.146103:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://edu.jiameng.com/, http://edu.jiameng.com
[1:1:0713/022530.160089:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/022530.197672:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022530.216173:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/022530.238531:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022530.238735:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://edu.jiameng.com/"
[1:1:0713/022530.240086:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/022530.240823:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/022530.240955:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2314ea4ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/022530.241081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/022530.311809:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/022530.312310:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0713/022530.312443:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 2314ea4ee5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0713/022530.312650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/022530.523451:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/022530.628667:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022530.630137:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , $URL=function(){var D=function(E){var F=E.replace(/#(\d+)\$/g,function(G,H){return Array(+H+3).join(
[1:1:0713/022530.630314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022530.900655:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/022532.872644:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/022533.257537:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.367185:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.370811:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.371934:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.374444:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.376509:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.378511:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.424394:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.428058:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 182 0x7f4471c35bd0 0xf5e277da58 , "http://edu.jiameng.com/"
[1:1:0713/022533.596837:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.34291, 2079, 1
[1:1:0713/022533.597010:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022534.680313:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022534.680492:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://edu.jiameng.com/"
[1:1:0713/022534.682014:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7f44718cd070 0xf5e4425c60 , "http://edu.jiameng.com/"
[1:1:0713/022534.682618:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , jQuery.getPos = function(e) {
  var l = 0;
  var t = 0;
  var w = jQuery.intval(jQuery.css(e, 'wi
[1:1:0713/022534.682794:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022534.692993:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 331 0x7f44718cd070 0xf5e4425c60 , "http://edu.jiameng.com/"
[1:1:0713/022534.880764:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/022535.500338:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413, "http://edu.jiameng.com/"
[1:1:0713/022535.501383:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , /*!
 * Live800 Copyright 2019 GoldArmor Technology Inc.
 */
if(window.onerror=function(){return!0},!
[1:1:0713/022535.501563:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022535.553968:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 5000
[1:1:0713/022535.554249:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 519
[1:1:0713/022535.554427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 519 0x7f44718cd070 0xf5e4246ce0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 413
[1:1:0713/022535.556159:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 413, "http://edu.jiameng.com/"
[1:1:0713/022535.557984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://edu.jiameng.com/"
[1:1:0713/022535.566720:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0118921, 66, 1
[1:1:0713/022535.566887:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022536.311973:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 485 0x7f44737f52e0 0xf5e42652e0 , "http://edu.jiameng.com/"
[1:1:0713/022536.313739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (function(G,F,A){if(G.upLogger){return}var E="v0.4.5";var K={setCookie:function(P,T,R,O,Q,N){Q=K.get
[1:1:0713/022536.313939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022536.342489:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 486 0x7f44737f52e0 0xf5e28a44e0 , "http://edu.jiameng.com/"
[1:1:0713/022536.343267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , !function(){var e=/([http|https]:\/\/[a-zA-Z0-9\_\.]+\.baidu\.com)/gi,r=window.location.href,o=docum
[1:1:0713/022536.343461:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022536.805162:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022536.805325:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://edu.jiameng.com/"
[1:1:0713/022536.806411:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7f44718cd070 0xf5e4285060 , "http://edu.jiameng.com/"
[1:1:0713/022536.807764:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , /*! jQuery v1.8.2 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};ret
[1:1:0713/022536.807920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022536.881591:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7f44718cd070 0xf5e4285060 , "http://edu.jiameng.com/"
[1:1:0713/022536.893328:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7f44718cd070 0xf5e4285060 , "http://edu.jiameng.com/"
[1:1:0713/022536.896275:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 528 0x7f44718cd070 0xf5e4285060 , "http://edu.jiameng.com/"
		remove user.f_29f9515d -> 0
		remove user.e_cc105256 -> 0
[1:1:0713/022538.196126:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e4198
[1:1:0713/022538.196353:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022538.196559:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 702
[1:1:0713/022538.196710:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 702 0x7f44718cd070 0xf5e4d57c60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 528 0x7f44718cd070 0xf5e4285060 
[1:1:0713/022538.275763:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.47048, 0, 0
[1:1:0713/022538.275984:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022538.997893:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 601 0x7f44737f52e0 0xf5e4377be0 , "http://edu.jiameng.com/"
[1:1:0713/022539.005209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (function(){var h={},mt={},c={id:"97de9ca765f96d6e8245be3bc8b15cac",dm:["jiameng.com"],js:"tongji.ba
[1:1:0713/022539.006532:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022539.018794:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4190
[1:1:0713/022539.018996:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022539.019226:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 755
[1:1:0713/022539.019396:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 755 0x7f44718cd070 0xf5e43a7c60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 601 0x7f44737f52e0 0xf5e4377be0 
[17891:17891:0713/022551.719937:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -356
[17891:17891:0713/022551.749701:INFO:CONSOLE(26)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://chat56.live800.com/live800/chatClient/textStatic.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://chat56.live800.com/live800/chatClient/textButton.js?jid=3725594327&companyID=273370&configID=73507&codeType=custom (26)
[17891:17891:0713/022551.750568:INFO:CONSOLE(26)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://chat56.live800.com/live800/chatClient/textStatic.js, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://chat56.live800.com/live800/chatClient/textButton.js?jid=3725594327&companyID=273370&configID=73507&codeType=custom (26)
[3:3:0713/022551.845491:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/022551.945994:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 602 0x7f44737f52e0 0xf5e24f9d60 , "http://edu.jiameng.com/"
[1:1:0713/022551.947720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (function(){var h={},mt={},c={id:"88f653ceac701f5861a323d28823f600",dm:["jiameng.com"],js:"tongji.ba
[1:1:0713/022551.947920:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022551.956762:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4190
[1:1:0713/022551.956958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022551.957165:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 809
[1:1:0713/022551.957341:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 809 0x7f44718cd070 0xf5e4372c60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 602 0x7f44737f52e0 0xf5e24f9d60 
[1:1:0713/022552.070593:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 610 0x7f44737f52e0 0xf5e435c1e0 , "http://edu.jiameng.com/"
[1:1:0713/022552.074084:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (function(){var h={},mt={},c={id:"550cc1ca24d2ded09292d5e7695af507",dm:["jiameng.com","m2-jiameng-co
[1:1:0713/022552.074274:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022552.084593:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4148
[1:1:0713/022552.084801:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022552.085063:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 832
[1:1:0713/022552.085217:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 832 0x7f44718cd070 0xf5e439c560 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 610 0x7f44737f52e0 0xf5e435c1e0 
[1:1:0713/022553.379817:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022553.380008:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://edu.jiameng.com/"
[1:1:0713/022553.386553:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0065279, 56, 1
[1:1:0713/022553.386775:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/022553.511346:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 713 0x7f44737f52e0 0xf5e438f2e0 , "http://edu.jiameng.com/"
[1:1:0713/022553.513521:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (function(A,B,F){if(A.upLogger){return}var E={jsName:"up_beacon.js",defaultVer:201701101,getVersion:
[1:1:0713/022553.513706:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022554.263849:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/022554.264053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022554.957138:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 755, 7f4474212881
[1:1:0713/022554.970381:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"601 0x7f44737f52e0 0xf5e4377be0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022554.970604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"601 0x7f44737f52e0 0xf5e4377be0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022554.970873:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022554.971232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022554.971408:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022554.971887:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022554.972025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022554.972236:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 962
[1:1:0713/022554.972389:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 962 0x7f44718cd070 0xf5e2772760 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 755 0x7f44718cd070 0xf5e43a7c60 
[1:1:0713/022554.972914:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 519, 7f4474212881
[1:1:0713/022554.988180:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"413","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022554.988379:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"413","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022554.988591:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022554.989064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , startFlowCapacity()
[1:1:0713/022554.989176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022554.997303:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 702, 7f4474212881
[1:1:0713/022555.014312:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"528 0x7f44718cd070 0xf5e4285060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022555.014523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"528 0x7f44718cd070 0xf5e4285060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022555.014774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022555.015096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){opts.auto.progress&&opts.auto.progress.updater.call(opts.auto.progress.bar[0],100),opts.auto.onTi
[1:1:0713/022555.015200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022555.090760:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022555.090935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022555.091114:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 970
[1:1:0713/022555.091232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 970 0x7f44718cd070 0xf5e2718be0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 702 0x7f44718cd070 0xf5e4d57c60 
[1:1:0713/022555.101960:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 13
[1:1:0713/022555.102245:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 971
[1:1:0713/022555.102369:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 971 0x7f44718cd070 0xf5e4aa5c60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 702 0x7f44718cd070 0xf5e4d57c60 
[1:1:0713/022555.942511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 809, 7f4474212881
[1:1:0713/022555.957795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"602 0x7f44737f52e0 0xf5e24f9d60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022555.958010:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"602 0x7f44737f52e0 0xf5e24f9d60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022555.958277:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022555.958715:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022555.958839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022555.959204:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022555.959295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022555.959460:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 985
[1:1:0713/022555.959568:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 985 0x7f44718cd070 0xf5e55c98e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 809 0x7f44718cd070 0xf5e4372c60 
[1:1:0713/022556.071904:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 832, 7f4474212881
[1:1:0713/022556.088987:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"610 0x7f44737f52e0 0xf5e435c1e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022556.089219:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"610 0x7f44737f52e0 0xf5e435c1e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022556.089431:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022556.089706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022556.089810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022556.090178:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022556.090282:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022556.090459:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 993
[1:1:0713/022556.090576:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 993 0x7f44718cd070 0xf5e55c9d60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 832 0x7f44718cd070 0xf5e439c560 
[1:1:0713/022557.304924:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/022557.305172:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://edu.jiameng.com/"
[1:1:0713/022557.306169:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 920 0x7f44718cd070 0xf5e4a1d660 , "http://edu.jiameng.com/"
[1:1:0713/022557.306830:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.w
[1:1:0713/022557.306952:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[17891:17891:0713/022557.309067:INFO:CONSOLE(1360)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1255731443&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://edu.jiameng.com/ (1360)
[17891:17891:0713/022557.312946:INFO:CONSOLE(1360)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://s11.cnzz.com/z_stat.php?id=1255731443&show=pic, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://edu.jiameng.com/ (1360)
[1:1:0713/022557.804865:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , document.readyState
[1:1:0713/022557.805080:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.427581:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 962, 7f4474212881
[1:1:0713/022558.444525:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"755 0x7f44718cd070 0xf5e43a7c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.444747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"755 0x7f44718cd070 0xf5e43a7c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.444968:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022558.445283:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022558.445431:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.445772:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022558.445946:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022558.446172:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1041
[1:1:0713/022558.446336:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7f44718cd070 0xf5e484da60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 962 0x7f44718cd070 0xf5e2772760 
[1:1:0713/022558.446899:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 970, 7f4474212881
[1:1:0713/022558.462462:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"702 0x7f44718cd070 0xf5e4d57c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.462677:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"702 0x7f44718cd070 0xf5e4d57c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.462891:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022558.463175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022558.463285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.463857:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 971, 7f44742128db
[1:1:0713/022558.479980:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"702 0x7f44718cd070 0xf5e4d57c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.480173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"702 0x7f44718cd070 0xf5e4d57c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.480402:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1042
[1:1:0713/022558.480521:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1042 0x7f44718cd070 0xf5e4784860 , 5:3_http://edu.jiameng.com/, 0, , 971 0x7f44718cd070 0xf5e4aa5c60 
[1:1:0713/022558.480706:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022558.480971:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022558.481093:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.481686:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022558.481789:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022558.481949:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1043
[1:1:0713/022558.482059:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1043 0x7f44718cd070 0xf5e4372ce0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 971 0x7f44718cd070 0xf5e4aa5c60 
[1:1:0713/022558.501391:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022558.501580:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022558.501771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1045
[1:1:0713/022558.501912:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1045 0x7f44718cd070 0xf5e44289e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 971 0x7f44718cd070 0xf5e4aa5c60 
[1:1:0713/022558.646140:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 985, 7f4474212881
[1:1:0713/022558.663152:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"809 0x7f44718cd070 0xf5e4372c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.663372:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"809 0x7f44718cd070 0xf5e4372c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.663622:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022558.663942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022558.664081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.664443:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022558.664546:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022558.664705:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1058
[1:1:0713/022558.664815:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1058 0x7f44718cd070 0xf5e21ddb60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 985 0x7f44718cd070 0xf5e55c98e0 
[1:1:0713/022558.683042:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 994 0x7f44737f52e0 0xf5e43f8f60 , "http://edu.jiameng.com/"
[1:1:0713/022558.684507:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , window.lxb=window.lxb||{};lxb.instance=lxb.instance||0;lxb.instance++;(function(){var a={};lxb.add=l
[1:1:0713/022558.684613:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.756044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 993, 7f4474212881
[1:1:0713/022558.773511:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"832 0x7f44718cd070 0xf5e439c560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.773751:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"832 0x7f44718cd070 0xf5e439c560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022558.774020:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022558.774343:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022558.774492:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022558.774860:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022558.774979:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022558.775180:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1065
[1:1:0713/022558.775300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1065 0x7f44718cd070 0xf5e43fcde0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 993 0x7f44718cd070 0xf5e55c9d60 
[1:1:0713/022558.866114:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1002, "http://edu.jiameng.com/"
[1:1:0713/022558.867337:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (function(){function p(){this.c="1255731443";this.ca="z";this.Y="pic";this.V="";this.X="";this.D="15
[1:1:0713/022558.867451:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[17891:17891:0713/022558.894499:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1255731443&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1255731443&show=pic (17)
[17891:17891:0713/022558.899687:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=1255731443&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s11.cnzz.com/z_stat.php?id=1255731443&show=pic (17)
[1:1:0713/022559.051433:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , document.readyState
[1:1:0713/022559.051643:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022559.841087:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1043, 7f4474212881
[1:1:0713/022559.861329:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"971 0x7f44718cd070 0xf5e4aa5c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022559.861579:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"971 0x7f44718cd070 0xf5e4aa5c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022559.861856:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022559.862169:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022559.862307:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022559.915184:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022559.915608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/022559.915723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022559.953130:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022559.953512:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , t.onload, (){live800.utils.setSessionCookie("VisitorCapacity","1")}
[1:1:0713/022559.953628:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022559.954598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1041, 7f4474212881
[1:1:0713/022559.972576:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"962 0x7f44718cd070 0xf5e2772760 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022559.972779:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"962 0x7f44718cd070 0xf5e2772760 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022559.972978:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022559.973291:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022559.973403:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022559.973697:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022559.973802:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022559.973974:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1102
[1:1:0713/022559.974090:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1102 0x7f44718cd070 0xf5e4a1d5e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1041 0x7f44718cd070 0xf5e484da60 
[1:1:0713/022600.028036:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022600.028429:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/022600.028542:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022600.072587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022600.073001:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , f.onload, (){f.onload=u;f=window[d]=u;a&&a(b)}
[1:1:0713/022600.073122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022600.205127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1058, 7f4474212881
[1:1:0713/022600.223942:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"985 0x7f44718cd070 0xf5e55c98e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022600.224136:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"985 0x7f44718cd070 0xf5e55c98e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022600.224338:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022600.224607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022600.224705:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022600.224993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022600.225129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022600.225342:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1118
[1:1:0713/022600.225423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1118 0x7f44718cd070 0xf5e55d1ae0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1058 0x7f44718cd070 0xf5e21ddb60 
[1:1:0713/022600.453998:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1065, 7f4474212881
[1:1:0713/022600.470236:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"993 0x7f44718cd070 0xf5e55c9d60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022600.470402:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"993 0x7f44718cd070 0xf5e55c9d60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022600.470599:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022600.470872:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022600.470984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022600.471294:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022600.471399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022600.471566:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1124
[1:1:0713/022600.471687:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1124 0x7f44718cd070 0xf5e42622e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1065 0x7f44718cd070 0xf5e43fcde0 
[1:1:0713/022600.509124:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1081, "http://edu.jiameng.com/"
[1:1:0713/022600.509861:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0713/022600.510015:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022600.541451:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://edu.jiameng.com/"
[1:1:0713/022600.631811:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://edu.jiameng.com/"
[1:1:0713/022600.985123:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e41e0
[1:1:0713/022600.985307:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022600.985546:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1142
[1:1:0713/022600.985702:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1142 0x7f44718cd070 0xf5e5f9dee0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1081
[1:1:0713/022601.130107:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://edu.jiameng.com/"
[1:1:0713/022601.132065:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://edu.jiameng.com/"
[1:1:0713/022601.133785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://edu.jiameng.com/"
[1:1:0713/022601.135376:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://edu.jiameng.com/"
[1:1:0713/022601.253846:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , document.readyState
[1:1:0713/022601.254055:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022601.823125:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1102, 7f4474212881
[1:1:0713/022601.841103:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1041 0x7f44718cd070 0xf5e484da60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022601.841319:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1041 0x7f44718cd070 0xf5e484da60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022601.841563:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022601.841896:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022601.842070:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022601.842442:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022601.842571:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022601.842817:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1170
[1:1:0713/022601.842974:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7f44718cd070 0xf5e44ad360 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1102 0x7f44718cd070 0xf5e4a1d5e0 
[1:1:0713/022601.940095:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1121 0x7f44737f52e0 0xf5e573af60 , "http://edu.jiameng.com/"
[1:1:0713/022601.941025:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , /**/_lxb_jsonp_jy0fmg1k_({"status":0,"data":{"position":"51","phone":"","closeModule":"<ins class=\"
[1:1:0713/022601.941476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022601.944916:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4180
[1:1:0713/022601.945101:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022601.945317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1173
[1:1:0713/022601.945479:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1173 0x7f44718cd070 0xf5e4ab1260 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1121 0x7f44737f52e0 0xf5e573af60 
[1:1:0713/022602.006874:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1118, 7f4474212881
[1:1:0713/022602.027237:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1058 0x7f44718cd070 0xf5e21ddb60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.027436:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1058 0x7f44718cd070 0xf5e21ddb60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.027659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022602.027974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022602.028058:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.028352:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022602.028447:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022602.028606:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1181
[1:1:0713/022602.028718:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1181 0x7f44718cd070 0xf5e4a22be0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1118 0x7f44718cd070 0xf5e55d1ae0 
[1:1:0713/022602.394444:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://edu.jiameng.com/"
[1:1:0713/022602.394911:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , d, (a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cJ&&delete 
[1:1:0713/022602.395107:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.395749:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://edu.jiameng.com/"
[1:1:0713/022602.397096:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://edu.jiameng.com/"
[1:1:0713/022602.397443:INFO:event_target.cc(534)] !!!!!!!!!!!!!!!! RegisteredEventListener::SetCallback. 0x18bd40a1a4c0
[1:1:0713/022602.532987:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1124, 7f4474212881
[1:1:0713/022602.550581:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1065 0x7f44718cd070 0xf5e43fcde0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.550770:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1065 0x7f44718cd070 0xf5e43fcde0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.550977:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022602.551265:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022602.551385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.551693:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022602.551805:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022602.551984:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1207
[1:1:0713/022602.552118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1207 0x7f44718cd070 0xf5e22506e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1124 0x7f44718cd070 0xf5e42622e0 
[1:1:0713/022602.590578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1045, 7f4474212881
[1:1:0713/022602.608920:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"971 0x7f44718cd070 0xf5e4aa5c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.609134:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"971 0x7f44718cd070 0xf5e4aa5c60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.609328:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022602.609596:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){opts.auto.progress&&opts.auto.progress.updater.call(opts.auto.progress.bar[0],100),opts.auto.onTi
[1:1:0713/022602.609699:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.657127:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022602.657314:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022602.657513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1208
[1:1:0713/022602.657653:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1208 0x7f44718cd070 0xf5e43774e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1045 0x7f44718cd070 0xf5e44289e0 
[1:1:0713/022602.664266:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 13
[1:1:0713/022602.664512:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1209
[1:1:0713/022602.664625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1209 0x7f44718cd070 0xf5e27687e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1045 0x7f44718cd070 0xf5e44289e0 
[1:1:0713/022602.701049:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://edu.jiameng.com/"
[1:1:0713/022602.701454:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/022602.701557:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.740155:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , document.readyState
[1:1:0713/022602.740340:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.881352:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1170, 7f4474212881
[1:1:0713/022602.901558:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1102 0x7f44718cd070 0xf5e4a1d5e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.901750:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1102 0x7f44718cd070 0xf5e4a1d5e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.901949:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022602.902218:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022602.902320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022602.902609:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022602.902703:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022602.902868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1219
[1:1:0713/022602.902982:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1219 0x7f44718cd070 0xf5e4a1eae0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1170 0x7f44718cd070 0xf5e44ad360 
[1:1:0713/022602.903462:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1173, 7f4474212881
[1:1:0713/022602.922028:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1121 0x7f44737f52e0 0xf5e573af60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.922215:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1121 0x7f44737f52e0 0xf5e573af60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022602.922415:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022602.922681:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){var i=lxb.use("base").g(f);i.parentNode.removeChild(i)}
[1:1:0713/022602.922797:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.000556:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1181, 7f4474212881
[1:1:0713/022603.018894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1118 0x7f44718cd070 0xf5e55d1ae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.019071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1118 0x7f44718cd070 0xf5e55d1ae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.019267:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.019584:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022603.019692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.019993:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022603.020103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.020280:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1221
[1:1:0713/022603.020416:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1221 0x7f44718cd070 0xf5e2349e60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1181 0x7f44718cd070 0xf5e4a22be0 
[1:1:0713/022603.383848:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1207, 7f4474212881
[1:1:0713/022603.403115:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1124 0x7f44718cd070 0xf5e42622e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.403355:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1124 0x7f44718cd070 0xf5e42622e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.403623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.403918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022603.404076:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.404414:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022603.404569:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.404781:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1239
[1:1:0713/022603.404887:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1239 0x7f44718cd070 0xf5e5650ee0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1207 0x7f44718cd070 0xf5e22506e0 
[1:1:0713/022603.424935:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1208, 7f4474212881
[1:1:0713/022603.444222:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1045 0x7f44718cd070 0xf5e44289e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.444438:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1045 0x7f44718cd070 0xf5e44289e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.444634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.444887:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022603.444977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.445457:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1209, 7f44742128db
[1:1:0713/022603.463332:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1045 0x7f44718cd070 0xf5e44289e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.463485:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1045 0x7f44718cd070 0xf5e44289e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.463691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1240
[1:1:0713/022603.463797:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7f44718cd070 0xf5e4425260 , 5:3_http://edu.jiameng.com/, 0, , 1209 0x7f44718cd070 0xf5e27687e0 
[1:1:0713/022603.463966:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.464192:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022603.464277:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.464600:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022603.464718:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022603.464874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1241
[1:1:0713/022603.464975:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1241 0x7f44718cd070 0xf5e439c260 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1209 0x7f44718cd070 0xf5e27687e0 
[1:1:0713/022603.481956:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022603.482121:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022603.482291:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1243
[1:1:0713/022603.482402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1243 0x7f44718cd070 0xf5e438fee0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1209 0x7f44718cd070 0xf5e27687e0 
[1:1:0713/022603.504518:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , document.readyState
[1:1:0713/022603.504696:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.602903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1219, 7f4474212881
[1:1:0713/022603.622305:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1170 0x7f44718cd070 0xf5e44ad360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.622516:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1170 0x7f44718cd070 0xf5e44ad360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.622738:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.623062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022603.623232:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.623551:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022603.623663:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.623850:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1250
[1:1:0713/022603.623976:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7f44718cd070 0xf5e423e6e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1219 0x7f44718cd070 0xf5e4a1eae0 
[1:1:0713/022603.643184:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1221, 7f4474212881
[1:1:0713/022603.662647:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1181 0x7f44718cd070 0xf5e4a22be0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.662849:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1181 0x7f44718cd070 0xf5e4a22be0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.663058:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.663342:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022603.663455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.663770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022603.663861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.664023:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1251
[1:1:0713/022603.664123:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1251 0x7f44718cd070 0xf5e271a660 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1221 0x7f44718cd070 0xf5e2349e60 
[1:1:0713/022603.798756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.799193:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0713/022603.799314:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.800227:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.800549:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.800819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.801109:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.801406:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.801683:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://edu.jiameng.com/"
[1:1:0713/022603.802480:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://edu.jiameng.com/"
[1:1:0713/022603.803078:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e42f0
[1:1:0713/022603.803194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.803377:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1254
[1:1:0713/022603.803504:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1254 0x7f44718cd070 0xf5e4d57ae0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1236 0x7f44718cd070 0xf5e4df7a60 
[1:1:0713/022603.803759:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://edu.jiameng.com/"
[1:1:0713/022603.804199:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e41f0
[1:1:0713/022603.804296:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.804450:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1255
[1:1:0713/022603.804549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1255 0x7f44718cd070 0xf5e49cd760 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1236 0x7f44718cd070 0xf5e4df7a60 
[1:1:0713/022603.804741:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "pageshow", "http://edu.jiameng.com/"
[1:1:0713/022603.805171:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e41f0
[1:1:0713/022603.805357:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022603.805603:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1256
[1:1:0713/022603.805762:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1256 0x7f44718cd070 0xf5e61e7a60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1236 0x7f44718cd070 0xf5e4df7a60 
[1:1:0713/022603.948044:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1241, 7f4474212881
[1:1:0713/022603.966565:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1209 0x7f44718cd070 0xf5e27687e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.966747:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1209 0x7f44718cd070 0xf5e27687e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.966948:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.967215:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022603.967326:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022603.967758:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1142, 7f4474212881
[1:1:0713/022603.985216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1081","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.985384:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1081","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022603.985579:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022603.985840:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){opts.auto.progress&&opts.auto.progress.updater.call(opts.auto.progress.bar[0],100),opts.auto.onTi
[1:1:0713/022603.985959:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.022758:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.022936:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022604.023131:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1271
[1:1:0713/022604.023250:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1271 0x7f44718cd070 0xf5e4d6eb60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1142 0x7f44718cd070 0xf5e5f9dee0 
[1:1:0713/022604.029495:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 13
[1:1:0713/022604.029799:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1273
[1:1:0713/022604.029930:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1273 0x7f44718cd070 0xf5e44c3fe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1142 0x7f44718cd070 0xf5e5f9dee0 
[1:1:0713/022604.069648:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , document.readyState
[1:1:0713/022604.069840:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.204646:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1254, 7f4474212881
[1:1:0713/022604.224102:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1236 0x7f44718cd070 0xf5e4df7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.224321:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1236 0x7f44718cd070 0xf5e4df7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.224549:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.224927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022604.225074:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.225521:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.225674:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022604.225898:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1285
[1:1:0713/022604.226065:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1285 0x7f44718cd070 0xf5e4276260 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1254 0x7f44718cd070 0xf5e4d57ae0 
[1:1:0713/022604.226670:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1255, 7f4474212881
[1:1:0713/022604.244860:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1236 0x7f44718cd070 0xf5e4df7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.245054:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1236 0x7f44718cd070 0xf5e4df7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.245285:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.245544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022604.245664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.245939:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.246056:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022604.246215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1286
[1:1:0713/022604.246325:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1286 0x7f44718cd070 0xf5e49c5ee0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1255 0x7f44718cd070 0xf5e49cd760 
[1:1:0713/022604.246819:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1256, 7f4474212881
[1:1:0713/022604.266666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1236 0x7f44718cd070 0xf5e4df7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.266860:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1236 0x7f44718cd070 0xf5e4df7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.267069:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.267358:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022604.267459:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.267744:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.267838:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022604.267996:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1287
[1:1:0713/022604.268089:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1287 0x7f44718cd070 0xf5e62f58e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1256 0x7f44718cd070 0xf5e61e7a60 
[1:1:0713/022604.563413:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1271, 7f4474212881
[1:1:0713/022604.582427:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1142 0x7f44718cd070 0xf5e5f9dee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.582619:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1142 0x7f44718cd070 0xf5e5f9dee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.582830:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.583135:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022604.583253:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.602049:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1273, 7f44742128db
[1:1:0713/022604.619075:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1142 0x7f44718cd070 0xf5e5f9dee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.619237:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1142 0x7f44718cd070 0xf5e5f9dee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.619449:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1303
[1:1:0713/022604.619566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1303 0x7f44718cd070 0xf5e49fd1e0 , 5:3_http://edu.jiameng.com/, 0, , 1273 0x7f44718cd070 0xf5e44c3fe0 
[1:1:0713/022604.619762:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.620009:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022604.620111:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.620440:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.620533:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022604.620671:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1304
[1:1:0713/022604.620761:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1304 0x7f44718cd070 0xf5e4d65660 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1273 0x7f44718cd070 0xf5e44c3fe0 
[1:1:0713/022604.636082:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.636224:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022604.636382:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1306
[1:1:0713/022604.636477:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1306 0x7f44718cd070 0xf5e27c2260 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1273 0x7f44718cd070 0xf5e44c3fe0 
[1:1:0713/022604.751115:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1285, 7f4474212881
[1:1:0713/022604.768857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1254 0x7f44718cd070 0xf5e4d57ae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.769024:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1254 0x7f44718cd070 0xf5e4d57ae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.769231:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.769517:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022604.769619:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.769894:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.769974:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022604.770117:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1312
[1:1:0713/022604.770214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1312 0x7f44718cd070 0xf5e2349660 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1285 0x7f44718cd070 0xf5e4276260 
[1:1:0713/022604.806522:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1286, 7f4474212881
[1:1:0713/022604.824951:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1255 0x7f44718cd070 0xf5e49cd760 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.825208:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1255 0x7f44718cd070 0xf5e49cd760 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.825401:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.825684:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022604.825787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.826073:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.826167:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022604.826322:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1313
[1:1:0713/022604.826427:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1313 0x7f44718cd070 0xf5e427fe60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1286 0x7f44718cd070 0xf5e49c5ee0 
[1:1:0713/022604.826872:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1287, 7f4474212881
[1:1:0713/022604.845175:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1256 0x7f44718cd070 0xf5e61e7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.845347:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1256 0x7f44718cd070 0xf5e61e7a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022604.845550:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022604.845809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022604.845921:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022604.846209:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022604.846315:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022604.846478:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1314
[1:1:0713/022604.846603:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1314 0x7f44718cd070 0xf5e2670f60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1287 0x7f44718cd070 0xf5e62f58e0 
[1:1:0713/022605.058054:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1304, 7f4474212881
[1:1:0713/022605.075255:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1273 0x7f44718cd070 0xf5e44c3fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.075427:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1273 0x7f44718cd070 0xf5e44c3fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.075634:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.075908:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022605.076023:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.112578:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1312, 7f4474212881
[1:1:0713/022605.131447:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1285 0x7f44718cd070 0xf5e4276260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.131648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1285 0x7f44718cd070 0xf5e4276260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.131881:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.132157:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.132275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.132585:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.132677:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.132839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1327
[1:1:0713/022605.132946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7f44718cd070 0xf5e24fd860 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1312 0x7f44718cd070 0xf5e2349660 
[1:1:0713/022605.169082:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1313, 7f4474212881
[1:1:0713/022605.186386:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1286 0x7f44718cd070 0xf5e49c5ee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.186564:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1286 0x7f44718cd070 0xf5e49c5ee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.186775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.187054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.187175:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.187481:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.187631:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.187835:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1328
[1:1:0713/022605.187963:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1328 0x7f44718cd070 0xf5e4848560 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1313 0x7f44718cd070 0xf5e427fe60 
[1:1:0713/022605.206934:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1314, 7f4474212881
[1:1:0713/022605.225042:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1287 0x7f44718cd070 0xf5e62f58e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.225266:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1287 0x7f44718cd070 0xf5e62f58e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.225481:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.225763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.225891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.226197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.226308:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.226484:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1329
[1:1:0713/022605.226612:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7f44718cd070 0xf5e645b4e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1314 0x7f44718cd070 0xf5e2670f60 
[1:1:0713/022605.355534:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1327, 7f4474212881
[1:1:0713/022605.373596:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1312 0x7f44718cd070 0xf5e2349660 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.373780:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1312 0x7f44718cd070 0xf5e2349660 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.373988:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.374264:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.374379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.374678:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.374777:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.374934:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1337
[1:1:0713/022605.375043:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1337 0x7f44718cd070 0xf5e55d15e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1327 0x7f44718cd070 0xf5e24fd860 
[1:1:0713/022605.375570:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1328, 7f4474212881
[1:1:0713/022605.393788:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1313 0x7f44718cd070 0xf5e427fe60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.393949:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1313 0x7f44718cd070 0xf5e427fe60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.394146:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.394392:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.394505:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.395753:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.395847:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.396039:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1338
[1:1:0713/022605.396133:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7f44718cd070 0xf5e267ba60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1328 0x7f44718cd070 0xf5e4848560 
[1:1:0713/022605.396590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1329, 7f4474212881
[1:1:0713/022605.414304:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1314 0x7f44718cd070 0xf5e2670f60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.414465:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1314 0x7f44718cd070 0xf5e2670f60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.414651:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.414895:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.414984:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.415234:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.415328:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.415483:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1339
[1:1:0713/022605.415586:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1339 0x7f44718cd070 0xf5e5650060 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1329 0x7f44718cd070 0xf5e645b4e0 
[1:1:0713/022605.483800:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1337, 7f4474212881
[1:1:0713/022605.501640:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1327 0x7f44718cd070 0xf5e24fd860 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.501806:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1327 0x7f44718cd070 0xf5e24fd860 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.502021:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.502289:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.502393:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.503288:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.503397:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.503567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1345
[1:1:0713/022605.503671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7f44718cd070 0xf5e4ab9fe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1337 0x7f44718cd070 0xf5e55d15e0 
[1:1:0713/022605.556865:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1338, 7f4474212881
[1:1:0713/022605.574681:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1328 0x7f44718cd070 0xf5e4848560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.574847:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1328 0x7f44718cd070 0xf5e4848560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.575048:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.575371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.575472:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.575768:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.575866:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.576033:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1352
[1:1:0713/022605.576144:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1352 0x7f44718cd070 0xf5e2250960 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1338 0x7f44718cd070 0xf5e267ba60 
[1:1:0713/022605.576625:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1339, 7f4474212881
[1:1:0713/022605.594588:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1329 0x7f44718cd070 0xf5e645b4e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.594746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1329 0x7f44718cd070 0xf5e645b4e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.594941:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.595188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.595292:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.595570:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.595670:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.595825:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1353
[1:1:0713/022605.595918:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1353 0x7f44718cd070 0xf5e423efe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1339 0x7f44718cd070 0xf5e5650060 
[1:1:0713/022605.649910:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1345, 7f4474212881
[1:1:0713/022605.667429:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1337 0x7f44718cd070 0xf5e55d15e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.667593:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1337 0x7f44718cd070 0xf5e55d15e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.667791:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.668060:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.668170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.668481:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.668576:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.668728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1358
[1:1:0713/022605.668820:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1358 0x7f44718cd070 0xf5e4d69be0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1345 0x7f44718cd070 0xf5e4ab9fe0 
[1:1:0713/022605.688245:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1352, 7f4474212881
[1:1:0713/022605.706140:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1338 0x7f44718cd070 0xf5e267ba60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.706306:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1338 0x7f44718cd070 0xf5e267ba60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.706501:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.706763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.706876:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.707181:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.707306:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.707501:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1361
[1:1:0713/022605.707608:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1361 0x7f44718cd070 0xf5e22835e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1352 0x7f44718cd070 0xf5e2250960 
[1:1:0713/022605.743147:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1353, 7f4474212881
[1:1:0713/022605.760257:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1339 0x7f44718cd070 0xf5e5650060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.760420:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1339 0x7f44718cd070 0xf5e5650060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.760603:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.760850:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.760953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.761236:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.761341:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.761511:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1365
[1:1:0713/022605.761627:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1365 0x7f44718cd070 0xf5e26c48e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1353 0x7f44718cd070 0xf5e423efe0 
[1:1:0713/022605.814587:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1358, 7f4474212881
[1:1:0713/022605.832002:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1345 0x7f44718cd070 0xf5e4ab9fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.832185:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1345 0x7f44718cd070 0xf5e4ab9fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.832418:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.832693:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.832801:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.833148:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.833240:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.833378:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1374
[1:1:0713/022605.833467:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1374 0x7f44718cd070 0xf5e62d54e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1358 0x7f44718cd070 0xf5e4d69be0 
[1:1:0713/022605.833979:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1361, 7f4474212881
[1:1:0713/022605.856264:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1352 0x7f44718cd070 0xf5e2250960 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.856461:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1352 0x7f44718cd070 0xf5e2250960 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022605.856659:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022605.856929:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022605.857011:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022605.857338:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022605.857452:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022605.857754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1378
[1:1:0713/022605.857869:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1378 0x7f44718cd070 0xf5e2670a60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1361 0x7f44718cd070 0xf5e22835e0 
[1:1:0713/022606.060563:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1365, 7f4474212881
[1:1:0713/022606.078730:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1353 0x7f44718cd070 0xf5e423efe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.078887:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1353 0x7f44718cd070 0xf5e423efe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.079086:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.079350:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.079458:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.079754:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.079861:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.080030:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1403
[1:1:0713/022606.080127:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1403 0x7f44718cd070 0xf5e63711e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1365 0x7f44718cd070 0xf5e26c48e0 
[1:1:0713/022606.116544:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1374, 7f4474212881
[1:1:0713/022606.133878:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1358 0x7f44718cd070 0xf5e4d69be0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.134041:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1358 0x7f44718cd070 0xf5e4d69be0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.134243:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.134499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.134612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.134902:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.135007:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.135181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1404
[1:1:0713/022606.135291:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1404 0x7f44718cd070 0xf5e2774fe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1374 0x7f44718cd070 0xf5e62d54e0 
[1:1:0713/022606.171826:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1378, 7f4474212881
[1:1:0713/022606.189570:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1361 0x7f44718cd070 0xf5e22835e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.189734:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1361 0x7f44718cd070 0xf5e22835e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.189933:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.190190:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.190304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.190594:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.190698:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.190866:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1406
[1:1:0713/022606.190983:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1406 0x7f44718cd070 0xf5e667c060 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1378 0x7f44718cd070 0xf5e2670a60 
[1:1:0713/022606.333043:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1243, 7f4474212881
[1:1:0713/022606.351371:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1209 0x7f44718cd070 0xf5e27687e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.351542:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1209 0x7f44718cd070 0xf5e27687e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.351750:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.352032:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){opts.auto.progress&&opts.auto.progress.updater.call(opts.auto.progress.bar[0],100),opts.auto.onTi
[1:1:0713/022606.352145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.385931:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.386079:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022606.386259:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1417
[1:1:0713/022606.386377:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1417 0x7f44718cd070 0xf5e433ee60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1243 0x7f44718cd070 0xf5e438fee0 
[1:1:0713/022606.409866:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 13
[1:1:0713/022606.410109:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1418
[1:1:0713/022606.410232:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1418 0x7f44718cd070 0xf5e667c660 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1243 0x7f44718cd070 0xf5e438fee0 
[1:1:0713/022606.521791:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1403, 7f4474212881
[1:1:0713/022606.540395:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1365 0x7f44718cd070 0xf5e26c48e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.540577:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1365 0x7f44718cd070 0xf5e26c48e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.540764:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.541054:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.541209:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.541554:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.541660:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.541874:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1427
[1:1:0713/022606.541992:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1427 0x7f44718cd070 0xf5e645ba60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1403 0x7f44718cd070 0xf5e63711e0 
[1:1:0713/022606.561663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1404, 7f4474212881
[1:1:0713/022606.580178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1374 0x7f44718cd070 0xf5e62d54e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.580349:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1374 0x7f44718cd070 0xf5e62d54e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.580556:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.580802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.580889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.581175:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.581269:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.581422:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1428
[1:1:0713/022606.581526:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1428 0x7f44718cd070 0xf5e664a060 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1404 0x7f44718cd070 0xf5e2774fe0 
[1:1:0713/022606.582081:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1406, 7f4474212881
[1:1:0713/022606.601076:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1378 0x7f44718cd070 0xf5e2670a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.601248:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1378 0x7f44718cd070 0xf5e2670a60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.601442:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.601719:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.601832:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.602117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.602222:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.602384:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1430
[1:1:0713/022606.602476:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1430 0x7f44718cd070 0xf5e26cd360 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1406 0x7f44718cd070 0xf5e667c060 
[1:1:0713/022606.683514:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1417, 7f4474212881
[1:1:0713/022606.704048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1243 0x7f44718cd070 0xf5e438fee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.704251:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1243 0x7f44718cd070 0xf5e438fee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.704459:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.704720:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022606.704820:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.724586:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1418, 7f44742128db
[1:1:0713/022606.742727:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1243 0x7f44718cd070 0xf5e438fee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.742894:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1243 0x7f44718cd070 0xf5e438fee0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.743108:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1438
[1:1:0713/022606.743225:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1438 0x7f44718cd070 0xf5e66801e0 , 5:3_http://edu.jiameng.com/, 0, , 1418 0x7f44718cd070 0xf5e667c660 
[1:1:0713/022606.743420:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.743694:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022606.743800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.744147:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.744247:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022606.744405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1439
[1:1:0713/022606.744512:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1439 0x7f44718cd070 0xf5e66fd5e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1418 0x7f44718cd070 0xf5e667c660 
[1:1:0713/022606.746105:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1427, 7f4474212881
[1:1:0713/022606.766137:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1403 0x7f44718cd070 0xf5e63711e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.766347:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1403 0x7f44718cd070 0xf5e63711e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.766587:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.766892:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.767039:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.767360:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.767491:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.767656:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1441
[1:1:0713/022606.767770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1441 0x7f44718cd070 0xf5e66fdde0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1427 0x7f44718cd070 0xf5e645ba60 
[1:1:0713/022606.768267:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1428, 7f4474212881
[1:1:0713/022606.787384:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1404 0x7f44718cd070 0xf5e2774fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.787552:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1404 0x7f44718cd070 0xf5e2774fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.787748:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.788002:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.788112:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.788401:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.788484:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.788652:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1444
[1:1:0713/022606.788746:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1444 0x7f44718cd070 0xf5e22bafe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1428 0x7f44718cd070 0xf5e664a060 
[1:1:0713/022606.864654:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1430, 7f4474212881
[1:1:0713/022606.884291:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1406 0x7f44718cd070 0xf5e667c060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.884476:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1406 0x7f44718cd070 0xf5e667c060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022606.884666:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022606.884957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022606.885098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022606.885400:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022606.885505:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022606.885691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1447
[1:1:0713/022606.885807:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1447 0x7f44718cd070 0xf5e667cae0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1430 0x7f44718cd070 0xf5e26cd360 
[1:1:0713/022606.986906:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1438, 7f44742128db
[1:1:0713/022607.007121:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1418 0x7f44718cd070 0xf5e667c660 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.007269:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1418 0x7f44718cd070 0xf5e667c660 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.007475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1456
[1:1:0713/022607.007591:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1456 0x7f44718cd070 0xf5e26cd360 , 5:3_http://edu.jiameng.com/, 0, , 1438 0x7f44718cd070 0xf5e66801e0 
[1:1:0713/022607.007781:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.008062:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022607.008166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.009476:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1439, 7f4474212881
[1:1:0713/022607.030658:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1418 0x7f44718cd070 0xf5e667c660 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.030811:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1418 0x7f44718cd070 0xf5e667c660 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.030997:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.031245:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022607.031344:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.089055:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1441, 7f4474212881
[1:1:0713/022607.106933:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1427 0x7f44718cd070 0xf5e645ba60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.107107:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1427 0x7f44718cd070 0xf5e645ba60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.107302:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.107567:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.107686:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.107971:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.108063:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.108223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1459
[1:1:0713/022607.108326:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1459 0x7f44718cd070 0xf5e664a0e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1441 0x7f44718cd070 0xf5e66fdde0 
[1:1:0713/022607.127440:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1444, 7f4474212881
[1:1:0713/022607.145496:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1428 0x7f44718cd070 0xf5e664a060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.145659:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1428 0x7f44718cd070 0xf5e664a060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.145852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.146108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.146219:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.146531:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.146629:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.146793:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1460
[1:1:0713/022607.146911:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1460 0x7f44718cd070 0xf5e435c8e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1444 0x7f44718cd070 0xf5e22bafe0 
[1:1:0713/022607.147406:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1447, 7f4474212881
[1:1:0713/022607.165937:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1430 0x7f44718cd070 0xf5e26cd360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.166102:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1430 0x7f44718cd070 0xf5e26cd360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.166295:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.166539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.166651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.166946:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.167040:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.167200:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1462
[1:1:0713/022607.167304:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1462 0x7f44718cd070 0xf5e26300e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1447 0x7f44718cd070 0xf5e667cae0 
[1:1:0713/022607.204523:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1456, 7f44742128db
[1:1:0713/022607.222465:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1438 0x7f44718cd070 0xf5e66801e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.222620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1438 0x7f44718cd070 0xf5e66801e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.222829:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1464
[1:1:0713/022607.222944:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1464 0x7f44718cd070 0xf5e4d65f60 , 5:3_http://edu.jiameng.com/, 0, , 1456 0x7f44718cd070 0xf5e26cd360 
[1:1:0713/022607.223121:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.223371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022607.223508:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.223852:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.223959:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022607.224104:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1465
[1:1:0713/022607.224198:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1465 0x7f44718cd070 0xf5e54e1060 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1456 0x7f44718cd070 0xf5e26cd360 
[1:1:0713/022607.238848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.239001:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022607.239160:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1467
[1:1:0713/022607.239266:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1467 0x7f44718cd070 0xf5e434c4e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1456 0x7f44718cd070 0xf5e26cd360 
[1:1:0713/022607.241903:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1306, 7f4474212881
[1:1:0713/022607.262133:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1273 0x7f44718cd070 0xf5e44c3fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.262309:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1273 0x7f44718cd070 0xf5e44c3fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.262509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.262773:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){opts.auto.progress&&opts.auto.progress.updater.call(opts.auto.progress.bar[0],100),opts.auto.onTi
[1:1:0713/022607.262885:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.306037:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 13
[1:1:0713/022607.306277:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1471
[1:1:0713/022607.306397:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1471 0x7f44718cd070 0xf5e4df6560 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1306 0x7f44718cd070 0xf5e27c2260 
[1:1:0713/022607.437637:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1459, 7f4474212881
[1:1:0713/022607.458265:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1441 0x7f44718cd070 0xf5e66fdde0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.458492:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1441 0x7f44718cd070 0xf5e66fdde0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.458774:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.459130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.459250:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.459574:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.459679:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.459839:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1482
[1:1:0713/022607.459946:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1482 0x7f44718cd070 0xf5e22e3260 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1459 0x7f44718cd070 0xf5e664a0e0 
[1:1:0713/022607.460429:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1465, 7f4474212881
[1:1:0713/022607.480283:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1456 0x7f44718cd070 0xf5e26cd360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.480454:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1456 0x7f44718cd070 0xf5e26cd360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.480658:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.480901:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022607.481005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.481412:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1460, 7f4474212881
[1:1:0713/022607.500114:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1444 0x7f44718cd070 0xf5e22bafe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.500278:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1444 0x7f44718cd070 0xf5e22bafe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.500471:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.500711:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.500810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.501138:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.501244:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.501412:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1483
[1:1:0713/022607.501528:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1483 0x7f44718cd070 0xf5e66f9ce0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1460 0x7f44718cd070 0xf5e435c8e0 
[1:1:0713/022607.520830:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1462, 7f4474212881
[1:1:0713/022607.539935:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1447 0x7f44718cd070 0xf5e667cae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.540123:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1447 0x7f44718cd070 0xf5e667cae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.540349:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.540628:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.540738:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.541063:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.541179:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.541370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1485
[1:1:0713/022607.541470:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1485 0x7f44718cd070 0xf5e665d4e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1462 0x7f44718cd070 0xf5e26300e0 
[1:1:0713/022607.567319:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1471, 7f44742128db
[1:1:0713/022607.587995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1306 0x7f44718cd070 0xf5e27c2260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.588249:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1306 0x7f44718cd070 0xf5e27c2260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.588531:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1491
[1:1:0713/022607.588650:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1491 0x7f44718cd070 0xf5e54e1160 , 5:3_http://edu.jiameng.com/, 0, , 1471 0x7f44718cd070 0xf5e4df6560 
[1:1:0713/022607.588852:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.589136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022607.589271:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.589634:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.589721:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022607.589853:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1492
[1:1:0713/022607.589942:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1492 0x7f44718cd070 0xf5e6700ee0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1471 0x7f44718cd070 0xf5e4df6560 
[1:1:0713/022607.766127:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1482, 7f4474212881
[1:1:0713/022607.785009:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1459 0x7f44718cd070 0xf5e664a0e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.785199:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1459 0x7f44718cd070 0xf5e664a0e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.785395:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.785673:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.785787:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.786109:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.786208:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.786370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1502
[1:1:0713/022607.786481:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1502 0x7f44718cd070 0xf5e645bbe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1482 0x7f44718cd070 0xf5e22e3260 
[1:1:0713/022607.909237:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1491, 7f44742128db
[1:1:0713/022607.933789:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1471 0x7f44718cd070 0xf5e4df6560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.933993:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1471 0x7f44718cd070 0xf5e4df6560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.934274:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1506
[1:1:0713/022607.934408:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1506 0x7f44718cd070 0xf5e6816ce0 , 5:3_http://edu.jiameng.com/, 0, , 1491 0x7f44718cd070 0xf5e54e1160 
[1:1:0713/022607.934610:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.934893:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022607.935018:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.936358:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1492, 7f4474212881
[1:1:0713/022607.958128:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1471 0x7f44718cd070 0xf5e4df6560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.958305:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1471 0x7f44718cd070 0xf5e4df6560 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.958518:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.958786:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022607.958905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.959343:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1483, 7f4474212881
[1:1:0713/022607.979183:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1460 0x7f44718cd070 0xf5e435c8e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.979361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1460 0x7f44718cd070 0xf5e435c8e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022607.979551:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022607.979805:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022607.979923:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022607.980225:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022607.980337:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022607.980514:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1508
[1:1:0713/022607.980625:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1508 0x7f44718cd070 0xf5e6864260 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1483 0x7f44718cd070 0xf5e66f9ce0 
[1:1:0713/022608.001211:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1485, 7f4474212881
[1:1:0713/022608.020568:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1462 0x7f44718cd070 0xf5e26300e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.020746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1462 0x7f44718cd070 0xf5e26300e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.020939:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.021214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.021331:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.021641:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.021752:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.021930:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1509
[1:1:0713/022608.022056:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1509 0x7f44718cd070 0xf5e6863fe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1485 0x7f44718cd070 0xf5e665d4e0 
[1:1:0713/022608.022509:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1502, 7f4474212881
[1:1:0713/022608.042301:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1482 0x7f44718cd070 0xf5e22e3260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.042479:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1482 0x7f44718cd070 0xf5e22e3260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.042684:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.042950:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.043068:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.043369:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.043479:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.043642:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1510
[1:1:0713/022608.043752:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1510 0x7f44718cd070 0xf5e664a6e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1502 0x7f44718cd070 0xf5e645bbe0 
[1:1:0713/022608.044188:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1506, 7f44742128db
[1:1:0713/022608.064064:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1491 0x7f44718cd070 0xf5e54e1160 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.064231:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1491 0x7f44718cd070 0xf5e54e1160 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.064453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://edu.jiameng.com/, 1511
[1:1:0713/022608.064574:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1511 0x7f44718cd070 0xf5e4a7f2e0 , 5:3_http://edu.jiameng.com/, 0, , 1506 0x7f44718cd070 0xf5e6816ce0 
[1:1:0713/022608.064755:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.064997:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , p.fx.tick, (){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.st
[1:1:0713/022608.065100:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.065445:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.065559:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 0
[1:1:0713/022608.065728:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1512
[1:1:0713/022608.065846:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1512 0x7f44718cd070 0xf5e36b70e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1506 0x7f44718cd070 0xf5e6816ce0 
[1:1:0713/022608.080997:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2500, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.081177:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 2500
[1:1:0713/022608.081392:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1513
[1:1:0713/022608.081516:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1513 0x7f44718cd070 0xf5e66fd460 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1506 0x7f44718cd070 0xf5e6816ce0 
[1:1:0713/022608.126205:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1512, 7f4474212881
[1:1:0713/022608.146178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1506 0x7f44718cd070 0xf5e6816ce0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.146426:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1506 0x7f44718cd070 0xf5e6816ce0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.146671:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.146976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , , (){cN=b}
[1:1:0713/022608.147118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.147594:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1508, 7f4474212881
[1:1:0713/022608.167905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1483 0x7f44718cd070 0xf5e66f9ce0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.168068:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1483 0x7f44718cd070 0xf5e66f9ce0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.168263:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.168524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.168632:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.168909:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.168978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.169164:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1520
[1:1:0713/022608.169279:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1520 0x7f44718cd070 0xf5e49e9460 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1508 0x7f44718cd070 0xf5e6864260 
[1:1:0713/022608.169728:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1509, 7f4474212881
[1:1:0713/022608.190076:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1485 0x7f44718cd070 0xf5e665d4e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.190256:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1485 0x7f44718cd070 0xf5e665d4e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.190453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.190706:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.190786:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.191056:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.191151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.191312:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1521
[1:1:0713/022608.191420:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1521 0x7f44718cd070 0xf5e26cae60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1509 0x7f44718cd070 0xf5e6863fe0 
[1:1:0713/022608.191852:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1510, 7f4474212881
[1:1:0713/022608.212221:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1502 0x7f44718cd070 0xf5e645bbe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.212392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1502 0x7f44718cd070 0xf5e645bbe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.212585:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.212819:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.212895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.213209:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.213311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.213486:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1522
[1:1:0713/022608.213596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1522 0x7f44718cd070 0xf5e66fc760 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1510 0x7f44718cd070 0xf5e664a6e0 
[1:1:0713/022608.289807:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1520, 7f4474212881
[1:1:0713/022608.309469:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1508 0x7f44718cd070 0xf5e6864260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.309692:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1508 0x7f44718cd070 0xf5e6864260 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.309947:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.310309:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.310464:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.310818:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.310932:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.311113:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1524
[1:1:0713/022608.311238:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1524 0x7f44718cd070 0xf5e46d0460 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1520 0x7f44718cd070 0xf5e49e9460 
[1:1:0713/022608.311734:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1521, 7f4474212881
[1:1:0713/022608.331840:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1509 0x7f44718cd070 0xf5e6863fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.332016:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1509 0x7f44718cd070 0xf5e6863fe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.332221:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.332488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.332605:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.332901:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.332988:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.333168:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1526
[1:1:0713/022608.333278:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1526 0x7f44718cd070 0xf5e66fdbe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1521 0x7f44718cd070 0xf5e26cae60 
[1:1:0713/022608.333739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1522, 7f4474212881
[1:1:0713/022608.353904:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1510 0x7f44718cd070 0xf5e664a6e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.354086:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1510 0x7f44718cd070 0xf5e664a6e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.354299:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.354574:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.354690:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.354988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.355091:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.355230:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1528
[1:1:0713/022608.355311:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1528 0x7f44718cd070 0xf5e55fe8e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1522 0x7f44718cd070 0xf5e66fc760 
[1:1:0713/022608.431493:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1524, 7f4474212881
[1:1:0713/022608.451500:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1520 0x7f44718cd070 0xf5e49e9460 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.451726:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1520 0x7f44718cd070 0xf5e49e9460 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.451981:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.452304:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.452450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.452757:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.452863:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.453025:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1530
[1:1:0713/022608.453181:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1530 0x7f44718cd070 0xf5e43a4ae0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1524 0x7f44718cd070 0xf5e46d0460 
[1:1:0713/022608.453679:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1526, 7f4474212881
[1:1:0713/022608.473848:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1521 0x7f44718cd070 0xf5e26cae60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.474026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1521 0x7f44718cd070 0xf5e26cae60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.474233:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.474499:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.474617:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.474916:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.475026:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.475201:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1532
[1:1:0713/022608.475324:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1532 0x7f44718cd070 0xf5e49fc8e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1526 0x7f44718cd070 0xf5e66fdbe0 
[1:1:0713/022608.475802:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1528, 7f4474212881
[1:1:0713/022608.496162:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1522 0x7f44718cd070 0xf5e66fc760 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.496351:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1522 0x7f44718cd070 0xf5e66fc760 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.496561:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.496823:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.496919:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.497210:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.497324:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.497509:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1534
[1:1:0713/022608.497632:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1534 0x7f44718cd070 0xf5e43acbe0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1528 0x7f44718cd070 0xf5e55fe8e0 
[1:1:0713/022608.574022:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1530, 7f4474212881
[1:1:0713/022608.594136:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1524 0x7f44718cd070 0xf5e46d0460 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.594361:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1524 0x7f44718cd070 0xf5e46d0460 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.594614:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.594942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.595098:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.595456:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.595570:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.595750:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1536
[1:1:0713/022608.595874:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1536 0x7f44718cd070 0xf5e2349360 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1530 0x7f44718cd070 0xf5e43a4ae0 
[1:1:0713/022608.596375:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1532, 7f4474212881
[1:1:0713/022608.616445:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1526 0x7f44718cd070 0xf5e66fdbe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.616626:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1526 0x7f44718cd070 0xf5e66fdbe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.616822:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.617096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.617218:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.617518:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.617628:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.617807:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1538
[1:1:0713/022608.617929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1538 0x7f44718cd070 0xf5e685aa60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1532 0x7f44718cd070 0xf5e49fc8e0 
[1:1:0713/022608.618399:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1534, 7f4474212881
[1:1:0713/022608.638602:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1528 0x7f44718cd070 0xf5e55fe8e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.638791:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1528 0x7f44718cd070 0xf5e55fe8e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.638985:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.639246:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.639362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.639663:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.639772:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.639946:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1540
[1:1:0713/022608.640069:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1540 0x7f44718cd070 0xf5e68643e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1534 0x7f44718cd070 0xf5e43acbe0 
[1:1:0713/022608.725141:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1536, 7f4474212881
[1:1:0713/022608.745595:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1530 0x7f44718cd070 0xf5e43a4ae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.745786:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1530 0x7f44718cd070 0xf5e43a4ae0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.745996:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.746281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.746398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.746705:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.746816:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.746994:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1547
[1:1:0713/022608.747118:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1547 0x7f44718cd070 0xf5e6863060 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1536 0x7f44718cd070 0xf5e2349360 
[1:1:0713/022608.788217:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1538, 7f4474212881
[1:1:0713/022608.808048:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1532 0x7f44718cd070 0xf5e49fc8e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.808238:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1532 0x7f44718cd070 0xf5e49fc8e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.808453:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.808734:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.808839:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.809179:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.809294:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.809472:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1550
[1:1:0713/022608.809596:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1550 0x7f44718cd070 0xf5e4d65b60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1538 0x7f44718cd070 0xf5e685aa60 
[1:1:0713/022608.810051:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1540, 7f4474212881
[1:1:0713/022608.830437:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1534 0x7f44718cd070 0xf5e43acbe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.830620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1534 0x7f44718cd070 0xf5e43acbe0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.830826:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.831094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.831210:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.831512:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.831623:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.831800:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1551
[1:1:0713/022608.831910:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1551 0x7f44718cd070 0xf5e4df6ce0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1540 0x7f44718cd070 0xf5e68643e0 
[1:1:0713/022608.895702:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1547, 7f4474212881
[1:1:0713/022608.915724:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1536 0x7f44718cd070 0xf5e2349360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.915910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1536 0x7f44718cd070 0xf5e2349360 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.916128:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.916411:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.916531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.916826:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.916916:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.917100:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1555
[1:1:0713/022608.917224:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1555 0x7f44718cd070 0xf5e26b3f60 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1547 0x7f44718cd070 0xf5e6863060 
[1:1:0713/022608.939974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1550, 7f4474212881
[1:1:0713/022608.961065:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1538 0x7f44718cd070 0xf5e685aa60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.961278:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1538 0x7f44718cd070 0xf5e685aa60 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022608.961492:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022608.961775:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022608.961894:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022608.962201:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022608.962314:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022608.962494:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1559
[1:1:0713/022608.962617:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1559 0x7f44718cd070 0xf5e6680760 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1550 0x7f44718cd070 0xf5e4d65b60 
[1:1:0713/022609.005377:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1551, 7f4474212881
[1:1:0713/022609.025314:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1540 0x7f44718cd070 0xf5e68643e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022609.025523:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1540 0x7f44718cd070 0xf5e68643e0 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022609.025732:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022609.026019:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022609.026138:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022609.026444:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022609.026556:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022609.026734:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1561
[1:1:0713/022609.026857:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1561 0x7f44718cd070 0xf5e66fc4e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1551 0x7f44718cd070 0xf5e4df6ce0 
[1:1:0713/022609.048459:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1555, 7f4474212881
[1:1:0713/022609.068790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"1fb571202860","ptid":"1547 0x7f44718cd070 0xf5e6863060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022609.068973:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://edu.jiameng.com/","ptid":"1547 0x7f44718cd070 0xf5e6863060 ","rf":"5:3_http://edu.jiameng.com/"}
[1:1:0713/022609.069168:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://edu.jiameng.com/"
[1:1:0713/022609.069444:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://edu.jiameng.com/, 1fb571202860, , a, (){clearTimeout(z);var b;q&&(b="visible"==document[q]);v&&(b=!document[v]);p="undefined"==typeof b?t
[1:1:0713/022609.069562:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://edu.jiameng.com/", "edu.jiameng.com", 3, 1, , , 0
[1:1:0713/022609.069867:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 100, 0x60ef0a29c8, 0xf5e24e4150
[1:1:0713/022609.069978:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://edu.jiameng.com/", 100
[1:1:0713/022609.070189:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://edu.jiameng.com/, 1564
[1:1:0713/022609.070284:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1564 0x7f44718cd070 0xf5e42760e0 , 5:3_http://edu.jiameng.com/, 1, -5:3_http://edu.jiameng.com/, 1555 0x7f44718cd070 0xf5e26b3f60 
