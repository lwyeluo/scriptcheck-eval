[0712/220213.950986:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220213.951244:INFO:switcher_clone.cc(787)] backtrace rip is 7ff6a67d5891
[0712/220214.535041:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220214.535274:INFO:switcher_clone.cc(787)] backtrace rip is 7f91488af891
[1:1:0712/220214.539174:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/220214.539323:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/220214.542201:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0712/220215.439260:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/220215.439540:INFO:switcher_clone.cc(787)] backtrace rip is 7f5fe546a891
[9493:9493:0712/220215.524898:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile
ATTENTION: default value of option force_s3tc_enable overridden by environment.

DevTools listening on ws://127.0.0.1:9222/devtools/browser/843aa06e-6889-49ab-b7bb-561baa5b0dc1
[9525:9525:0712/220215.594079:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9525
[9538:9538:0712/220215.605073:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=9538
[9493:9493:0712/220215.812288:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[9493:9523:0712/220215.812709:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/220215.812814:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220215.813057:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220215.813428:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220215.813547:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/220215.815298:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x32d31055, 1
[1:1:0712/220215.815556:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2e7c0b09, 0
[1:1:0712/220215.815694:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0xd218d25, 3
[1:1:0712/220215.815823:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x39192737, 2
[1:1:0712/220215.815953:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 090b7c2e 5510ffffffd332 37271939 25ffffff8d210d , 10104, 4
[1:1:0712/220215.816650:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9493:9523:0712/220215.816748:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING	|.U�27'9%�!��
[9493:9523:0712/220215.816798:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is 	|.U�27'9%�!(���
[1:1:0712/220215.816744:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146ae90a0, 3
[9493:9523:0712/220215.816929:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[9493:9523:0712/220215.816963:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9546, 4, 090b7c2e 5510d332 37271939 258d210d 
[1:1:0712/220215.817276:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146c75080, 2
[1:1:0712/220215.817379:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9130937d20, -2
[1:1:0712/220215.825417:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220215.825921:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 39192737
[1:1:0712/220215.826416:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 39192737
[1:1:0712/220215.827239:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 39192737
[1:1:0712/220215.827828:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.827943:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.828046:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.828143:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.828390:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 39192737
[1:1:0712/220215.828543:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220215.828621:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220215.830440:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 39192737
[1:1:0712/220215.830621:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 39192737
[1:1:0712/220215.830941:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 39192737
[1:1:0712/220215.832188:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.832305:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.832409:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.832505:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39192737
[1:1:0712/220215.833025:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 39192737
[1:1:0712/220215.833209:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220215.833286:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220215.835975:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220215.836190:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220215.836282:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde14ce6e8, 0x7ffde14ce668)
[1:1:0712/220215.845117:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220215.847968:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9493:9493:0712/220216.344899:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220216.345449:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9493:0712/220216.353634:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[9493:9493:0712/220216.353693:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[9493:9493:0712/220216.353765:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,9546, 4
[9493:9505:0712/220216.356452:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[9493:9505:0712/220216.356515:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/220216.357223:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220216.415266:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x244c2acc6220
[1:1:0712/220216.415429:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[9493:9517:0712/220216.569727:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/220216.648876:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/220217.454711:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220217.456482:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220217.818125:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[9493:9493:0712/220217.818231:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/220217.953673:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220218.058930:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/220218.059103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220218.065386:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/220218.065566:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220218.107955:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220218.108152:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220218.259285:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220218.261891:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/220218.262053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220218.274815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220218.278344:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/220218.278476:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220218.282737:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[9493:9493:0712/220218.283390:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220218.284438:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x244c2acc4e20
[1:1:0712/220218.284624:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[9493:9493:0712/220218.285790:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[9493:9493:0712/220218.298381:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[9493:9493:0712/220218.298468:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/220218.319011:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220218.706743:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 424 0x7f91325122e0 0x244c2ad4a2e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220218.707450:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/220218.707627:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220218.708245:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9493:9493:0712/220218.738810:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/220218.740031:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x244c2acc5820
[1:1:0712/220218.740633:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[9493:9493:0712/220218.741891:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/220218.747483:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220218.747645:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[9493:9493:0712/220218.750120:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[9493:9493:0712/220218.757094:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220218.758837:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220218.763729:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[9493:9505:0712/220218.763803:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220218.763821:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[9493:9493:0712/220218.763866:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[9493:9493:0712/220218.763935:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,9546, 4
[1:7:0712/220218.766679:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220218.797459:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[9493:9523:0712/220218.797724:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/220218.797852:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220218.797996:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220218.798194:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220218.798279:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/220218.800432:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x67a32a2, 1
[1:1:0712/220218.800649:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xd610045, 0
[1:1:0712/220218.800761:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x8a21a05, 3
[1:1:0712/220218.800857:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1444e7cd, 2
[1:1:0712/220218.800942:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4500610d ffffffa2327a06 ffffffcdffffffe74414 051affffffa208 , 10104, 5
[1:1:0712/220218.801675:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9493:9523:0712/220218.801896:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGE
[9493:9523:0712/220218.801952:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is E
[1:1:0712/220218.801889:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146ae90a0, 3
[9493:9523:0712/220218.802120:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9587, 5, 4500610d a2327a06 cde74414 051aa208 
[1:1:0712/220218.802091:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146c75080, 2
[1:1:0712/220218.802197:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9130937d20, -2
[1:1:0712/220218.811866:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220218.812114:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1444e7cd
[1:1:0712/220218.812290:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1444e7cd
[1:1:0712/220218.812562:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1444e7cd
[1:1:0712/220218.813094:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.813206:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.813307:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.813400:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.813662:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1444e7cd
[1:1:0712/220218.813791:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220218.813868:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220218.815583:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1444e7cd
[1:1:0712/220218.815787:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1444e7cd
[1:1:0712/220218.816109:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1444e7cd
[1:1:0712/220218.816932:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.817079:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.817191:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.817299:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1444e7cd
[1:1:0712/220218.817805:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1444e7cd
[1:1:0712/220218.817985:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220218.818069:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220218.820778:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220218.821005:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220218.821124:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde14ce6e8, 0x7ffde14ce668)
[1:1:0712/220218.827363:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220218.829541:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/220218.921882:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x244c2ac96220
[1:1:0712/220218.922132:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/220219.063406:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/220219.266411:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 476 0x7f91325122e0 0x244c2b06c1e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220219.266993:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/220219.267109:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220219.267443:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[9493:9493:0712/220219.412484:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[9493:9493:0712/220219.412554:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/220219.424819:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220219.584983:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220219.814714:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220219.814882:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220219.935675:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220219.937360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/220219.937559:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220219.939905:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220219.984935:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/220219.985362:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 1fc759181f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/220219.985512:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/220220.021645:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.022395:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/220220.022527:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/220220.022664:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.096091:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.105634:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/220220.105809:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/220220.105995:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.265083:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/220220.438505:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/http://www.taobao.com/"
[1:1:0712/220220.494448:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/220220.540915:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/220220.569170:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/220220.609018:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/220220.637754:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/220220.677869:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/220220.736016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.736479:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220220.736644:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.793873:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.799563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220220.799766:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.827228:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.827722:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220220.827891:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.887476:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.887965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220220.888125:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.923109:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.923544:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220220.923694:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.946603:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.947059:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220220.947229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220220.978949:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220220.979389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220220.979549:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.002385:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.002836:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220221.002971:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.039634:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.040119:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220221.040325:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.064548:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.069918:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220221.070117:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.105756:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.106230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220221.106436:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.128785:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.129338:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220221.129560:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[9493:9523:0712/220221.133060:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 6
[3:3:0712/220221.133198:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220221.133326:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220221.133493:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220221.133613:INFO:zygote_linux.cc(633)] 		cid is 6
[1:1:0712/220221.135851:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x4ddb8ce, 1
[1:1:0712/220221.136049:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xbab83a6, 0
[1:1:0712/220221.136156:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x3bce6171, 3
[1:1:0712/220221.136293:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x3d3bf4ad, 2
[1:1:0712/220221.136420:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffa6ffffff83ffffffab0b ffffffceffffffb8ffffffdd04 ffffffadfffffff43b3d 7161ffffffce3b , 10104, 6
[1:1:0712/220221.137182:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9493:9523:0712/220221.137344:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING���θ���;=qa�;��
[9493:9523:0712/220221.137387:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is ���θ���;=qa�;x���
[9493:9523:0712/220221.137494:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9602, 6, a683ab0b ceb8dd04 adf43b3d 7161ce3b 
[1:1:0712/220221.137333:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146ae90a0, 3
[1:1:0712/220221.137714:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146c75080, 2
[1:1:0712/220221.137844:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9130937d20, -2
[1:1:0712/220221.144059:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220221.144596:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d3bf4ad
[1:1:0712/220221.145099:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d3bf4ad
[1:1:0712/220221.146843:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d3bf4ad
[1:1:0712/220221.152978:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.153206:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.153389:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.153563:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.153859:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d3bf4ad
[1:1:0712/220221.154050:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220221.154176:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220221.155837:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 3d3bf4ad
[1:1:0712/220221.156012:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 3d3bf4ad
[1:1:0712/220221.156333:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 3d3bf4ad
[1:1:0712/220221.157076:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.157199:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.157318:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.157434:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 3d3bf4ad
[1:1:0712/220221.157851:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 3d3bf4ad
[1:1:0712/220221.158041:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220221.158125:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220221.160637:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220221.160869:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220221.160960:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde14cef78, 0x7ffde14ceef8)
[1:1:0712/220221.166543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.167053:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220221.167267:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.182624:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220221.190240:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.190759:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220221.190963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.224302:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.224730:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/220221.224873:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/220221.259557:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/220221.260069:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 1fc7592af288, , , (ev) {
    thumb.classList.add('failed-img');
    thumb.removeChild(img);
    // Store the type for 
[1:1:0712/220221.260362:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[9493:9493:0712/220221.455470:ERROR:CONSOLE(143)] "Failed to execute 'postMessage' on 'DOMWindow': The target origin provided ('https://www.close5.com') does not match the recipient window's origin ('chrome-search://local-ntp').", source: chrome-search://most-visited/single.js (143)
[9493:9493:0712/220223.165410:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220223.178557:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 7
[9493:9523:0712/220223.178799:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 7
[3:3:0712/220223.178915:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/220223.179042:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/220223.179255:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/220223.179334:INFO:zygote_linux.cc(633)] 		cid is 7
[1:1:0712/220223.182858:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x219de7a3, 1
[1:1:0712/220223.183064:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x3b071779, 0
[1:1:0712/220223.183168:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x45c1ec6, 3
[1:1:0712/220223.183248:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x1e6fd45b, 2
[1:1:0712/220223.183321:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 7917073b ffffffa3ffffffe7ffffff9d21 5bffffffd46f1e ffffffc61e5c04 , 10104, 7
[1:1:0712/220223.184004:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[9493:9523:0712/220223.184112:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGy;��![�o�\��
[9493:9523:0712/220223.184150:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is y;��![�o�\���
[9493:9523:0712/220223.184291:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 9611, 7, 7917073b a3e79d21 5bd46f1e c61e5c04 
[1:1:0712/220223.184478:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146ae90a0, 3
[1:1:0712/220223.184577:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9146c75080, 2
[1:1:0712/220223.184657:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f9130937d20, -2
[1:1:0712/220223.194487:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/220223.194679:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e6fd45b
[1:1:0712/220223.194812:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e6fd45b
[1:1:0712/220223.195042:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e6fd45b
[1:1:0712/220223.195526:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.205385:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.205577:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.205744:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.206074:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e6fd45b
[1:1:0712/220223.206256:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[1:1:0712/220223.206383:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220223.208087:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 1e6fd45b
[1:1:0712/220223.208265:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 1e6fd45b
[1:1:0712/220223.208577:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 1e6fd45b
[1:1:0712/220223.209481:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.209619:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.209725:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.209833:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 1e6fd45b
[1:1:0712/220223.210336:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 1e6fd45b
[1:1:0712/220223.210481:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f91488af7ba
[9493:9493:0712/220223.210564:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/220223.210554:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f91488a6def, 7f91488af77a, 7f91488b10cf
[1:1:0712/220223.214405:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/220223.214668:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/220223.214781:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde14ce6e8, 0x7ffde14ce668)
[1:1:0712/220223.220929:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/220223.223007:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[9493:9493:0712/220223.229014:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://www.ebay.com/
[9493:9493:0712/220223.229157:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:3_https://www.ebay.com/, https://www.ebay.com/, 1
[9493:9493:0712/220223.229241:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:3_https://www.ebay.com/, HTTP/1.1 200 status:200 x-content-type-options:nosniff x-xss-protection:1; mode=block x-frame-options:SAMEORIGIN content-security-policy:default-src 'self' blob: wss: data: https:; img-src 'self' data: https:; script-src 'self' 'unsafe-eval' 'unsafe-inline' blob: data: https:; style-src 'self' 'unsafe-inline' data: https:;  content-type:text/html;charset=utf-8 rlogid:t6klaook%60b0%3D%3C%3Dpieojbnkmcc4%3B(4%3E632%3E7-16be67df5bb-0x1703 content-encoding:gzip strict-transport-security:max-age=31536000 x-envoy-upstream-service-time:55 x-ebay-pop-id:UFES2-LAX-dweb-1 server:envoy date:Fri, 12 Jul 2019 14:02:23 GMT vary:Accept-Encoding set-cookie:npii=btguid/78cc0a5016b0aa4145dfbea8ffffe29860eaf9ef^cguid/4b3b21ff16b0ad4b14c600abec65f44060eaf9ef^; Domain=.ebay.com; Path=/; Expires=Sun, 11 Jul 2021 14:02:23 GMT set-cookie:ebay=%5Ejs%3D1%5Edv%3D5d28925c%5Esbf%3D%23000000%5E; Domain=.ebay.com; Path=/ set-cookie:dp1=bu1p/QEBfX0BAX19AQA**60eaf9ef^pbf/%23e0002000000000000000005f09c66f^tzo/-1e05d28a0ee^bl/CN60eaf9ef^; Domain=.ebay.com; Path=/; Expires=Sun, 11 Jul 2021 14:02:23 GMT set-cookie:s=CgAD4ACBdKeReNzhjYzBhNTAxNmIwYWE0MTQ1ZGZiZWE4ZmZmZmUyOTg1kEPz; Domain=.ebay.com; Path=/; HttpOnly set-cookie:nonsession=BAQAAAWoZJLj4AAaAADMABl8Jxm8xMDAwMDAAygAgYOr57zc4Y2MwYTUwMTZiMGFhNDE0NWRmYmVhOGZmZmZlMjk4AMsAAV0omfc5TK2zw0+X1RXo+MXNdP9ZfoxlhDI*; Domain=.ebay.com; Path=/; Expires=Sun, 11 Jul 2021 14:02:23 GMT set-cookie:bm_sv=1636203E0EF3D24F2925EEA9FCBF1C2B~cE/fbfOigonJUNqgwx/9iHhw1zVZGyqPeB2rgAklPP2PN2TeJidQih043TLv29VZJLYPNul+s9+QxmdgIRkX4AHgWcBStUVrgauEu0uBv/my8/13NpKvRgZqGfC9R6mYbFQT2skyA5kf9IitoqfOtg==; Domain=.ebay.com; Path=/; Max-Age=7070; HttpOnly  ,0, 7
[3:3:0712/220223.239263:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[9493:9505:0712/220223.241125:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 3
[9493:9505:0712/220223.241190:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/220223.293022:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220223.368698:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x244c2acd5220
[1:1:0712/220223.368864:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/220223.402703:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:3_https://www.ebay.com/
[9493:9493:0712/220223.527911:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:3_https://www.ebay.com/, https://www.ebay.com/, 1
[9493:9493:0712/220223.527976:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, https://www.ebay.com/, https://www.ebay.com
[1:1:0712/220223.535515:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220223.535991:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220223.581319:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220223.633711:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220223.644105:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220223.644228:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220223.681504:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 117 0x7f91305ea070 0x244c2adbf460 , "https://www.ebay.com/"
[1:1:0712/220223.682576:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , 
    (function() {
        var useCustomFont = ('fontDisplay' in document.documentElement.style) ||

[1:1:0712/220223.682719:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220223.683177:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220223.690548:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 117 0x7f91305ea070 0x244c2adbf460 , "https://www.ebay.com/"
[1:1:0712/220223.760536:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220224.248056:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220224.584776:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220224.700047:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f91305ea070 0x244c2a89f2e0 , "https://www.ebay.com/"
[1:1:0712/220224.701486:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , 
            window.highline = {"isWebpSupported":true,"isLowBandwidth":false,"lazyLoadAll":true,"la
[1:1:0712/220224.701688:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220224.702709:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f91305ea070 0x244c2a89f2e0 , "https://www.ebay.com/"
[1:1:0712/220224.704804:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f91305ea070 0x244c2a89f2e0 , "https://www.ebay.com/"
[1:1:0712/220224.707382:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220224.712845:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 195 0x7f91305ea070 0x244c2a89f2e0 , "https://www.ebay.com/"
		remove user.e_c4ec3ba4 -> 0
[1:1:0712/220224.765854:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.0635719, 61, 1
[1:1:0712/220224.766020:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220225.066542:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220225.066688:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220225.071629:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 253 0x7f91305ea070 0x244c2ae58060 , "https://www.ebay.com/"
[1:1:0712/220225.072162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , 
            // so we can add no-js styles as well
            document.body.classList.remove("hl-no
[1:1:0712/220225.072316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220225.080077:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.013375, 77, 1
[1:1:0712/220225.080254:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220225.108545:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 259 0x7f91325122e0 0x244c2a89df60 , "https://www.ebay.com/"
[1:1:0712/220225.109098:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&
[1:1:0712/220225.109220:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220225.174507:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220225.174677:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220225.175156:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 274 0x7f91305ea070 0x244c2adb4fe0 , "https://www.ebay.com/"
[1:1:0712/220225.175787:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (function(){try{var d=document.cookie,a=((a=d.match(/u1f[^a-zA-Z0-9]([^^]*)[0-9a-z]{8}/))?a[1].repla
[1:1:0712/220225.175918:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220225.254221:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.079582, 1464, 1
[1:1:0712/220225.254447:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220225.339113:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220225.340219:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220225.340407:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220225.354410:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220225.355074:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220225.355262:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220225.367062:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220225.382000:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220225.382141:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220225.400698:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220225.401322:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220225.401455:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[3:3:0712/220226.206831:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 2
[1:1:0712/220226.208029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.221417:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.222057:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.222214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.223705:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.234378:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.235023:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.235188:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.236268:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.246874:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.247469:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.247601:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.248682:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.264305:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.264877:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.265002:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.266055:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.276875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.277516:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.277624:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.279762:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.292801:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.293438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.293569:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.294669:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220226.305596:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.306220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.306359:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.318881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.319524:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.319661:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.326585:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.327216:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.327346:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.334617:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.335252:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.335381:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.354690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.355310:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.355424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.366633:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.367107:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.367229:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.373250:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.373691:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.373810:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.379734:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.380158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.380275:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.386256:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.386690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.386808:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.397450:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.397988:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.398110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.404727:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.405267:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.405396:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.411760:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.412204:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.412330:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.418559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.418974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.419094:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.430434:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.431138:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.431457:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.438400:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.438907:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.439077:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.451171:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.451663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , onload, typeof lazyLoad !== 'undefined' && lazyLoad.addToQueue(this, true)
[1:1:0712/220226.451784:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.464817:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220226.464953:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220226.608177:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220226.781501:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7f9130952bd0 0x244c2afd6e58 , "https://www.ebay.com/"
[1:1:0712/220226.783356:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (function(){function g(b,d){var a=Error('Cannot find module "'+b+'"'+(d?' from "'+d+'"':""));a.code=
[1:1:0712/220226.783511:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220226.793879:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 361 0x7f9130952bd0 0x244c2afd6e58 , "https://www.ebay.com/"
		remove user.e_d140485a -> 0
[1:1:0712/220226.957844:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220226.958336:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220226.958528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220227.011846:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f9130952bd0 0x244c2b1f73d8 , "https://www.ebay.com/"
[1:1:0712/220227.014262:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , $_mod.main("/jquery$3.2.1","dist/jquery");$_mod.def("/jquery$3.2.1/dist/jquery",function(la,Gc,aa){v
[1:1:0712/220227.014450:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220227.135013:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 382 0x7f9130952bd0 0x244c2b1f73d8 , "https://www.ebay.com/"
[1:1:0712/220227.901337:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.767018, 0, 1
[1:1:0712/220227.901561:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220228.043804:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220228.044029:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220228.044597:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f91305ea070 0x244c2b2cd160 , "https://www.ebay.com/"
[1:1:0712/220228.045206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , window.HL_PAGE_TRACKING = [{"eventFamily":"HOMEPAGE","eventAction":"PAGEPING","operationId":"2481888
[1:1:0712/220228.045374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220228.046567:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f91305ea070 0x244c2b2cd160 , "https://www.ebay.com/"
[1:1:0712/220228.048062:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f91305ea070 0x244c2b2cd160 , "https://www.ebay.com/"
[1:1:0712/220228.064918:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f91305ea070 0x244c2b2cd160 , "https://www.ebay.com/"
[1:1:0712/220228.079249:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f91305ea070 0x244c2b2cd160 , "https://www.ebay.com/"
[1:1:0712/220228.096297:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 406 0x7f91305ea070 0x244c2b2cd160 , "https://www.ebay.com/"
[1:1:0712/220228.113053:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 60000
[1:1:0712/220228.113370:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 7:3_https://www.ebay.com/, 438
[1:1:0712/220228.113546:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 438 0x7f91305ea070 0x244c2aff39e0 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 406 0x7f91305ea070 0x244c2b2cd160 
[1:1:0712/220228.139995:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.095926, 725, 1
[1:1:0712/220228.140194:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220228.172231:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220228.172660:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220228.172800:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220228.187901:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220228.188551:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220228.188723:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220228.218170:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220228.218560:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220228.218679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220228.235914:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220228.236317:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220228.236428:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220228.461226:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220228.461453:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220228.462052:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7f91305ea070 0x244c2afd3b60 , "https://www.ebay.com/"
[1:1:0712/220228.462642:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , window.widget_platform = {"renderType":1,"renderDelay":500,"triggerFallBack":true,"status":4,"queryP
[1:1:0712/220228.462822:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220228.466602:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7f91305ea070 0x244c2afd3b60 , "https://www.ebay.com/"
[1:1:0712/220228.496298:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7f91305ea070 0x244c2afd3b60 , "https://www.ebay.com/"
[1:1:0712/220228.498343:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 444 0x7f91305ea070 0x244c2afd3b60 , "https://www.ebay.com/"
[1:1:0712/220228.926025:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x3cb3640029c8, 0x244c2ab1f9a0
[1:1:0712/220228.926236:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 60
[1:1:0712/220228.926418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 485
[1:1:0712/220228.926550:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 485 0x7f91305ea070 0x244c2bc2ade0 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 444 0x7f91305ea070 0x244c2afd3b60 
[1:1:0712/220228.961659:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 20000
[1:1:0712/220228.961940:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 486
[1:1:0712/220228.962068:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 486 0x7f91305ea070 0x244c2afe1760 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 444 0x7f91305ea070 0x244c2afd3b60 
[1:1:0712/220228.962680:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.501105, 4, 0
[1:1:0712/220228.962794:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220229.048177:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220229.048597:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220229.048735:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220229.073576:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220229.073913:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220229.074053:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220229.091428:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220229.091800:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220229.091905:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220229.118511:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220229.118934:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220229.119073:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220229.296050:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220229.296231:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220229.296890:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f91305ea070 0x244c2bc30360 , "https://www.ebay.com/"
[1:1:0712/220229.297458:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , function $af(d,a,e,l,g,h,k,b,f,c){c=$af;if(a&&!c[a])(c[a+="$"]||(c[a]=[])).push(d);else{e=document;l
[1:1:0712/220229.297606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220229.298590:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f91305ea070 0x244c2bc30360 , "https://www.ebay.com/"
[1:1:0712/220229.300534:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f91305ea070 0x244c2bc30360 , "https://www.ebay.com/"
[1:1:0712/220229.302147:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 487 0x7f91305ea070 0x244c2bc30360 , "https://www.ebay.com/"
[1:1:0712/220230.570345:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 2000, 0x3cb3640029c8, 0x244c2ab1f9a0
[1:1:0712/220230.570571:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 2000
[1:1:0712/220230.570826:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 513
[1:1:0712/220230.571001:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 513 0x7f91305ea070 0x244c2c456060 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 487 0x7f91305ea070 0x244c2bc30360 
[1:1:0712/220230.582225:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.28602, 4, 0
[1:1:0712/220230.582427:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220230.630197:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 485, 7f9132f2f881
[1:1:0712/220230.638787:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"444 0x7f91305ea070 0x244c2afd3b60 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220230.639012:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"444 0x7f91305ea070 0x244c2afd3b60 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220230.639280:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220230.639613:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){f.on("resize.gh",d.execute_on_load_or_resize)}
[1:1:0712/220230.639758:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220230.661007:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220230.662159:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220230.662337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220230.842130:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220230.842368:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://www.ebay.com/"
[1:1:0712/220230.843837:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.ebay.com/"
[1:1:0712/220230.844207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){b=$rmod.require("/$/raptor-pubsub"),A=b.channel("site-speed-ebay")}
[1:1:0712/220230.844379:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220230.847787:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.ebay.com/"
[1:1:0712/220230.850324:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.ebay.com/"
[1:1:0712/220230.884192:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300000, 0x3cb3640029c8, 0x244c2ab1f9e0
[1:1:0712/220230.884360:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 300000
[1:1:0712/220230.884558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 524
[1:1:0712/220230.884674:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 524 0x7f91305ea070 0x244c2c33b7e0 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 514 0x7f91305ea070 0x244c2c36ba60 
[1:1:0712/220230.884927:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.ebay.com/"
[1:1:0712/220230.888956:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.ebay.com/"
[1:1:0712/220230.900889:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "https://www.ebay.com/"
[1:1:0712/220232.580307:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 513, 7f9132f2f881
[1:1:0712/220232.589812:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"487 0x7f91305ea070 0x244c2bc30360 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220232.589995:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"487 0x7f91305ea070 0x244c2bc30360 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220232.590189:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220232.590446:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , setRtmFallbacks, (a){var b=this;this.usedFallback=!0;Array.prototype.forEach.call(this.getEls("rtmImages"),function(c
[1:1:0712/220232.590531:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220232.592499:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.594573:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x244c2be2fe20
[1:1:0712/220232.594726:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[1:1:0712/220232.602223:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.602386:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.603517:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.605364:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 5, 0x244c2acd3420
[1:1:0712/220232.605742:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 5
[1:1:0712/220232.612937:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.613104:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.614256:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.616158:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 6, 0x244c2bd4e020
[1:1:0712/220232.616301:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 6
[1:1:0712/220232.623600:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.623758:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.624828:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.626638:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 7, 0x244c2bd40220
[1:1:0712/220232.626753:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 7
[1:1:0712/220232.633859:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.634016:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.635087:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.636827:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 8, 0x244c2b471820
[1:1:0712/220232.636927:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 8
[1:1:0712/220232.644936:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.645093:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.646196:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.647900:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 9, 0x244c2b472220
[1:1:0712/220232.648024:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 9
[1:1:0712/220232.655104:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.655259:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.656293:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.658022:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 10, 0x244c2be24420
[1:1:0712/220232.658167:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 10
[1:1:0712/220232.665334:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.665491:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[1:1:0712/220232.666546:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[1:1:0712/220232.668268:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 11, 0x244c2be2ea20
[1:1:0712/220232.668403:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 11
[1:1:0712/220232.675431:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/220232.675582:INFO:render_frame_impl.cc(7019)] 	 [url] = https://www.ebay.com
[9493:9505:0712/220235.147526:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/220241.506046:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/220241.506282:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[9493:9493:0712/220241.720579:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.723943:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 4, 4, 
[9493:9493:0712/220241.728653:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.732960:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.735617:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 5, 5, 
[9493:9493:0712/220241.746927:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.753962:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.756598:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 6, 6, 
[9493:9493:0712/220241.763096:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.768446:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.771102:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 7, 7, 
[9493:9493:0712/220241.775906:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.780225:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.782652:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 8, 8, 
[9493:9493:0712/220241.788077:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.793342:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.795586:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 9, 9, 
[9493:9493:0712/220241.799810:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.803810:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.806242:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 10, 10, 
[9493:9493:0712/220241.810698:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[9493:9493:0712/220241.814658:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[9493:9493:0712/220241.816795:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 11, 11, 
[9493:9493:0712/220241.821150:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 7:3_https://www.ebay.com/
[3:3:0712/220241.847110:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/220242.461366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){var d=c.getBoundingClientRect().width,g=b.firstElementChild.getBoundingClientRect().left;
a.setSt
[1:1:0712/220242.461594:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[9493:9493:0712/220242.747222:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220242.750793:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220242.763287:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 4
[9493:9505:0712/220242.763353:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 4, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220242.764183:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220242.764244:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:4_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19392.html, 4
[9493:9493:0712/220242.764320:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:4_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*251644%3E%29pqtfwpu%29qki%29fgg%7E-fij-16be67e42a6-0xed ETag: 6a95190c03637fcb2887890ee605c226 Last-Modified: Fri, 12 Jul 2019 13:57:50 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:41 GMT Server: ebay server  ,9611, 7
[1:1:0712/220242.764795:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220242.764961:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:7:0712/220242.769947:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220242.772932:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220242.776598:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220242.789156:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 5
[9493:9505:0712/220242.789234:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 5, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220242.792363:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220242.792420:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:5_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19393.html, 5
[9493:9493:0712/220242.792489:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:5_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*250%3E%3B76%29pqtfwpu%29qki%29fgg%7E-fij-16be67e42be-0xf6 ETag: 87e9aba781bdc4cb8148eca10e3f9f59 Last-Modified: Fri, 12 Jul 2019 14:01:37 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:42 GMT Server: ebay server  ,9611, 7
[1:7:0712/220242.799094:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220242.826385:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220242.838111:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220242.849883:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 7
[9493:9505:0712/220242.849961:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 7, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220242.852023:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220242.852076:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:7_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19395.html, 7
[9493:9493:0712/220242.852155:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:7_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*250%3E%3B76%29pqtfwpu%29qki%29fgg%7E-fij-16be67e42ec-0xea ETag: d8883db9cab6f52cf59d112580278b6e Last-Modified: Fri, 12 Jul 2019 14:01:45 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:42 GMT Server: ebay server  ,9611, 7
[1:7:0712/220242.858308:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220242.927161:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.ebay.com/"
[1:1:0712/220242.927982:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (a){var d=a.source;if(d==b||!d&&"si"===a.data)a.stopPropagation(),0<c.length&&c.shift()()}
[1:1:0712/220242.928154:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220242.988988:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3500, 0x3cb3640029c8, 0x244c2ab1fb40
[1:1:0712/220242.989220:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 3500
[1:1:0712/220242.989444:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 747
[1:1:0712/220242.989619:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 747 0x7f91305ea070 0x244c2caf9ee0 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 679 0x7f91305ea070 0x244c2c81cd60 
[9493:9493:0712/220243.014624:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220243.017869:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220243.029040:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 8
[9493:9505:0712/220243.029105:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 8, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220243.031013:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220243.031068:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:8_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19396.html, 8
[9493:9493:0712/220243.031142:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:8_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*251644%3E%29pqtfwpu%29qki%29fgg%7E-fij-16be67e43b2-0xe9 ETag: 6f447e17767e6d6e2f55e77cfbfb28f5 Last-Modified: Fri, 12 Jul 2019 13:57:52 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:41 GMT Server: ebay server  ,9611, 7
[9493:9493:0712/220243.031742:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:7:0712/220243.032090:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220243.035203:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220243.047429:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 6
[9493:9505:0712/220243.047502:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 6, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220243.047546:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220243.047593:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:6_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19394.html, 6
[9493:9493:0712/220243.047658:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:6_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*251644%3E%29pqtfwpu%29qki%29fgg%7E-fij-16be67e42c5-0xfb ETag: 7a0c0b8069606b4f6acfbbf759c17e26 Last-Modified: Fri, 12 Jul 2019 13:57:53 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:41 GMT Server: ebay server  ,9611, 7
[9493:9493:0712/220243.049605:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[1:7:0712/220243.050067:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220243.053937:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220243.065385:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 9
[9493:9505:0712/220243.065457:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 9, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220243.065491:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220243.065537:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:9_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19397.html, 9
[9493:9493:0712/220243.065605:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:9_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*250%3E%3B76%29pqtfwpu%29qki%29fgg%7E-fij-16be67e43c7-0xef ETag: 6458b912a031462f276f38ce657d71a4 Last-Modified: Fri, 12 Jul 2019 14:01:37 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:42 GMT Server: ebay server  ,9611, 7
[1:7:0712/220243.072988:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220243.098493:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220243.101933:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220243.117589:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 10
[9493:9505:0712/220243.117660:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 10, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220243.119580:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220243.119629:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:10_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19398.html, 10
[9493:9493:0712/220243.119705:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:10_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*250%3E%3B76%29pqtfwpu%29qki%29fgg%7E-fij-16be67e4406-0xe4 ETag: 0c472d4f0a09e7eb07ea7e0b7604fb57 Last-Modified: Fri, 12 Jul 2019 14:01:40 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:42 GMT Server: ebay server  ,9611, 7
[1:7:0712/220243.120731:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[9493:9493:0712/220243.168580:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[9493:9493:0712/220243.171725:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[9493:9505:0712/220243.182830:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 7, 11
[9493:9505:0712/220243.182892:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 7, 11, HandleIncomingMessage, HandleIncomingMessage
[9493:9493:0712/220243.182924:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation https://pages.ebay.com/
[9493:9493:0712/220243.182966:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:11_https://pages.ebay.com/, https://pages.ebay.com/SE/en-US/rtm_default/1200/19399.html, 11
[9493:9493:0712/220243.183029:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 7:11_https://pages.ebay.com/, HTTP/1.1 200 OK RlogId: t6fug%60f%3F%3Cumjcwbbc*251644%3E%29pqtfwpu%29qki%29fgg%7E-fij-16be67e4450-0x109 ETag: 8396a29199ec68dc624f78b4314aaa87 Last-Modified: Fri, 12 Jul 2019 13:57:53 GMT X-Content-Type-Options: nosniff X-XSS-Protection: 1; mode=block Content-Encoding: gzip Content-Type: text/html;charset=UTF-8 Transfer-Encoding: chunked Date: Fri, 12 Jul 2019 14:02:43 GMT Server: ebay server  ,9611, 7
[1:7:0712/220243.185875:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/220243.702543:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:4_https://pages.ebay.com/
[1:1:0712/220243.733855:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220243.734051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220243.806362:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:5_https://pages.ebay.com/
[1:1:0712/220244.094327:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:7_https://pages.ebay.com/
[1:1:0712/220244.213453:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.ebay.com/"
[1:1:0712/220244.213919:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){var t=Date.now();(!o||o+e<t)&&(o=t,n.apply(void 0,arguments))}
[1:1:0712/220244.214096:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220244.215053:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.ebay.com/"
[1:1:0712/220244.215774:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.ebay.com/"
[1:1:0712/220244.218735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "https://www.ebay.com/"
[1:1:0712/220244.336118:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 60, 0x3cb3640029c8, 0x244c2ab1f9f0
[1:1:0712/220244.336346:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 60
[1:1:0712/220244.336558:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 796
[1:1:0712/220244.336709:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 796 0x7f91305ea070 0x244c2cdc9d60 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 746 0x7f913f8fb960 0x244c2c9e1c40 0x244c2c9e1c50 
[1:1:0712/220244.462085:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:8_https://pages.ebay.com/
[1:1:0712/220244.544871:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:6_https://pages.ebay.com/
[1:1:0712/220244.624125:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:9_https://pages.ebay.com/
[1:1:0712/220244.698275:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:10_https://pages.ebay.com/
[1:1:0712/220244.780438:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 7:11_https://pages.ebay.com/
[9493:9493:0712/220244.918351:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:4_https://pages.ebay.com/, https://pages.ebay.com/, 4
[9493:9493:0712/220244.918437:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 4, 4, https://pages.ebay.com/, https://pages.ebay.com
[1:1:0712/220244.918661:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220244.938360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220244.938925:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220244.997450:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220244.998844:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:5_https://pages.ebay.com/, https://pages.ebay.com/, 5
[9493:9493:0712/220244.998902:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 5, 5, https://pages.ebay.com/, https://pages.ebay.com
[1:1:0712/220245.114271:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220245.118731:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:7_https://pages.ebay.com/, https://pages.ebay.com/, 7
[9493:9493:0712/220245.118788:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 7, 7, https://pages.ebay.com/, https://pages.ebay.com
[1:1:0712/220245.282449:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){var d=c.getBoundingClientRect().width,g=b.firstElementChild.getBoundingClientRect().left;
a.setSt
[1:1:0712/220245.282681:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220245.301719:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 796, 7f9132f2f881
[1:1:0712/220245.316526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"746 0x7f913f8fb960 0x244c2c9e1c40 0x244c2c9e1c50 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220245.316761:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"746 0x7f913f8fb960 0x244c2c9e1c40 0x244c2c9e1c50 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220245.316993:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220245.317269:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){f.on("resize.gh",d.execute_on_load_or_resize)}
[1:1:0712/220245.317405:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220245.398301:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220245.399526:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:8_https://pages.ebay.com/, https://pages.ebay.com/, 8
[9493:9493:0712/220245.399585:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 8, 8, https://pages.ebay.com/, https://pages.ebay.com
[9493:9493:0712/220245.443720:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:6_https://pages.ebay.com/, https://pages.ebay.com/, 6
[9493:9493:0712/220245.443786:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 6, 6, https://pages.ebay.com/, https://pages.ebay.com
[1:1:0712/220245.444194:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220245.501829:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:9_https://pages.ebay.com/, https://pages.ebay.com/, 9
[9493:9493:0712/220245.501904:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 9, 9, https://pages.ebay.com/, https://pages.ebay.com
[1:1:0712/220245.501871:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220245.542262:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:10_https://pages.ebay.com/, https://pages.ebay.com/, 10
[1:1:0712/220245.542272:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[9493:9493:0712/220245.542331:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 10, 10, https://pages.ebay.com/, https://pages.ebay.com
[9493:9493:0712/220245.596173:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 7, 7:11_https://pages.ebay.com/, https://pages.ebay.com/, 11
[9493:9493:0712/220245.596241:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 11, 11, https://pages.ebay.com/, https://pages.ebay.com
[1:1:0712/220245.596537:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/220245.716427:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220245.825348:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220245.825577:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220245.877271:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220246.122148:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220246.303206:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.ebay.com/"
[1:1:0712/220246.303696:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (a){var d=a.source;if(d==b||!d&&"si"===a.data)a.stopPropagation(),0<c.length&&c.shift()()}
[1:1:0712/220246.303872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220246.358865:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3500, 0x3cb3640029c8, 0x244c2ab1fa20
[1:1:0712/220246.359083:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 3500
[1:1:0712/220246.359330:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 921
[1:1:0712/220246.359486:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 921 0x7f91305ea070 0x244c2cdc9f60 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 856 0x7f91305ea070 0x244c2cdca7e0 
[1:1:0712/220246.470347:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220246.639075:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220246.816247:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220246.983606:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.119410:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.355220:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.355399:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19392.html"
[1:1:0712/220247.380438:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220247.380602:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220247.416110:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.416258:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19393.html"
[1:1:0712/220247.457125:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.457285:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19395.html"
[1:1:0712/220247.554963:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.555138:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19396.html"
[1:1:0712/220247.598891:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.599055:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19394.html"
[1:1:0712/220247.675707:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.675882:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19397.html"
[1:1:0712/220247.756438:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.756619:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19398.html"
[1:1:0712/220247.783376:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/220247.783557:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "https://pages.ebay.com/SE/en-US/rtm_default/1200/19399.html"
[1:1:0712/220247.923807:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220247.924005:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[9493:9505:0712/220248.440236:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -100
[1:1:0712/220248.663995:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220248.664191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[9493:9505:0712/220248.779122:ERROR:ssl_client_socket_impl.cc(1046)] handshake failed; returned -1, SSL error code 1, net_error -101
[1:1:0712/220249.051473:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220249.051635:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220249.284614:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 486, 7f9132f2f881
[1:1:0712/220249.303894:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"444 0x7f91305ea070 0x244c2afd3b60 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220249.304149:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"444 0x7f91305ea070 0x244c2afd3b60 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220249.304447:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220249.304979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , GH.windowLoad()
[1:1:0712/220249.305126:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220249.381957:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220249.382183:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220249.696871:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220249.697069:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220250.133186:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220250.133398:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220250.290099:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 921, 7f9132f2f881
[1:1:0712/220250.310790:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"856 0x7f91305ea070 0x244c2cdca7e0 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220250.311004:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"856 0x7f91305ea070 0x244c2cdca7e0 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220250.311246:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220250.311573:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){if(a.isMoving)return a.once("carousel-update",j);j()}
[1:1:0712/220250.311689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220250.433130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220250.433301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220250.597261:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.ebay.com/"
[1:1:0712/220250.597663:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (a){var d=a.source;if(d==b||!d&&"si"===a.data)a.stopPropagation(),0<c.length&&c.shift()()}
[1:1:0712/220250.597804:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220250.649559:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3500, 0x3cb3640029c8, 0x244c2ab1fa20
[1:1:0712/220250.649715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 3500
[1:1:0712/220250.649881:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 1175
[1:1:0712/220250.649992:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1175 0x7f91305ea070 0x244c2d073c60 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 1157 0x7f91305ea070 0x244c2cec63e0 
[1:1:0712/220250.689967:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220250.690159:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220250.913230:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220250.913448:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220251.172200:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220251.172372:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220251.598035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220251.598200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220252.282232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220252.282424:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[9493:9493:0712/220252.442792:WARNING:gaia_auth_fetcher.cc(873)] Could not reach Google Accounts servers: errno -356
[1:1:0712/220252.724587:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "transitionend", "https://www.ebay.com/"
[1:1:0712/220252.725423:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (b){b.target===a.listEl&&a.emitUpdate()}
[1:1:0712/220252.725565:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220252.785205:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220252.785385:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220253.226531:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220253.226725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220253.337246:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.337657:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , loadAll, (){for(var e=H.queue.length-1;0<=e;e--){var n=document.createEvent("Event");n.initEvent("lazyLoad",!
[1:1:0712/220253.337798:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220253.338485:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.342171:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.345728:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.349183:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.352534:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.355909:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.359192:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.362521:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.366044:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.369617:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.373120:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.376327:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.380687:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.384137:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.387819:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.390984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "lazyLoad", "https://www.ebay.com/"
[1:1:0712/220253.412275:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.430881:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.432594:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.434402:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3cb3640029c8, 0x244c2ab1f9f0
[1:1:0712/220253.434575:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 1
[1:1:0712/220253.434782:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:11_https://pages.ebay.com/, 1338
[1:1:0712/220253.434901:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1338 0x7f91305ea070 0x244c2cd817e0 , 7:11_https://pages.ebay.com/, 1, -7:3_https://www.ebay.com/, 1303 0x7f91305ea070 0x244c2d0b48e0 
[1:1:0712/220253.439357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1, 0x3cb3640029c8, 0x244c2ab1f9f0
[1:1:0712/220253.439468:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 1
[1:1:0712/220253.439623:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:11_https://pages.ebay.com/, 1339
[1:1:0712/220253.439736:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1339 0x7f91305ea070 0x244c2cec61e0 , 7:11_https://pages.ebay.com/, 1, -7:3_https://www.ebay.com/, 1303 0x7f91305ea070 0x244c2d0b48e0 
[1:1:0712/220253.440029:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.440875:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.444103:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.446887:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220253.624526:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , document.readyState
[1:1:0712/220253.624728:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220253.824143:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , windowLoad, (){var a;if(!GH.windowLoaded)for(objName in GH.windowLoaded=!0,GH.CompConstructors)try{a=GH[objName]
[1:1:0712/220253.824320:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220254.461390:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:11_https://pages.ebay.com/, 1338, 7f9132f2f881
[1:1:0712/220254.481663:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"1303 0x7f91305ea070 0x244c2d0b48e0 ","rf":"7:11_https://pages.ebay.com/"}
[1:1:0712/220254.481809:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"1303 0x7f91305ea070 0x244c2d0b48e0 ","rf":"7:11_https://pages.ebay.com/"}
[1:1:0712/220254.481983:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220254.482239:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){b.ajax(c,{dataType:"jsonp",jsonpCallback:"GH_personalizedData"})}
[1:1:0712/220254.482341:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220254.484094:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/220254.562067:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:11_https://pages.ebay.com/, 1339, 7f9132f2f881
[1:1:0712/220254.583900:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"1303 0x7f91305ea070 0x244c2d0b48e0 ","rf":"7:11_https://pages.ebay.com/"}
[1:1:0712/220254.584198:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"1303 0x7f91305ea070 0x244c2d0b48e0 ","rf":"7:11_https://pages.ebay.com/"}
[1:1:0712/220254.584466:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220254.584754:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){f()||a("#gh-sbc-o").append(b.buildOverlayHTML()).addClass("gh-o")}
[1:1:0712/220254.584854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220255.029187:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 1175, 7f9132f2f881
[1:1:0712/220255.052198:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"26a706d82860","ptid":"1157 0x7f91305ea070 0x244c2cec63e0 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220255.052423:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-7:3_https://www.ebay.com/","ptid":"1157 0x7f91305ea070 0x244c2cec63e0 ","rf":"7:3_https://www.ebay.com/"}
[1:1:0712/220255.052660:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "https://www.ebay.com/"
[1:1:0712/220255.052976:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (){if(a.isMoving)return a.once("carousel-update",j);j()}
[1:1:0712/220255.053123:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220255.574971:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220255.575378:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220255.575501:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220255.742895:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220255.743366:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220255.743503:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220255.881522:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220255.881943:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220255.882084:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220255.936388:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "https://www.ebay.com/"
[1:1:0712/220255.936808:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , (a){var d=a.source;if(d==b||!d&&"si"===a.data)a.stopPropagation(),0<c.length&&c.shift()()}
[1:1:0712/220255.936942:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220255.989731:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 3500, 0x3cb3640029c8, 0x244c2ab1fa20
[1:1:0712/220255.989893:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "https://www.ebay.com/", 3500
[1:1:0712/220255.990063:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 7:3_https://www.ebay.com/, 1479
[1:1:0712/220255.990194:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1479 0x7f91305ea070 0x244c2cfb1c60 , 7:3_https://www.ebay.com/, 1, -7:3_https://www.ebay.com/, 1427 0x7f91305ea070 0x244c2d048e60 
[1:1:0712/220256.053572:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.053952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.054088:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.097788:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.098141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.098276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.202735:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.203133:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.203243:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.266496:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.266848:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.266977:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.311332:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.311739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.311872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.389910:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1445 0x7f91325122e0 0x244c2bc30460 , "https://www.ebay.com/"
[1:1:0712/220256.390548:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , try{window.HL_AD_TRACKING_CALLBACK([
{"width":"0","id":"1650","type":"none","content":"","height":"0
[1:1:0712/220256.390689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.392592:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.415882:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1446 0x7f91325122e0 0x244c2a9a1160 , "https://www.ebay.com/"
[1:1:0712/220256.416653:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , try{window.HL_CAT_NAV_RTM_CALLBACK([{"iid":"4496816799494669721","width":"770","mid":"17360","id":"1
[1:1:0712/220256.416782:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.533719:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.534156:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.534288:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.828944:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 1463 0x7f91325122e0 0x244c2afd3660 , "https://www.ebay.com/"
[1:1:0712/220256.829608:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , , GH_personalizedData({"error":"Bullseye for cart count call returned empty JSON response with error c
[1:1:0712/220256.829783:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.830208:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.926018:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.926430:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.926570:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220256.971751:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220256.972115:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220256.972259:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220257.072336:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220257.072765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220257.072893:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220257.117556:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220257.117899:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220257.118030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220257.182803:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220257.183185:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220257.183329:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220257.283479:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220257.283931:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220257.284072:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
[1:1:0712/220257.412339:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "https://www.ebay.com/"
[1:1:0712/220257.412760:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -7:3_https://www.ebay.com/, 26a706d82860, , e, (n){t&&a&&(H.setLoadTime(a),a.src=i,a[T](u,e),a[T](w,r),t.style.backgroundImage="url('"+i+"')",t[E](
[1:1:0712/220257.412904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "https://www.ebay.com/", "www.ebay.com", 3, 1, , , 0
