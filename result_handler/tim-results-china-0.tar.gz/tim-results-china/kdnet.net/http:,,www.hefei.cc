[0712/171504.959646:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/171504.959900:INFO:switcher_clone.cc(787)] backtrace rip is 7f0eebc09891
[0712/171505.511057:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/171505.511306:INFO:switcher_clone.cc(787)] backtrace rip is 7fbc97407891
[1:1:0712/171505.515205:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0712/171505.515373:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0712/171505.518233:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[27423:27423:0712/171506.299040:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/1d1dbf2a-885f-4b0b-9a27-ef8600c0c941
[0712/171506.354424:INFO:switcher_clone.cc(818)] ### setup!!!
[0712/171506.354686:INFO:switcher_clone.cc(787)] backtrace rip is 7f6a2442c891
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[27454:27454:0712/171506.504443:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=27454
[27469:27469:0712/171506.504774:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=27469
[27423:27423:0712/171506.557530:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[27423:27452:0712/171506.557932:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0712/171506.558060:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/171506.558222:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/171506.558558:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/171506.558700:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0712/171506.561849:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xa1421aa, 1
[1:1:0712/171506.562089:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0xf7122e9, 0
[1:1:0712/171506.562189:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x2989dc68, 3
[1:1:0712/171506.562276:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x7fc616a, 2
[1:1:0712/171506.562371:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffe922710f ffffffaa21140a 6a61fffffffc07 68ffffffdcffffff8929 , 10104, 4
[1:1:0712/171506.563086:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[27423:27452:0712/171506.563205:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING�"q�!
ja�h܉)��
[1:1:0712/171506.563243:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbc956410a0, 3
[27423:27452:0712/171506.563358:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is �"q�!
ja�h܉)Hz��
[1:1:0712/171506.563385:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbc957cd080, 2
[27423:27452:0712/171506.563511:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[1:1:0712/171506.563471:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbc7f48fd20, -2
[27423:27452:0712/171506.563549:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 27477, 4, e922710f aa21140a 6a61fc07 68dc8929 
[1:1:0712/171506.571268:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/171506.571732:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7fc616a
[1:1:0712/171506.572201:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7fc616a
[1:1:0712/171506.572967:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7fc616a
[1:1:0712/171506.573534:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.573655:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.573771:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.573884:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.574147:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7fc616a
[1:1:0712/171506.574315:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbc974077ba
[1:1:0712/171506.574411:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbc973fedef, 7fbc9740777a, 7fbc974090cf
[1:1:0712/171506.576070:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 7fc616a
[1:1:0712/171506.576243:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 7fc616a
[1:1:0712/171506.576541:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 7fc616a
[1:1:0712/171506.577393:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.577513:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.577614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.577724:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 7fc616a
[1:1:0712/171506.578250:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 7fc616a
[1:1:0712/171506.578414:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbc974077ba
[1:1:0712/171506.578470:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbc973fedef, 7fbc9740777a, 7fbc974090cf
[1:1:0712/171506.581212:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/171506.581444:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/171506.581560:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde54adb38, 0x7ffde54adab8)
[1:1:0712/171506.588417:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/171506.591169:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[27423:27423:0712/171507.028599:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27423:27423:0712/171507.029180:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27423:27434:0712/171507.036760:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[27423:27434:0712/171507.036821:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[27423:27423:0712/171507.036831:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[27423:27423:0712/171507.036873:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[27423:27423:0712/171507.036935:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,27477, 4
[1:7:0712/171507.037787:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/171507.083943:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0x73c96073220
[1:1:0712/171507.084086:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[27423:27445:0712/171507.094573:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0712/171507.269294:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0712/171507.947498:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/171507.949176:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[27423:27423:0712/171507.991793:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[27423:27423:0712/171507.991865:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/171508.379051:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/171508.428162:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/171508.428333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171508.433996:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0712/171508.434118:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171508.515967:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171508.516105:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171508.674913:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 359, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171508.677415:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/171508.677548:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171508.689563:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 360, "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171508.692511:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0712/171508.692639:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171508.696389:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[27423:27423:0712/171508.697050:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/171508.698160:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x73c96071e20
[1:1:0712/171508.698261:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[27423:27423:0712/171508.699513:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[27423:27423:0712/171508.710987:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[27423:27423:0712/171508.711067:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0712/171508.730612:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171509.029995:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 419 0x7fbc8106a2e0 0x73c9617d560 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171509.030735:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0712/171509.030914:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171509.031559:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[27423:27423:0712/171509.057836:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0712/171509.058946:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0x73c96072820
[1:1:0712/171509.059116:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[27423:27423:0712/171509.060375:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0712/171509.066006:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0712/171509.066248:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[27423:27423:0712/171509.068249:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[27423:27423:0712/171509.073113:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27423:27423:0712/171509.073554:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[27423:27434:0712/171509.078059:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[27423:27434:0712/171509.078113:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[27423:27423:0712/171509.078132:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[27423:27423:0712/171509.078170:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[27423:27423:0712/171509.078230:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,27477, 4
[1:7:0712/171509.079545:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/171509.351960:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0712/171509.475357:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 469 0x7fbc8106a2e0 0x73c963e5360 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171509.475992:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0712/171509.476148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171509.476543:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[27423:27423:0712/171509.618966:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[27423:27423:0712/171509.619045:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0712/171509.630612:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171509.763595:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[27423:27423:0712/171509.920895:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[27423:27452:0712/171509.921161:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0712/171509.921285:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0712/171509.921411:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0712/171509.921594:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0712/171509.921670:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0712/171509.924048:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0xbb4e4aa, 1
[1:1:0712/171509.924279:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x18cd3342, 0
[1:1:0712/171509.924379:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x68d92c3, 3
[1:1:0712/171509.924531:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x178d06de, 2
[1:1:0712/171509.924644:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 4233ffffffcd18 ffffffaaffffffe4ffffffb40b ffffffde06ffffff8d17 ffffffc3ffffff92ffffff8d06 , 10104, 5
[1:1:0712/171509.925384:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[27423:27452:0712/171509.925536:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGB3�����Ò���
[27423:27452:0712/171509.925580:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is B3�����Ò��&��
[1:1:0712/171509.925526:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbc956410a0, 3
[1:1:0712/171509.925623:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbc957cd080, 2
[27423:27452:0712/171509.925720:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 27521, 5, 4233cd18 aae4b40b de068d17 c3928d06 
[1:1:0712/171509.925716:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7fbc7f48fd20, -2
[1:1:0712/171509.934790:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0712/171509.934987:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 178d06de
[1:1:0712/171509.935143:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 178d06de
[1:1:0712/171509.935400:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 178d06de
[1:1:0712/171509.935899:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.935995:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.936087:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.936179:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.936427:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 178d06de
[1:1:0712/171509.936562:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbc974077ba
[1:1:0712/171509.936639:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbc973fedef, 7fbc9740777a, 7fbc974090cf
[1:1:0712/171509.938341:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 178d06de
[1:1:0712/171509.938512:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 178d06de
[1:1:0712/171509.938812:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 178d06de
[1:1:0712/171509.939566:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.939664:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.939768:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.939871:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 178d06de
[1:1:0712/171509.940357:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 178d06de
[1:1:0712/171509.940525:INFO:switcher_clone.cc(775)] clone wrapper rip is 7fbc974077ba
[1:1:0712/171509.940609:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7fbc973fedef, 7fbc9740777a, 7fbc974090cf
[1:1:0712/171509.943192:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0712/171509.943442:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0712/171509.943553:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffde54adb38, 0x7ffde54adab8)
[1:1:0712/171509.949506:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0712/171509.951645:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0712/171509.962392:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171509.962532:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/171510.048425:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0x73c96033220
[1:1:0712/171510.048577:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0712/171510.179210:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 542, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/171510.180781:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c0edac2e5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0712/171510.180915:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/171510.183170:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/171510.239426:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0712/171510.239825:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 0c0edab01f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0712/171510.239951:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0712/171510.286005:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/171510.286732:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/171510.286856:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c0edac2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/171510.286999:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[27423:27423:0712/171510.345229:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[27423:27423:0712/171510.347157:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[1:1:0712/171510.350366:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "message", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/171510.350833:INFO:switcher_impl.cc(1329)] 			updated frame chain. [WARN] the first frame is not the last frame in GPFrameChain. [first, lastGP] = 4:4_chrome-search://most-visited/, 4:1_chrome-search://local-ntp/
[1:1:0712/171510.350941:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c0edac2e5b8, , handlePostMessage, (event) {
  if (event.data instanceof Array) {
    for (var i = 0; i < event.data.length; ++i) {
   
[1:1:0712/171510.351140:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[27423:27423:0712/171510.364945:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://www.hefei.cc/
[27423:27423:0712/171510.364998:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hefei.cc/, http://www.hefei.cc/, 1
[27423:27423:0712/171510.365057:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://www.hefei.cc/, HTTP/1.1 200 OK Server: nginx Date: Fri, 12 Jul 2019 09:15:10 GMT Content-Type: text/html;charset=gbk Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Set-Cookie: PHPSESSID=b71q7ddug82ltaek7dnuhceg75; path=/ Expires: Thu, 19 Nov 1981 08:52:00 GMT Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0 Pragma: no-cache Content-Encoding: gzip  ,27521, 5
[27423:27434:0712/171510.391566:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[27423:27434:0712/171510.391630:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0712/171510.392109:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0712/171510.413775:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://www.hefei.cc/
[27423:27423:0712/171510.468494:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://www.hefei.cc/, http://www.hefei.cc/, 1
[27423:27423:0712/171510.468552:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://www.hefei.cc/, http://www.hefei.cc
[1:1:0712/171510.481406:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171510.482648:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171510.521096:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/171510.544432:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171510.545275:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://m.vk.com/"
[1:1:0712/171510.566045:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171510.566237:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hefei.cc/"
[1:1:0712/171510.625799:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.qq.com/"
[1:1:0712/171510.727166:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://amazon.com/"
[1:1:0712/171510.785091:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://taobao.com/"
[1:1:0712/171510.812108:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://tmall.com/"
[1:1:0712/171510.850708:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://www.jd.com/"
[1:1:0712/171510.968159:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://yahoo.com/"
[1:1:0712/171511.003705:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_FAILED","chrome-search://thumb/https://sohu.com/"
[1:1:0712/171511.023854:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0712/171511.024278:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 0c0edac2e5b8, , countLoad, () {
  loadedCounter -= 1;
  if (loadedCounter <= 0) {
    swapInNewTiles();
    logEvent(LOG_TYPE.N
[1:1:0712/171511.024422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0712/171511.387399:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fbc957cd080 0x73c961eab00 1 0 0x73c961eab18 , "http://www.hefei.cc/"
[1:1:0712/171511.400475:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/171511.403910:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , /*!
 * jQuery JavaScript Library v1.4.2
 * http://jquery.com/
 *
 * Copyright 2010, John Resig

[1:1:0712/171511.404208:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171511.423414:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fbc957cd080 0x73c961eab00 1 0 0x73c961eab18 , "http://www.hefei.cc/"
[1:1:0712/171511.472800:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 221 0x7fbc957cd080 0x73c961eab00 1 0 0x73c961eab18 , "http://www.hefei.cc/"
[1:1:0712/171511.578510:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 237, "http://www.hefei.cc/"
[1:1:0712/171511.579160:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , ,  function   ad(){if(document.getElementById("edu_ad63")) {document.getElementById("edu_ad63").innerH
[1:1:0712/171511.579322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171511.616089:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.036242, 164, 1
[1:1:0712/171511.616276:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/171511.754964:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171511.755144:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hefei.cc/"
[1:1:0712/171511.755566:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 261 0x7fbc7f142070 0x73c96345860 , "http://www.hefei.cc/"
[1:1:0712/171511.756047:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , 
	function check_form(name)
	{
		var x ;
		var mycars =[1,2,4,5,6];
		for ( x in mycars)
		{
			chgC
[1:1:0712/171511.756170:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171511.856090:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.100931, 1865, 1
[1:1:0712/171511.856268:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/171512.348972:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171512.349193:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hefei.cc/"
[1:1:0712/171512.349621:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7fbc7f142070 0x73c9638f4e0 , "http://www.hefei.cc/"
[1:1:0712/171512.350175:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , 
ad();
jQuery(document).ready(function(){
if(jQuery("#slideAD div").html()==""){jQuery("#slideAD").d
[1:1:0712/171512.350342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171512.360731:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7fbc7f142070 0x73c9638f4e0 , "http://www.hefei.cc/"
[1:1:0712/171512.382580:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7fbc7f142070 0x73c9638f4e0 , "http://www.hefei.cc/"
[1:1:0712/171512.694928:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 332 0x7fbc7f142070 0x73c9638f4e0 , "http://www.hefei.cc/"
[1:1:0712/171513.674715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 5000
[1:1:0712/171513.675057:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 410
[1:1:0712/171513.675223:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 410 0x7fbc7f142070 0x73c964a9de0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 332 0x7fbc7f142070 0x73c9638f4e0 
[1:1:0712/171513.755459:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 5000
[1:1:0712/171513.755735:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 416
[1:1:0712/171513.755860:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 416 0x7fbc7f142070 0x73c962ba5e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 332 0x7fbc7f142070 0x73c9638f4e0 
[1:1:0712/171513.776811:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 1.42758, 0, 0
[1:1:0712/171513.776990:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/171514.484269:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171514.484413:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://www.hefei.cc/"
[1:1:0712/171514.486191:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 423 0x7fbc7f142070 0x73c96b45560 , "http://www.hefei.cc/"
[1:1:0712/171514.488680:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (function(){function p(){this.c="840562";this.ca="z";this.Y="pic";this.V="";this.X="";this.D="156291
[1:1:0712/171514.488821:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171515.249435:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0712/171515.676991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.678346:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , !function(){var p,q,r,a=function(){var b,c,d,e,a=document.getElementsByTagName("script");for(b=0,c=a
[1:1:0712/171515.678526:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171515.698664:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.720969:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.723544:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.725274:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.727064:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.728272:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[1:1:0712/171515.730063:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 547, "http://www.hefei.cc/"
[27423:27423:0712/171523.230776:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=840562&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s138.cnzz.com/stat.php?id=840562&web_id=840562&show=pic (17)
[27423:27423:0712/171523.231670:INFO:CONSOLE(17)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://c.cnzz.com/core.php?web_id=840562&show=pic&t=z, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://s138.cnzz.com/stat.php?id=840562&web_id=840562&show=pic (17)
[27423:27423:0712/171523.251099:INFO:CONSOLE(157)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://stat.house365.com/hfcccount.php?website=2&referer=&resource=http%3A//www.hefei.cc/&charset=GBK&guid=453823882&sessionid=569767767&isnewvisiter=1&subsecs=0&bwlastvdays=0&todayfirst=1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stat.house365.com/hfcccount.js (157)
[27423:27423:0712/171523.251906:INFO:CONSOLE(157)] "A parser-blocking, cross site (i.e. different eTLD+1) script, http://stat.house365.com/hfcccount.php?website=2&referer=&resource=http%3A//www.hefei.cc/&charset=GBK&guid=453823882&sessionid=569767767&isnewvisiter=1&subsecs=0&bwlastvdays=0&todayfirst=1, is invoked via document.write. The network request for this script MAY be blocked by the browser in this or a future page load due to poor network connectivity. If blocked in this page load, it will be confirmed in a subsequent console message. See https://www.chromestatus.com/feature/5718547946799104 for more details.", source: http://stat.house365.com/hfcccount.js (157)
[3:3:0712/171523.285358:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0712/171524.044474:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649, "http://www.hefei.cc/"
[1:1:0712/171524.044951:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , 
[1:1:0712/171524.045090:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171524.046788:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649, "http://www.hefei.cc/"
[1:1:0712/171524.114559:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 649, "http://www.hefei.cc/"
[1:1:0712/171524.137098:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.hefei.cc/"
[1:1:0712/171524.167675:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 4000
[1:1:0712/171524.167933:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 802
[1:1:0712/171524.168053:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 802 0x7fbc7f142070 0x73c961e54e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 649
[1:1:0712/171524.170823:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 30000
[1:1:0712/171524.171032:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 803
[1:1:0712/171524.171143:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 803 0x7fbc7f142070 0x73c961ebf60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 649
[1:1:0712/171524.183107:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://www.hefei.cc/"
[1:1:0712/171525.247014:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0712/171525.247252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171525.526249:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171525.526585:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171525.526811:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171525.527029:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171525.527243:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0712/171525.797829:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 410, 7fbc81a878db
[1:1:0712/171525.812210:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"332 0x7fbc7f142070 0x73c9638f4e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171525.812444:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"332 0x7fbc7f142070 0x73c9638f4e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171525.812680:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 894
[1:1:0712/171525.812819:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 894 0x7fbc7f142070 0x73c962a6d60 , 5:3_http://www.hefei.cc/, 0, , 410 0x7fbc7f142070 0x73c964a9de0 
[1:1:0712/171525.812954:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171525.813233:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171525.813395:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171525.817227:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171525.817393:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171525.817597:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 895
[1:1:0712/171525.817723:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 895 0x7fbc7f142070 0x73c96289ee0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 410 0x7fbc7f142070 0x73c964a9de0 
[1:1:0712/171525.818167:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 416, 7fbc81a878db
[1:1:0712/171525.832298:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"332 0x7fbc7f142070 0x73c9638f4e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171525.832489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"332 0x7fbc7f142070 0x73c9638f4e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171525.832691:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 896
[1:1:0712/171525.832802:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 896 0x7fbc7f142070 0x73c96a7b3e0 , 5:3_http://www.hefei.cc/, 0, , 416 0x7fbc7f142070 0x73c962ba5e0 
[1:1:0712/171525.832935:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171525.833213:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171525.833318:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171525.840162:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171525.840311:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171525.840479:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 897
[1:1:0712/171525.840578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 897 0x7fbc7f142070 0x73c964b7ce0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 416 0x7fbc7f142070 0x73c962ba5e0 
[1:1:0712/171527.248993:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "error", "http://www.hefei.cc/"
[1:1:0712/171527.249428:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , a.(anonymous function).e.(anonymous function).onload.e.(anonymous function).onerror.e.(anonymous function).onabort, (){try{this.onload=this.onerror=this.onabort=null,e[this.ka]=null}catch(f){}}
[1:1:0712/171527.249544:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171527.339493:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171527.339651:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171527.623784:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0712/171527.886987:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 895, 7fbc81a87881
[1:1:0712/171527.903115:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"410 0x7fbc7f142070 0x73c964a9de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171527.903317:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"410 0x7fbc7f142070 0x73c964a9de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171527.903612:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171527.904018:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171527.904153:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171527.905572:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171527.905694:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171527.905876:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 958
[1:1:0712/171527.906005:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 958 0x7fbc7f142070 0x73c962a9a60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 895 0x7fbc7f142070 0x73c96289ee0 
[1:1:0712/171527.906501:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 897, 7fbc81a87881
[1:1:0712/171527.923562:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"416 0x7fbc7f142070 0x73c962ba5e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171527.923744:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"416 0x7fbc7f142070 0x73c962ba5e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171527.923919:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171527.924201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171527.924297:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171527.924966:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171527.925092:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171527.925251:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 959
[1:1:0712/171527.925366:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 959 0x7fbc7f142070 0x73c9628c9e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 897 0x7fbc7f142070 0x73c964b7ce0 
[1:1:0712/171528.490099:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171528.490264:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171528.814995:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0712/171528.815172:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "data:text/html,pluginplaceholderdata"
[1:1:0712/171528.815950:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 945 0x7fbc7f142070 0x73c96b295e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/171528.816476:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 04bbf1766410, , , 
        function setMessage(msg) {
          document.getElementById('message').textContent = msg;

[1:1:0712/171528.816618:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/171528.828429:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 945 0x7fbc7f142070 0x73c96b295e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/171528.831061:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 945 0x7fbc7f142070 0x73c96b295e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/171528.832465:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 945 0x7fbc7f142070 0x73c96b295e0 , "data:text/html,pluginplaceholderdata"
[1:1:0712/171529.108930:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 958, 7fbc81a87881
[1:1:0712/171529.125795:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"895 0x7fbc7f142070 0x73c96289ee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.126026:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"895 0x7fbc7f142070 0x73c96289ee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.126262:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171529.126634:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171529.126790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171529.127581:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171529.127729:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171529.127929:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1021
[1:1:0712/171529.128042:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1021 0x7fbc7f142070 0x73c9649abe0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 958 0x7fbc7f142070 0x73c962a9a60 
[1:1:0712/171529.128653:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 959, 7fbc81a87881
[1:1:0712/171529.146542:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"897 0x7fbc7f142070 0x73c964b7ce0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.146738:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"897 0x7fbc7f142070 0x73c964b7ce0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.146923:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171529.147214:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171529.147324:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171529.147870:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171529.147969:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171529.148119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1022
[1:1:0712/171529.148214:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1022 0x7fbc7f142070 0x73c964c87e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 959 0x7fbc7f142070 0x73c9628c9e0 
[1:1:0712/171529.203315:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 802, 7fbc81a878db
[1:1:0712/171529.220535:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"649","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.220731:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"649","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.220939:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1026
[1:1:0712/171529.221076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1026 0x7fbc7f142070 0x73c9631d7e0 , 5:3_http://www.hefei.cc/, 0, , 802 0x7fbc7f142070 0x73c961e54e0 
[1:1:0712/171529.221281:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171529.221563:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){showNextBox();}
[1:1:0712/171529.221682:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171529.397079:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171529.397284:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171529.549742:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 894, 7fbc81a878db
[1:1:0712/171529.568791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"410 0x7fbc7f142070 0x73c964a9de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.568974:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"410 0x7fbc7f142070 0x73c964a9de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.569202:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1037
[1:1:0712/171529.569436:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1037 0x7fbc7f142070 0x73c962b5760 , 5:3_http://www.hefei.cc/, 0, , 894 0x7fbc7f142070 0x73c962a6d60 
[1:1:0712/171529.569701:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171529.570012:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171529.570110:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171529.570690:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171529.570798:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171529.570963:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1038
[1:1:0712/171529.571062:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1038 0x7fbc7f142070 0x73c964b7ce0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 894 0x7fbc7f142070 0x73c962a6d60 
[1:1:0712/171529.590682:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 896, 7fbc81a878db
[1:1:0712/171529.608227:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"416 0x7fbc7f142070 0x73c962ba5e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.608383:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"416 0x7fbc7f142070 0x73c962ba5e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171529.608561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1040
[1:1:0712/171529.608659:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1040 0x7fbc7f142070 0x73c965755e0 , 5:3_http://www.hefei.cc/, 0, , 896 0x7fbc7f142070 0x73c96a7b3e0 
[1:1:0712/171529.608827:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171529.609121:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171529.609227:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171529.615911:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171529.616076:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171529.616260:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1041
[1:1:0712/171529.616392:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1041 0x7fbc7f142070 0x73c96a718e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 896 0x7fbc7f142070 0x73c96a7b3e0 
[1:1:0712/171529.816997:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "data:text/html,pluginplaceholderdata"
[1:1:0712/171529.818035:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:0_null/, 04bbf1766410, , onload, notifyDidFinishLoading();
[1:1:0712/171529.818166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "data:text/html,pluginplaceholderdata", "", 0, 1, , , 0
[1:1:0712/171530.227948:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171530.228147:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171530.284288:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1038, 7fbc81a87881
[1:1:0712/171530.302331:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"894 0x7fbc7f142070 0x73c962a6d60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171530.302565:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"894 0x7fbc7f142070 0x73c962a6d60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171530.302866:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171530.303206:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171530.303321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171530.303940:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171530.304058:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171530.304232:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1074
[1:1:0712/171530.304355:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1074 0x7fbc7f142070 0x73c97a992e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1038 0x7fbc7f142070 0x73c964b7ce0 
[1:1:0712/171530.304912:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1041, 7fbc81a87881
[1:1:0712/171530.323507:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"896 0x7fbc7f142070 0x73c96a7b3e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171530.323707:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"896 0x7fbc7f142070 0x73c96a7b3e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171530.323900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171530.324202:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171530.324322:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171530.324906:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171530.325003:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171530.325199:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1075
[1:1:0712/171530.325317:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1075 0x7fbc7f142070 0x73c97dba7e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1041 0x7fbc7f142070 0x73c96a718e0 
[1:1:0712/171530.950238:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171530.950402:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171530.972300:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1074, 7fbc81a87881
[1:1:0712/171530.990841:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1038 0x7fbc7f142070 0x73c964b7ce0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171530.991096:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1038 0x7fbc7f142070 0x73c964b7ce0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171530.991698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171530.992302:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171530.992415:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171530.993143:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171530.993295:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171530.993505:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1104
[1:1:0712/171530.993645:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1104 0x7fbc7f142070 0x73c96321960 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1074 0x7fbc7f142070 0x73c97a992e0 
[1:1:0712/171530.994576:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1075, 7fbc81a87881
[1:1:0712/171531.014161:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1041 0x7fbc7f142070 0x73c96a718e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.014333:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1041 0x7fbc7f142070 0x73c96a718e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.014510:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171531.014826:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171531.014944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.015507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171531.015603:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171531.015754:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1106
[1:1:0712/171531.015852:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1106 0x7fbc7f142070 0x73c95d50ee0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1075 0x7fbc7f142070 0x73c97dba7e0 
[1:1:0712/171531.396515:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171531.396680:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.549941:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1104, 7fbc81a87881
[1:1:0712/171531.571578:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1074 0x7fbc7f142070 0x73c97a992e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.571759:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1074 0x7fbc7f142070 0x73c97a992e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.571934:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171531.572251:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171531.572374:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.573045:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171531.573159:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171531.573310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1130
[1:1:0712/171531.573423:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1130 0x7fbc7f142070 0x73c97ea2460 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1104 0x7fbc7f142070 0x73c96321960 
[1:1:0712/171531.594104:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1106, 7fbc81a87881
[1:1:0712/171531.612831:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1075 0x7fbc7f142070 0x73c97dba7e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.613002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1075 0x7fbc7f142070 0x73c97dba7e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.613204:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171531.613488:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171531.613596:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.614126:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171531.614210:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171531.614388:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1133
[1:1:0712/171531.614510:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1133 0x7fbc7f142070 0x73c965cc8e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1106 0x7fbc7f142070 0x73c95d50ee0 
[1:1:0712/171531.727431:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171531.727589:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.943101:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1130, 7fbc81a87881
[1:1:0712/171531.963235:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1104 0x7fbc7f142070 0x73c96321960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.963419:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1104 0x7fbc7f142070 0x73c96321960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.963623:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171531.963978:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171531.964122:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.964824:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171531.964958:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171531.965181:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1147
[1:1:0712/171531.965300:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1147 0x7fbc7f142070 0x73c97f68e60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1130 0x7fbc7f142070 0x73c97ea2460 
[1:1:0712/171531.965879:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1133, 7fbc81a87881
[1:1:0712/171531.986678:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1106 0x7fbc7f142070 0x73c95d50ee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.986895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1106 0x7fbc7f142070 0x73c95d50ee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171531.987097:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171531.987697:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171531.987824:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171531.988390:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171531.988526:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171531.988720:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1150
[1:1:0712/171531.988851:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1150 0x7fbc7f142070 0x73c97ea22e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1133 0x7fbc7f142070 0x73c965cc8e0 
[1:1:0712/171532.010076:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171532.010248:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.358750:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1147, 7fbc81a87881
[1:1:0712/171532.379633:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1130 0x7fbc7f142070 0x73c97ea2460 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.379895:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1130 0x7fbc7f142070 0x73c97ea2460 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.380140:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171532.380497:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171532.380650:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.381376:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171532.381510:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171532.381714:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1170
[1:1:0712/171532.381859:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1170 0x7fbc7f142070 0x73c97ea1260 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1147 0x7fbc7f142070 0x73c97f68e60 
[1:1:0712/171532.403902:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171532.404081:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.405574:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1150, 7fbc81a87881
[1:1:0712/171532.426369:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1133 0x7fbc7f142070 0x73c965cc8e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.426569:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1133 0x7fbc7f142070 0x73c965cc8e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.426773:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171532.427108:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171532.427233:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.427812:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171532.427913:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171532.428081:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1176
[1:1:0712/171532.428208:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1176 0x7fbc7f142070 0x73c97ea51e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1150 0x7fbc7f142070 0x73c97ea22e0 
[1:1:0712/171532.527684:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1026, 7fbc81a878db
[1:1:0712/171532.546673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"802 0x7fbc7f142070 0x73c961e54e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.546827:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"802 0x7fbc7f142070 0x73c961e54e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.547008:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1179
[1:1:0712/171532.547114:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1179 0x7fbc7f142070 0x73c97e3cfe0 , 5:3_http://www.hefei.cc/, 0, , 1026 0x7fbc7f142070 0x73c9631d7e0 
[1:1:0712/171532.547283:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171532.547530:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){showNextBox();}
[1:1:0712/171532.547631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.836896:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1170, 7fbc81a87881
[1:1:0712/171532.856247:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1147 0x7fbc7f142070 0x73c97f68e60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.856456:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1147 0x7fbc7f142070 0x73c97f68e60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.856627:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171532.856888:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171532.856972:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.857717:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171532.857857:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171532.858159:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1191
[1:1:0712/171532.858294:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1191 0x7fbc7f142070 0x73c97f55ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1170 0x7fbc7f142070 0x73c97ea1260 
[1:1:0712/171532.878664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171532.878807:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.880035:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1176, 7fbc81a87881
[1:1:0712/171532.900517:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1150 0x7fbc7f142070 0x73c97ea22e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.900695:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1150 0x7fbc7f142070 0x73c97ea22e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171532.900862:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171532.901196:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171532.901301:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171532.901838:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171532.901935:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171532.902096:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1194
[1:1:0712/171532.902191:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1194 0x7fbc7f142070 0x73c97f58560 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1176 0x7fbc7f142070 0x73c97ea51e0 
[1:1:0712/171533.161172:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1191, 7fbc81a87881
[1:1:0712/171533.183051:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1170 0x7fbc7f142070 0x73c97ea1260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.183250:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1170 0x7fbc7f142070 0x73c97ea1260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.183444:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.183774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171533.183953:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.184635:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.184734:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.184895:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1206
[1:1:0712/171533.185003:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1206 0x7fbc7f142070 0x73c961411e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1191 0x7fbc7f142070 0x73c97f55ae0 
[1:1:0712/171533.207485:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171533.207679:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.209108:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1194, 7fbc81a87881
[1:1:0712/171533.229241:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1176 0x7fbc7f142070 0x73c97ea51e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.229419:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1176 0x7fbc7f142070 0x73c97ea51e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.229593:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.229875:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171533.229978:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.230507:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.230620:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.230779:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1210
[1:1:0712/171533.230895:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1210 0x7fbc7f142070 0x73c96340d60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1194 0x7fbc7f142070 0x73c97f58560 
[1:1:0712/171533.458799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1206, 7fbc81a87881
[1:1:0712/171533.480418:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1191 0x7fbc7f142070 0x73c97f55ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.480641:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1191 0x7fbc7f142070 0x73c97f55ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.480847:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.481201:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171533.481353:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.482003:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.482108:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.482276:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1222
[1:1:0712/171533.482390:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1222 0x7fbc7f142070 0x73c97e34d60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1206 0x7fbc7f142070 0x73c961411e0 
[1:1:0712/171533.521131:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171533.521286:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.522474:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1210, 7fbc81a87881
[1:1:0712/171533.542641:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1194 0x7fbc7f142070 0x73c97f58560 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.542820:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1194 0x7fbc7f142070 0x73c97f58560 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.542998:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.543275:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171533.543378:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.543925:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.544020:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.544169:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1225
[1:1:0712/171533.544277:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1225 0x7fbc7f142070 0x73c97ed27e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1210 0x7fbc7f142070 0x73c96340d60 
[1:1:0712/171533.772384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1222, 7fbc81a87881
[1:1:0712/171533.793925:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1206 0x7fbc7f142070 0x73c961411e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.794163:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1206 0x7fbc7f142070 0x73c961411e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.794408:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.794737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171533.794902:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.795524:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.795636:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.795830:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1240
[1:1:0712/171533.795941:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1240 0x7fbc7f142070 0x73c9639cf60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1222 0x7fbc7f142070 0x73c97e34d60 
[1:1:0712/171533.816736:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171533.816895:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.856940:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1225, 7fbc81a87881
[1:1:0712/171533.875857:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1210 0x7fbc7f142070 0x73c96340d60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.876043:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1210 0x7fbc7f142070 0x73c96340d60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.876236:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.876550:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171533.876658:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.877286:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.877420:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.877640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1243
[1:1:0712/171533.877828:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1243 0x7fbc7f142070 0x73c97fa25e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1225 0x7fbc7f142070 0x73c97ed27e0 
[1:1:0712/171533.878421:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1037, 7fbc81a878db
[1:1:0712/171533.899350:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"894 0x7fbc7f142070 0x73c962a6d60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.899537:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"894 0x7fbc7f142070 0x73c962a6d60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.899864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1244
[1:1:0712/171533.900035:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1244 0x7fbc7f142070 0x73c97ec2860 , 5:3_http://www.hefei.cc/, 0, , 1037 0x7fbc7f142070 0x73c962b5760 
[1:1:0712/171533.900278:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.900606:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171533.900697:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.901136:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.901239:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.901405:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1245
[1:1:0712/171533.901516:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1245 0x7fbc7f142070 0x73c97eec5e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1037 0x7fbc7f142070 0x73c962b5760 
[1:1:0712/171533.965437:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1040, 7fbc81a878db
[1:1:0712/171533.987057:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"896 0x7fbc7f142070 0x73c96a7b3e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.987246:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"896 0x7fbc7f142070 0x73c96a7b3e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171533.987475:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1249
[1:1:0712/171533.987599:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1249 0x7fbc7f142070 0x73c97f8fc60 , 5:3_http://www.hefei.cc/, 0, , 1040 0x7fbc7f142070 0x73c965755e0 
[1:1:0712/171533.987813:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171533.988158:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171533.988316:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171533.994920:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171533.995103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171533.995327:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1250
[1:1:0712/171533.995488:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1250 0x7fbc7f142070 0x73c97f2f9e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1040 0x7fbc7f142070 0x73c965755e0 
[1:1:0712/171534.171824:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171534.172017:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.193902:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1245, 7fbc81a87881
[1:1:0712/171534.213921:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1037 0x7fbc7f142070 0x73c962b5760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.214097:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1037 0x7fbc7f142070 0x73c962b5760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.214272:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171534.214570:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171534.214673:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.215262:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171534.215433:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171534.215696:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1263
[1:1:0712/171534.215843:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1263 0x7fbc7f142070 0x73c97f55ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1245 0x7fbc7f142070 0x73c97eec5e0 
[1:1:0712/171534.237895:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1250, 7fbc81a87881
[1:1:0712/171534.258511:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1040 0x7fbc7f142070 0x73c965755e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.258718:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1040 0x7fbc7f142070 0x73c965755e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.258942:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171534.259299:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171534.259460:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.259994:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171534.260075:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171534.260233:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1267
[1:1:0712/171534.260329:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1267 0x7fbc7f142070 0x73c97eb98e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1250 0x7fbc7f142070 0x73c97f2f9e0 
[1:1:0712/171534.449226:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171534.449434:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.597173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1263, 7fbc81a87881
[1:1:0712/171534.618777:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1245 0x7fbc7f142070 0x73c97eec5e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.619002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1245 0x7fbc7f142070 0x73c97eec5e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.619183:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171534.619481:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171534.619612:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.620398:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171534.620512:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171534.620688:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1280
[1:1:0712/171534.620855:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1280 0x7fbc7f142070 0x73c97dc1960 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1263 0x7fbc7f142070 0x73c97f55ae0 
[1:1:0712/171534.621481:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1267, 7fbc81a87881
[1:1:0712/171534.643425:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1250 0x7fbc7f142070 0x73c97f2f9e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.643652:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1250 0x7fbc7f142070 0x73c97f2f9e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.643871:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171534.644209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171534.644313:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.644891:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171534.644984:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171534.645143:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1283
[1:1:0712/171534.645258:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1283 0x7fbc7f142070 0x73c97f552e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1267 0x7fbc7f142070 0x73c97eb98e0 
[1:1:0712/171534.709539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171534.709692:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.964076:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1280, 7fbc81a87881
[1:1:0712/171534.988322:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1263 0x7fbc7f142070 0x73c97f55ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.988527:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1263 0x7fbc7f142070 0x73c97f55ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171534.988727:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171534.989024:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171534.989145:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171534.989770:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171534.989882:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171534.990066:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1299
[1:1:0712/171534.990201:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1299 0x7fbc7f142070 0x73c97f5c0e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1280 0x7fbc7f142070 0x73c97dc1960 
[1:1:0712/171534.991019:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1283, 7fbc81a87881
[1:1:0712/171535.013673:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1267 0x7fbc7f142070 0x73c97eb98e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.013861:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1267 0x7fbc7f142070 0x73c97eb98e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.014041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171535.014324:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171535.014469:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.015016:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171535.015128:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171535.015276:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1300
[1:1:0712/171535.015370:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1300 0x7fbc7f142070 0x73c97dc1c60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1283 0x7fbc7f142070 0x73c97f552e0 
[1:1:0712/171535.080751:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171535.080922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.338113:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1299, 7fbc81a87881
[1:1:0712/171535.362694:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1280 0x7fbc7f142070 0x73c97dc1960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.362875:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1280 0x7fbc7f142070 0x73c97dc1960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.363053:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171535.363389:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171535.363533:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.364375:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171535.364616:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171535.364828:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1312
[1:1:0712/171535.364929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1312 0x7fbc7f142070 0x73c97f55ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1299 0x7fbc7f142070 0x73c97f5c0e0 
[1:1:0712/171535.365739:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1300, 7fbc81a87881
[1:1:0712/171535.388392:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1283 0x7fbc7f142070 0x73c97f552e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.388584:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1283 0x7fbc7f142070 0x73c97f552e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.388775:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171535.389096:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171535.389214:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.389822:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171535.389926:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171535.390072:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1315
[1:1:0712/171535.390188:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1315 0x7fbc7f142070 0x73c97fcbde0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1300 0x7fbc7f142070 0x73c97dc1c60 
[1:1:0712/171535.434695:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171535.434869:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.666838:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1312, 7fbc81a87881
[1:1:0712/171535.687418:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1299 0x7fbc7f142070 0x73c97f5c0e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.687620:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1299 0x7fbc7f142070 0x73c97f5c0e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.687811:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171535.688103:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171535.688200:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.688806:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171535.688900:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171535.689051:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1327
[1:1:0712/171535.689226:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1327 0x7fbc7f142070 0x73c97fe3ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1312 0x7fbc7f142070 0x73c97f55ae0 
[1:1:0712/171535.689824:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1315, 7fbc81a87881
[1:1:0712/171535.712689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1300 0x7fbc7f142070 0x73c97dc1c60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.712910:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1300 0x7fbc7f142070 0x73c97dc1c60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171535.713129:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171535.713496:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171535.713606:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.714156:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171535.714256:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171535.714416:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1329
[1:1:0712/171535.714524:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1329 0x7fbc7f142070 0x73c97f5bbe0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1315 0x7fbc7f142070 0x73c97fcbde0 
[1:1:0712/171535.737626:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171535.737813:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171535.980604:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1327, 7fbc81a87881
[1:1:0712/171536.005434:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1312 0x7fbc7f142070 0x73c97f55ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.005678:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1312 0x7fbc7f142070 0x73c97f55ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.006041:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.006371:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171536.006527:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.007168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171536.007302:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171536.007527:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1340
[1:1:0712/171536.007648:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1340 0x7fbc7f142070 0x73c97f5c0e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1327 0x7fbc7f142070 0x73c97fe3ae0 
[1:1:0712/171536.008199:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1329, 7fbc81a87881
[1:1:0712/171536.031778:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1315 0x7fbc7f142070 0x73c97fcbde0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.031992:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1315 0x7fbc7f142070 0x73c97fcbde0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.032188:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.032514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171536.032872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.033486:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171536.033646:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171536.033873:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1345
[1:1:0712/171536.034040:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1345 0x7fbc7f142070 0x73c97ab82e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1329 0x7fbc7f142070 0x73c97f5bbe0 
[1:1:0712/171536.076508:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171536.076675:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.320349:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1340, 7fbc81a87881
[1:1:0712/171536.344549:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1327 0x7fbc7f142070 0x73c97fe3ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.344719:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1327 0x7fbc7f142070 0x73c97fe3ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.344880:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.345209:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171536.345304:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.345929:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171536.346025:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171536.346167:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1360
[1:1:0712/171536.346296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1360 0x7fbc7f142070 0x73c97ec98e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1340 0x7fbc7f142070 0x73c97f5c0e0 
[1:1:0712/171536.346861:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1345, 7fbc81a87881
[1:1:0712/171536.370254:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1329 0x7fbc7f142070 0x73c97f5bbe0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.370463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1329 0x7fbc7f142070 0x73c97f5bbe0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.370714:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.371063:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171536.371186:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.371828:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171536.371968:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171536.372166:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1363
[1:1:0712/171536.372296:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1363 0x7fbc7f142070 0x73c9795e960 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1345 0x7fbc7f142070 0x73c97ab82e0 
[1:1:0712/171536.441942:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171536.442119:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.466313:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1179, 7fbc81a878db
[1:1:0712/171536.488182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1026 0x7fbc7f142070 0x73c9631d7e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.488393:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1026 0x7fbc7f142070 0x73c9631d7e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.488619:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1368
[1:1:0712/171536.488795:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1368 0x7fbc7f142070 0x73c9793ea60 , 5:3_http://www.hefei.cc/, 0, , 1179 0x7fbc7f142070 0x73c97e3cfe0 
[1:1:0712/171536.489049:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.489379:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){showNextBox();}
[1:1:0712/171536.489524:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.747511:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1360, 7fbc81a87881
[1:1:0712/171536.772636:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1340 0x7fbc7f142070 0x73c97f5c0e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.772843:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1340 0x7fbc7f142070 0x73c97f5c0e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.773072:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.773397:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171536.773528:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.774221:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171536.774347:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171536.774524:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1381
[1:1:0712/171536.774616:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1381 0x7fbc7f142070 0x73c97fdb760 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1360 0x7fbc7f142070 0x73c97ec98e0 
[1:1:0712/171536.775162:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1363, 7fbc81a87881
[1:1:0712/171536.799044:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1345 0x7fbc7f142070 0x73c97ab82e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.799243:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1345 0x7fbc7f142070 0x73c97ab82e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171536.799468:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171536.799883:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171536.800029:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171536.800642:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171536.800753:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171536.800918:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1382
[1:1:0712/171536.801015:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1382 0x7fbc7f142070 0x73c97fc2ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1363 0x7fbc7f142070 0x73c9795e960 
[1:1:0712/171536.847987:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171536.848148:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171537.162242:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1381, 7fbc81a87881
[1:1:0712/171537.187705:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1360 0x7fbc7f142070 0x73c97ec98e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.187954:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1360 0x7fbc7f142070 0x73c97ec98e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.188191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171537.188539:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171537.188653:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171537.189306:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171537.189400:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171537.189543:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1396
[1:1:0712/171537.189630:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1396 0x7fbc7f142070 0x73c97463460 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1381 0x7fbc7f142070 0x73c97fdb760 
[1:1:0712/171537.214283:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1382, 7fbc81a87881
[1:1:0712/171537.236931:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1363 0x7fbc7f142070 0x73c9795e960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.237161:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1363 0x7fbc7f142070 0x73c9795e960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.237359:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171537.237667:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171537.237791:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171537.238349:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171537.238448:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171537.238640:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1398
[1:1:0712/171537.238785:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1398 0x7fbc7f142070 0x73c97eb7760 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1382 0x7fbc7f142070 0x73c97fc2ae0 
[1:1:0712/171537.262737:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171537.262939:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171537.531285:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1396, 7fbc81a87881
[1:1:0712/171537.650181:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1381 0x7fbc7f142070 0x73c97fdb760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.650392:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1381 0x7fbc7f142070 0x73c97fdb760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.650576:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171537.650881:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171537.650979:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171537.651594:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171537.651715:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171537.651880:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1414
[1:1:0712/171537.651988:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1414 0x7fbc7f142070 0x73c97fb6060 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1396 0x7fbc7f142070 0x73c97463460 
[1:1:0712/171537.652792:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1398, 7fbc81a87881
[1:1:0712/171537.676449:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1382 0x7fbc7f142070 0x73c97fc2ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.678414:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1382 0x7fbc7f142070 0x73c97fc2ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171537.678624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171537.678927:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171537.679051:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171537.679615:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171537.679728:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171537.679904:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1418
[1:1:0712/171537.680017:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1418 0x7fbc7f142070 0x73c97462f60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1398 0x7fbc7f142070 0x73c97eb7760 
[1:1:0712/171537.726136:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171537.726285:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.115509:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1414, 7fbc81a87881
[1:1:0712/171538.141769:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1396 0x7fbc7f142070 0x73c97463460 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.141964:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1396 0x7fbc7f142070 0x73c97463460 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.142166:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171538.142504:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171538.142631:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.143247:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171538.143392:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171538.143611:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1433
[1:1:0712/171538.143770:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1433 0x7fbc7f142070 0x73c97ff3c60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1414 0x7fbc7f142070 0x73c97fb6060 
[1:1:0712/171538.144407:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1418, 7fbc81a87881
[1:1:0712/171538.170101:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1398 0x7fbc7f142070 0x73c97eb7760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.170312:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1398 0x7fbc7f142070 0x73c97eb7760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.170517:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171538.170802:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171538.170944:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.171520:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171538.171626:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171538.171792:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1436
[1:1:0712/171538.171907:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1436 0x7fbc7f142070 0x73c97eec260 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1418 0x7fbc7f142070 0x73c97462f60 
[1:1:0712/171538.196975:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171538.197176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.523173:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1433, 7fbc81a87881
[1:1:0712/171538.547372:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1414 0x7fbc7f142070 0x73c97fb6060 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.547604:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1414 0x7fbc7f142070 0x73c97fb6060 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.547849:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171538.548220:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171538.548373:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.549118:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171538.549273:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171538.549453:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1449
[1:1:0712/171538.549578:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1449 0x7fbc7f142070 0x73c97ffb060 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1433 0x7fbc7f142070 0x73c97ff3c60 
[1:1:0712/171538.575772:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171538.575930:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.577216:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1436, 7fbc81a87881
[1:1:0712/171538.601815:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1418 0x7fbc7f142070 0x73c97462f60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.602024:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1418 0x7fbc7f142070 0x73c97462f60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171538.602260:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171538.602645:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171538.602776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171538.603426:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171538.603534:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171538.603693:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1454
[1:1:0712/171538.603801:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1454 0x7fbc7f142070 0x73c9649fa60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1436 0x7fbc7f142070 0x73c97eec260 
[1:1:0712/171538.978703:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1449, 7fbc81a87881
[1:1:0712/171539.004457:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1433 0x7fbc7f142070 0x73c97ff3c60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.004648:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1433 0x7fbc7f142070 0x73c97ff3c60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.004890:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171539.005210:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171539.005309:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.006037:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171539.006151:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171539.006317:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1479
[1:1:0712/171539.006459:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1479 0x7fbc7f142070 0x73c97eb9ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1449 0x7fbc7f142070 0x73c97ffb060 
[1:1:0712/171539.057360:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171539.057573:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.058981:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1454, 7fbc81a87881
[1:1:0712/171539.084186:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1436 0x7fbc7f142070 0x73c97eec260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.084431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1436 0x7fbc7f142070 0x73c97eec260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.085309:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171539.085687:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171539.085872:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.086492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171539.086648:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171539.086868:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1482
[1:1:0712/171539.086998:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1482 0x7fbc7f142070 0x73c97dc1960 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1454 0x7fbc7f142070 0x73c9649fa60 
[1:1:0712/171539.087543:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1244, 7fbc81a878db
[1:1:0712/171539.111995:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1037 0x7fbc7f142070 0x73c962b5760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.112175:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1037 0x7fbc7f142070 0x73c962b5760 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.112386:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1483
[1:1:0712/171539.112503:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1483 0x7fbc7f142070 0x73c9723a160 , 5:3_http://www.hefei.cc/, 0, , 1244 0x7fbc7f142070 0x73c97ec2860 
[1:1:0712/171539.112686:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171539.112952:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171539.113104:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.113526:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171539.113639:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171539.113809:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1484
[1:1:0712/171539.113936:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1484 0x7fbc7f142070 0x73c97da4360 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1244 0x7fbc7f142070 0x73c97ec2860 
[1:1:0712/171539.164064:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1249, 7fbc81a878db
[1:1:0712/171539.188828:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1040 0x7fbc7f142070 0x73c965755e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.189002:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1040 0x7fbc7f142070 0x73c965755e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.189223:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1488
[1:1:0712/171539.189359:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1488 0x7fbc7f142070 0x73c96598560 , 5:3_http://www.hefei.cc/, 0, , 1249 0x7fbc7f142070 0x73c97f8fc60 
[1:1:0712/171539.189553:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171539.189831:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171539.189941:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.196456:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171539.196629:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171539.196834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1489
[1:1:0712/171539.196957:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1489 0x7fbc7f142070 0x73c98000960 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1249 0x7fbc7f142070 0x73c97f8fc60 
[1:1:0712/171539.651130:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171539.651366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.701799:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1484, 7fbc81a87881
[1:1:0712/171539.725955:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1244 0x7fbc7f142070 0x73c97ec2860 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.726141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1244 0x7fbc7f142070 0x73c97ec2860 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.726324:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171539.726630:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171539.726740:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.727346:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171539.727539:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171539.727820:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1507
[1:1:0712/171539.727994:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1507 0x7fbc7f142070 0x73c97f58ae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1484 0x7fbc7f142070 0x73c97da4360 
[1:1:0712/171539.728564:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1489, 7fbc81a87881
[1:1:0712/171539.753224:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1249 0x7fbc7f142070 0x73c97f8fc60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.753441:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1249 0x7fbc7f142070 0x73c97f8fc60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171539.753717:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171539.754094:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171539.754252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171539.754913:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171539.755129:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171539.755325:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1509
[1:1:0712/171539.755478:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1509 0x7fbc7f142070 0x73c97f5b9e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1489 0x7fbc7f142070 0x73c98000960 
[1:1:0712/171540.103658:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171540.103854:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.169502:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1507, 7fbc81a87881
[1:1:0712/171540.197756:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1484 0x7fbc7f142070 0x73c97da4360 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.197961:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1484 0x7fbc7f142070 0x73c97da4360 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.198224:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171540.198546:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171540.198668:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.199329:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171540.199429:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171540.199591:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1531
[1:1:0712/171540.199703:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1531 0x7fbc7f142070 0x73c98000be0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1507 0x7fbc7f142070 0x73c97f58ae0 
[1:1:0712/171540.252900:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1509, 7fbc81a87881
[1:1:0712/171540.277269:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1489 0x7fbc7f142070 0x73c98000960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.277449:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1489 0x7fbc7f142070 0x73c98000960 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.277624:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171540.277925:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171540.278030:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.278564:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171540.278659:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171540.278828:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1536
[1:1:0712/171540.278935:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1536 0x7fbc7f142070 0x73c95c64e60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1509 0x7fbc7f142070 0x73c97f5b9e0 
[1:1:0712/171540.459561:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171540.459721:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.534562:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1368, 7fbc81a878db
[1:1:0712/171540.561178:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1179 0x7fbc7f142070 0x73c97e3cfe0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.561356:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1179 0x7fbc7f142070 0x73c97e3cfe0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.561579:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1541
[1:1:0712/171540.561707:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1541 0x7fbc7f142070 0x73c97e3cfe0 , 5:3_http://www.hefei.cc/, 0, , 1368 0x7fbc7f142070 0x73c9793ea60 
[1:1:0712/171540.561900:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171540.562165:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){showNextBox();}
[1:1:0712/171540.562276:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.767777:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1531, 7fbc81a87881
[1:1:0712/171540.796657:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1507 0x7fbc7f142070 0x73c97f58ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.796877:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1507 0x7fbc7f142070 0x73c97f58ae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.797074:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171540.797418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171540.797554:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.798222:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171540.798332:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171540.798502:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1551
[1:1:0712/171540.798614:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1551 0x7fbc7f142070 0x73c964a06e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1531 0x7fbc7f142070 0x73c98000be0 
[1:1:0712/171540.852598:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1536, 7fbc81a87881
[1:1:0712/171540.877805:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1509 0x7fbc7f142070 0x73c97f5b9e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.878014:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1509 0x7fbc7f142070 0x73c97f5b9e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171540.878261:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171540.878607:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171540.878761:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171540.879378:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171540.879516:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171540.879730:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1555
[1:1:0712/171540.879847:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1555 0x7fbc7f142070 0x73c97fc2ee0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1536 0x7fbc7f142070 0x73c95c64e60 
[1:1:0712/171540.932212:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171540.932380:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171541.263259:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1551, 7fbc81a87881
[1:1:0712/171541.289217:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1531 0x7fbc7f142070 0x73c98000be0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.289398:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1531 0x7fbc7f142070 0x73c98000be0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.289584:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171541.289897:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171541.290004:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171541.290632:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171541.290795:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171541.291038:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1573
[1:1:0712/171541.291213:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1573 0x7fbc7f142070 0x73c962825e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1551 0x7fbc7f142070 0x73c964a06e0 
[1:1:0712/171541.291840:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1555, 7fbc81a87881
[1:1:0712/171541.318245:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1536 0x7fbc7f142070 0x73c95c64e60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.318463:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1536 0x7fbc7f142070 0x73c95c64e60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.318692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171541.319017:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171541.319169:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171541.319835:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171541.319948:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171541.320119:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1575
[1:1:0712/171541.320219:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1575 0x7fbc7f142070 0x73c964a0a60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1555 0x7fbc7f142070 0x73c97fc2ee0 
[1:1:0712/171541.346939:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171541.347106:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171541.754960:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1573, 7fbc81a87881
[1:1:0712/171541.784071:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1551 0x7fbc7f142070 0x73c964a06e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.784252:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1551 0x7fbc7f142070 0x73c964a06e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.784438:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171541.784728:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171541.784827:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171541.785464:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171541.785568:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171541.785738:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1591
[1:1:0712/171541.785858:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1591 0x7fbc7f142070 0x73c9629aee0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1573 0x7fbc7f142070 0x73c962825e0 
[1:1:0712/171541.786433:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1575, 7fbc81a87881
[1:1:0712/171541.816704:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1555 0x7fbc7f142070 0x73c97fc2ee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.816907:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1555 0x7fbc7f142070 0x73c97fc2ee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171541.817105:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171541.817447:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171541.817599:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171541.818197:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171541.818291:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171541.818435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1596
[1:1:0712/171541.818547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1596 0x7fbc7f142070 0x73c96b2c660 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1575 0x7fbc7f142070 0x73c964a0a60 
[1:1:0712/171541.869042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171541.869488:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.005016:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hefei.cc/"
[1:1:0712/171542.005487:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , ready, (){if(!c.isReady){if(!s.body)return setTimeout(c.ready,13);c.isReady=true;if(Q){for(var a,b=0;a=Q[b+
[1:1:0712/171542.005642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.005877:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://www.hefei.cc/"
[1:1:0712/171542.300822:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1591, 7fbc81a87881
[1:1:0712/171542.321791:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1573 0x7fbc7f142070 0x73c962825e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.321983:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1573 0x7fbc7f142070 0x73c962825e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.322191:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171542.322533:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171542.322689:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.323357:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171542.323504:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171542.323748:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1616
[1:1:0712/171542.323878:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1616 0x7fbc7f142070 0x73c97f68f60 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1591 0x7fbc7f142070 0x73c9629aee0 
[1:1:0712/171542.324423:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1596, 7fbc81a87881
[1:1:0712/171542.347695:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1575 0x7fbc7f142070 0x73c964a0a60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.347851:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1575 0x7fbc7f142070 0x73c964a0a60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.348017:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171542.348277:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171542.348388:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.348897:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171542.348983:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171542.349150:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1618
[1:1:0712/171542.349275:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1618 0x7fbc7f142070 0x73c96a7a9e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1596 0x7fbc7f142070 0x73c96b2c660 
[1:1:0712/171542.423089:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , document.readyState
[1:1:0712/171542.423270:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.836430:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1616, 7fbc81a87881
[1:1:0712/171542.865306:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1591 0x7fbc7f142070 0x73c9629aee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.865509:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1591 0x7fbc7f142070 0x73c9629aee0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.865692:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171542.865964:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171542.866082:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.866696:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171542.866809:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171542.866978:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1639
[1:1:0712/171542.867099:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1639 0x7fbc7f142070 0x73c97f8d6e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1616 0x7fbc7f142070 0x73c97f68f60 
[1:1:0712/171542.915420:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1618, 7fbc81a87881
[1:1:0712/171542.937905:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1596 0x7fbc7f142070 0x73c96b2c660 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.938074:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1596 0x7fbc7f142070 0x73c96b2c660 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171542.938251:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171542.938592:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171542.938725:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171542.939303:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171542.939405:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171542.939567:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1641
[1:1:0712/171542.939679:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1641 0x7fbc7f142070 0x73c96598660 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1618 0x7fbc7f142070 0x73c96a7a9e0 
[1:1:0712/171543.342662:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1639, 7fbc81a87881
[1:1:0712/171543.372346:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1616 0x7fbc7f142070 0x73c97f68f60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.372529:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1616 0x7fbc7f142070 0x73c97f68f60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.372696:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171543.372974:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171543.373091:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171543.373765:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171543.373883:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171543.374094:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1655
[1:1:0712/171543.374230:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1655 0x7fbc7f142070 0x73c97ff9060 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1639 0x7fbc7f142070 0x73c97f8d6e0 
[1:1:0712/171543.402590:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1641, 7fbc81a87881
[1:1:0712/171543.426991:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1618 0x7fbc7f142070 0x73c96a7a9e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.427163:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1618 0x7fbc7f142070 0x73c96a7a9e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.427339:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171543.427619:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171543.427742:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171543.428266:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171543.428361:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171543.428513:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1660
[1:1:0712/171543.428605:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1660 0x7fbc7f142070 0x73c964c1ee0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1641 0x7fbc7f142070 0x73c96598660 
[1:1:0712/171543.854499:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1655, 7fbc81a87881
[1:1:0712/171543.877423:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1639 0x7fbc7f142070 0x73c97f8d6e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.877583:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1639 0x7fbc7f142070 0x73c97f8d6e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.877756:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171543.878058:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171543.878179:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171543.878792:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171543.878928:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171543.879146:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1678
[1:1:0712/171543.879260:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1678 0x7fbc7f142070 0x73c96335660 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1655 0x7fbc7f142070 0x73c97ff9060 
[1:1:0712/171543.879786:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1660, 7fbc81a87881
[1:1:0712/171543.903956:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1641 0x7fbc7f142070 0x73c96598660 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.904103:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1641 0x7fbc7f142070 0x73c96598660 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171543.904271:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171543.904510:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171543.904609:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171543.905182:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171543.905279:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171543.905430:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1680
[1:1:0712/171543.905536:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1680 0x7fbc7f142070 0x73c97fc21e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1660 0x7fbc7f142070 0x73c964c1ee0 
[1:1:0712/171544.007974:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1483, 7fbc81a878db
[1:1:0712/171544.033271:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1244 0x7fbc7f142070 0x73c97ec2860 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.033431:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1244 0x7fbc7f142070 0x73c97ec2860 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.033616:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1687
[1:1:0712/171544.033734:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1687 0x7fbc7f142070 0x73c97ec2d60 , 5:3_http://www.hefei.cc/, 0, , 1483 0x7fbc7f142070 0x73c9723a160 
[1:1:0712/171544.033914:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171544.034188:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171544.034296:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171544.034699:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171544.034803:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171544.034959:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1688
[1:1:0712/171544.035068:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1688 0x7fbc7f142070 0x73c96b421e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1483 0x7fbc7f142070 0x73c9723a160 
[1:1:0712/171544.106716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1488, 7fbc81a878db
[1:1:0712/171544.129887:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1249 0x7fbc7f142070 0x73c97f8fc60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.130037:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1249 0x7fbc7f142070 0x73c97f8fc60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.130215:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1690
[1:1:0712/171544.130331:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1690 0x7fbc7f142070 0x73c9806bf60 , 5:3_http://www.hefei.cc/, 0, , 1488 0x7fbc7f142070 0x73c96598560 
[1:1:0712/171544.130509:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171544.130765:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){
					//用于判断方向不同的时候，页数的显示;
					if(opts.direction == 'left'||
[1:1:0712/171544.130881:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171544.136958:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171544.137115:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171544.137281:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1691
[1:1:0712/171544.137402:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1691 0x7fbc7f142070 0x73c97f2f360 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1488 0x7fbc7f142070 0x73c96598560 
[1:1:0712/171544.463440:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1688, 7fbc81a87881
[1:1:0712/171544.486083:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1483 0x7fbc7f142070 0x73c9723a160 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.486261:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1483 0x7fbc7f142070 0x73c9723a160 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.486440:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171544.486723:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171544.486838:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171544.487460:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171544.487582:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171544.487771:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1705
[1:1:0712/171544.487920:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1705 0x7fbc7f142070 0x73c96a7bae0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1688 0x7fbc7f142070 0x73c96b421e0 
[1:1:0712/171544.536190:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1691, 7fbc81a87881
[1:1:0712/171544.562170:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1488 0x7fbc7f142070 0x73c96598560 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.562416:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1488 0x7fbc7f142070 0x73c96598560 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.562662:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171544.563005:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171544.563160:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171544.563739:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171544.563862:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171544.564054:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1710
[1:1:0712/171544.564185:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1710 0x7fbc7f142070 0x73c9795ede0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1691 0x7fbc7f142070 0x73c97f2f360 
[1:1:0712/171544.564716:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1541, 7fbc81a878db
[1:1:0712/171544.592106:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"1368 0x7fbc7f142070 0x73c9793ea60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.592268:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"1368 0x7fbc7f142070 0x73c9793ea60 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.592445:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://www.hefei.cc/, 1711
[1:1:0712/171544.592547:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1711 0x7fbc7f142070 0x73c97fae160 , 5:3_http://www.hefei.cc/, 0, , 1541 0x7fbc7f142070 0x73c97e3cfe0 
[1:1:0712/171544.592715:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171544.592968:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , , (){showNextBox();}
[1:1:0712/171544.593061:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171544.911773:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1705, 7fbc81a87881
[1:1:0712/171544.937583:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1688 0x7fbc7f142070 0x73c96b421e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.937746:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1688 0x7fbc7f142070 0x73c96b421e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171544.937929:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171544.938256:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171544.938366:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171544.938977:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171544.939118:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171544.939310:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1726
[1:1:0712/171544.939473:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1726 0x7fbc7f142070 0x73c9799b8e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1705 0x7fbc7f142070 0x73c96a7bae0 
[1:1:0712/171544.992079:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1710, 7fbc81a87881
[1:1:0712/171545.016266:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1691 0x7fbc7f142070 0x73c97f2f360 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.016486:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1691 0x7fbc7f142070 0x73c97f2f360 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.016698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171545.017020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171545.017163:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171545.017708:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171545.017806:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171545.017964:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1730
[1:1:0712/171545.018076:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1730 0x7fbc7f142070 0x73c97eb9660 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1710 0x7fbc7f142070 0x73c9795ede0 
[1:1:0712/171545.366136:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1726, 7fbc81a87881
[1:1:0712/171545.393216:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1705 0x7fbc7f142070 0x73c96a7bae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.393408:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1705 0x7fbc7f142070 0x73c96a7bae0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.393583:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171545.393904:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171545.394041:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171545.394666:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171545.394797:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171545.394975:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1744
[1:1:0712/171545.395109:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1744 0x7fbc7f142070 0x73c96164260 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1726 0x7fbc7f142070 0x73c9799b8e0 
[1:1:0712/171545.422584:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1730, 7fbc81a87881
[1:1:0712/171545.446623:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1710 0x7fbc7f142070 0x73c9795ede0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.446801:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1710 0x7fbc7f142070 0x73c9795ede0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.446970:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171545.447237:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171545.447337:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171545.447848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171545.447941:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171545.448101:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1748
[1:1:0712/171545.448195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1748 0x7fbc7f142070 0x73c9723a360 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1730 0x7fbc7f142070 0x73c97eb9660 
[1:1:0712/171545.797068:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1744, 7fbc81a87881
[1:1:0712/171545.825853:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1726 0x7fbc7f142070 0x73c9799b8e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.826071:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1726 0x7fbc7f142070 0x73c9799b8e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.826256:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171545.826621:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171545.826790:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171545.827484:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171545.827594:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171545.827764:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1760
[1:1:0712/171545.827868:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1760 0x7fbc7f142070 0x73c96140ce0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1744 0x7fbc7f142070 0x73c96164260 
[1:1:0712/171545.828387:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1748, 7fbc81a87881
[1:1:0712/171545.853666:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1730 0x7fbc7f142070 0x73c97eb9660 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.853847:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1730 0x7fbc7f142070 0x73c97eb9660 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171545.854016:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171545.854287:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171545.854391:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171545.854926:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171545.855026:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171545.855185:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1761
[1:1:0712/171545.855302:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1761 0x7fbc7f142070 0x73c96041de0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1748 0x7fbc7f142070 0x73c9723a360 
[1:1:0712/171546.131729:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1760, 7fbc81a87881
[1:1:0712/171546.160911:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1744 0x7fbc7f142070 0x73c96164260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.161141:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1744 0x7fbc7f142070 0x73c96164260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.161305:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171546.161620:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171546.161776:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171546.162492:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171546.162643:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171546.162864:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1775
[1:1:0712/171546.163009:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1775 0x7fbc7f142070 0x73c97ec27e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1760 0x7fbc7f142070 0x73c96140ce0 
[1:1:0712/171546.193062:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1761, 7fbc81a87881
[1:1:0712/171546.219257:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1748 0x7fbc7f142070 0x73c9723a360 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.219489:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1748 0x7fbc7f142070 0x73c9723a360 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.219655:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171546.219944:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171546.220045:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171546.220594:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171546.220689:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171546.220833:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1779
[1:1:0712/171546.220929:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1779 0x7fbc7f142070 0x73c97fc21e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1761 0x7fbc7f142070 0x73c96041de0 
[1:1:0712/171546.558644:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1775, 7fbc81a87881
[1:1:0712/171546.588603:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1760 0x7fbc7f142070 0x73c96140ce0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.588808:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1760 0x7fbc7f142070 0x73c96140ce0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.588997:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171546.589305:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171546.589465:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171546.590125:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171546.590241:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171546.590418:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1792
[1:1:0712/171546.590532:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1792 0x7fbc7f142070 0x73c97588de0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1775 0x7fbc7f142070 0x73c97ec27e0 
[1:1:0712/171546.616663:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1779, 7fbc81a87881
[1:1:0712/171546.641622:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1761 0x7fbc7f142070 0x73c96041de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.641789:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1761 0x7fbc7f142070 0x73c96041de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.641956:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171546.642221:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171546.642321:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171546.642848:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171546.642941:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171546.643092:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1794
[1:1:0712/171546.643195:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1794 0x7fbc7f142070 0x73c96321260 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1779 0x7fbc7f142070 0x73c97fc21e0 
[1:1:0712/171546.929117:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1792, 7fbc81a87881
[1:1:0712/171546.959008:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1775 0x7fbc7f142070 0x73c97ec27e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.959205:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1775 0x7fbc7f142070 0x73c97ec27e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.959403:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171546.959726:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171546.959860:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171546.960487:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171546.960591:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171546.960834:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1804
[1:1:0712/171546.960972:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1804 0x7fbc7f142070 0x73c974bc360 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1792 0x7fbc7f142070 0x73c97588de0 
[1:1:0712/171546.961527:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1794, 7fbc81a87881
[1:1:0712/171546.988965:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1779 0x7fbc7f142070 0x73c97fc21e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.989173:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1779 0x7fbc7f142070 0x73c97fc21e0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171546.989342:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171546.989643:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171546.989747:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171546.990297:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171546.990399:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171546.990561:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1807
[1:1:0712/171546.990671:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1807 0x7fbc7f142070 0x73c97ecc360 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1794 0x7fbc7f142070 0x73c96321260 
[1:1:0712/171547.277344:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1804, 7fbc81a87881
[1:1:0712/171547.306689:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1792 0x7fbc7f142070 0x73c97588de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171547.306872:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1792 0x7fbc7f142070 0x73c97588de0 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171547.307072:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171547.307372:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171547.307506:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171547.308117:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171547.308233:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171547.308443:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1818
[1:1:0712/171547.308566:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1818 0x7fbc7f142070 0x73c972229e0 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1804 0x7fbc7f142070 0x73c974bc360 
[1:1:0712/171547.334770:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1807, 7fbc81a87881
[1:1:0712/171547.361949:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"04bbf16a2860","ptid":"1794 0x7fbc7f142070 0x73c96321260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171547.362142:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://www.hefei.cc/","ptid":"1794 0x7fbc7f142070 0x73c96321260 ","rf":"5:3_http://www.hefei.cc/"}
[1:1:0712/171547.362350:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://www.hefei.cc/"
[1:1:0712/171547.362640:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://www.hefei.cc/, 04bbf16a2860, , scrollFunc, (){
				var _dir = (opts.direction == 'left' || opts.direction == 'right') ? 'scrollLeft':'scrollTo
[1:1:0712/171547.362760:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://www.hefei.cc/", "www.hefei.cc", 3, 1, , , 0
[1:1:0712/171547.363281:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 10, 0xc6a451629c8, 0x73c95eb1950
[1:1:0712/171547.363378:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://www.hefei.cc/", 10
[1:1:0712/171547.363536:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://www.hefei.cc/, 1822
[1:1:0712/171547.363644:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 1822 0x7fbc7f142070 0x73c97da7560 , 5:3_http://www.hefei.cc/, 1, -5:3_http://www.hefei.cc/, 1807 0x7fbc7f142070 0x73c97ecc360 
