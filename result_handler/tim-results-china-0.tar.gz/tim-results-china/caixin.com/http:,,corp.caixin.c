[0713/010928.124310:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010928.124565:INFO:switcher_clone.cc(787)] backtrace rip is 7fca86cf0891
[0713/010928.674909:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010928.675157:INFO:switcher_clone.cc(787)] backtrace rip is 7f4044e82891
[1:1:0713/010928.678983:INFO:content_main_runner.cc(320)] >>> [Setup] RunZyote
[1:1:0713/010928.679148:INFO:zygote_main_linux.cc(351)] >>> [Setup] tmpfile success. fd is 315
[3:3:0713/010928.681994:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 3
[0713/010929.499631:INFO:switcher_clone.cc(818)] ### setup!!!
[0713/010929.499918:INFO:switcher_clone.cc(787)] backtrace rip is 7f875332e891
[5937:5937:0713/010929.558613:INFO:extension_system_impl.cc(379)] >>> [browser][EXT] ExtensionSystemImpl::InitForRegularProfile

DevTools listening on ws://127.0.0.1:9222/devtools/browser/d2cb58b5-2ce6-48ef-93a6-53e97f551f67
ATTENTION: default value of option force_s3tc_enable overridden by environment.
[5971:5971:0713/010929.650881:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5971
[5982:5982:0713/010929.651198:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=5982
[5937:5937:0713/010929.798965:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 4
[5937:5967:0713/010929.799378:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 4
[3:3:0713/010929.799517:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/010929.799693:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/010929.800176:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/010929.800307:INFO:zygote_linux.cc(633)] 		cid is 4
[1:1:0713/010929.804589:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x34e29224, 1
[1:1:0713/010929.804808:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x2528b726, 0
[1:1:0713/010929.804902:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x31f6453, 3
[1:1:0713/010929.804969:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x39e516c5, 2
[1:1:0713/010929.805058:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = 26ffffffb72825 24ffffff92ffffffe234 ffffffc516ffffffe539 53641f03 , 10104, 4
[1:1:0713/010929.805837:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5937:5967:0713/010929.805945:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PING&�(%$��4��9Sd�C,
[5937:5967:0713/010929.805987:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is &�(%$��4��9Sd���C,
[1:1:0713/010929.805946:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f40430bc0a0, 3
[1:1:0713/010929.806065:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4043248080, 2
[5937:5967:0713/010929.806150:INFO:switcher_host_impl.cc(16)] >>> [INIT] create a SwitcherSiteQueue
[5937:5967:0713/010929.806187:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 5990, 4, 26b72825 2492e234 c516e539 53641f03 
[1:1:0713/010929.806150:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f402cf0ad20, -2
[1:1:0713/010929.813949:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/010929.814402:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 39e516c5
[1:1:0713/010929.814844:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 39e516c5
[1:1:0713/010929.815622:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 39e516c5
[1:1:0713/010929.816211:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.816308:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.816408:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.816495:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.816716:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 39e516c5
[1:1:0713/010929.816852:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4044e827ba
[1:1:0713/010929.816908:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4044e79def, 7f4044e8277a, 7f4044e840cf
[1:1:0713/010929.818643:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 39e516c5
[1:1:0713/010929.818866:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 39e516c5
[1:1:0713/010929.819206:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 39e516c5
[1:1:0713/010929.820023:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.820112:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.820211:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.820285:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 39e516c5
[1:1:0713/010929.820764:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 39e516c5
[1:1:0713/010929.820906:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4044e827ba
[1:1:0713/010929.820962:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4044e79def, 7f4044e8277a, 7f4044e840cf
[1:1:0713/010929.823385:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/010929.823578:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/010929.823648:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4d5f9a28, 0x7ffe4d5f99a8)
[1:1:0713/010929.830241:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/010929.834118:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[5937:5937:0713/010930.229892:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5937:5937:0713/010930.230373:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5937:5937:0713/010930.239939:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://local-ntp/
[5937:5937:0713/010930.240001:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/local-ntp.html, 1
[5937:5937:0713/010930.240073:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:1_chrome-search://local-ntp/, HTTP/1.1 200 OK Content-Security-Policy: script-src 'strict-dynamic' 'sha256-Fl9ifwsOFaaBTg9WmeRGJRw8O0Xrn9qON++y9ixPeek=' 'sha256-F/uxTxmIB+TXvkVBPdiX36hMiHjGTtrHZWFzoRAgyoY=';object-src 'none';child-src chrome-search://most-visited/ https://*.google.com/; X-Frame-Options: DENY Cache-Control: no-cache  ,5990, 4
[5937:5948:0713/010930.241112:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 1
[5937:5948:0713/010930.241174:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 1, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/010930.242585:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010930.292825:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 1, 0xeda8a4bf220
[1:1:0713/010930.293179:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 1
[5937:5961:0713/010930.334031:WARNING:simple_synchronous_entry.cc(1255)] Could not open platform files for entry.
[1:1:0713/010930.499263:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:1_chrome-search://local-ntp/
[1:1:0713/010931.212372:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010931.213957:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5937:5937:0713/010931.542112:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:1_chrome-search://local-ntp/, chrome-search://local-ntp/, 1
[5937:5937:0713/010931.542183:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 1, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/010931.700214:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010931.807395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/010931.807600:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010931.813020:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , , if (window.chrome &&    window.chrome.embeddedSearch &&    window.chrome.embeddedSearch.newTabPage &
[1:1:0713/010931.813185:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010931.845646:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010931.845812:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010931.996569:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 357, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010931.999080:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , , // Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/010931.999228:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010932.010983:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 358, "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010932.013965:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , , // Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed 
[1:1:0713/010932.014103:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010932.017767:INFO:html_tree_builder.cc(780)] >>> [renderer][DOM] receive <iframe>
[5937:5937:0713/010932.018441:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[5937:5937:0713/010932.020933:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: , 3, 2, 
[1:1:0713/010932.019510:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xeda8a4bde20
[1:1:0713/010932.021131:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[5937:5937:0713/010932.033836:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:3_chrome-search://local-ntp/, chrome-search://local-ntp/, 2
[5937:5937:0713/010932.033916:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 2, 3, chrome-search://local-ntp/, chrome-search://local-ntp
[1:1:0713/010932.053229:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010932.355590:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 418 0x7f402eae52e0 0xeda8a6ce060 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010932.356255:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , , var configData = {"googleBaseUrl":"https://www.google.com.hk/","isAccessibleBrowser":false,"isGoogle
[1:1:0713/010932.356422:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010932.356985:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5937:5937:0713/010932.381683:INFO:render_frame_host_impl.cc(1417)] 	 enter RenderFrameHostImpl::OnCreateChildFrame
[1:1:0713/010932.382774:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 4, 0xeda8a4be820
[1:1:0713/010932.382946:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 4
[5937:5937:0713/010932.384208:INFO:frame_tree.cc(218)] 	 enter FrameTree::AddFrame: mv-single, 4, 3, 
[1:1:0713/010932.389753:INFO:render_frame_impl.cc(7018)] >>> [renderer][DOM] RenderFrameImpl::BeginNavigation
[1:1:0713/010932.389964:INFO:render_frame_impl.cc(7019)] 	 [url] = chrome-search://local-ntp
[5937:5937:0713/010932.391127:INFO:render_frame_host_impl.cc(3108)] >>> [broswer][navigation] RenderFrameHostImpl::BeginNavigation. ID from switcher is 4:1_chrome-search://local-ntp/
[5937:5937:0713/010932.395190:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5937:5937:0713/010932.395584:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5937:5948:0713/010932.399977:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 4, 4
[5937:5948:0713/010932.400030:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 4, 4, HandleIncomingMessage, HandleIncomingMessage
[5937:5937:0713/010932.400051:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation chrome-search://most-visited/
[5937:5937:0713/010932.400090:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page, 3
[5937:5937:0713/010932.400150:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 4:4_chrome-search://most-visited/, HTTP/1.1 200 OK Content-Security-Policy: script-src chrome://resources 'self' 'unsafe-eval';object-src 'none';child-src 'none'; Cache-Control: no-cache  ,5990, 4
[1:7:0713/010932.401602:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010932.664321:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 4:4_chrome-search://most-visited/
[1:1:0713/010932.785718:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 465 0x7f402eae52e0 0xeda8a7369e0 , "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010932.786300:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , , var ddl = {"image":null,"metadata":null,"usable":true,"v":1};
[1:1:0713/010932.786443:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010932.786863:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[5937:5937:0713/010932.946295:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 4, 4:4_chrome-search://most-visited/, chrome-search://most-visited/, 3
[5937:5937:0713/010932.946365:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 3, 4, chrome-search://most-visited/, chrome-search://most-visited
[1:1:0713/010932.958003:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[5937:5937:0713/010933.079373:INFO:render_process_host_impl.cc(1626)] >>> RenderProcessHostImpl::Init. cid = 5
[5937:5967:0713/010933.079676:INFO:zygote_communication_linux.cc(115)] >>> ZygoteCommunication::ForkRequest. cid is 5
[3:3:0713/010933.079802:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 0
[3:3:0713/010933.079947:INFO:zygote_linux.cc(693)] >>> [Setup] Zygote begins to fork a new process
[3:3:0713/010933.080142:INFO:zygote_linux.cc(626)] 	Zygote::ReadArgsAndFork. begin to read cid
[3:3:0713/010933.080224:INFO:zygote_linux.cc(633)] 		cid is 5
[1:1:0713/010933.082487:INFO:switcher_impl.cc(197)] >>> [INFO] key id[0] is 0x32442c29, 1
[1:1:0713/010933.082694:INFO:switcher_impl.cc(197)] >>> [INFO] key id[1] is 0x7719ed4, 0
[1:1:0713/010933.082847:INFO:switcher_impl.cc(197)] >>> [INFO] key id[2] is 0x1105ca5d, 3
[1:1:0713/010933.082963:INFO:switcher_impl.cc(197)] >>> [INFO] key id[3] is 0x2f247db9, 2
[1:1:0713/010933.083059:INFO:switcher_impl.cc(207)] >>> [INIT] [key for HMAC, sizeof(metadata), cid] = ffffffd4ffffff9e7107 292c4432 ffffffb97d242f 5dffffffca0511 , 10104, 5
[1:1:0713/010933.083773:INFO:switcher_wrapper.cc(54)] ### [Switcher][signal] --install signal
[5937:5967:0713/010933.083927:INFO:zygote_communication_linux.cc(157)] >>> [INIT] [n, buf] = 26, CHILD_PINGԞq),D2�}$/]�z�C,
[5937:5967:0713/010933.083966:INFO:zygote_communication_linux.cc(164)] >>> [INIT] key for HMAC is Ԟq),D2�}$/]���z�C,
[1:1:0713/010933.083928:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f40430bc0a0, 3
[5937:5967:0713/010933.084094:INFO:switcher_host_impl.cc(95)] >>> [Key] add a new renderer process. [pid, cid, key] = 6033, 5, d49e7107 292c4432 b97d242f 5dca0511 
[1:1:0713/010933.084083:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f4043248080, 2
[1:1:0713/010933.084189:INFO:switcher_impl.cc(275)] >>> [INIT] try to add handler, addr, type, num = 0x7f402cf0ad20, -2
[1:1:0713/010933.093436:INFO:sandbox_bpf.cc(155)] >>> [sandbox] prepare to start sandbox [pid]=1
[1:1:0713/010933.093675:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f247db9
[1:1:0713/010933.093849:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f247db9
[1:1:0713/010933.094118:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f247db9
[1:1:0713/010933.094623:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.094724:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.094819:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.094914:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.095173:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f247db9
[1:1:0713/010933.095302:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4044e827ba
[1:1:0713/010933.095379:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4044e79def, 7f4044e8277a, 7f4044e840cf
[1:1:0713/010933.097097:INFO:syscall_parameters_restrictions.cc(259)] >>> [Seccomp] mprotect: r9 must equal 2f247db9
[1:1:0713/010933.097276:INFO:baseline_policy.cc(168)] === [Seccomp] rt_sigprocmask: r9 must equal 2f247db9
[1:1:0713/010933.097577:INFO:syscall_parameters_restrictions.cc(158)] === [Seccomp] clone: r9 must equal 2f247db9
[1:1:0713/010933.098363:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.098500:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.098614:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.098729:INFO:baseline_policy.cc(178)] === [Seccomp] fxattr: r9 must equal 2f247db9
[1:1:0713/010933.099240:INFO:syscall_parameters_restrictions.cc(321)] === [Seccomp] tgkill: r9 must equal 2f247db9
[1:1:0713/010933.099433:INFO:switcher_clone.cc(775)] clone wrapper rip is 7f4044e827ba
[1:1:0713/010933.099518:INFO:baseline_policy.cc(145)] ### [Setup] the addr for request_key should be 7f4044e79def, 7f4044e8277a, 7f4044e840cf
[1:1:0713/010933.102194:INFO:sandbox_bpf.cc(236)] === [Seccomp] clear secret now
[1:1:0713/010933.103985:INFO:sandbox_bpf.cc(274)] >>> [Setup] test the sigprocmask.
[1:1:0713/010933.104085:INFO:sandbox_bpf.cc(278)] >>> [Setup] prepare to invoke sigprocmask(1, 0x7ffe4d5f9a28, 0x7ffe4d5f99a8)
[1:1:0713/010933.110512:INFO:partitions.cc(74)] >>> [Partition] Partitions::Initialize
[1:1:0713/010933.111430:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010933.112441:INFO:v8_initializer.cc(584)] >>> [V8] V8Initializer::InitializeMainThread
[1:1:0713/010933.208448:INFO:render_frame_impl.cc(1477)] 	RenderFrameImpl::Initialize. 3, 0xeda8a490220
[1:1:0713/010933.208644:INFO:web_local_frame_impl.cc(1666)] 		WebLocalFrame::SetRoutingID. routing_id = 3
[1:1:0713/010933.402647:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010933.402839:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[5937:5937:0713/010933.445462:INFO:navigation_url_loader_network_service.cc(1293)] 	 enter NavigationURLLoaderNetworkService::OnReceiveResponse
[5937:5937:0713/010933.447334:INFO:navigation_handle_impl.cc(765)] 	 enter NavigationHandleImpl::WillProcessResponse
[5937:5937:0713/010933.466446:INFO:render_frame_host_impl.cc(3699)] >>> RenderFrameHostImpl::CommitNavigation http://corp.caixin.com/
[5937:5937:0713/010933.466505:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://corp.caixin.com/, http://corp.caixin.com/joinus/, 1
[5937:5937:0713/010933.466566:INFO:render_frame_host_impl.cc(3718)] >>>	[site, common.url, headers] = 5:3_http://corp.caixin.com/, HTTP/1.1 200 OK Date: Fri, 12 Jul 2019 17:06:08 GMT Content-Type: text/html; charset=UTF-8 Transfer-Encoding: chunked Connection: keep-alive Vary: Accept-Encoding Content-Encoding: gzip  ,6033, 5
[5937:5948:0713/010933.466663:INFO:interface_endpoint_client.cc(447)] >>> [Frame] get kURLLoader_ProceedWithResponse_Name. [pid, routing_id] = 5, 3
[5937:5948:0713/010933.466714:INFO:mojo_async_resource_handler.cc(459)] >>> [IPC] MojoAsyncResourceHandler::ProceedWithResponse konws [cid, routing_id]: 5, 3, HandleIncomingMessage, HandleIncomingMessage
[1:7:0713/010933.467233:INFO:ipc_mojo_bootstrap.cc(809)] >>> [IPC] Accept. post a task to AcceptOnProxyThread
[1:1:0713/010933.482186:INFO:ipc_mojo_bootstrap.cc(894)] ### [Switcher][kFrameNavigationControl_CommitNavigation_Name] get additional field: 5:3_http://corp.caixin.com/
[5937:5937:0713/010933.541048:INFO:switcher_host_impl.cc(127)] >>> [Key] add a new principal. [cid, principal, url, frame_id] = 5, 5:3_http://corp.caixin.com/, http://corp.caixin.com/, 1
[5937:5937:0713/010933.541110:INFO:frame_tree_node.cc(349)] 	FrameTreeNode::SetCurrentOrigin. [frameid, routingid, origin, url] = 1, 3, http://corp.caixin.com/, http://corp.caixin.com
[1:1:0713/010933.553092:INFO:html_document_parser.cc(1203)]  $$$ [TASK] HTMLDocumentParser::AppendBytes -> BackgroundHTMLParser::AppendRawBytesFromMainThread
[1:1:0713/010933.566680:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 540, "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010933.568409:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:4_chrome-search://most-visited/, 04a1054ee5b8, , , /* Copyright 2015 The Chromium Authors. All rights reserved.
 * Use of this source code is governed 
[1:1:0713/010933.568591:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page", "most-visited", 4, 1, chrome-search://local-ntp, local-ntp, 1
[1:1:0713/010933.571113:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "chrome-search://most-visited/single.html?removeTooltip=Don%27t%20show%20on%20this%20page"
[1:1:0713/010933.593110:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010933.625790:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010933.625989:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://corp.caixin.com/joinus/"
[1:1:0713/010933.745776:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "chrome-search://local-ntp/local-ntp.html"
[1:1:0713/010933.746207:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -4:1_chrome-search://local-ntp/, 04a1053c1f78, , iframe.onload, () {
    reloadTiles();
    sendThemeInfoToMostVisitedIframe();
  }
[1:1:0713/010933.746333:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "chrome-search://local-ntp/local-ntp.html", "local-ntp", 1, 1, , , 0
[1:1:0713/010933.790856:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010933.874549:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f402cf25bd0 0xeda8a5a6358 , "http://corp.caixin.com/joinus/"
[1:1:0713/010933.879716:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , /*! jQuery v1.7.2 jquery.com | jquery.org/license */
(function(a,b){function cy(a){return f.isWindow
[1:1:0713/010933.879922:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010933.881769:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[1:1:0713/010933.978894:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f402cf25bd0 0xeda8a5a6358 , "http://corp.caixin.com/joinus/"
[1:1:0713/010933.983315:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 174 0x7f402cf25bd0 0xeda8a5a6358 , "http://corp.caixin.com/joinus/"
[1:1:0713/010934.769607:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7f4043248080 0xeda8a4751a0 1 0 0xeda8a4751b8 , "http://corp.caixin.com/joinus/"
[1:1:0713/010934.770733:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , /*

*设置cookie值

*/

function SetCookieValue(_Name,_Value,_Expires,_Type){

  var _LargeExpDate
[1:1:0713/010934.770906:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010934.773111:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7f4043248080 0xeda8a4751a0 1 0 0xeda8a4751b8 , "http://corp.caixin.com/joinus/"
[1:1:0713/010934.775989:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 211 0x7f4043248080 0xeda8a4751a0 1 0 0xeda8a4751b8 , "http://corp.caixin.com/joinus/"
[1:1:0713/010934.967281:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 245 0x7f402cbbd070 0xeda8a4c62e0 , "http://corp.caixin.com/joinus/"
[1:1:0713/010934.968232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , document.writeln("<scr" + "ipt type='text/javascript' src='http://file.caixin.com/webjs/content/base
[1:1:0713/010934.968427:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010935.067487:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 254 0x7f4043248080 0xeda8a5fd920 1 0 0xeda8a5fd938 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.068514:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; 
var bas
[1:1:0713/010935.068687:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010935.079512:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010935.095869:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010935.096049:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://corp.caixin.com/joinus/"
[1:1:0713/010935.097311:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f402cbbd070 0xeda8a545260 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.098477:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , var hexcase=0;function hex_md5(a){ if(a=="") return a; return rstr2hex(rstr_md5(str2rstr_utf8(a)))}f
[1:1:0713/010935.098642:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010935.118276:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 258 0x7f402cbbd070 0xeda8a545260 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.178233:INFO:html_parser_scheduler.cc(143)]  		HTMLParserScheduler::YieldIfNeeded. 0.08219, 493, 1
[1:1:0713/010935.178448:INFO:html_parser_scheduler.cc(81)]  $$$ [TASK] HTMLParserScheduler::ScheduleForUnpause -> HTMLParserScheduler::ContinueParsing
[1:1:0713/010935.275199:INFO:html_parser_scheduler.cc(158)]  $$$ [TASK] HTMLParserScheduler::ContinueParsing
[1:1:0713/010935.275405:INFO:html_document_parser.cc(272)] >>> HTMLDocumentParser::ResumeParsingAfterYield. url is "http://corp.caixin.com/joinus/"
[1:1:0713/010935.276815:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.278042:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , var mapCode = [[
	{url:"http://www.caixin.com",title:"首页"},
	{url:"http://economy.caixin.com/"
[1:1:0713/010935.278187:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010935.303551:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.307389:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.322226:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.364124:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.372560:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.376486:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.388207:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 279 0x7f402cbbd070 0xeda8a7c1b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010935.393283:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://corp.caixin.com/joinus/"
[1:1:0713/010935.909103:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 5000
[1:1:0713/010935.909417:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://corp.caixin.com/, 375
[1:1:0713/010935.909549:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 375 0x7f402cbbd070 0xeda8a92dc60 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 279 0x7f402cbbd070 0xeda8a7c1b60 
[1:1:0713/010935.989387:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3a740fea29c8, 0xeda8a0a0440
[1:1:0713/010935.989570:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 0
[1:1:0713/010935.989760:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 377
[1:1:0713/010935.989884:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 377 0x7f402cbbd070 0xeda8a8d5be0 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 279 0x7f402cbbd070 0xeda8a7c1b60 
[1:1:0713/010936.000168:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3a740fea29c8, 0xeda8a0a0440
[1:1:0713/010936.000310:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 0
[1:1:0713/010936.000490:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 378
[1:1:0713/010936.000611:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 378 0x7f402cbbd070 0xeda8a851560 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 279 0x7f402cbbd070 0xeda8a7c1b60 
[1:1:0713/010936.050280:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "DOMContentLoaded", "http://corp.caixin.com/joinus/"
[1:1:0713/010936.210205:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: net::ERR_NAME_NOT_RESOLVED","http://static1.bfdcdn.com/service/caixingwang/caixingwang.js"
[1:1:0713/010936.667563:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 377, 7f402f502881
[1:1:0713/010936.673471:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"279 0x7f402cbbd070 0xeda8a7c1b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010936.673815:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"279 0x7f402cbbd070 0xeda8a7c1b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010936.674153:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010936.674538:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){}
[1:1:0713/010936.674693:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010936.682863:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 378, 7f402f502881
[1:1:0713/010936.689182:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"279 0x7f402cbbd070 0xeda8a7c1b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010936.689340:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"279 0x7f402cbbd070 0xeda8a7c1b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010936.689506:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010936.689774:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){}
[1:1:0713/010936.689889:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010936.801952:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 401 0x7f402eae52e0 0xeda8a8d5960 , "http://corp.caixin.com/joinus/"
[1:1:0713/010936.803763:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , 
// Copyright 2012 Google Inc. All rights reserved.
(function(){

var data = {
"resource": {
  "vers
[1:1:0713/010936.803904:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010936.813278:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3a740fea29c8, 0xeda8a0a0190
[1:1:0713/010936.813424:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 0
[1:1:0713/010936.813618:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 440
[1:1:0713/010936.813743:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 440 0x7f402cbbd070 0xeda8a8c2260 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 401 0x7f402eae52e0 0xeda8a8d5960 
[1:1:0713/010936.814150:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3a740fea29c8, 0xeda8a0a0190
[1:1:0713/010936.814261:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 0
[1:1:0713/010936.814424:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 441
[1:1:0713/010936.814542:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 441 0x7f402cbbd070 0xeda8a7c19e0 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 401 0x7f402eae52e0 0xeda8a8d5960 
[1:1:0713/010936.858206:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 409 0x7f402eae52e0 0xeda8a8d52e0 , "http://corp.caixin.com/joinus/"
[1:1:0713/010936.859418:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , !function(t,e){function i(t){for(var e;e=t.shift();)e()}function n(){p.loading=1;var n,o="";try{n=t.
[1:1:0713/010936.859561:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010936.876148:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 410 0x7f402eae52e0 0xeda8a86fce0 , "http://corp.caixin.com/joinus/"
[1:1:0713/010936.878419:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , /**/jQuery1720045720986257136165_1562951373956({"code":0,"msg":"SUCCESS","data":{"begins":{"A":[{"co
[1:1:0713/010936.878564:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010936.884054:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://corp.caixin.com/joinus/"
[1:1:0713/010936.928991:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 414 0x7f402eae52e0 0xeda8a839660 , "http://corp.caixin.com/joinus/"
[1:1:0713/010936.931006:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (function(){var k=this||self,l=function(a,b){a=a.split(".");var c=k;a[0]in c||"undefined"==typeof c.
[1:1:0713/010936.931156:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010937.167798:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 415 0x7f402eae52e0 0xeda8a7b0b60 , "http://corp.caixin.com/joinus/"
[1:1:0713/010937.171141:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , !function t(e,r,i){function n(s,a){if(!r[s]){if(!e[s]){var u="function"==typeof require&&require;if(
[1:1:0713/010937.171327:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010938.454621:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
[5937:5937:0713/010953.079697:INFO:CONSOLE(1)] "Uncaught TypeError: Cannot read property 'top' of null", source: http://file.caixin.com/webchannel/all/js/dist/channel.js (1)
[3:3:0713/010953.107500:INFO:zygote_linux.cc(266)] >>> [Setup] Zygote receive a msg: 1
[1:1:0713/010953.367015:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 1500, 0x3a740fea29c8, 0xeda8a0a0280
[1:1:0713/010953.367194:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 1500
[1:1:0713/010953.367379:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 528
[1:1:0713/010953.367495:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 528 0x7f402cbbd070 0xeda8a86ee60 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 415 0x7f402eae52e0 0xeda8a7b0b60 
[1:1:0713/010953.522639:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 440, 7f402f502881
[1:1:0713/010953.531661:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"401 0x7f402eae52e0 0xeda8a8d5960 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010953.531888:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"401 0x7f402eae52e0 0xeda8a8d5960 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010953.532083:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010953.532395:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , of, (){var a=nf();try{var b=yc.h,c=v["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;fo
[1:1:0713/010953.532543:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010953.572076:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 440 0x7f402cbbd070 0xeda8a8c2260 , "http://corp.caixin.com/joinus/"
[1:1:0713/010953.579956:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 441, 7f402f502881
[1:1:0713/010953.589526:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"401 0x7f402eae52e0 0xeda8a8d5960 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010953.589735:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"401 0x7f402eae52e0 0xeda8a8d5960 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010953.589928:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010953.590232:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))}
[1:1:0713/010953.590342:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.166281:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.166690:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0713/010954.166817:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.167238:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.168447:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.170565:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 300, 0x3a740fea29c8, 0xeda8a0a0210
[1:1:0713/010954.170723:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 300
[1:1:0713/010954.171079:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 550
[1:1:0713/010954.171211:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 550 0x7f402cbbd070 0xeda8adfbbe0 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 499
[1:1:0713/010954.211051:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.211425:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0713/010954.211536:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.211948:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.229979:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , "use strict";(function(InjectedScriptHost,inspectedGlobalObject,injectedScriptId){function push(arra
[1:1:0713/010954.230166:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.554707:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.555077:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , i.onreadystatechange, (){return 4===i.readyState?"function"==typeof e?e(i):void 0:"function"==typeof r?r(i):void 0}
[1:1:0713/010954.555191:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.555419:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.556739:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010954.581075:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://corp.caixin.com/, 375, 7f402f5028db
[1:1:0713/010954.589842:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"279 0x7f402cbbd070 0xeda8a7c1b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010954.590127:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"279 0x7f402cbbd070 0xeda8a7c1b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010954.590435:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://corp.caixin.com/, 579
[1:1:0713/010954.590551:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 579 0x7f402cbbd070 0xeda8aa2c860 , 5:3_http://corp.caixin.com/, 0, , 375 0x7f402cbbd070 0xeda8a92dc60 
[1:1:0713/010954.590698:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010954.591172:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , showAuto()
[1:1:0713/010954.591252:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.649317:INFO:console_message.cc(26)] >>> [renderer][DOM] ConsoleMessage::CreateForRequest: [msg, url] = "Failed to load resource: the server responded with a status of 502 (Bad Gateway)","https://www.qipus.cn/cmp/cmp.api?r=&s=5004&u=http%3A%2F%2Fcorp.caixin.com%2Fjoinus%2F"
[1:1:0713/010954.671252:INFO:script_loader.cc(852)]  $$$ [Script] ScriptLoader::ExecuteScriptBlock. task_id, url is 544 0x7f402eae52e0 0xeda8a8773e0 , "http://corp.caixin.com/joinus/"
[1:1:0713/010954.671745:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , _1UUPQ('CLAnatI5Al0pHgsbR1XsgQA')
[1:1:0713/010954.671863:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010954.798739:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , document.readyState
[1:1:0713/010954.798932:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.029384:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 550, 7f402f502881
[1:1:0713/010955.039523:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"499","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.039741:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"499","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.039940:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010955.040258:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){return r.sendPV(t,e)}
[1:1:0713/010955.040361:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.247984:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.248432:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , d.onload.d.onerror, (){d.onload=null;d.onerror=null;c()}
[1:1:0713/010955.248574:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.249684:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.250004:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.250808:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.251311:INFO:dom_window_timers.cc(97)] $$$ [Timeout] setTimeout. [script_state, execution_context] = 0, 0x3a740fea29c8, 0xeda8a0a01f0
[1:1:0713/010955.251407:INFO:dom_timer.cc(67)]  $$$ [Timeout] DOMTimer::Install. context is: "http://corp.caixin.com/joinus/", 0
[1:1:0713/010955.251576:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 624
[1:1:0713/010955.251670:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 624 0x7f402cbbd070 0xeda8b4911e0 , 5:3_http://corp.caixin.com/, 1, -5:3_http://corp.caixin.com/, 586 0x7f402cbbd070 0xeda8b14f060 
[1:1:0713/010955.251857:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "load", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.309281:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , document.readyState
[1:1:0713/010955.309441:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.365282:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 528, 7f402f502881
[1:1:0713/010955.373278:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"415 0x7f402eae52e0 0xeda8a7b0b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.373415:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"415 0x7f402eae52e0 0xeda8a7b0b60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.373570:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010955.373852:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){return t.registerDomObserver()}
[1:1:0713/010955.373963:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.666651:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.667064:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){return 4===u.readyState&&(""!==o&&(t.sendVisitTimeout-=300),t.removeAjax(u),window.grWaitTime=+Da
[1:1:0713/010955.667184:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.667404:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "readystatechange", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.690139:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:108, 5:3_http://corp.caixin.com/, 624, 7f402f502881
[1:1:0713/010955.700958:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"06a870722860","ptid":"586 0x7f402cbbd070 0xeda8b14f060 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.701191:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"-5:3_http://corp.caixin.com/","ptid":"586 0x7f402cbbd070 0xeda8b14f060 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.701355:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010955.701617:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))}
[1:1:0713/010955.701703:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.783690:INFO:event_target.cc(828)] >>> [Listener] EventTarget::FireEventListeners. [event, url] = "resize", "http://corp.caixin.com/joinus/"
[1:1:0713/010955.784071:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , (){+new Date-i>t&&(i=+new Date,e())}
[1:1:0713/010955.784176:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010955.946642:INFO:task_annotator.cc(107)] >>> [Timeout] run task: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://corp.caixin.com/, 579, 7f402f5028db
[1:1:0713/010955.955772:INFO:switcher_impl.cc(1728)] #### [CurTask] BY VA -> {"fc":"","gpfc":"","ptid":"375 0x7f402cbbd070 0xeda8a92dc60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.955930:INFO:switcher_impl.cc(1767)] #### [CurTask] BY ID -> {"fc":"","gpfc":"","ptid":"375 0x7f402cbbd070 0xeda8a92dc60 ","rf":"5:3_http://corp.caixin.com/"}
[1:1:0713/010955.956105:INFO:thread_controller_impl.cc(154)] >>> [Timeout] ThreadControllerImpl::DidQueueTask: DOMTimer@../../third_party/blink/renderer/core/frame/dom_timer.cc:110, 5:3_http://corp.caixin.com/, 657
[1:1:0713/010955.956228:INFO:switcher_impl.cc(662)] 	Record a new Task for DOMTimer [task, root_frame, num, frame_chain, parentTID] = 657 0x7f402cbbd070 0xeda8a545de0 , 5:3_http://corp.caixin.com/, 0, , 579 0x7f402cbbd070 0xeda8aa2c860 
[1:1:0713/010955.956371:INFO:dom_timer.cc(165)]  $$$ [Timeout] DOMTimer::Fired(). context is: "http://corp.caixin.com/joinus/"
[1:1:0713/010955.956664:INFO:switcher_impl.cc(1427)] 		updated frame chain: [num, frameChain, subject, last, function_name, source_code] = 1, -5:3_http://corp.caixin.com/, 06a870722860, , , showAuto()
[1:1:0713/010955.956736:INFO:binding_security.cc(230)] 	metadata is [subject_url, domain, routing_id, frame_chain_length, parent_origin, parent_domain, parent_routing_id] = "http://corp.caixin.com/joinus/", "corp.caixin.com", 3, 1, , , 0
[1:1:0713/010956.004985:INFO:platform_thread_posix.cc(131)] >>> invoke pthread_create
